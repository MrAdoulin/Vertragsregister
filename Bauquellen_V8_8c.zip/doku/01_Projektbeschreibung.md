# Projektbeschreibung Vertragsregister

## 1. Zweck

Ein Freund von Nico verwaltet Verträge, Leistungen und Rechnungen. [GESAGT: Nico, 08.10.2026]
Er hat nur Windows, LibreOffice und ein lokales Qwen ohne Dateizugriff.
Das Ziel ist: den richtigen und letztgültigen Vertrag schnell finden, Fristen nicht verpassen, Leistungen und Rechnungen prüfen.

Nico baut das Register für ihn. Nico testet auf seinem PC (Windows, LibreOffice 26.2, Bildschirm 1920×991, Gerätename „flash“).
Claude baut in einer Linux-Sandbox (LibreOffice 24.2.7, Xvfb) und testet dort automatisch.

## 2. Geschichte in Kürze

| Datum | Stand | Inhalt |
|---|---|---|
| 08.10. | AP1–AP3 (Calc) | Vorlage `.ods`: Fristen, Leistungen, Übersicht, Vertretung, Notes-Termine (`.ics`) |
| 13.10. | B1 / B1.1 | Neuauftrag: gleiche Logik als LibreOffice Base (Calc war „zerbrechlich und unintuitiv“). Klick-Prototyp mit Einzelformularen |
| 13./14.10. | V8 | Umbau zur **Ein-Fenster-Anwendung** mit allen Bereichen (B2 Leistungen/Protokoll, B3 Notes/Abgleich/Sicherung, B4 Änderungsspur/Vertretung/Anleitung) |
| 14.10. | V8.1 (a–c) | Windows-Test-Fehler, Vertragsnummer, Fenster, Papierkorb, Sicherung, „Fehler/Wunsch melden“ |
| 14./15.10. | V8.2a–c | Ampel und rote Markierung am Lösungsort, „H“-Knopf (heute), Sichern-Knöpfe grau, Tooltips |
| 15.10. | V8.3 | „Ersetzt Vertrag“ mit Links, Partner in zwei Listen, diverse Meldungen |
| 15.10. | V8.4 | Storno-Zeile, volle Fensterbreite, Partner-Stand, Datumsformat, Textordner je Datei |
| 15.10. | V8.5 / V8.5b | Meldungen Q1–Q8, Gesamtsuche, Auswahllisten-Leiste, Markierungsspalte links, Kleinpunkte |
| 16.10. | V8.6 / V8.6b | Ablage-Vorschlag als Link (N14), Statistik als Calc-Pivot (N16), Umbenennung Ereignisarten (N20), Layoutprüfung, Statistik- und Korrigieren-Korrektur |

Details: `03_Auftragslog.md` und `logs/Session-Log_2026-10-08_Vertragsregister.md`.

## 3. Architektur

- **Eine Datei:** `Vertragsregister_v8_6b.odb` = LibreOffice-Base-Dokument mit eingebetteter **Firebird**-Datenbank (kein Java nötig), einem Formulardokument „Vertragsregister“ und der Basic-Bibliothek mit Modul `App`.
- **Ein Fenster:** Das Formular enthält alle Ansichten als Bereiche. Ein Wechsel blendet Steuerelemente über `EnableVisible` am Modell ein und aus und tauscht die Seitenvorlage (Hintergrund-Kartenbild) je Bereich.
- **Makros sind Pflicht.** Ohne Makros bleibt nur der Notweg: Tabellen direkt im Base-Fenster plus Anleitung. [GESAGT: Nico 13.10. 21:32, Option „ein Fenster“, nicht notfallfähig ohne Makro]
- **Speichern:** Daten der eingebetteten DB stehen erst nach dem Speichern der `.odb` in der Datei. Die Makros speichern die `.odb` nach jedem gesicherten Datensatz.
- **Gebaut, nicht gezeichnet:** Die `.odb` entsteht vollständig per Skript (`build_base.py`). Nichts wird von Hand in der .odb geändert. Jede Änderung geht in die Quellen und dann in einen Neubau.

### Bauweg

```
python3 build_base.py <ziel.odb> [--ohne-beispiele] [--start=XX] [--ohne-makros]
```

1. `db_build.py` legt Firebird-Tabellen, Trigger, Sichten, Auswahllisten und Beispieldaten an (Definitionen in `schema.py`).
2. `forms_def.py` beschreibt alle Bereiche und Steuerelemente; `formkit.py` ist der Baukasten (Karten, Raster, Knöpfe, „H“-Knöpfe, Seitenvorlagen).
3. `app/*.bas` werden zu einem Modul `App` verbunden und eingebettet (Konstanten wie `FORMBEREICHE` erzeugt der Bau).
4. `tooltips.py` füllt Tooltips, `anleitung.py` liefert die Hilfetexte.
5. `odb_patch.py` bearbeitet die fertige zip-Datei nach (z. B. Ausrichtung).
6. Der Bau meldet Warnungen, z. B. `Beschriftung neben H zu lang`.

## 4. Bereiche (Ansichten)

Jedes Steuerelement heißt `<Bereich>_<Name>`, z. B. `LI_txtSuche`. `NA` ist immer sichtbar.

| Kürzel | Ansicht |
|---|---|
| NA | Seitenleiste: Navigation, „Suche überall“, Beenden, Melden (Käfer), Einstellungen (Zahnrad) |
| ST | Übersicht: Kacheln, Aufgaben, Fristen, Export, Notes-Export, Statistik |
| LI | Verträge (Liste mit Suche, „Neuer Vertrag“) |
| VE1 / VE2 / VE3 | Vertrag: Stammdaten + Entscheidung · Leistungen & Protokoll · Dokumente & Verlauf |
| LE | Leistungen (alle Verträge) |
| PR | Protokoll & Rechnungen (Ereignisse: Leistungsanfall, Leistung erbracht, Rechnung erhalten, Reklamation) |
| PA | Partner (zwei Listen: mit laufendem Vertrag / ohne) |
| VT1 / VT2 | Vertretung |
| AE | Änderungen (Änderungsspur) |
| AB | Ablage prüfen (Abgleich Ordner ↔ Register, Vorschlag als Link) |
| GS | Suche überall (Treffer, Vorschau mit fettem Treffer) |
| PK | Papierkorb & Sicherung |
| EI | Einstellungen (Ablagepfad, Sicherung, Datumsformat, Auswahllisten) |
| HI | Hilfe (Anleitung) |

## 5. Datenmodell (Firebird, `schema.py`)

Tabellen: `Partner`, `Vertrag`, `Entscheidung`, `Dokument`, `Leistung`, `Ereignis` (Protokoll), `Liste` (Auswahllisten), `Einstellung`, `Aenderung` (Spur), `Vertretung`, `VertretungPunkt`, `AbgleichBefund`, `Treffer` (Suche, Arbeitstabelle), `PK_Verweis` (Papierkorb-Verweise), `R_Vergleich`.

Sichten (Auswahl): `V_Vertrag1..5`/`V_Vertrag` (Fristen, Stichtag, Ampel), `V_Leistung1..3`/`V_Leistung` (Zuletzt, Nächste, Hinweis), `V_Ereignis1..2`/`V_Ereignis` (Reaktionszeit, Kostengrenze, Prüfergebnis), `V_HeuteListe`, `V_Aufgaben`, `V_Fristen`, `V_Kennzahlen`, `V_NotesTermine`, `V_AenderungListe`, `V_Papierkorb`, `V_PartnerStand`, `V_Vertretung`.

Trigger:
- `TS_<Tabelle>`: Änderungsspur je Feld (alt/neu), Benutzer aus Kontextvariable `BENUTZER`; `KEINE_SPUR` schaltet ab.
- `TP_Vertrag_Verweis`, `TL_Leistung_Ctx`: Papierkorb und Spur bei kaskadiertem Löschen.
- CHECK-Regeln als Rückhalt hinter den Formularprüfungen.

## 6. Basic-Module (`app/`)

| Modul | Inhalt |
|---|---|
| 01_kern | Start, Bereichswechsel, `Spaeter()` (AsyncCallback-Warteschlange), `AppDoc()`, Speichern, Prüfungen, VERSION |
| 02_vertrag | Übersicht, Vertragsliste, Vertrag, Entscheidung |
| 03_leistung | Leistungen, „Heute erbracht“, Protokoll |
| 04_b3 | Notes-Termine (.ics), Ablage prüfen (Abgleich), Export |
| 05_sicherung | Papierkorb, Textsicherung (CSV), .odb-Sicherung, Textordner |
| 06_melden | „Fehler/Wunsch melden“: Dialog, PNG-Export, Eintrag in `Meldungen/meldungen.txt` |
| 07_markieren | rote Markierung am Lösungsort |
| 08_heute | „H“-Knöpfe neben Datumsfeldern |
| 09_sichern | Sichern-Knöpfe grau, solange nichts geändert ist |
| 10_verknuepfung | „Ersetzt Vertrag“ mit Links in beide Richtungen |
| 11_partnerlisten | Partner in zwei Listen |
| 12_storno | Storno, „Korrigieren“ |
| 13_breite | Seite füllt Fensterbreite, `BreiteMerken`/`LageHerstellen` |
| 14_partnerstand | Kontaktdaten mit „(Stand: Datum)“ |
| 15_datumformat | einstellbares Datumsformat |
| 16_listen | Auswahllisten-Knopfleiste |
| 17_suche | Gesamtsuche |
| 18_statistik | Statistik als Calc-Datei mit Pivot und Diagramm |

## 7. Ablage und Dateien beim Freund

- Ablagepfad (Einstellung, Beispiel `Z:\Verträge\`): Ordner je Vertrag, Namensregel siehe Hilfe › Ablage. „Ablage prüfen“ vergleicht Ordner und Register.
- Neben der `.odb` legt das Register an: `Export/`, `Sicherung/`, `Text/` bzw. `Text_<name>/`, `Meldungen/`.
- Notes: Export als `.ics` mit fester UID je Termin (Import in HCL Notes).

## 8. Fachregeln (Kurzfassung, Details im Entscheidungsregister)

- Stichtag: Rückrechnung vorsichtig, gleicher Monatstag wie Vertragsende (im Zweifel früher). Rechtliche Richtigkeit [UNBEKANNT].
- Automatische Verlängerung: Laufzeitende wird fortgerechnet.
- Rechnung korrigiert/neu ausgestellt: alte Zeile ändern und „Korrigieren“; der alte Stand bleibt als stornierte Zeile.
- Stornierte Zeilen zählen nicht zur Kostengrenze und sind nicht offen.
- Kombi-Vertragsarten legt der Nutzer selbst über die Auswahllisten an (keine Unterarten).

## 9. Testumgebung (Sandbox, Linux)

- LibreOffice 24.2.7 mit `libreoffice-base` und `libreoffice-sdbc-firebird`, Python mit `uno`, `python3-xlib`, Xvfb.
- `xui.py` startet LibreOffice auf einem virtuellen Bildschirm und klickt über XTest. `v8ui.py` rechnet Seitenkoordinaten in Bildschirmpunkte um und bietet `mitte("NAME")`.
- `alle_tests.sh` führt alle Oberflächentests nacheinander aus, Ergebnis in `tests.log`.
- DB-Tests: `test_db_v8*.py`. Fristtest: `test_frist_db.py ../cases.xlsx ../cases3.xlsx` (die xlsx am selben Tag neu berechnen, die Erwartungswerte hängen von HEUTE ab).
- Windows-Test: per Bildschirmsteuerung auf Nicos PC, Testordner `C:\Claude Projekts\Vertragsregister-Test`.
