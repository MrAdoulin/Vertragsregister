# Entscheidungsregister Vertragsregister

Teil A fasst die geltenden Entscheidungen zusammen. Teil B enthält alle Entscheidungsstellen wörtlich aus dem Session-Log (mit Log-Zeile).
Ein entschiedener Punkt wird nicht neu gefragt, er wird zitiert. Bei Widerspruch gilt die jüngere Entscheidung; ersetzte Entscheidungen stehen in Teil B.

## Teil A – Geltende Entscheidungen (Stand 16.10.2026)

### Plattform und Grundsatz
| Nr | Entscheidung | Herkunft |
|---|---|---|
| G1 | Plattform LibreOffice Base mit eingebettetem Firebird; Browser-App verworfen; Calc-Fassung bleibt nur Referenz | [GESAGT: Nico 13.10.] |
| G2 | Ein-Fenster-Anwendung (V8), Makros Pflicht; Notweg = Tabellen im Base-Fenster + Anleitung | [GESAGT: Nico 13.10. 21:32]; Auslegung V8 Nr. 2 |
| G3 | Frischer Start ohne Import; Demodaten generiert | [GESAGT: Nico 13.10.] |
| G4 | Bau vollständig in der Cloud, danach lokaler Test auf Nicos PC | [GESAGT: Nico 13.10. 21:32] |
| G5 | Navigation über feste Seitenleiste links | Auslegung V8 Nr. 1, nicht widersprochen |
| G6 | Ablage auf Netzlaufwerk mit einheitlichem Laufwerksbuchstaben, Vorgabe `Z:\Verträge\`; Ordner je Vertrag; Unterordner `_bearbeitbar`, `_korrespondenz` | [GESAGT: Nico 08.10.] |
| G7 | Vertragsnummer von Hand im Format `NN_NNN_NN_JJJJ` (Typ_Art_lfd_Jahr); doppelt → ablehnen, anderer Aufbau → Warnung; ersetzt V-001 überall; ohne Nummer „unbenannt n“ | [GESAGT: Nico 14.10. E2/E4/E5, 14:34] |
| G8 | Kalender HCL Notes, Export als `.ics` | [GESAGT: Nico 08.10.] |
| G9 | Änderungsspur vollständig (alt/neu, Person, Zeit) + Vertretungsübergabe | [GESAGT: Nico 08.10.] |

### Fachregeln
| Nr | Entscheidung | Herkunft |
|---|---|---|
| F1 | Stichtag: vorsichtig, gleicher Monatstag (keine Monatsletzter-Regel). Rechtliche Richtigkeit [UNBEKANNT] | [GESAGT: Nico 15.10. 22:xx, Auswahl] |
| F2 | Korrigierte/neu ausgestellte Rechnung: alte Zeile ändern und „Korrigieren“ → alter Stand als stornierte Zeile, Eintrag behält Nummer | [GESAGT: Nico 15.10., Auswahl]; Q6 |
| F3 | Stornierte Zeilen zählen nicht zur Kostengrenze und sind nicht offen; Schalter blendet sie ein/aus | E21 |
| F4 | Ereignisarten: Leistungsanfall, Leistung erbracht, Rechnung erhalten, Reklamation | [GESAGT: Nico 15.10. N20] |
| F5 | Kombi-Vertragsarten legt der Nutzer selbst in den Auswahllisten an; keine Unterarten | [GESAGT: Nico 15.10. N01] |
| F6 | Rot = dringend (diese Woche, heute, überfällig), Schwellen einstellbar: allgemein 7, Kündigung 30, Aufgaben ohne Datum 14 Tage ab Entstehung | [GESAGT: Nico 14.10. E15/E16, 18:43] |
| F7 | Markierung am Lösungsort: Rahmen + rotes „!“ mit Tooltip | [GESAGT: Nico 14.10.] |
| F8 | Reaktionszeit verfehlt = neutraler Hinweis ohne Ampel | Q5, Auslegung |
| F9 | „Heute erbracht“ legt Eintrag mit Beschreibung an, Status „Angaben ergänzen“ bis einmal gesichert | Q3, Auslegung |

### Oberfläche
| Nr | Entscheidung | Herkunft |
|---|---|---|
| U1 | Seite füllt die Fensterbreite; Mindestzoom + Rollbalken | E17, E3 |
| U2 | „H“-Knopf nur bei leeren Datumsfeldern, ohne Verschiebung von Feldern; seit V8.6 neben der Beschriftung | E19, [GESAGT: Nico 16.10. 00:11] |
| U3 | Sichern-Knöpfe grau, solange nichts geändert ist | M06 |
| U4 | Auswahllisten mit Knopfleiste „+ Neu“, „Entfernen“, „▲“, „▼“ | E22 |
| U5 | Gesamtsuche in der Seitenleiste, Vorschau mit Trefferwort fett wie in der Quelle | E23, E24, [GESAGT 18:42] |
| U6 | Raster: Markierungsspalte links in allen Rastern („Variante links“) | [GESAGT: Nico 15.10. 20:10] |
| U7 | Einfachklick markiert, Doppelklick öffnet | E26 |
| U8 | Sortierknopf im Kartenkopf der Übersicht | E25 |
| U9 | Ablage prüfen: intern = Link + Rückfrage + Aktion in der DB; extern = nur zeigen (Ordner öffnen); keine Dateiaktion durch das Register | [GESAGT: Nico 15.10. N14] |
| U10 | Statistik: Knopf erzeugt Calc-Datei mit Daten, Pivot-Tabelle und Diagramm | [GESAGT: Nico 15.10. N16] |
| U11 | „Melden“ (Fehler/Wunsch) für Nico und den Freund; einfach halten, kein Fensterfoto | E11/E12, [GESAGT 15.10. 20:15] |

### Sicherung
| Nr | Entscheidung | Herkunft |
|---|---|---|
| S1 | Sicherung automatisch ohne Rückfrage; kurze Bestätigung | E9 |
| S2 | Textsicherung: Monat voll + Tag Änderungen; 30-Tage-Schwelle statt Kalendermonat | E7, [GESAGT 14.10. 12:34] |
| S3 | Spiegel F1 + F2 + F3 | E8 |
| S4 | Papierkorb mit Zurückholen | V8.1 P4 |

### Arbeitsweise
| Nr | Entscheidung | Herkunft |
|---|---|---|
| A1 | Tests nur in `C:\Claude Projekts\Vertragsregister-Test`; Downloads nicht benutzen | [GESAGT: Nico 13.10.] |
| A2 | Keine Dateien auf Nicos PC löschen/verschieben; Testordner räumt Nico selbst auf | [GESAGT: Nico 16.10. 00:11] |
| A3 | Windows-Test: Bildschirm je Version nach Freigabe | [GESAGT: Nico] |
| A4 | Changerequests vor Bearbeitung gegen den Stand prüfen | [GESAGT: Nico 15.10. 18:45] |

## Teil B – Entscheidungsstellen wörtlich aus dem Session-Log

### Entscheidungsregister  (Log-Zeile 16)
- Format .ods [GESAGT: Angebot von Claude, bestätigt durch Nico].
- Vertragsordner verlinkt statt Einzeldatei: Ordner enthält nach Ablageregel nur geltende Dokumente; Link bleibt bei neuem Nachtrag gültig. [Auslegung durch Claude]
- Auto-Verlängerung: Formel rechnet das aktuelle Laufzeitende fort. [Auslegung durch Claude]

### Interview Runde 1/5 — beantwortet (Entscheidungsregister)  (Log-Zeile 65)
- Makros: [GESAGT: Nico] „Ja erlaubt, ich weiß aber nicht, ob er sich damit wohl fühlt. Tob dich mal aus, zur Not müssen wir später zurückskalieren"
  → Auslegung Claude: Makros nur als Komfortschicht; Kernfunktion läuft ohne Makros; Rückbau = Makros entfernen. Alternative: Makros tragend (Dialoge, Formulare). Korrigierbar: ja.
- Kalender: [GESAGT: Nico] HCL Notes.
- Anzahl Verträge: [GESAGT: Nico] 30 bis 150.
- Paket: [GESAGT: Nico] „Leistungen prüfen" (Lücken 5, 6) und „Übersicht und Betrieb" (Lücken 8, 9, 10). Empfehlung „Fristen sichern" nicht gewählt.
- Widerspruch: Kalenderantwort betrifft nur Lücke 1 (nicht gewählt) → Rückfrage Runde 2.

### Interview Runde 2/5 — beantwortet (Entscheidungsregister)  (Log-Zeile 73)
- Fristen: [GESAGT: Nico] „Ja, ganz dazu" → Lücken 1, 2, 7 im Paket.
- Rechnungen: [GESAGT: Nico] Freund prüft und gibt Rechnungen sachlich frei.
- Ablageort: [GESAGT: Nico] Netzlaufwerk, mehrere Bearbeiter.
- Interview beendet: keine offene Frage ändert die Arbeit mehr. Restliche Technikfragen (Notes-Import, Dateisperre) gehen als Optionen in PLANEN.

### Entscheidungsregister Plan (08.10.2026 ~15:35)  (Log-Zeile 102)
- Änderungsspur: [GESAGT: Nico] Option B (LibreOffice-Änderungsverfolgung).
- Reihenfolge: [GESAGT: Nico] AP1 → AP2 → AP3.
- Freigabe: [GESAGT: Nico] „Warte noch kurz" → nicht freigegeben. Kein Bau begonnen.

### Entscheidungsregister 08.10.2026 ~15:36  (Log-Zeile 114)
- Datenlage: [GESAGT: Nico] Verträge werden neu nach Ablageregel angelegt → Abgleich über ID, keine Inventur.
- Abgleich-Makro: [GESAGT: Nico] in AP3.
- Freigabe: [GESAGT: Nico] „los: UMSETZEN erstes Paket" (AP1, inkl. Link-Korrektur Serverpfade).

### Entscheidungsregister 08.10.2026 ~15:39  (Log-Zeile 125)
- Zweite Datei: [GESAGT: Nico] beides kommt vor (bearbeitbare Fassung und Anlage).
- Ablage: [GESAGT: Nico] Unterordner _bearbeitbar; _korrespondenz ja.
- Freigabe: [GESAGT: Nico] „los: AP1 mit neuer Regel".
- Auslegung: Hauptordner = alles, was gilt, in jedem Format (auch Anlage nur als .ods). _bearbeitbar = nicht bindende Kopien und Entwürfe. Alternative: Anlagen in eigenem Unterordner. Korrigierbar: ja.

### Entscheidungsregister 08.10.2026 ~15:41  (Log-Zeile 135)
- Laufwerksbuchstabe: [GESAGT: Nico] überall gleich → ein Pfad in Listen J7, Vorgabe Z:\Verträge\.
---

### Auftrag Base (Entwurf, wartet auf Bestätigung)  (Log-Zeile 428)
AUSLEGUNG: Maßstab „wie Apple" = Abnahmepunkte 1–4 (Startseite, 2 Klicks, keine DB-Begriffe, keine Tabellen). Alternative: reiner Stil (Farben, Schrift). Korrigierbar: ja.

### Entscheidungsregister Plan B1 (13.10.2026)  (Log-Zeile 442)
- Oberfläche: [GESAGT: Nico] Option A Base-Formulare.
- Freigabe: [GESAGT: Nico] „los: UMSETZEN B1".
- MODUS: UMSETZEN · Paket B1.

### Windows-Test — Entscheidungsregister (13.10.2026)  (Log-Zeile 481)
- Zeitpunkt: [GESAGT: Nico] „Jetzt".
- Makros: [GESAGT: Nico] Nur den Testordner als vertrauenswürdig eintragen; Eintrag nach dem Test entfernen.
- Ablageort: [GESAGT: Nico] Downloads\Vertragsregister-Test.
- 13.10.2026: Nico hat die Freigabe für den Ordner Downloads abgelehnt. Windows-Test angehalten. Nichts auf Nicos PC geändert.
- [GESAGT: Nico, 13:56] „nutze Cloude projects" → Auslegung: Ordner C:\Claude Projekts (laut userPreferences Ablageort für Logs). Alternative: Funktion „Projekte" in Claude; sie legt keine Datei auf den PC. Korrigierbar: ja.
- Freigabe C:\Claude Projekts erteilt. Testdatei → C:\Claude Projekts\Vertragsregister-Test\; Session-Log → C:\Claude Projekts\Logs\.

### Rückmeldungen 13.10.2026 17:17–17:24 → Paket B1.1 „Flüssig und Feinschliff" (Stufe M, UMSETZEN nach Auswahl)  (Log-Zeile 665)
  Entscheidung [GESAGT: Nico, Auswahl]: „Fenster vorab laden" — alle 4 Formulare beim Start laden, Wechsel nur noch ein- und ausblenden.
- [GESAGT: Nico, Auswahl 17:18] „Jetzt handeln" → „To-do"; danach [GESAGT: Nico, 17:24 + Auswahl] Rot = „Dringender Handlungsbedarf!", Gelb = „To-do" (statt „Bald fällig"), je für Kachel und Filterknopf. Ersetzt die Auswahl von 17:18.

### Windows-Test v4/v5 (13.10.2026 18:01–18:10)  (Log-Zeile 686)
- [GESAGT: Nico, 18:00 Auswahl] „Jetzt prüfen".

### Auftrag V8 — 13.10.2026, 21:32 (Codemarke V8)  (Log-Zeile 743)
- AUSLEGUNGSENTSCHEIDUNGEN (entschieden statt gefragt, Nico verlangt Vollständigkeit vor dem Test):

### Bericht (§15)  (Log-Zeile 799)
AUSLEGUNGSENTSCHEIDUNG (zusätzlich zu 1–7 im Auftrag):

### Entscheidungsregister (Interview V8.1, Runde 1, 14.10.2026)  (Log-Zeile 876)
- E1 Umfang V8.1: [GESAGT: Nico] „Fehler + W1–W5 zusammen".
- E2 Vertragsnummer: [GESAGT: Nico] „Beispiel für die Vertragsnummer in Real: 12_132_01_2026 wobei soweit ich weiß 12 die typenzahl, 132 die Art, 01 die laufende Jahrenummer und 2026 das jahr des Abschluss ist." Rolle (ersetzt V-001 oder zusätzlich) nicht gewählt → Runde 2. Befund: Die Nummer enthält „_"; der Abgleich trennt die Nummer am ersten „_" vom Ordnernamen [GEFUNDEN: 04_b3.bas AbgleichAusfuehren] → Regel muss sich ändern.
- E3 Kleines Fenster: [GESAGT: Nico] „Mindestzoom + Rollbalken".

### Entscheidungsregister (Interview V8.1, Runde 2, 14.10.2026)  (Log-Zeile 881)
- E4 Rolle Vertragsnummer: [GESAGT: Nico] „Ersetzt V-001 überall". Vertrag ohne Nummer zeigt vorläufig V-nnn.
- E5 Vergabe: [GESAGT: Nico] „Von Hand eintragen + prüfen" (doppelt → ablehnen; anderer Aufbau als NN_NNN_NN_JJJJ → Warnung, speichern trotzdem).
- E6 W5 neu gefasst: [GESAGT: Nico] „Bitte mache unterschiedliche Optionen für ein Volles Backup, das laufend selbständig überschrieben wird mit jeder Änderung, (soll vor technischem Datenverlust schützen durch byteswitches usw) und einer Export/importfunktion von text als CSV, dass vor Nutzerverursachten Datenverlusten schützen soll und sich auf ein Jahresweises/monatsweises und tageweises Exportsystem stützt, wo nur die letzten änderungen abgeglichen werden. Bitte überlege dir wie das am technisch smartesten/saubersten implementiert werden kann, auch für nicht technikaffine nutzer. Das ganze soll mit einem regelmäßigen "Backup speichern" popup erledigt sein im Alltag und wie von magischer hand bei Datenverlust über letzte Sicherung wiederherstellen (Auswahl des Tages) alle verlustigen Daten wiederfinden. Hierzu auch gelöschte Daten in einen Art papierkorb legen und erst nach 90 Tagen oder auf bestätigung wirklich löschen"
- Grundlagen für W5 [GEFUNDEN]: .odb wird nach jedem Datensatz gespeichert (01_kern.bas Gespeichert → DbDoc().store()); Spur-Trigger speichert beim Löschen nur Kurzbeschreibung (schema.py, Aktion 'gelöscht'); IDs GENERATED BY DEFAULT AS IDENTITY (explizite ID beim Zurückholen möglich).
- Optionen W5 an Nico (Schichten Papierkorb K1/K2, Textsicherung T1/T2/T3, Spiegel F1/F2/F3, Popup U1/U2), Paketschnitt P1–P5 → Runde 3.

### Entscheidungsregister (Interview V8.1, Runde 3, 14.10.2026)  (Log-Zeile 888)
- E7 Textsicherung: [GESAGT: Nico] „T3 Monat voll + Tag Änderungen".
- E8 Spiegel: [GESAGT: Nico] „F1 + F2 + F3".
- E9 Popup: [GESAGT: Nico] „Immer automatisch" → keine Frage, kurze Bestätigung „Tagessicherung gespeichert". Ersetzt den Wunsch „regelmäßiges Backup speichern popup" aus E6 (§22: Rückmeldung vor Auftragstext).
- E10 Papierkorb K1 (Schattentabellen per Trigger) — Empfehlung ohne Gegenstimme; [ANGENOMMEN, inval: Nico wählt K2].

### Auftrag V8.1 — Entwurf zur Bestätigung (14.10.2026)  (Log-Zeile 911)
AUSLEGUNG: „ein Paket je Durchlauf" (§2) und „alles zusammen" (E1) → P1–P5 nacheinander, jedes mit Test, Log und §16 abgeschlossen, bevor das nächste beginnt; lokaler Test nach P5. Alternative: Halt nach jedem Paket. Korrigierbar: ja.

### Bericht (§15)  (Log-Zeile 1011)
AUSLEGUNGSENTSCHEIDUNG:

### F4 Analyse – 14.10.2026 16:20–17:05 (MODUS: ANALYSIEREN)  (Log-Zeile 1086)
- [GESAGT: Nico 16:1x, Auswahl] F4: „Erst tiefer untersuchen".

### §15 Bericht – Nachtest und Korrektur V8.1 → V8.1c  (Log-Zeile 1141)
AUSLEGUNGSENTSCHEIDUNG: Beenden schließt LibreOffice nur, wenn kein anderes Dokument offen ist (wie bisher). Alternative war: immer ganz beenden. Korrigierbar: ja.

### Feature-Gespräch – 14.10.2026 18:22 (MODUS: PLANEN, vorgeschlagen)  (Log-Zeile 1182)
- E15 [GESAGT: Nico, Auswahl]: Aufgaben ohne Datum zählen ab Entstehung (z. B. Rechnungsdatum); rot ab einstellbarer Tageszahl (Vorschlag 14), davor gelb.
- E16 [GESAGT: Nico, Auswahl]: Kündigungen bekommen eigene Rot-Schwelle in den Einstellungen (Vorschlag 30 Tage).
- E17 [GESAGT: Nico, Auswahl]: M02 – Seite füllt die Fensterbreite, Listen und Karten wachsen mit; kein freies Verschieben.
- E20 [GESAGT: Nico, Auswahl]: M20 = Vorschlagsliste (Auswahl mit Freitext, zuletzt benutzte Werte, angemeldeter Name vorab).
- E21 [GESAGT: Nico, Auswahl]: M16 = Storno-Zeile: „Korrigieren" markiert Eintrag als storniert („✕ storniert:"), zählt nicht; neuer Eintrag daneben; Schalter blendet stornierte ein/aus.
- E22 [GESAGT: Nico, Auswahl]: M11/M12 = Knopfleiste „+ Neu", „Entfernen", „▲", „▼"; Spalte „Reihe" entfällt.
- E23 [GESAGT: Nico, Auswahl]: M09/M13/M23 = eine Gesamtsuche in der Seitenleiste (Verträge, Leistungen inkl. Stand, Protokoll, Partner, Dokumente, Hilfe), Trefferliste, Doppelklick springt; Suchen je Ansicht bleiben.
- E24 [GESAGT: Nico, Auswahl]: Treffer = Liste („Herkunft | … «WORT» …", Wort in Großbuchstaben) + Vorschau des markierten Treffers als formatierter Text (Zitat, Trefferwort fett); Doppelklick springt.
  AUSLEGUNG: „reicht" = keine zusätzliche Markierung in der Liste. Alternative war: Liste mit dezenter Markierung, z. B. „…" um das Wort. Korrigierbar: ja.
- E25 [GESAGT: Nico, Auswahl]: Sortierknopf im Kartenkopf („Sortiert: Dringlichkeit ▾"), Klick schaltet Dringlichkeit → Datum → Vertrag → Aufgabe; für „Offen" und „Nächste Termine".
- E27 [GESAGT: Nico, Auswahl]: Demodaten in neuen Ordner „Ablage_V82" (alte Ablage bleibt unberührt).

### §15 Bericht V8.2a  (Log-Zeile 1231)
AUSLEGUNGSENTSCHEIDUNG: Ende eines nicht verlängernden Vertrags nutzt die Kündigungsschwelle (30). Alternative: allgemeine Schwelle (7). Korrigierbar: ja.

### Windows-Test V8.2a (14.10.2026, 20:48–20:50) — §15-Bericht  (Log-Zeile 1275)
AUSLEGUNGSENTSCHEIDUNG: Einstellungen nicht geändert, nur angesehen. Alternative war: Schwelle ändern und Wirkung prüfen (in test_db_v82a abgedeckt). Korrigierbar: ja

### V8.2b – 14.10.2026 ab 20:57 (MODUS: UMSETZEN, Stufe M)  (Log-Zeile 1304)
  AUSLEGUNG: Gesicherte Protokolleinträge lassen sich bis Paket D (Storno-Zeile) nicht mehr löschen; Korrektur über „Storniert". Alternative war: Löschen für gesicherte Einträge behalten. Korrigierbar: ja.

### §15 Bericht – V8.2b + V8.2c (Lieferung V8.2c, 15.10.2026 09:23)  (Log-Zeile 1345)
AUSLEGUNGSENTSCHEIDUNG: B2 = Option 1 (Zeilen ohne Datum ans Ende). Alternative war: Bezugsdatum grau zeigen. Korrigierbar: ja.

### Entscheidungen 15.10.2026 09:40–09:45 (MODUS: PLANEN)  (Log-Zeile 1379)
- Befund [GEFUNDEN: exp_farbe.py, Eigenschaften PA_gridPartner]: Schriftfarbe im Raster nur je Spalte (CharColor) oder ganzes Raster (TextColor), nicht je Zeile.
- E28 [GESAGT: Nico 09:40/09:45] N05: Status „zukünftig“; Jahreskosten anteilig als Prognose der erwarteten Realkosten. Zeitraum = laufendes Kalenderjahr (Option 1). Endende Verträge (gekündigt/befristet) zählen ebenfalls nur anteilig bis zum Ende (Option 1).
  ANNAHME: „zukünftig“ automatisch bei Beginn > heute, ab Beginntag „aktiv“; Fristen/Ampel laufen schon vorher. BELEG: Vorschlag, kein Widerspruch. INVALIDIERUNG: Nico widerspricht. STAND: offen.
- E29 [GESAGT: Nico 09:43] N04: zwei Listen; oben groß Partner mit laufendem Vertrag; unten kleiner (ca. ¼ Höhe), graue Schrift, Zusatz „(inaktiv)“ (nie Vertrag) / „(historisch)“ (alle beendet).
- Offen an Nico: Windows-Test V8.2c (Freigabe Bildschirm), LEC-Dienstverträge (N01/N07/N08/N10), „Ersetzt durch“ (N06), N20 Umbenennung.
- E30 [GESAGT: Nico 09:47] „umdrehen ist gut“ + Link in beide Richtungen („ersetzt: LINK“, „wird ersetzt durch: LINK“), ohne große Verschiebung → Plan bestätigt [GESAGT: Nico 09:47 „Freigabe für den offenen rest, inkl. PC Nutzung“].
- LEC-Vorschlag bestätigt (gleiche Freigabe): Vertragsart „Dienstvertrag (LEC)“, Partner „LEC (HRMO)“, Zusatzangaben nur bei dieser Art.

### V8.4 / Paket D – 15.10.2026 13:40–14:50 (MODUS: UMSETZEN, Stufe M) [GESAGT: Nico 09:47/13:25 Freigabe]  (Log-Zeile 1444)
  AUSLEGUNG: eigener Unterordner je weiterer Datei. Alternative war: Dateinamen-Präfix für stand/basis/zip im gemeinsamen Ordner. Korrigierbar: ja.

### Bericht V8.4 (§15)  (Log-Zeile 1457)
AUSLEGUNGSENTSCHEIDUNG: F10 eigener Unterordner „Text_<Dateiname>“. Alternative war: Präfix im gemeinsamen Ordner. Korrigierbar: ja.

### V8.5 – 15.10.2026 ab 18:45 (MODUS: UMSETZEN, Stufe M) [GESAGT: Nico 18:45 „letzte Changerequests … prüfen ob längst bearbeitet … Arbeit fortsetzen“]  (Log-Zeile 1481)
  AUSLEGUNG: „vervollständigt“ = Eintrag einmal gesichert. Alternative war: erst bei geänderter Beschreibung oder Beleg. Korrigierbar: ja.
  AUSLEGUNG: „als Hinweis“ = keine offene Aufgabe. Alternative war: gelb lassen, nur Text ändern. Korrigierbar: ja.

### Paket C in V8.5 (MODUS: UMSETZEN) [GESAGT: Nico 09:47 Freigabe Pakete D und C; 18:45 „Arbeit fortsetzen“]  (Log-Zeile 1497)
  AUSLEGUNG: Groß-/Kleinschreibung egal, Treffer je Feld (ein Datensatz kann mehrfach erscheinen). Alternative war: ein Treffer je Datensatz. Korrigierbar: ja.

### Bericht V8.5 / V8.5b (§15)  (Log-Zeile 1544)
AUSLEGUNGSENTSCHEIDUNG: Q3 „ergänzt“ = einmal gesichert (Alt.: Beschreibung/Beleg geändert); Q5 Hinweis ohne Ampel (Alt.: gelb lassen); Suche: Treffer je Feld (Alt.: je Datensatz); F10 eigener Textordner (Alt.: Präfix). Korrigierbar: ja.

### Entscheidungen offene Punkte – 15.10.2026 22:07 ff. (MODUS: PLANEN) [GESAGT: Nico 22:07 „gehen wir die offenen Punkte durch … ich geb dir jeweils die Entscheidung“]  (Log-Zeile 1562)
- N14 [GESAGT: Nico, Auswahl]: Intern ja (Link + Rückfrage, Aktion in der Datenbank), extern nur zeigen (Ordner öffnen, Zielname zeigen); keine Dateiaktion durch das Register; Spalte intern/extern.
- N16 [GESAGT: Nico, Auswahl]: Knopf „Statistik“ erzeugt Calc-Datei mit Daten, Pivot-Tabelle und Diagramm.
- N01 [GESAGT: Nico] Rückfrage: „ist es wirklich notwendig eine Subart zu bilden? reicht es nicht eine neue zusätzliche Hauptart anzulegen?“ → Antwort folgt (Runde 2).
- N20 [GESAGT: Nico, Auswahl]: Umbenennen wie geschrieben: Störung → Leistungsanfall, Rechnung → Rechnung erhalten (Reihenfolge Leistungsanfall, Leistung erbracht, Rechnung erhalten, Reklamation).
- N01 [GESAGT: Nico, Auswahl]: Kombi-Arten selbst über Auswahllisten anlegen; kein Umbau. ✅ ERLEDIGT (15.10.2026) ohne Code.
- Stichtag [GESAGT: Nico, Auswahl]: vorsichtig lassen (gleicher Monatstag). ✅ ERLEDIGT (15.10.2026), keine Änderung. Rechtliche Richtigkeit weiter [UNBEKANNT].
- Korrigierte Rechnungen [GESAGT: Nico, Auswahl]: Neuausstellung mit neuer Nummer = alte Zeile ändern und „Korrigieren“. Umsetzung: Anleitung + Tooltip.
- Testordner [GESAGT: Nico, Auswahl]: verschieben in Unterordner „_alt“, nur nach Freigabe der Dateiliste. BEFUND [GEFUNDEN: Werkzeugliste]: Die Verbindung zum PC kann Dateien lesen und schreiben, aber nicht verschieben oder löschen (kein Befehlszugriff). → Rückmeldung an Nico.

### V8.6 – 16.10.2026 ab 00:11 (MODUS: UMSETZEN, Stufe M) [GESAGT: Nico 00:11 „los. bitte prüfe auch, dass die Heute buttons keinen text verdecken und sich buttons nicht überlappen“]  (Log-Zeile 1573)
- Berechtigungen [GESAGT: Nico 00:11, Auswahl]: Windows-Test V8.6 ohne weitere Rückfrage (Bildschirm, LibreOffice); Testdaten in V8.6 ändern erlaubt (Korrigieren, Abgleich-Aktion, Statistik); Testordner räumt Nico selbst auf.
  AUSLEGUNG: „Datei fehlt unter Dokumente“ → Aktion „eintragen (gilt)“; die Alternative „nach _ersetzt verschieben“ bleibt Handarbeit. Korrigierbar: ja.

### Bericht V8.6 (§15)  (Log-Zeile 1592)
AUSLEGUNGSENTSCHEIDUNG: Datei fehlt unter Dokumente → Aktion „eintragen“. Alternative: nach _ersetzt verschieben (extern). Korrigierbar: ja.

### Migrationspaket – 16.10.2026 10:49 [GESAGT: Nico 10:49 „…speichere in einem Unterordner Vertragsregister unter claude projekts alles zu diesem Projekt, sodass ich mit Claude Code weiterarbeiten kann…“]  (Log-Zeile 1629)
- AUSLEGUNG: „komplette Ablage alter Versionen“ = alle gelieferten .odb und Bauquellen-Zips aus dieser Sitzung plus Calc-Fassung (AP1–AP3). Zwischendateien der Sandbox (Fotos, Debug-Skripte) nicht. Alternative: ganzer Scratchpad (39 MB). Korrigierbar: ja.