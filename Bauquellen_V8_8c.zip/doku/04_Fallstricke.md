# Fallstricke und häufige Stolpersteine

Alle Punkte sind beim Bau von B1 bis V8.6b aufgetreten. Fundstellen stehen im Session-Log (`logs/`).

## A. LibreOffice Base und eingebettete Firebird-Datenbank

1. **Daten stehen erst nach dem Speichern der .odb in der Datei.** Wird die Verbindung vor dem Speichern geschlossen, ist `database/` leer. Die Makros speichern deshalb nach jedem gesicherten Datensatz. [GEFUNDEN: probe.odb/probe2.odb, 13.10.]
2. **„Too many Contexts … 256“:** Firebird kopiert Sichtausdrücke mit Unterabfragen bei jeder Verwendung. Abhilfe: LEFT JOIN auf gruppierte Teilabfragen statt verschachtelter Unterabfragen in Sichten.
3. **Der SQL-Parser von Base kennt nicht alles**, z. B. `DATEADD` in Formularfiltern und `ORDER BY … NULLS FIRST` (Formular lud nicht, die Meldung blockierte alle weiteren Formulare). Abhilfe: berechnete Spalte in der Sicht (z. B. `AlterTage`).
4. **Prepared Statements:** INTEGER-Spalten mit `setInt` füllen. `setLong` liefert „Incorrect type“.
5. **Kontextvariablen** (`RDB$SET_CONTEXT('USER_SESSION'|'USER_TRANSACTION', …)`) wirken in Triggern nur, wenn die Ergebniszeile mit `next()` abgeholt wird.
6. **FK ON DELETE SET NULL:** Ein BEFORE-DELETE-Trigger sieht die verweisenden Zeilen noch. Zurückholen aus dem Papierkorb stellt SET-NULL-Verweise nicht von selbst her → Tabelle `PK_Verweis`.
7. **Kaskadiertes Löschen:** Werte für Trigger der Kaskade über den Transaktionskontext weitergeben (`TL_Leistung_Ctx`).
8. **CHECK-Regeln** lehnen ab, was die Formularprüfung durchlässt. Eine abgelehnte Prüfung erzeugte eine zweite Meldung (RowSetVetoException) → still abfangen.

## B. Formulare, Steuerelemente, Basic

9. **Bereichswechsel über das Modell** (`EnableVisible`): 0,4 ms je Steuerelement. Über `setVisible` am Steuerelement dreimal langsamer. Formulare nicht über alle Steuerelemente suchen (0,1 s je Aufruf) → direkte Pfade, Konstante `FORMBEREICHE` aus dem Bau.
10. **`ThisComponent` zeigt nach dem Speichern der .odb nicht mehr auf das Formular.** Immer `AppDoc()` benutzen.
11. **Knöpfe nehmen keinen Fokus:** Der getippte Wert steht noch nicht im Rowset. Vor dem Speichern `commit()` auf alle gebundenen Felder. Einen Fokuswechsel in ein anderes Formular vermeiden: Base speichert dann selbst ein zweites Mal.
12. **Leere Datumsfelder:** `CDateFromUnoDate` auf 0.0.0 bricht ab → Hilfsfunktion `SpalteDatum`.
13. **`Format()` mit „_“** im Muster macht zwei Leerzeichen → Datum und Zeit getrennt formatieren.
14. **Reihenfolge von Ereignissen:** Was nach Rowset-Ereignissen laufen muss, geht über `Spaeter(code, arg)` (AsyncCallback). Neue Fälle in `Spaeter_notify` (01_kern) eintragen. Unter Windows laufen nachgelagerte Ereignisse anders als in Xvfb (Korrigieren-Auswahl, V8.6b).
15. **Rowsets nie aus dem Python-Testthread bewegen** (Deadlock bei `reload()`). Basic-Hilfen benutzen: `TSetListe`, `TSql`, `TNeuLaden`, `TGehe`, `TVertrag`, `TLeistung`, `TAbgleichZeile`, `TBreiteCheck`, `TLage`.
16. **Rasterspalten:** `supportsService` wirft bei Spalten eine Ausnahme. Stattdessen `ColumnServiceName = "DateField"` prüfen (mit `On Error Resume Next`).
17. **Fettdruck je Wort** geht in einem TextField mit `RichText=True` (XText, CharWeight).
18. **LibreOffice verschiebt beim Laden einzelne Formen am rechten Rand** (Ursache [UNBEKANNT]). Abhilfe: `BreiteMerken` beim Bau/Start, `LageHerstellen` über `Spaeter("LAGE")` beim Start und bei Zoom.
19. **„H“-Knöpfe:** immer neben der Beschriftung (Beschriftungsbreite = Feldbreite − 650). Der Bau warnt bei zu langen Beschriftungen. Windows-Schrift ist breiter als in der Sandbox.
20. **Titelbeschriftungen schlucken Klicks**, wenn sie über Knöpfe reichen. Titelbreite nach Textlänge: `min(14000, 620*len+600)`.
21. **Entwurfsleisten** waren beim Öffnen unter Windows sichtbar und verschwanden erst beim ersten Klick; dabei verschob sich die Seite, und der Klick ging ins Leere (K2). V8.6g: LeistenAus noch einmal im letzten Startschritt (`StartFertig`).
21a. **Zoom „ganze Seite“ lässt immer einen grauen Rand.** Randlos geht es nur mit „Seitenbreite exakt“ (DocumentZoomType 4), wenn das Seitenformat exakt dem Fensterformat entspricht (V8.6e).
21b. **Ein ausgeblendetes Inhaltsfenster wird nach `setVisible(True)` unter Windows nicht gezeichnet**, auch nicht nach `invalidate`. Erst eine Größenänderung zeichnet die Writer-Ansicht. Abhilfe: Größe kurz um 1 Punkt ändern und zurücksetzen (V8.6g).
21c. **Seitenvorlagen nicht über die Höhe erkennen**, seit sich auch die Höhe ändert: über den Namen („Standard“, „B_*“).

## C. Calc-Ausgaben (Export, Statistik)

22. **Statistik-Pivot:** `RowGrand`/`ColumnGrand = False`, sonst landet „Summe Ergebnis“ im Diagramm. Spaltenbreiten fest setzen (OptimalWidth über einen langen Titel macht Spalte A riesig). Diagramm nicht über die Pivot-Tabelle legen.
23. Breiten in 1/100 mm werden gerundet (6000 → 6001). Tests mit Toleranz.
23a. **Diagrammbereich nicht aus `getOutputRange()`** nehmen: Er enthält Filter- und „Daten“-Zeile, daraus werden leere Kategorien. Bereich ab der Zeile mit den Spaltentiteln (V8.6c/d).
23b. **StarBasic: `aArr(0).Feld = x` ändert bei Structs nur eine Kopie.** Struct in eigene Variable holen, ändern, zurück ins Array schreiben (V8.6d).
23c. **Quellen nicht mit PowerShell 5.1 schreiben:** `Set-Content -Encoding UTF8` setzt eine BOM, der Bau bricht dann bei `BauProbe` ab.

## D. Tests in der Sandbox

24. **Nie zwei Testläufe parallel** (gemeinsames LibreOffice-Profil, `pgrep`/`kill` treffen den anderen Lauf).
25. **`pgrep -f soffice.bin`** meldet Fehlalarme, wenn ein Bau läuft oder die eigene Befehlszeile das Muster enthält. Muster als `soffice\.bin` schreiben.
26. **Nach dem Start 3 s warten**, bevor geklickt wird: die Breitenanpassung läuft nachgelagert (in `v8ui.V8.__init__`).
27. **Knöpfe über den Namen klicken** (`mitte("NAME")`), nicht über feste Koordinaten. Jede neue Knopfleiste hat feste Klickpunkte verschoben.
28. **Ohne Fenstermanager** erreichen Tasten keinen Dialog → Dialoge über Bedienungshilfe-Aktionen schließen (`dialog_weg`, `dialog_eingabe`).
29. **Fristtest nach Mitternacht** schlägt fehl, wenn `cases*.xlsx` nicht am selben Tag neu berechnet wurden (recalc mit LibreOffice headless).
29a. **Tests, die Werte über das Modell setzen (`TSetText`), umgehen den Fokus-Fehler** (Fallstrick 11). So blieb K1 („Korrigieren“ ohne Feldwechsel) in der Sandbox unsichtbar. Für Knöpfe, die Eingaben auswerten, mindestens einen Test per Tastatur.
30. Test-SQL mit Ereignisarten nach jeder Umbenennung anpassen (N20: „Rechnung“ → „Rechnung erhalten“).

## E. Windows-Test auf Nicos PC

31. Öffnen über das Startcenter › Datei öffnen (Pfad eintippen). Fenster aus dem Vollbild holen, damit das Claude-Fenster nichts verdeckt.
32. Nicos PC hat kein Laufwerk `Z:` → „Ablage prüfen“ meldet „Ablagepfad nicht erreichbar“. Für einen echten Test einen Ablagepfad im Testordner einstellen.
33. Eine PowerShell aus Basic zu starten kostete ~11 s und lief nie zu Ende (Fensterfoto, V8.1). Entfernt. Keine PowerShell-Aufrufe für Komfortfunktionen.
34. `RegRead` (Zeitzone für DTSTAMP) kann unter Windows gesperrt sein → dann bleibt Ortszeit [ANGENOMMEN].
35. Die Verbindung zum PC kann Dateien lesen und schreiben. Verschieben und Löschen geht nur mit Befehlszugriff und Freigabe.

36a. **Zwei Register gleichzeitig offen und eines über „Beenden“ schließen → LibreOffice stürzt ab** (A1, 16.10.). Beim Testen alte Versionen vorher einzeln beenden.
36b. Ins Startcenter klicken, um es nach vorn zu holen, kann ein zuletzt benutztes Dokument öffnen. Auf leere Fläche oder die Titelleiste klicken.

## F. Arbeitsweise

36. Die `.odb` nie von Hand ändern und weitergeben. Immer Quellen ändern, neu bauen, testen.
37. Vor jeder Version die Quellen sichern (`Bauquellen_V*.zip`).
38. Nicos Meldungen kommen über „Melden“ in `Meldungen/meldungen.txt` im Testordner. Vor dem Bearbeiten prüfen, was schon erledigt ist.
