# Stand und offene Punkte (16.10.2026, 11:50)

## Stand

- Version **V8.6g** (`aktuell/Vertragsregister_v8_6g.odb`, auch im Testordner; Quellen `aktuell/quellen/v8`, Sicherung `Bauquellen_V8_6g.zip`). Unter Windows gebaut und unter Windows geprüft. UI-Tests nicht gelaufen (kein Xvfb).
- Testordner: `_v8_6e` und `_v8_6f` sind Zwischenstände (leere Seite beim Start), nicht benutzen.
- V8.6g gegenüber V8.6d:
  - Seite füllt das Fenster randlos (Seitenformat = Fensterformat, Zoom „Seitenbreite exakt“), Karten bis zur Unterkante (BOTTOM 17450), Fußzeile der Seitenleiste tiefer.
  - Start ohne Geflacker: Seite erscheint erst fertig, keine Entwurfsleisten mehr, der erste Klick wirkt sofort.
- Windows bestätigt am 16.10.: Statistik (S1, S2), Korrigieren ohne Tab (K1), Auswahl nach Korrigieren (Befund 1), K2 nicht mehr nachweisbar, randloses Layout in Übersicht/Protokoll/Verträge/Vertrag, Anpassung beim Wiederherstellen des Fensters.
- Neue Befunde 16.10.: R1 (Auswahl springt nach Größenänderung), A1 (Absturz beim Beenden, wenn zwei Register offen sind), Rasterspalte „Jahreskosten“ in Verträge knapp abgeschnitten.

## Offen

| Punkt | Woran es hängt | Vorschlag |
|---|---|---|
| ~~Windows-Prüfung V8.6b (Statistik, Korrigieren)~~ ✅ ERLEDIGT (16.10.2026) | – | – |
| ~~K1 Korrigieren ohne Feldwechsel~~ ✅ ERLEDIGT (16.10.2026, V8.6c) | – | Test per Tastatur in test_v84_ui ergänzen |
| ~~S1/S2 Statistik-Diagramm~~ ✅ ERLEDIGT (16.10.2026, V8.6d) | – | – |
| ~~K2 erster Klick verpufft~~ ✅ ERLEDIGT (16.10.2026, V8.6g: Ursache Entwurfsleisten) | – | – |
| ~~Außenkanten nach außen, Start-Geflacker~~ ✅ ERLEDIGT (16.10.2026, V8.6g) | Nico sieht es sich an | – |
| R1 Auswahl springt nach Größenänderung auf andere Zeile | [UNBEKANNT] ob neu seit V8.6e | in V8.6d nachstellen (Eintrag wählen, Fenster wiederherstellen); dann Ursache in BreiteAnpassen (Rasterspalten/Lage) suchen |
| A1 Absturz beim Beenden mit zwei offenen Registern | Randfall, trifft vor allem Tests | Zu_notify/AndereDokumente bei zwei Registern untersuchen |
| Tests nachziehen | kein Xvfb hier | test_v81_p3 (ZoomType 4 statt 2), v8ui.py (Seitenkoordinaten ohne Rand), Prüfungen nahe der Unterkante |
| Voller Rücktest V8.6g | kein Linux/Xvfb auf Nicos PC | `alle_tests.sh`, DB-Tests, Fristtest |
| N14-Link unter Windows | kein Laufwerk Z: | Ablagepfad in den Einstellungen auf `C:\Claude Projekts\Vertragsregister-Test\Ablage_V82\` stellen und prüfen |
| Notes-Dubletten beim Neuimport | [UNBEKANNT], kein Notes in der Testumgebung | beim ersten Import beim Freund prüfen (feste UID je Termin) |
| Ursache der Formverschiebung beim Laden | [UNBEKANNT] | Teil der Analyse unten |
| DTSTAMP-Umrechnung (Registry) | nur unter Windows prüfbar | eine .ics exportieren und Zeitstempel ansehen |
| Stichtag Monatsletzter | rechtliche Richtigkeit [UNBEKANNT] | bleibt vorsichtig (Entscheidung F1) |
| Testordner aufräumen | Nico | Nico verschiebt selbst nach `_alt` |
| ~~Bau unter Windows~~ ✅ ERLEDIGT (16.10.2026) | – | siehe CLAUDE.md › Bauen |
| Hinweiszeile HIL-01 + ORI-01 | V8.7 gebaut (Testordner), unterbrochen: Fokus verdrängt To Do; 12-px-Versatz bei abgeschalteter Zeile [UNBEKANNT]; Texte-Abnahme, Zip fehlen | siehe Log „V8.7 Hinweiszeile“ |
| Analyse: weitere nicht tragende Workarounds, Verständlichkeit für Nachfolger [GESAGT: Nico 16.10.] | Analyseauftrag | Modus ANALYSIEREN, Liste mit Aufwand/Nutzen; Kandidaten: LageHerstellen (Ursache Formverschiebung), doppelte LeistenAus-Aufrufe, Spaeter-Codes |

## Fortsetzungs-Block (kopierfertig für eine neue Sitzung)

```
Arbeitsdatei: C:\Claude Projekts\Vertragsregister\aktuell\quellen\v8 (Bau Linux: python3 build_base.py v8.odb;
  Bau Windows: siehe CLAUDE.md, LibreOffice-Python + PYTHONPATH=_pylib; Quellen nie mit PowerShell 5.1 schreiben (BOM);
  Tests: bash alle_tests.sh unter Linux/Xvfb, nichts parallel; DB: test_db_v8..v85.py;
  Frist: cases*.xlsx am selben Tag neu berechnen, dann test_frist_db.py ../cases.xlsx ../cases3.xlsx).
Arbeitsgrundlage: V8.6g (aktuell\Vertragsregister_v8_6g.odb). Log: logs\Session-Log_2026-10-08_Vertragsregister.md
  (gleicher Inhalt in C:\Claude Projekts\Logs).
Meldungen gelesen bis 16.10. 14:41:55 (Testordner\Meldungen\meldungen.txt); Plan dazu: Plan_V8.8_Meldungen_16-10.md (P1–P6, Entscheidungen D1–D6).
Bisher erledigt: AP1–AP3 (Calc), B1, B1.1, V8–V8.6g; Windows-Prüfung V8.6b, c, d, g.
Nächstes Paket: Nicos Abnahme V8.6g (randlos, Start); R1 klären; Tests nachziehen + voller Rücktest (Linux);
  Analyse Workarounds; neue Meldungen.
Geltende Regeln: Nicos Protokoll (Modus, Stufe, Tags, Log, §15/§16); Sandbox/Bau zuerst; nur Testordner;
  keine Dateien auf Nicos PC löschen/verschieben; Bildschirm je Version nach Freigabe;
  Tests klicken Knöpfe über den Namen; V8-Sitzung wartet 3 s; pgrep nie mit Muster aus der eigenen Befehlszeile;
  nie zwei Register gleichzeitig offen beenden (A1).
```

## Nachtrag 16.10.2026 17:10 – Auslieferung V8.8c ✅
- Lieferordner `Lieferung_V8.8c\`: Vertragsregister.odb (mit Beispieldaten), README_Schnellstart.md, IT_Sicherheitsbeschreibung.md, Gesamtbeschreibung_und_Fortsetzung.md (dort Abschnitt 5 = aktuelle offene Liste O1–O16), Bauquellen_V8_8c.zip. Testordner: Vertragsregister_v8_8c.odb.
- Windows-Kurzprüfung winpruef.py 13/14, Sichtprüfung ST/PR/EI ok. UI-Tests (Linux) nicht gelaufen.
- `Vertragsregister_mit_Beispielen.odb` im Lieferordner ist doppelt (gleich Vertragsregister.odb) – Nico entfernt sie selbst [GESAGT: Nico „es braucht keine Version ohne Beispiele“].
