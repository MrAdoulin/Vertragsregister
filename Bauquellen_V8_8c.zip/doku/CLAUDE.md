# CLAUDE.md – Vertragsregister (LibreOffice Base)

Lies zuerst `05_Stand_und_Offen.md` (Fortsetzungs-Block), dann `04_Fallstricke.md`.
Projektbeschreibung: `01_Projektbeschreibung.md`. Entscheidungen: `02_Entscheidungsregister.md`.

## Arbeitsregeln von Nico (gelten dauerhaft)

- Nicos Protokoll aus seinen Claude-Einstellungen gilt: genau ein Modus (ANALYSIEREN, PLANEN, UMSETZEN), Stufe S/M/L, Herkunfts-Tags (`[GESAGT]`, `[GEFUNDEN]`, `[GESCHLOSSEN aus]`, `[ANGENOMMEN, inval]`, `[UNBEKANNT]`), Bericht nach §15, Abschluss nach §16, Fortsetzungs-Block.
- Jeden Zustand in den Log schreiben: `logs/Session-Log_2026-10-08_Vertragsregister.md` fortführen oder einen neuen Log je Session unter `C:\Claude Projekts\Logs` anlegen.
- Auftragstext nie löschen. Erledigtes mit `✅ ERLEDIGT (Datum)` markieren.
- Der Modus wechselt nur, wenn Nico ihn wechselt.
- Tests auf Nicos PC nur im Testordner `C:\Claude Projekts\Vertragsregister-Test`.
- Den Ordner Downloads nicht benutzen. Andere Dokumente von Nico nicht anfassen.
- Auf Nicos PC keine Dateien löschen oder verschieben. Den Testordner räumt Nico selbst auf.
- Bildschirmsteuerung: nur für den freigegebenen Test. Die Freigabe gilt je Version.
- Bug-Report-Mechanik („Melden“) nicht ausbauen. [GESAGT: Nico 15.10. 20:15]

## Bauen

```bash
cd aktuell/quellen/v8
python3 build_base.py v8.odb            # Beispieldaten, Start in der Übersicht
python3 build_base.py out.odb --ohne-beispiele
```

- Braucht Python mit `uno` und ein `soffice` im PATH. `uno_util.py` startet ein eigenes headless soffice mit Profil in `_profile/<port>`.
- Gebaut und getestet wurde unter Linux (Ubuntu, LibreOffice 24.2.7, Pakete `libreoffice-base`, `libreoffice-sdbc-firebird`).
- Unter Windows (seit V8.6c, 16.10.2026 erfolgreich): Python von LibreOffice, Pillow aus `_pylib` (einmalig: `& "C:\Program Files\LibreOffice\program\python.exe" -m pip install --target _pylib pillow`):
  ```powershell
  $env:PYTHONPATH = (Resolve-Path _pylib).Path
  & "C:\Program Files\LibreOffice\program\python.exe" build_base.py v8.odb
  ```
  Bleibt nach einem Abbruch eine headless-Instanz stehen: nur den Prozess mit `port=2020;` in der Befehlszeile beenden, nie Nicos LibreOffice.
- Die Version steht in `app/01_kern.bas`: `Private Const VERSION = "V8.8c"`.
- Codemarken: jede Änderung trägt einen Kommentar mit Version und Auftrag, z. B. `' V8.6b: …`.

## Testen

```bash
bash alle_tests.sh                       # alle Oberflächentests (Xvfb), Ergebnis in tests.log; nie parallel starten
python3 test_db_v85.py                   # DB-Tests (auch test_db_v8 … v83)
python3 test_frist_db.py ../cases.xlsx ../cases3.xlsx   # Fristlogik, cases*.xlsx vorher am selben Tag neu berechnen
python3 -u test_v86_ui.py                # einzelner Test
```

- Oberflächentests brauchen Linux mit Xvfb und `python3-xlib` (XTest). Unter Windows laufen sie nicht. Möglichkeiten: WSL2 mit Xvfb oder eine Claude-Code-Cloud-Sitzung.
- Nach jeder Änderung den RÜCKTEST laufen lassen: betroffene Tests, vor einer Lieferung `alle_tests.sh`, DB-Tests und den Fristtest.
- Danach Windows-Sichtprüfung auf Nicos PC (Schriftbreiten, Reihenfolge von Ereignissen und Calc unterscheiden sich).

## Liefern

1. Quellen sichern als `Bauquellen_V<x>.zip`.
2. `.odb` als `Vertragsregister_v<x>.odb` in den Testordner legen.
3. Log aktualisieren (§15-Bericht, §16, Fortsetzungs-Block).

## Wichtigste Fallstricke (Kurzliste)

- Daten der eingebetteten DB stehen erst nach dem Speichern der `.odb` in der Datei.
- `AppDoc()` statt `ThisComponent`.
- Nachgelagerte Schritte über `Spaeter(code, arg)`; neue Codes in `Spaeter_notify` eintragen.
- In Tests keine Rowsets aus Python bewegen; Basic-Hilfen `T*` benutzen.
- Knöpfe in Tests über `mitte("NAME")` klicken; 3 s nach dem Start warten.
- `setInt` statt `setLong` für INTEGER.
