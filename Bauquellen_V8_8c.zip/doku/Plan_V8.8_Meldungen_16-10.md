# Plan V8.8: Änderungswünsche und Meldungen vom 16.10.2026

Stand 16.10.2026 · MODUS: PLANEN · Grundlage V8.7 (Testordner, unfertig)

Quellen:
- Chat [GESAGT: Nico 16.10.]: (W1) „Delay bis zum Anzeigen des Tooltips customizable über die Einstellung … Bei aktiver Hinweisspalte soll der Tooltip deaktiviert sein. Default eine Sekunde, Bruchteile möglich (0,3 oder 1,5).“ (W2) „Toggle für die Farbcolorierung der Hinweisspalte bzw. Verminderung des Umfanges (nur mehr Statusupdates bzw. was grad technisch sperrt, keine ‚how to benutzen‘, das bleibt rein im Tooltip, der dann wieder aktiviert wird)“.
- 17 Meldungen `Vertragsregister-Test\Meldungen\meldungen.txt`, 16.10. 13:55–14:41, Version V8.7 (Kürzel M1–M17 unten).
- Offene Fehler aus dem Bau V8.7 (Log „V8.7 Hinweiszeile“): F1 Fokus verdrängt To Do, F2 Versatz 12 px bei abgeschalteter Zeile.

## 1. Machbarkeit Tooltip-Verzögerung (W1)

- LibreOffice kennt **keine einstellbare Verzögerung** für Tooltips. `HelpSettings::GetTipDelay()` ist fest. In der Experten-Konfiguration gibt es nur `org.openoffice.Office.Common/Help/Tip` (an/aus), und das gilt für das **ganze** LibreOffice des Nutzers. [GEFUNDEN: ask.libreoffice.org/t/how-to-disable-or-delay-tooltips/39909, docs.libreoffice.org vcl HelpSettings, Bug 118284]
- Folge: Der Tooltip wird **selbst gebaut**:
  - Die Hilfetexte stehen nicht mehr in `HelpText`, also gibt es keinen LibreOffice-Tooltip.
  - Unsere Hover-Beobachter (gibt es seit V8.7) starten eine Wartezeit.
  - Danach erscheint ein eigenes kleines Hinweisfeld (gelbes Label auf der Seite) neben dem Element.
  - Maus weg → Feld weg.
- Offene Technikfrage: Basic hat keinen Zeitgeber.
  - Weg A: kleines Python-Skript im Dokument mit `threading.Timer`, das über `AsyncCallback` zurückruft. Python ist in LibreOffice für Windows enthalten [ANGENOMMEN, inval: Installation beim Freund ohne Python-Skripting].
  - Weg B: wiederholte `AsyncCallback`-Aufrufe mit Zeitvergleich. Das kostet während der Wartezeit Rechenzeit.
  - → **Versuch S0b** entscheidet.

## 2. Pakete

### P1 Hinweiszeile fertigstellen (V8.7 → V8.8) — W1, W2, M8, M11, M13, F1, F2

| Nr. | Inhalt | Quelle |
|---|---|---|
| P1.1 | Fokus steht **unter** dem To Do (beim Tippen bleibt das Pflichtfeld-To-Do sichtbar), Mauszeiger darüber | F1 |
| P1.2 | Versatz von ~12 px bei abgeschalteter Zeile beheben (Ursache suchen; Nachstellen ohne Makros begonnen) | F2 |
| P1.3 | Ergebnis mit kleinem Zeitstempel („13:55 ✓ Meldung gespeichert“), höchstens **10 s** sichtbar, danach nicht wieder; kein Hin- und Herspringen mit Hover | M13 |
| P1.4 | **Drei Stufen** der Zeile in den Einstellungen: „Aus“ · „Nur Status und To Do“ (Ergebnis, was gerade sperrt, Pflichtfelder; keine Bedienhinweise) · „Mit Bedienhinweisen“ (wie V8.7) | W2 |
| P1.5 | Schalter **Farben** der Zeile (aus = alles grau, Zeichen ✓/! bleiben) | W2 |
| P1.6 | **Eigener Tooltip** mit Verzögerung aus den Einstellungen, Vorgabe 1,0 s, Dezimalwerte (0,3 · 1,5); aus bei „Mit Bedienhinweisen“, an bei „Nur Status …“ und „Aus“ | W1, W2 |
| P1.7 | Einstellungen neu ordnen: eigene Karte **„Anzeige“** (Hinweiszeile, Farben, Tooltip-Verzögerung), „Beispieldaten“ eigene Karte, weniger Leerfläche (z. B. unter „Auswahllisten“) | M8 |
| P1.8 | Präzisere Leistungs-Hinweise: statt „Was bei dieser Leistung zu tun ist.“ je Zustand ein konkreter Satz mit Feld und Ort, z. B. „Fällig am 01.11.2026 – Termin mit dem Partner vereinbaren; erbracht: ‚Heute erbracht‘“ | M11 |
| P1.9 | Liste der Standard-, To-Do- und Tooltip-Texte zur Abnahme vorlegen | Auftrag V8.7 |

### P2 Fehler: Auswahl und Sprünge — M1, M2, M3, M7, R1

| Nr. | Fehler | Quelle |
|---|---|---|
| P2.1 | Doppelklick auf einen Protokolleintrag im Vertrag (VE2) öffnet „Protokoll & Rechnungen“, wählt den Eintrag aber nicht aus. Man landet bei einem anderen Vertrag (Kaffeemaschine → Drucker). | M1 |
| P2.2 | Im Protokoll steht rechts der richtige Eintrag, links ist er weder markiert noch mit dem grünen Pfeil versehen | M2 |
| P2.3 | Nach dem Speichern blinkt „Reaktion am“ orange (Neuberechnung sichtbar); nach dem Sichern soll dieselbe Zeile im neuen Stand stehen | M3 |
| P2.4 | Gesamtsuche springt nicht zum Treffer, nur in die Partnerauswahl | M7 |
| P2.5 | Auswahl springt nach Fenstergrößenänderung auf eine andere Zeile | R1 (16.10.) |

Vermutung [GESCHLOSSEN aus: M1, M2, R1, Befund 1 V8.6]: Eine gemeinsame Ursache ist wahrscheinlich: Raster und Detail werden getrennt positioniert, und nachgelagerte Ereignisse (`Spaeter`) überschreiben die Auswahl. Erst die Ursache suchen, dann einmal beheben.

### P3 Begriffe und Beschriftungen — M4, M6, M9, M10 (Text), M12, M15

| Nr. | Alt | Neu | Quelle |
|---|---|---|---|
| P3.1 | Spaltenkopf „Name“ in den beiden Partnerlisten (+ Überschrift darüber) | „Mit laufendem Vertrag“ / „Ohne laufenden Vertrag“ als Spaltenkopf, Überschrift entfällt | M4 |
| P3.2 | „SUCHE ÜBERALL“ | „ALLES DURCHSUCHEN“ (Ansicht „Suche überall“ entsprechend) | M6 |
| P3.3 | „Prüfergebnis“ (Protokoll) | „Stand“ | M9 |
| P3.4 | „Storniert (zählt nicht)“ | „Storniert“ | M10 |
| P3.5 | „Reaktion am“ | „Erledigung am“ (Erledigung der Leistung durch den Partner) | M12 |
| P3.6 | „Protokoll & Rechnungen“ (Seitenleiste) | „Rechnungsverlauf“ | M15 |

Mit P3 werden Hilfe (`anleitung.py`), Tooltips, To-Do-Texte und Tests abgeglichen (HIL-02).

### P4 Knopf „Stornieren“ — M10

- Roter Knopf „Stornieren“ unten links im Eintrag. Er setzt „Storniert“; das Kästchen selbst ist nicht mehr per Hand änderbar.
- Rückfrage wie beim Löschen.
- Bedeutung laut Nico: „Wirkt rückwirkend auf einen Eintrag wie Korrigieren, aber ohne Nachfolgeeintrag.“

### P5 Suche — M5 (+ SPR-02)

- Groß-/Kleinschreibung egal (heute schon in den Ansichtssuchen; Gesamtsuche prüfen).
- Leerzeichen kulant: „Kaffee service“ findet „Kaffeeservice“ und umgekehrt.
- Schalter **„Ähnliche Schreibweisen“** direkt unter der Suche, Vorgabe an: c/k, s/ß/ss, č/c, ä/ae, ö/oe, ü/ue usw.

### P6 Layout und Schrift — M14, M16, M17

| Nr. | Wunsch | Quelle |
|---|---|---|
| P6.1 | Datum überall kurz „23.12.26“ | M14 |
| P6.2 | Schriftgrößen vereinheitlichen; Tabellen mit Auto-Zoom (möglichst alle Inhalte sichtbar) und Knöpfen + / − | M14 |
| P6.3 | Seitenleiste schmaler, mehr Platz für Tabellen | M16 |
| P6.4 | Normale Schriftgröße in den Einstellungen; im Vollbild wird die Schrift nicht größer, man sieht **mehr** statt einer vergrößerten 1:1-Kopie | M17 |

P6.4 ändert das Grundprinzip von V8.6e/g: Die Seite folgt dann nicht mehr dem Fensterformat bei mitwachsendem Zoom. Der Zoom bleibt fest (Schriftgröße), die Seite wird in beide Richtungen so groß wie das Fenster, und Listen und Raster wachsen, Knöpfe und Felder nicht. Das ist ein eigener Umbau mit eigenem Versuch.

## 3. Entscheidungen für Nico

| Nr. | Frage | Empfehlung |
|---|---|---|
| D1 | Reihenfolge der Pakete | **P1 → P2 → P3+P4 → P5 → P6**. P1 schließt den laufenden Bau ab; P2 sind Fehler, die zu falschen Einträgen führen. |
| D2 | Tooltip-Technik (W1) | Versuch S0b mit Weg A (Python-Zeitgeber) und Rückfall Weg B. Bitte **freigeben, dass das Register ein kleines Python-Skript im Dokument tragen darf**. |
| D3 | Stufe „Nur Status und To Do“: zählt das Pflichtfeld-To-Do dazu? | **Ja**, es ist „was grad technisch sperrt“. |
| D4 | „Erledigung am“ (M12): nur die Beschriftung oder alle Texte (z. B. „Reaktion offen“ → „Erledigung offen“, „Leistungsanfall ohne Reaktion“, „Soll-Reaktionszeit“)? | **Alle sichtbaren Texte**; Datenbankspalten (`ReagiertAm`) bleiben. Offen: Bleibt die „Soll-Reaktionszeit“ ein eigener Begriff (Reaktion = Ansprechzeit) oder wird sie „Soll-Erledigungszeit“? |
| D5 | P6.4 Vollbild zeigt mehr statt größer | **Ja, als eigener Umbau nach P5**, mit Versuch; bis dahin bleibt V8.6g-Verhalten. |
| D6 | Grundstufe der Hinweiszeile für den Freund | **„Nur Status und To Do“**, Tooltip 1,0 s (W2 klingt danach); „Mit Bedienhinweisen“ für die Einarbeitung. |

## 4. Nächster Schritt nach Freigabe

P1 mit Versuch S0b (Zeitgeber, eigenes Tooltip-Feld, ~20 min), dann Bau V8.8 mit P1.1–P1.9, Windows-Prüfung, Texte zur Abnahme.
