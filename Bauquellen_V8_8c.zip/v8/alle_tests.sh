#!/bin/bash
# V8 · alle Oberflächentests nacheinander, Ergebnis in tests.log
cd "$(dirname "$0")"
: > tests.log
for t in test_v8_flow.py test_v8_flow2.py test_v8_flow3.py test_v81_ui.py test_v81_p3.py test_v81_p4.py test_v81_p5.py test_v81_p5b.py test_v81_p5c.py test_v81_p6.py test_v81_f2.py test_v82a_ui.py test_v82b_ui.py test_v82c_ui.py test_v83_ui.py test_v84_ui.py test_v84_f10.py test_v85_ui.py test_v85_c.py test_v86_layout.py test_v86_ui.py test_v8_x.py; do
  rm -rf xui_test/Export xui_test/Sicherung
  echo "=== $t" >> tests.log
  timeout 600 python3 -u $t > ${t%.py}.log 2>&1
  echo "exit $?" >> tests.log
  grep -E "^FEHL|ERGEBNIS|nach X|soffice läuft" ${t%.py}.log >> tests.log
  pgrep -f 'soffice\.bin' | xargs -r kill -9
  sleep 1
done
echo FERTIG >> tests.log
