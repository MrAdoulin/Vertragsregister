"""V8 · Texte für den Bereich Hilfe (Anleitung im Programm)."""

ERSTE_SCHRITTE = """1.  Entferne die Beispieldaten: Einstellungen (Zahnrad links unten) › Beispieldaten entfernen.

2.  Trag den Ablagepfad ein: Einstellungen › Ablage und Sicherung.

3.  Lege den ersten Vertrag an: Verträge › Neuer Vertrag.
    Pflicht sind Gegenstand und Vertragspartner.

4.  Trag die Leistungen des Vertrags ein: im Vertrag der Reiter „Leistungen & Protokoll“.

5.  Schau jeden Morgen in die Übersicht.
    Rot heißt: jetzt handeln. Gelb heißt: bald handeln.

Alles wird beim Wechseln der Ansicht gespeichert. Der Knopf „Sichern“ speichert sofort.

Fragen zu einem Feld? Zeig mit der Maus darauf: Die Zeile unter den Karten erklärt es.
Schneller mit der Tastatur: Strg+1 bis Strg+9 wechseln die Ansicht, Strg+S sichert, F1 öffnet die Hilfe."""

TEXT = """VERTRAGSREGISTER – ANLEITUNG

1  WAS DAS VERTRAGSREGISTER KANN
Das Register sammelt alle Verträge mit Laufzeit, Kündigungsfrist, Kosten und Dokumenten.
Es rechnet Kündigungsstichtage und Vertragsenden aus und warnt rechtzeitig.
Es hält fest, welche Leistungen ein Partner schuldet, und prüft Leistungsanfälle und Rechnungen dagegen.
Jede Änderung wird mit Name und Zeit aufgezeichnet.

2  BEDIENUNG
Links steht die Seitenleiste. Ein Klick wechselt die Ansicht.
Ein Doppelklick auf eine Zeile in einer Liste öffnet den Vertrag.
Beim Wechsel der Ansicht speichert das Register alle Eingaben. Der Knopf „Sichern“ speichert sofort.
„Sichern“ ist grau, solange nichts geändert ist, und blau, sobald es etwas zu sichern gibt.
Die Zeile unter den Karten (Hinweiszeile) zeigt, was zuletzt geschehen ist (z. B. „✓ 12:54 Gespeichert“, 10 Sekunden lang)
und was hier zu tun ist („To Do: …“). Einstellungen › „Beispieldaten und Anzeige“: Aus, Nur Status und To Do (Vorgabe)
oder Mit Bedienhinweisen (dann steht dort auch, wozu das Element unter der Maus dient). Dort auch Farben an/aus und
nach wie vielen Sekunden der Tooltip erscheint (z. B. 0,3 oder 1,5).
Leere Datumsfelder zeigen rechts über dem Feld ein kleines „H“. Ein Klick darauf trägt das heutige Datum ein.
Neue oder geänderte Einträge zeigen einen roten Knopf „Verwerfen“: Er nimmt ungesicherte Eingaben zurück.
Bei gesicherten Einträgen steht dort „Löschen“ (im Vertrag „Vertrag löschen“), immer mit Rückfrage.
Die Ansicht passt sich der Fensterbreite an: Im Vollbild werden Felder und Listen breiter.
„Beenden“ speichert und schließt das Register. Das X oben rechts schließt es ebenfalls ganz.
Felder mit * sind Pflicht. Fehlt ein Pflichtfeld, meldet sich das Register und speichert nicht.
Alles durchsuchen: Links unter den Ansichten einen Begriff eingeben und Enter drücken (oder die Lupe).
Groß-/Kleinschreibung und Leerzeichen sind egal („kaffee service“ findet „Kaffeeservice“). Mit dem Haken
„Ähnliche Schreibweisen“ findet sie auch ä/ae, ß/ss, c/k/č und einfache statt doppelter Buchstaben.
Die Liste zeigt jeden Fund mit Herkunft (Vertrag, Leistung, Protokoll, Partner, Dokument, Hilfe) und Ausschnitt.
Rechts steht der Ausschnitt mit dem Suchwort fett. Doppelklick oder „Öffnen ›“ springt zur Fundstelle;
„‹ Suche“ im Vertrag führt zurück zu den Treffern. Die Suche je Ansicht bleibt daneben bestehen.
Tastenkürzel:
  Strg+1 Übersicht · Strg+2 Verträge · Strg+3 Leistungen · Strg+4 Rechnungsverlauf · Strg+5 Partner
  Strg+6 Vertretung · Strg+7 Änderungen · Strg+8 Ablage prüfen · Strg+9 Papierkorb & Sicherung
  F1 oder Strg+0 Hilfe · Strg+, Einstellungen
  Strg+S Sichern · Strg+N Neu (Vertrag, Leistung, Eintrag, Partner, Vertretung)
  Strg+F Suche dieser Ansicht · Strg+Umschalt+F Alles durchsuchen
  Im Vertrag: Strg+Bild↑ / Strg+Bild↓ voriger/nächster Vertrag · Alt+← zurück zur Liste
Die Kürzel stehen auch im Hinweis der Knöpfe.

3  ÜBERSICHT UND AMPEL
Rot (!! dringend) = bald fällig oder überfällig:
  Kündigungsstichtag oder Vertragsende in den nächsten 30 Tagen,
  andere Termine (Leistung, Indexanpassung, Prüfung) in den nächsten 7 Tagen,
  Aufgaben ohne Termin (Rechnung prüfen, Leistungsanfall ohne Erledigung, Bestätigung fehlt) seit mehr als 14 Tagen offen.
Gelb (! offen) = noch zu erledigen, aber nicht dringend.
Die Tage stellst du unter Einstellungen ein.
„Offen“ listet alle roten und gelben Aufgaben. „Nächste Termine“ zeigt die nächsten 12 Monate.
Der Knopf „Sortiert: …“ oben in jeder Liste wechselt die Sortierung (Dringlichkeit, Datum, Vertrag, Aufgabe).
Ein Klick auf eine Kennzahl zeigt die passenden Verträge oder Leistungen.
„Kosten dieses Jahr (Prognose)“ rechnet jeden Vertrag anteilig nach seinen Lauftagen im Kalenderjahr:
Beginnt ein Vertrag am 1. November, zählt er mit zwei Zwölfteln; endet er am 30. Juni, mit der Hälfte.
Wo etwas zu tun ist, ist das Feld oder der Knopf, mit dem du es erledigst, rot oder gelb markiert.
Die Beschriftung trägt ein „!“. Zeig mit der Maus darauf: Der Tooltip sagt, was zu tun ist.
Ist es erledigt, verschwindet die Markierung. Auch die Reiter im Vertrag tragen ein „!“, wenn darin etwas offen ist.

4  EINEN VERTRAG ANLEGEN
Verträge › Neuer Vertrag. Trag den Gegenstand ein und wähle den Partner.
Fehlt der Partner, klick neben dem Feld auf „Neu“ und gib den Namen ein.
In der Ansicht „Partner“ stehen oben die Partner mit laufendem Vertrag, darunter grau die ohne:
„(inaktiv)“ = nie ein Vertrag, „(historisch)“ = alle Verträge beendet. Ein Klick zeigt den Partner rechts.
Bei Ansprechperson, Telefon, E-Mail, Hotline und Kundennummer steht „Stand: TT.MM.JJJJ“ = Tag der letzten Änderung.
Vertragsnummer: eure Nummer, z. B. 12_132_01_2026. Jede Nummer gibt es nur einmal.
Ohne Nummer zeigt das Register vorläufig „unbenannt 7“ (7 = laufende Nummer im Register).
Laufzeit: Beginn und erstes Vertragsende. Verlängert sich der Vertrag von selbst, hake das an und
trag ein, um wie viele Monate er sich verlängert.
Kündigungsfrist in Monaten. Das Register rechnet daraus den Kündigungsstichtag.
Liegt der Beginn in der Zukunft, steht der Status von selbst auf „zukünftig“; am Beginntag wird er „aktiv“.
Fristen und Ampel laufen schon vorher, damit kein Stichtag verloren geht.
Löst der Vertrag einen alten ab, wähle den alten bei „Ersetzt Vertrag“. „›“ daneben öffnet ihn.
Der alte Vertrag zeigt dann „Wird ersetzt durch“ mit einem Link zum neuen.
Dienstverträge mit Angestellten (LEC): Vertragsart „Dienstvertrag (LEC)“, Partner „LEC (HRMO)“.
Dann erscheint der Reiter „Dienstvertrag“ für Angestellte/n, Dienstort, Sollstunden, Stundenlohn und Bereitschaft.
Der Stichtag ist der letzte Tag, an dem die Kündigung beim Partner eingelangt sein muss.
Plane den Versand vorher ein.
Hinweis zur Rechnung: Das Register rechnet den Stichtag vorsichtig. Endet ein Vertrag am 30. Juni und
die Frist beträgt drei Monate, zeigt es den 30. März. Im Zweifel liegt der Stichtag also früher.
Die rechtliche Prüfung im Einzelfall ersetzt das Register nicht.

5  ENTSCHEIDUNG ZUM STICHTAG
Im Vertrag rechts: „Verlängern“ oder „Kündigen“. Das Register trägt Datum und deinen Namen ein.
Unten in der Karte: „Sichern“ speichert, „Verwerfen“ nimmt ungesicherte Eingaben der Karte zurück.
Ein zweiter Klick am selben Tag legt keine zweite Entscheidung an.
Andere Entscheidungen, z. B. „neu verhandeln“, wählst du darunter in der Liste „Entscheidung“.
Datum und Name füllen sich beim Sichern selbst. Ein angefangenes Feld ohne Entscheidung hält nichts auf.
Bei einer Kündigung trag „Versandt am“ und später „Bestätigt am“ ein.
Solange die Bestätigung fehlt, bleibt der Vertrag gelb.
Ein Versand nach dem Stichtag erscheint rot.

6  UNBEFRISTETE VERTRÄGE
Lass das erste Vertragsende leer. Wähle bei „Kündbar zum“ den Termin, z. B. Quartalsende.
Das Register zeigt das früheste Ende bei einer Kündigung heute.

7  LEISTUNGEN
Im Vertrag der Reiter „Leistungen & Protokoll“. „+ Neu“ legt eine Leistung an.
Abdeckung: inklusive = im Preis enthalten. kostenpflichtig = wird extra verrechnet.
ausgeschlossen = nicht Teil des Vertrags.
Kostengrenze: nur bei inklusive. Bis zu diesem Betrag je Kalenderjahr ist die Leistung frei.
Erledigungszeit Soll: so viele Stunden hat der Partner nach der Meldung eines Leistungsanfalls Zeit, ihn zu erledigen.
Intervall: bei wiederkehrenden Leistungen, z. B. 6 für eine halbjährliche Wartung.
„Heute erbracht“ trägt die Leistung mit dem heutigen Datum ein. Daraus folgt die nächste Fälligkeit.
Der Eintrag bleibt mit „!“ offen, bis du ihn einmal ergänzt und sicherst („Offenen Eintrag öffnen ›“).
Eine neue Leistung legst du auch in der Ansicht „Leistungen“ an: „Neue Leistung“, dann den Vertrag wählen.
„Hinweis: Erledigungszeit im Detail prüfen“ heißt: Der Partner hat in den letzten 12 Monaten zu spät erledigt.
Der Tooltip nennt, wie oft. Der Hinweis zählt nicht als offene Aufgabe.
Die Spalte „!“ in der Liste der Vertragsleistungen: !! = dringend, ! = offen.
Ist bei einer Leistung eine Rechnung oder ein Leistungsanfall offen, führt „Offenen Eintrag öffnen ›“ direkt dorthin.
Ausgeschlossene Leistungen sind rot markiert („✕ ausgeschlossen“): dafür keine Rechnung freigeben.
Die Ansicht „Leistungen“ zeigt alle Leistungen aller Verträge.

8  PROTOKOLL UND RECHNUNGSPRÜFUNG
Die Ansicht „Rechnungsverlauf“ sammelt alle Ereignisse. „Neuer Eintrag“ legt eines an.
Wähle zuerst die Leistung und das Ereignis.
Leistung erbracht: Datum der Durchführung.
Leistungsanfall: Datum und Uhrzeit der Meldung und der Erledigung. Das Register vergleicht mit dem Soll.
Bleibt „Gemeldet am“ leer, gilt heute.
Reklamation: Datum und Beschreibung.
Rechnung erhalten: Datum = Rechnungsdatum. Trag Rechnungsnummer und Betrag ein.
Der Stand sagt, was zulässig ist:
  Zulässig – die Leistung ist kostenpflichtig.
  Über der Grenze – zulässig – die Kostengrenze des Jahres ist schon verbraucht.
  Verrechnet, obwohl inklusive – die Leistung ist im Preis enthalten.
  Teilweise inklusive – ein Teil liegt noch unter der Kostengrenze und ist nicht verrechenbar.
  Nicht im Vertrag – die Leistung ist ausgeschlossen. Prüfe, wer den Auftrag gegeben hat.
Freigabe: Trag Datum und Betrag ein. Gib höchstens den Betrag unter „Höchstens freigeben“ frei.
„Freigegeben von“ und „Beleg“ schlagen bisher benutzte Werte vor. Bleibt „Freigegeben von“ leer, gilt dein Name.
„Verwerfen“ erscheint, solange ein Eintrag ungesicherte Eingaben hat, und nimmt sie zurück.
Zurückgewiesene Rechnung: Freigegebener Betrag 0.
Eintrag falsch? Ändere den Wert (z. B. den Betrag) und klick auf „Korrigieren“. Nach der Rückfrage sichert das
Register die neuen Werte. Der bisherige Stand bleibt als stornierte Zeile (✕) erhalten; beide verweisen aufeinander.
Stellt der Partner eine Rechnung neu aus (neue Nummer): Trag in der alten Zeile die neue Rechnungsnummer und den
neuen Betrag ein und klick auf „Korrigieren“. Leg dafür keine neue Zeile an, sonst zählt der Betrag doppelt.
„Stornierte Einträge zeigen (✕)“ unter der Liste: Haken weg blendet stornierte Einträge aus.
Ein stornierter Eintrag zählt nicht zur Kostengrenze und ist nicht offen.
Stornieren ohne neuen Stand: roter Knopf „Stornieren“ unten links im Eintrag (mit Rückfrage, nicht umkehrbar).
Das Kästchen „Storniert“ lässt sich nicht von Hand setzen.
Die Spalte „!“ zeigt offene Einträge: !! = dringend, ! = offen.
„Offen“ zeigt, was noch zu tun ist, z. B. „Freigabe offen“ oder „ZU VIEL FREIGEGEBEN“.

9  DOKUMENTE UND ABLAGE
Jeder Vertrag hat einen Ordner im Ablagepfad: Vertragsnummer_Gegenstand_Partner,
z. B. 12_132_01_2023_Kaffeemaschine_MusterKaffeeservice.
Im Vertragsordner liegen die unterschriebenen Fassungen als PDF.
Unterordner: _bearbeitbar (Word-Fassungen), _korrespondenz (Briefe, Belege), _ersetzt (alte Fassungen).
Jeder Dateiname beginnt mit dem Datum: JJJJ-MM-TT_Name, z. B. 2026-03-01_Nachtrag-2.pdf.
Im Vertrag, Reiter „Dokumente & Verlauf“: Trag jede gültige Fassung ein und hake „Gilt“ an.
„Datei öffnen“ öffnet die markierte Datei. „Öffnen“ beim Ordnerfeld öffnet den Vertragsordner.

10  ABLAGE PRÜFEN
„Jetzt prüfen“ vergleicht den Ablagepfad mit dem Register und listet Abweichungen.
Die Vertragsordner liegen direkt im Ablagepfad, eine Ebene tief. Ihre Unterordner prüft das Register mit.
Gefunden werden:
Ordner ohne Vertrag, Vertrag ohne Ordner, Dateien ohne Datum, Dateien, die unter Dokumente fehlen,
neue Dateien seit der letzten Prüfung, fehlende Belege. Die Prüfung selbst ändert nichts.
Ein Doppelklick öffnet den Ordner oder die Datei.
Die Spalte „Wo“ sagt, wo zu handeln ist: intern = im Register, extern = in den Dateien.
Markiere eine Zeile: Unter der Liste steht der Vorschlag als Link. Intern setzt das Register ihn nach einer Rückfrage um
(z. B. „Heute geprüft“, Dokument eintragen). Extern öffnet der Link nur den Ordner; Dateien benennst und verschiebst du selbst.

11  TERMINE NACH HCL NOTES
„Termine (nach Notes) exportieren“ in der Übersicht schreibt alle Fristen in eine Kalenderdatei (.ics) im Ordner „Export“
neben dieser Datei: Stichtage mit Vorwarnung, Vertragsenden, Prüfungen, Indexanpassungen und
fällige Leistungen.
In HCL Notes: Kalender öffnen › Datei › Importieren › Dateityp iCalendar › Datei wählen.
Exportiere nach jeder größeren Änderung neu. Gleiche Termine haben dieselbe Kennung.
Unter Einstellungen › Termine nach Notes stellst du ein: Vorwarnung vor dem Stichtag in Tagen,
ganztägig oder zu einer Uhrzeit, und ob Notes vorher erinnert.

12  EXPORTIEREN
„Exportieren“ öffnet die Daten der aktuellen Ansicht als Tabelle in LibreOffice Calc.
Die Datei liegt im Ordner „Export“ neben dieser Datei. Speichere sie bei Bedarf als Excel-Datei.
„Statistik“ in der Übersicht erstellt eine Calc-Datei: Blatt „Daten“ (ein Vertrag je Zeile) und Blatt „Auswertung“
mit Pivot-Tabelle und Diagramm (Kosten je Vertragsart). Gliederung ändern: in die Tabelle klicken › Daten › Pivot-Tabelle ›
Bearbeiten, z. B. Partner oder Kostenstelle statt Vertragsart.

13  VERTRETUNG
Vor der Vertretung: Vertretung › Neue Vertretung. Trag ein, wer vertritt und von wann bis wann.
Arbeite die Checkliste ab. Schreib offene Punkte in den zweiten Reiter.
Nach der Rückgabe: Trag das Rückgabedatum ein. Der zweite Reiter zeigt alle Änderungen im Zeitraum.
Sieh sie durch und trag das Datum bei „Änderungen durchgesehen am“ ein.

14  ÄNDERUNGEN
Das Register zeichnet jede Änderung selbst auf: wer, wann, welches Feld, vorher und nachher.
Der Name kommt aus LibreOffice: Extras › Optionen › LibreOffice › Benutzerdaten.
Die Aufzeichnung lässt sich in der Oberfläche nicht abschalten oder löschen.

15  PAPIERKORB UND SICHERUNG
Papierkorb: Was du löschst, bleibt 90 Tage im Papierkorb (Seitenleiste › Papierkorb & Sicherung).
„Zurückholen“ stellt den Eintrag mit seiner alten Nummer wieder her, samt Leistungen und Protokoll.
„Endgültig löschen“ entfernt ihn sofort. Nach 90 Tagen löscht das Register ihn von selbst.
Sicherung: Sie läuft von selbst. Du musst nichts tun.
Spiegel: Nach dem Speichern (höchstens alle 2 Minuten) und beim Schließen kopiert das Register die ganze Datei
in den Sicherungsordner, abwechselnd als …_Spiegel_A.odb und …_Spiegel_B.odb. Einmal pro Woche prüft es
beim Schließen, ob sich der Spiegel öffnen lässt. Schlägt das fehl, meldet es sich beim nächsten Start.
Textsicherung: Beim Schließen schreibt das Register die Daten als Tabellen (CSV) in den Ordner „Text“:
alle 30 Tage einen Vollstand, sonst eine Tagesdatei mit den Änderungen seit dem Vollstand.
Es prüft jede Datei nach dem Schreiben. Tagesdateien bleiben 30 Tage, Vollstände etwa ein Jahr,
der erste Vollstand jedes Jahres bleibt immer.
Stand von Tag … zurückholen: Wähle den Tag und klick auf „Vergleichen“. Die Liste zeigt, was heute fehlt
oder anders ist. „Alle fehlenden zurückholen“ holt Fehlendes zurück und ändert nichts Bestehendes.
Für Geändertes hake „Zurück“ an und klick auf „Ausgewählte zurückholen“.
Notfall – die Datei lässt sich nicht mehr öffnen: Öffne im Sicherungsordner die neuere Spiegeldatei.
Sie fragt: „Als Register übernehmen?“ Bei Ja ersetzt sie die kaputte Datei; diese bleibt mit „_defekt“ liegen.
„Jetzt sichern“ schreibt Spiegel und Textsicherung sofort. Der Sicherungsordner ist einstellbar,
am besten auf einem anderen Laufwerk als das Register.
Liegen mehrere Registerdateien im selben Ordner, bekommt jede weitere einen eigenen Textordner „Text_<Dateiname>“.

16  EINSTELLUNGEN
Schwellen der Ampel (siehe Abschnitt 3), Prüfintervall, Ablagepfad, Sicherungsordner und Auswahllisten.
Auswahllisten: Zeile markieren. „+ Neu“ fragt nach dem neuen Wert für diese Liste. „Entfernen“ nimmt den Wert
aus der Auswahl; Einträge, die ihn tragen, behalten ihn. „▲“ und „▼“ ändern die Reihenfolge in der Auswahl.
Datumsanzeige: TT.MM.JJJJ, TT.MM.JJ oder JJJJ-MM-TT. Sie gilt nach dem Sichern sofort für alle Felder.
Die Werte gelten für alle, die mit dieser Datei arbeiten.

17  EINRICHTUNG AUF EINEM NEUEN PC
Das Register braucht Makros. LibreOffice führt sie nur in vertrauenswürdigen Ordnern aus.
Extras › Optionen › LibreOffice › Sicherheit › Makrosicherheit › Vertrauenswürdige Quellen ›
Vertrauenswürdige Speicherorte › Hinzufügen › den Ordner dieser Datei wählen › OK.
Danach die Datei neu öffnen. Die Anleitung „Einrichtung“ zeigt das mit Bildern.

18  WENN ETWAS NICHT GEHT
Fehler oder Wunsch melden: Klick links unten auf den Käfer, dann auf das Feld, den Knopf oder die
Liste, um die es geht. Schreib dazu, was falsch ist oder was anders sein soll, und klick auf „Speichern“.
Die Meldung landet in Meldungen/meldungen.txt neben dem Register, dazu ein Bild der Ansicht.
Ein zweiter Klick auf den Käfer bricht ab. Geht es um eine leere Fläche, klick ein Element daneben an und beschreib es.
Siehst du nur die Übersicht und die Knöpfe reagieren nicht, sind die Makros aus. Siehe Abschnitt 17.
Notweg ohne Makros: Im Fenster von LibreOffice Base links „Tabellen“ wählen. Dort lassen sich alle
Daten direkt ansehen und ändern. Die Prüfungen der Formulare laufen dann nicht.
Meldet das Register einen Fehler, schließe es und öffne es neu. Gespeicherte Daten bleiben erhalten.

19  GRENZEN
Das Register prüft keine Rechtslage. Es rechnet mit den eingetragenen Daten.
Die Datei ist für eine Person zur Zeit gedacht. Öffnen zwei Personen sie gleichzeitig, meldet
LibreOffice, dass sie gesperrt ist. Dann bitte warten, bis die andere Person sie geschlossen hat.
"""
