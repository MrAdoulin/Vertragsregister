REM V8 · Vertragsregister (LibreOffice Base): Ein-Fenster-Anwendung
REM Ein Formular „Vertragsregister" enthält alle Ansichten (Bereiche). Ein Wechsel blendet Steuerelemente ein und aus
REM (Modelleigenschaft EnableVisible) und tauscht die Seitenvorlage mit dem Kartenbild. Kein Fensterwechsel mehr.
REM Namen: <Bereich>_<Name>, z. B. LI_txtSuche. NA = Seitenleiste (immer sichtbar). VE gilt für VE1, VE2, VE3.
REM Regeln aus B1 (Windows-Tests 13.10.2026), weiter gültig:
REM  - Zustand steht in der Zusatzinformation (Tag) von Steuerelementen, nicht in Modulvariablen.
REM  - Nachgelagerte Schritte (AsyncCallback) bekommen alles über aData.
REM  - Im Startereignis kein Wait und kein „Minimized" (LibreOffice hing unter Windows).
REM  - Ein Makro am Schließen-Ereignis der .odb stürzt ab. V8 hängt am Schließen des Formulars (Versuch R3).
Option Explicit

Private Const FORM_APP = "Vertragsregister"
REM Wird beim Bau gefüllt: welches Formular Steuerelemente welcher Bereiche trägt (Formular:Bereich,…;…)
Private Const FORMBEREICHE = ""
Private Const EDITIERBAR = "Vertrag,Entscheidung,Dokumente,Leistung,Ereignis,Partner,Vertretung,Punkte,Einstellung,Listen"
REM V8.1-P3: kleinster Zoom in Prozent; darunter bleibt der Zoom stehen und Rollbalken erscheinen
Private Const MIN_ZOOM = 75
REM V8.1-P4: Tage im Papierkorb
Private Const PK_TAGE = 90
REM V8.1-P3: Beobachter müssen leben, solange das Register offen ist. Ausnahme von der Tag-Regel (Objekte, kein Text).
Global oZoomL As Object
Global oWaechter As Object
Global oWaechterDispatch As Object
Global oWaechterSlave As Object
Global oWaechterMaster As Object
REM V8.1-P6: Mausbeobachter beim Melden; Programmstand für Meldungen
Global oMeldenL As Object
REM V8.8 (ORI-04): Fenstertitel während des Starts
Global sStartTitel As String
Private Const VERSION = "V8.8c"

REM V8.1: Bauprüfung ruft diese Funktion auf; ein Syntaxfehler im Modul bricht dann schon den Bau ab
Function BauProbe() As Integer
	BauProbe = 1
End Function

REM ================================================================ Start und Ende
REM Ereignis „Dokument öffnen" der .odb
Sub AppStart(Optional oEvent)
	Dim oDb As Object, oC As Object
	On Error GoTo Rueckfall
	oDb = ThisDatabaseDocument
	oC = oDb.CurrentController
	If Not oC.isConnected() Then oC.connect()
	oC.loadComponent(com.sun.star.sdb.application.DatabaseObject.FORM, FORM_APP, False)
	oDb.setModified(False)
	Exit Sub
Rueckfall:
	On Error Resume Next
	ThisDatabaseDocument.FormDocuments.getByName(FORM_APP).open()
End Sub

REM Ereignis „Dokument öffnen" des Formulars: Leisten aus, ganze Seite, maximiert, Benutzer für die Änderungsspur.
Sub FormAnsicht(Optional oEvent)
	Dim oDoc As Object, oFr As Object, oNav As Object, oL As Object
	On Error Resume Next
	If IsMissing(oEvent) Then Exit Sub
	oDoc = oEvent.Source
	If oDoc.CurrentController.isFormDesignMode() Then Exit Sub
	oFr = oDoc.CurrentController.Frame
	REM V8.6e: Seite erst zeigen, wenn Leisten, Größe, Zoom und Lage fertig sind (Spaeter "FERTIG").
	REM Vorher sah man beim Start weißes Fenster, Entwurfsleisten und Geisterbilder (Windows-Test 16.10.).
	oFr.ComponentWindow.setVisible(False)
	REM V8.8 (ORI-04): Start dauert einige Sekunden – im Titel zeigen, dass gearbeitet wird
	sStartTitel = oFr.Title
	oFr.Title = "Vertragsregister wird geöffnet …"
	LeistenAus(oFr)
	oDoc.CurrentController.ViewSettings.ZoomType = com.sun.star.view.DocumentZoomType.PAGE_WIDTH_EXACT
	oFr.ContainerWindow.IsMaximized = True
	oNav = oDoc.DrawPage.Forms.getByName("Nav")
	oNav.getByName("NA_lblStatus").Tag = "app"
	BenutzerSetzen(oDoc)
	ZoomBeobachten(oDoc)
	oL = CreateUnoListener("StartNach_", "com.sun.star.awt.XCallback")
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Array(oDoc, oDoc.Parent))
End Sub

REM Nach dem Öffnen: Leisten noch einmal aus (Aktivieren blendet sie ein), Tagessicherung, Fokus.
Sub StartNach_notify(aData)
	Dim oDoc As Object, oDb As Object
	On Error Resume Next
	oDoc = aData(0)
	oDb = aData(1)
	LeistenAus(oDoc.CurrentController.Frame)
	FokusSetzen(oDoc, "ST")
	OdbWaechterAn(oDb)
	REM V8.1-P3 (Nico 14:34): Datenbankfenster im Hintergrund minimieren – erst hier, nicht im Startereignis (B1: Windows hing)
	If Not IstSpiegel(oDb) Then oDb.CurrentController.Frame.ContainerWindow.IsMinimized = True
	PapierkorbAufraeumen()
	MarkenAktualisieren()  ' V8.2a M08
	StatusTagesstand()  ' V8.3-E28
	AenderungBeobachten(oDoc)  ' V8.2b-M06
	DatumFormatSetzen(oDoc)    ' V8.4-E18
	Spaeter("FERTIG")  ' V8.6e: Leisten aus, Größe/Zoom/Lage, dann Seite zeigen (nach den anderen Start-Aufgaben)
	REM V8.1-P5: keine Vollkopie mehr beim Start; Spiegel und Textsicherung laufen nach dem Speichern und beim Schließen
	SpiegelUebernahmeFragen(oDb)
	ProbeWarnung(oDb)
	oDoc.setModified(False)
	oDb.setModified(False)
End Sub

REM Ereignis „Dokument wird geschlossen" des Formulars (X oder Beenden): danach die .odb schließen (Versuch R3).
Sub FormZu(Optional oEvent)
	Dim oL As Object
	On Error Resume Next
	If Not IsMissing(oEvent) Then
		REM Im Entwurfsmodus geöffnet: die .odb offen lassen
		If oEvent.Source.DrawPage.Forms.getByName("Nav").getByName("NA_lblStatus").Tag <> "app" Then Exit Sub
		REM V8.3-F2: Basic-Beobachter abmelden, bevor die Formulare abgeräumt werden (sonst Absturz beim Beenden, gdb 15.10.)
		TastenAus(oEvent.Source)  ' V8.8
		HoverAbmelden(oEvent.Source)  ' V8.7: Hover-Beobachter zuerst (V8.3-F2)
		AenderungAbmelden(oEvent.Source)
	End If
	oL = CreateUnoListener("Zu_", "com.sun.star.awt.XCallback")
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Array(ThisDatabaseDocument))
End Sub

REM V8.1-F2: offene Dokumente außer der .odb (Formular ist zu diesem Zeitpunkt schon geschlossen)
Function AndereDokumente(oDb As Object) As Integer
	Dim oEnum As Object, oC As Object, n As Integer
	On Error Resume Next
	oEnum = StarDesktop.Components.createEnumeration()
	Do While oEnum.hasMoreElements()
		oC = oEnum.nextElement()
		If Not EqualUnoObjects(oC, oDb) Then n = n + 1
	Loop
	AndereDokumente = n
End Function

Sub Zu_notify(aData)
	Dim oDb As Object, sProbe As String, oDisp As Object, oURL As New com.sun.star.util.URL, oT As Object
	Dim oDispQ As Object, oURLq As New com.sun.star.util.URL, aAsync(0) As New com.sun.star.beans.PropertyValue
	On Error Resume Next
	oDb = aData(0)
	REM V8.1-P5: Datenbankfenster ausblenden; die Sicherung läuft danach unsichtbar
	oDb.CurrentController.Frame.ContainerWindow.setVisible(False)
	oDb.store()
	sProbe = SicherungBeimSchliessen(oDb)
	oDb.setModified(False)
	REM V8.1-F2: Alles, was Basic braucht, läuft vor dem Schließen. Die .odb trägt dieses Makromodul;
	REM schließt sie, während Zu_notify noch läuft, stürzt LibreOffice beim Rücksprung ab [GEFUNDEN: gdb_ende_1.log].
	If sProbe <> "" Then SpiegelProbe(sProbe)
	oDb.CurrentController.Frame.releaseDispatchProviderInterceptor(oWaechter)
	REM V8.1-F2: Schließen in zwei Befehlen, beide ohne Warten und als Letztes:
	REM erst die .odb schließen (CloseWin), danach LibreOffice beenden (Quit, nachgelagert).
	REM Quit bei offener .odb bricht beim Trennen der Firebird-Datenbank ab [GEFUNDEN: gdb_q1.log].
	oT = createUnoService("com.sun.star.util.URLTransformer")
	oURL.Complete = ".uno:CloseWin"
	oT.parseStrict(oURL)
	oDisp = oDb.CurrentController.Frame.queryDispatch(oURL, "_self", 0)
	oURLq.Complete = ".uno:Quit"
	oT.parseStrict(oURLq)
	oDispQ = StarDesktop.queryDispatch(oURLq, "_self", 0)
	aAsync(0).Name = "SynchronMode"
	aAsync(0).Value = False
	oDisp.dispatch(oURL, Array())
	If AndereDokumente(oDb) = 0 Then oDispQ.dispatch(oURLq, aAsync())
End Sub

Sub AppBeenden(Optional oEvent)
	Dim oDoc As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	oDoc.CurrentController.Frame.close(True)
	Exit Sub
Fehler:
	Fehlermeldung("Beenden", Error$)
End Sub

REM ================================================================ V8.1-P3 Fenster
REM Zoom folgt der Fenstergröße (V8.6e: Seitenbreite exakt), aber nicht unter MIN_ZOOM. Ereignisse beim Ziehen werden gebündelt.
Sub ZoomBeobachten(oDoc As Object)
	On Error Resume Next
	oZoomL = CreateUnoListener("ZoomF_", "com.sun.star.awt.XWindowListener")
	oDoc.CurrentController.Frame.ContainerWindow.addWindowListener(oZoomL)
	REM V8.8 (KON-01): auch das Inhaltsfenster – eine eingeblendete Leiste (Strg+F-Suchleiste) verkleinert nur dieses
	oDoc.CurrentController.Frame.ComponentWindow.addWindowListener(oZoomL)
	ZoomAnpassen(oDoc)
End Sub

Sub ZoomF_windowResized(oEvent)
	Dim oL As Object, oNav As Object
	On Error Resume Next
	REM Marke im Tag: ein Anpassen ist schon unterwegs
	oNav = AppDoc().DrawPage.Forms.getByName("Nav")
	If oNav.getByName("NA_lblApp").HelpText = "zoom" Then Exit Sub
	oNav.getByName("NA_lblApp").HelpText = "zoom"
	oL = CreateUnoListener("ZoomS_", "com.sun.star.awt.XCallback")
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Array(AppDoc()))
End Sub

Sub ZoomS_notify(aData)
	On Error Resume Next
	aData(0).DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").HelpText = ""
	LeistenWeg(aData(0).CurrentController.Frame)  ' V8.8 (KON-01)
	ZoomAnpassen(aData(0))
End Sub

REM V8.6e: letzter Startschritt. Erst Leisten aus (sie kamen nach dem Minimieren der .odb wieder), dann Größe, Zoom
REM und Lage im verborgenen Fenster, zuletzt zeigen: ein einziges Zeichnen statt mehrerer Zwischenstände.
Sub StartFertig(oDoc As Object)
	Dim oFr As Object, r As Object, oCur As Object
	On Error Resume Next
	oFr = oDoc.CurrentController.Frame
	LeistenAus(oFr)
	REM V8.7 (HIL-01): Hinweiszeile an/aus aus den Dokumenteigenschaften; Zeile, Statuszeile und Seitenvorlage vor dem Zeigen
	AnzeigeLesen(oDoc.Parent)  ' V8.8c: Stufe, Farben, Tooltip-Verzögerung
	oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblHinweis").EnableVisible = Not bHwVoll
	AnzeigeZeigen(oDoc)
	If bHwVoll Then
		oCur = oDoc.Text.createTextCursor()
		oCur.PageDescName = "B_" & AktuellerBereich(oDoc) & "_voll"
	End If
	REM V8.6f: erst zeigen, dann Zoom und Neuzeichnen – umgekehrt blieb die Seite unter Windows leer (Test V8.6e)
	If sStartTitel <> "" Then oFr.Title = sStartTitel  ' V8.8 (ORI-04)
	oFr.ComponentWindow.setVisible(True)
	REM V8.6g: Neuzeichnen allein reichte nicht (V8.6f leer bis zur Größenänderung) → Größe kurz um 1 Punkt ändern
	r = oFr.ComponentWindow.getPosSize()
	oFr.ComponentWindow.setPosSize(r.X, r.Y, r.Width, r.Height - 1, com.sun.star.awt.PosSize.SIZE)
	oFr.ComponentWindow.setPosSize(r.X, r.Y, r.Width, r.Height, com.sun.star.awt.PosSize.SIZE)
	ZoomAnpassen(oDoc)
	oFr.ContainerWindow.invalidate(com.sun.star.awt.InvalidateStyle.CHILDREN + com.sun.star.awt.InvalidateStyle.UPDATE)
	oDoc.setModified(False)
	REM V8.7: Hover-Beobachter erst nach dem Zeigen und nur für den Startbereich (Versuch S0: alle auf einmal 611 ms)
	Spaeter("HW", AktuellerBereich(oDoc))
	TastenAn(oDoc)  ' V8.8: Tastenkürzel
End Sub

Sub ZoomAnpassen(oDoc As Object)
	Dim oVS As Object
	On Error Resume Next
	oVS = oDoc.CurrentController.ViewSettings
	BreiteAnpassen(oDoc)  ' V8.4-E17: Seitenverhältnis wie das Fenster
	LageHerstellen(oDoc)  ' V8.6
	REM V8.6e: Seitenbreite exakt – Seite hat das Fensterformat und liegt randlos im Fenster (vorher ganze Seite mit Rand)
	oVS.ZoomType = com.sun.star.view.DocumentZoomType.PAGE_WIDTH_EXACT
	If oVS.ZoomValue < MIN_ZOOM Then
		oVS.ZoomType = com.sun.star.view.DocumentZoomType.BY_VALUE
		oVS.ZoomValue = MIN_ZOOM
	End If
	REM Steuerelemente nach dem Zoomwechsel vollständig neu zeichnen
	oDoc.CurrentController.Frame.ComponentWindow.invalidate(com.sun.star.awt.InvalidateStyle.CHILDREN + com.sun.star.awt.InvalidateStyle.UPDATE)
End Sub

Sub ZoomF_windowMoved(oEvent)
End Sub
Sub ZoomF_windowShown(oEvent)
End Sub
Sub ZoomF_windowHidden(oEvent)
End Sub
Sub ZoomF_disposing(oEvent)
End Sub

REM Schließen des Datenbankfensters (X, Strg+W, Datei › Schließen/Beenden) fragt nach und beendet dann wie „Beenden".
REM Basic kann ein Schließen nicht abbrechen; ein Abfangen der Befehle am Fenster der .odb kann es (Versuch P3).
Sub OdbWaechterAn(oDb As Object)
	On Error Resume Next
	oWaechter = CreateUnoListener("OdbW_", "com.sun.star.frame.XDispatchProviderInterceptor")
	oWaechterDispatch = CreateUnoListener("OdbD_", "com.sun.star.frame.XDispatch")
	oDb.CurrentController.Frame.registerDispatchProviderInterceptor(oWaechter)
End Sub

Function IstSchliessBefehl(s As String) As Boolean
	Select Case s
		Case ".uno:CloseFrame", ".uno:CloseWin", ".uno:CloseDoc", ".uno:Quit"
			IstSchliessBefehl = True
		Case Else
			IstSchliessBefehl = False
	End Select
End Function

Function OdbW_queryDispatch(oURL, sZiel, nFlags)
	If IstSchliessBefehl(oURL.Complete) Then
		OdbW_queryDispatch = oWaechterDispatch
	ElseIf IsNull(oWaechterSlave) Then
		OdbW_queryDispatch = Nothing
	Else
		OdbW_queryDispatch = oWaechterSlave.queryDispatch(oURL, sZiel, nFlags)
	End If
End Function

Function OdbW_queryDispatches(aAnfragen)
	Dim a(), i As Integer
	If UBound(aAnfragen) < 0 Then
		OdbW_queryDispatches = a
		Exit Function
	End If
	ReDim a(UBound(aAnfragen))
	For i = 0 To UBound(aAnfragen)
		a(i) = OdbW_queryDispatch(aAnfragen(i).FeatureURL, aAnfragen(i).FrameName, aAnfragen(i).SearchFlags)
	Next i
	OdbW_queryDispatches = a
End Function

Function OdbW_getSlaveDispatchProvider()
	OdbW_getSlaveDispatchProvider = oWaechterSlave
End Function
Sub OdbW_setSlaveDispatchProvider(o)
	oWaechterSlave = o
End Sub
Function OdbW_getMasterDispatchProvider()
	OdbW_getMasterDispatchProvider = oWaechterMaster
End Function
Sub OdbW_setMasterDispatchProvider(o)
	oWaechterMaster = o
End Sub
Sub OdbW_disposing(oEvent)
End Sub

Sub OdbD_dispatch(oURL, aArgs)
	On Error Resume Next
	If MsgBox("Das schließt das Vertragsregister ganz." & Chr(10) & "Fortsetzen?", 4 + 32 + 256, "Vertragsregister") = 6 Then
		AppBeenden()
	End If
End Sub
Sub OdbD_addStatusListener(oL, oURL)
End Sub
Sub OdbD_removeStatusListener(oL, oURL)
End Sub

REM V8.8 (KON-01): einzelne sichtbare Leisten ausblenden (z. B. Suchleiste nach Strg+F aus einem Menü). Ohne Umschalten
REM wie LeistenAus, sonst löste das Ein-/Ausblenden selbst wieder eine Größenänderung aus.
Sub LeistenWeg(oFr As Object)
	Dim oLM As Object, a, i As Integer
	On Error Resume Next
	oLM = oFr.LayoutManager
	a = oLM.getElements()
	For i = 0 To UBound(a)
		If oLM.isElementVisible(a(i).ResourceURL) Then oLM.hideElement(a(i).ResourceURL)
	Next i
End Sub

REM B1.1-R1: HideCurrentUI (Menü) und Visible (Symbolleisten) wirken nur bei einer Änderung. Deshalb umschalten.
Sub LeistenAus(oFr As Object)
	Dim oLM As Object
	On Error Resume Next
	oLM = oFr.LayoutManager
	oLM.HideCurrentUI = False
	oLM.HideCurrentUI = True
	oLM.Visible = True
	oLM.Visible = False
End Sub

REM Benutzer aus den LibreOffice-Benutzerdaten als Sitzungsvariable für die Änderungsspur (V8-R4).
Sub BenutzerSetzen(oDoc As Object)
	Dim oNav As Object, s As String, oRs As Object
	On Error Resume Next
	s = Benutzer()
	oNav = oDoc.DrawPage.Forms.getByName("Nav")
	oRs = oNav.ActiveConnection.createStatement().executeQuery( _
		"SELECT RDB$SET_CONTEXT('USER_SESSION', 'BENUTZER', '" & Esc(s) & "') FROM RDB$DATABASE")
	REM Die Ergebniszeile muss abgeholt werden, sonst wirkt die Variable nicht
	oRs.next()
	oNav.getByName("NA_lblBenutzer").Label = "Angemeldet als " & s
	Fm(oDoc, "Einstellung").getByName("EI_lblName").Label = s
End Sub

Sub KeineSpur(oCon As Object, b As Boolean)
	Dim oRs As Object
	oRs = oCon.createStatement().executeQuery("SELECT RDB$SET_CONTEXT('USER_SESSION', 'KEINE_SPUR', " & _
		IIf(b, "'1'", "NULL") & ") FROM RDB$DATABASE")
	oRs.next()
End Sub

REM ================================================================ Bereiche
Function AktuellerBereich(oDoc As Object) As String
	AktuellerBereich = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag
End Function

Function Sichtbar(p As String, s As String) As Boolean
	Sichtbar = (p = "NA") Or (p = s) Or (Len(p) = 2 And Len(s) = 3 And Left(s, 2) = p)
End Function

REM Wechselt in den Bereich sNeu. Speichert vorher alle offenen Eingaben; lehnt eine Prüfung ab, bleibt die Ansicht.
REM bSpeichern = False: ohne Speichern wechseln (z. B. „Neuer Partner" aus einem noch ungespeicherten Vertrag).
Function Bereich(oDoc As Object, sNeu As String, Optional bSpeichern) As Boolean
	Dim oInfo As Object, sAlt As String, i As Integer, oCur As Object, sForm As String, bS As Boolean
	Bereich = False
	bS = True
	If Not IsMissing(bSpeichern) Then bS = bSpeichern
	oInfo = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp")
	sAlt = oInfo.Tag
	If bS Then
		If Not AlleSpeichernIn(oDoc, sForm) Then
			REM V8.8 (KON-04): Ausweg statt Sackgasse – nach der Pflichtfeld-Meldung anbieten, zu verwerfen und zu wechseln
			If sForm <> "" And sNeu <> sAlt And Left(FormBereich(sForm), 2) = Left(sAlt, 2) Then
				If MsgBox("Die Eingaben hier sind noch nicht gespeichert." & Chr(10) & Chr(10) & _
					"Verwerfen und die andere Ansicht öffnen?" & Chr(10) & "„Nein“ bleibt hier, damit du ergänzen kannst.", _
					4 + 32 + 256, "Vertragsregister") = 6 Then
					Verwerfen(oDoc, Fm(oDoc, sForm))
					REM V8.8b: nachgelagert wechseln – direkt danach wechselte die Ansicht nicht (Windows-Test 16.10.)
					Spaeter("BEREICH", sNeu)
					Exit Function
				End If
			End If
			REM Die abgelehnte Eingabe liegt in einem anderen Bereich: dorthin wechseln, damit sie sichtbar ist
			If sForm <> "" And Left(FormBereich(sForm), 2) <> Left(sAlt, 2) Then Bereich(oDoc, FormBereich(sForm), False)
			Exit Function
		End If
	End If
	If sAlt <> sNeu Then
		REM Nur Formulare durchgehen, die Steuerelemente des alten oder neuen Bereichs tragen
		Dim a, sE As String, sB As String, k As Integer
		a = Split(FORMBEREICHE, ";")
		For i = 0 To UBound(a)
			sE = a(i)
			k = InStr(sE, ":")
			sB = "," & Mid(sE, k + 1) & ","
			If InStr(sB, "," & sAlt & ",") > 0 Or InStr(sB, "," & sNeu & ",") > 0 Or InStr(sB, "," & Left(sAlt, 2) & ",") > 0 _
				Or InStr(sB, "," & Left(sNeu, 2) & ",") > 0 Then Zweig(Fm(oDoc, Left(sE, k - 1)), sAlt, sNeu)
		Next i
		oCur = oDoc.Text.createTextCursor()
		oCur.PageDescName = "B_" & sNeu & HwSuffix()  ' V8.7: _voll bei abgeschalteter Hinweiszeile
		NavMarkieren(oDoc, NavCode(sAlt), NavCode(sNeu))
		If Len(sNeu) = 3 Then TabMarkieren(oDoc, sNeu)
		oInfo.Tag = sNeu
		HinweisBereichNeu(oDoc)  ' V8.7 (ORI-01): Meldung der vorigen Ansicht sofort weg
	End If
	BereichLaden(oDoc, sNeu)
	REM V8.2b-M19/M06: nachgelagert, damit die Ansicht sofort bedienbar ist (flow3: Klick nach 0,8 s ging verloren)
	Spaeter("H")
	Spaeter("S")
	Spaeter("HW", sNeu)  ' V8.7: Hover-Beobachter des Bereichs, To Do
	oDoc.setModified(False)
	FokusSetzen(oDoc, sNeu)
	Bereich = True
End Function

REM Formularnamen haben keinen Unterstrich, Steuerelemente immer (<Bereich>_<Name>). Das spart die Dienstabfrage.
Sub Zweig(oF As Object, sAlt As String, sNeu As String)
	Dim j As Integer, m As Object, p As String, b As Boolean, k As Integer, sN As String
	For j = 0 To oF.Count - 1
		m = oF.getByIndex(j)
		sN = m.Name
		k = InStr(sN, "_")
		If k > 1 Then
			p = Left(sN, k - 1)
			b = Sichtbar(p, sNeu)
			If b <> Sichtbar(p, sAlt) Then m.EnableVisible = b
		End If
	Next j
End Sub

REM Welcher Seitenleisten-Eintrag leuchtet: der Vertrag gehört zu „Verträge".
Function NavCode(s As String) As String
	NavCode = Left(s, 2)
	If NavCode = "VE" Then NavCode = "LI"
End Function

Sub NavMarkieren(oDoc As Object, sAlt As String, sNeu As String)
	Dim oNav As Object
	On Error Resume Next
	oNav = oDoc.DrawPage.Forms.getByName("Nav")
	If sAlt <> sNeu Then
		With oNav.getByName("NA_nav" & sAlt)
			.BackgroundColor = RGB(255, 255, 255) : .TextColor = RGB(28, 28, 30) : .FontWeight = 100
		End With
	End If
	With oNav.getByName("NA_nav" & sNeu)
		.BackgroundColor = RGB(229, 241, 255) : .TextColor = RGB(0, 122, 255) : .FontWeight = 150
	End With
End Sub

Sub TabMarkieren(oDoc As Object, s As String)
	Dim oF As Object, i As Integer, oB As Object
	On Error Resume Next
	oF = Fm(oDoc, IIf(Left(s, 2) = "VE", "Vertrag", "Vertretung"))
	For i = 1 To 4
		REM V8.3-LEC: der vierte Reiter heißt VEt_tab4
		If oF.hasByName(Left(s, 2) & IIf(i = 4, "t", "") & "_tab" & i) Then
			oB = oF.getByName(Left(s, 2) & IIf(i = 4, "t", "") & "_tab" & i)
			If CStr(i) = Right(s, 1) Then
				oB.BackgroundColor = RGB(0, 122, 255) : oB.TextColor = RGB(255, 255, 255) : oB.FontWeight = 150
			Else
				oB.BackgroundColor = RGB(229, 229, 234) : oB.TextColor = RGB(110, 110, 115) : oB.FontWeight = 100
			End If
		End If
	Next i
End Sub

REM Beim Betreten eines Bereichs die Daten frisch laden (Kennzahlen, Listen, berechnete Werte).
Sub BereichLaden(oDoc As Object, s As String)
	Dim oF As Object
	On Error Resume Next
	Select Case s
		Case "ST"
			Fm(oDoc, "Nav").reload()
			Fm(oDoc, "Heute").reload()
			Fm(oDoc, "Fristen").reload()
		Case "LI"
			Fm(oDoc, "Liste").reload()
		Case "VE1"
			Fm(oDoc, "Info").reload()
			Fm(oDoc, "Vertrag").getByName("VE1_lbPartner").refresh()
			Fm(oDoc, "Vertrag").getByName("VE1_lbErsetzt").refresh()
		Case "VE2"
			Fm(oDoc, "LeistungInfo").reload()
			Fm(oDoc, "LeistungProt").reload()
		Case "VE3"
			Fm(oDoc, "Verlauf").reload()
		Case "LE"
			Fm(oDoc, "Leistungen").reload()
		Case "PR"
			Fm(oDoc, "Ereignis").getByName("PR_lbLeistung").refresh()
			Fm(oDoc, "Protokoll").reload()
		Case "PA"
			Fm(oDoc, "PartnerVertraege").reload()
			Spaeter("PAA")  ' V8.3-E29: nachgelagert, die Ansicht ist sofort bedienbar
		Case "VT1", "VT2"
			Fm(oDoc, "VtAenderung").reload()
		Case "AE"
			Fm(oDoc, "Aenderungen").reload()
		Case "AB"
			Fm(oDoc, "Abgleich").reload()
			AbgleichInfo(oDoc)
		Case "PK"
			Fm(oDoc, "Papierkorb").reload()
			Fm(oDoc, "Vergleich").reload()
			SicherungInfo(oDoc)
		Case "EI"
			Fm(oDoc, "Einstellung").reload()
	End Select
	If Left(s, 2) <> "ST" Then Fm(oDoc, "Nav").reload()
End Sub

Sub FokusSetzen(oDoc As Object, s As String)
	Dim sForm As String, sName As String
	On Error Resume Next
	Select Case s
		Case "ST" : sForm = "Nav" : sName = "NA_navST"
		Case "LI" : sForm = "Liste" : sName = "LI_txtSuche"
		Case "VE1" : sForm = "Vertrag" : sName = "VE_txtGegenstand"
		Case "VE2" : sForm = "Leistung" : sName = "VE2_gridLeistung"
		Case "VE3" : sForm = "Dokumente" : sName = "VE3_gridDok"
		Case "LE" : sForm = "Leistungen" : sName = "LE_txtSuche"
		Case "PR" : sForm = "Protokoll" : sName = "PR_txtSuche"
		Case "PA" : sForm = "PartnerAktiv" : sName = "PA_gridPartner"
		Case "VT1" : sForm = "Vertretung" : sName = "VT_gridVertretung"
		Case "VT2" : sForm = "Punkte" : sName = "VT2_gridPunkte"
		Case "AE" : sForm = "Aenderungen" : sName = "AE_txtSuche"
		Case "AB" : sForm = "Abgleich" : sName = "AB_gridAbgleich"
		Case "PK" : sForm = "Papierkorb" : sName = "PK_gridPapierkorb"
		Case "EI" : sForm = "Einstellung" : sName = "EI_txtAblage"
		Case "HI" : sForm = "Nav" : sName = "HI_txtAnleitung"
		Case "GS" : sForm = "Treffer" : sName = "GS_gridTreffer"
	End Select
	If sForm <> "" Then oDoc.CurrentController.getControl(Fm(oDoc, sForm).getByName(sName)).setFocus()
End Sub

REM In welchem Bereich steht ein bearbeitbares Formular?
Function FormBereich(sForm As String) As String
	Select Case sForm
		Case "Vertrag", "Entscheidung" : FormBereich = "VE1"
		Case "Leistung" : FormBereich = "VE2"
		Case "Dokumente" : FormBereich = "VE3"
		Case "Ereignis" : FormBereich = "PR"
		Case "Partner" : FormBereich = "PA"
		Case "Vertretung" : FormBereich = "VT1"
		Case "Punkte" : FormBereich = "VT2"
		Case "Einstellung", "Listen" : FormBereich = "EI"
		Case Else : FormBereich = "ST"
	End Select
End Function

REM Seitenleiste
Sub NavStart(Optional oEvent)
	Gehe("ST")
End Sub
Sub NavListe(Optional oEvent)
	Gehe("LI")
End Sub
Sub NavLeistung(Optional oEvent)
	Gehe("LE")
End Sub
Sub NavProtokoll(Optional oEvent)
	Gehe("PR")
End Sub
Sub NavPartner(Optional oEvent)
	Gehe("PA")
End Sub
Sub NavVertretung(Optional oEvent)
	Gehe("VT1")
End Sub
Sub NavAenderung(Optional oEvent)
	Gehe("AE")
End Sub
Sub NavPapierkorb(Optional oEvent)
	Gehe("PK")
End Sub
Sub NavAbgleich(Optional oEvent)
	Gehe("AB")
End Sub
Sub NavEinstellung(Optional oEvent)
	Gehe("EI")
End Sub
Sub NavHilfe(Optional oEvent)
	Gehe("HI")
End Sub

Sub Gehe(s As String)
	On Error GoTo Fehler
	Bereich(AppDoc(), s)
	Exit Sub
Fehler:
	Fehlermeldung("Ansicht wechseln", Error$)
End Sub

REM ================================================================ Speichern
REM Speichert alle bearbeitbaren Formulare. sForm liefert den Namen des Formulars, dessen Prüfung abgelehnt hat.
Function AlleSpeichernIn(oDoc As Object, Optional sForm) As Boolean
	Dim a, i As Integer, oF As Object
	AlleSpeichernIn = True
	FokusWeg(oDoc)
	a = Split(EDITIERBAR, ",")
	For i = 0 To UBound(a)
		oF = Fm(oDoc, a(i))
		If Not IsNull(oF) Then
			If oF.isLoaded() Then
				REM V8.2c-N11: angefangene neue Entscheidung ohne Art blockiert nichts; sie wird still verworfen
				If a(i) = "Entscheidung" Then
					If oF.IsNew And oF.IsModified Then
						If LeereEntscheidung(oF) Then Verwerfen(oDoc, oF)
					End If
				End If
				If Not Speichern(oDoc, oF, True) Then
					AlleSpeichernIn = False
					If Not IsMissing(sForm) Then sForm = a(i)
					Exit Function
				End If
			End If
		End If
	Next i
End Function

REM V8: Die Knöpfe nehmen keinen Fokus. Das Feld mit der Schreibmarke übernimmt seinen Wert erst, wenn es den Fokus
REM verliert (Xvfb-Test: Rechnungsbetrag „100" fehlte beim Sichern). Deshalb vor dem Speichern den Fokus wegnehmen.
REM Das Feld mit der Schreibmarke übernimmt seinen Wert (commit). Die Knöpfe nehmen keinen Fokus; ohne Übernahme fehlte
REM der zuletzt getippte Wert (Xvfb-Test J). Kein Fokuswechsel: Verlässt der Fokus ein Formular, speichert Base es ein
REM zweites Mal (Test K). Nur das fokussierte Feld: ein Sammel-commit schrieb nach dem Verwerfen veraltete Werte in den
REM aktuellen Datensatz (Test Verwerfen, Partnername leer).
Sub FokusWeg(oDoc As Object)
	Dim sB As String, a, i As Integer, sE As String, k As Integer, oF As Object, j As Integer, m As Object, n As Integer
	Dim oC As Object
	On Error Resume Next
	AuswahlUebernehmen(oDoc)  ' V8.8 (EIN-01)
	sB = AktuellerBereich(oDoc)
	a = Split(FORMBEREICHE, ";")
	For i = 0 To UBound(a)
		sE = a(i)
		k = InStr(sE, ":")
		If InStr("," & Mid(sE, k + 1) & ",", "," & sB & ",") > 0 Or InStr("," & Mid(sE, k + 1) & ",", "," & Left(sB, 2) & ",") > 0 Then
			oF = Fm(oDoc, Left(sE, k - 1))
			If oF.AllowUpdates Or oF.AllowInserts Then
				For j = 0 To oF.Count - 1
					m = oF.getByIndex(j)
					n = InStr(m.Name, "_")
					If n > 1 Then
						If Sichtbar(Left(m.Name, n - 1), sB) Then
							oC = oDoc.CurrentController.getControl(m)
							If Not IsNull(oC) Then
								If oC.hasFocus() Then
									If HasUnoInterfaces(oC, "com.sun.star.form.XBoundComponent") Then
										oC.commit()
									ElseIf HasUnoInterfaces(m, "com.sun.star.form.XBoundComponent") Then
										m.commit()
									End If
									Exit Sub
								End If
							End If
						End If
					End If
				Next j
			End If
		End If
	Next i
End Sub

REM V8.8 (EIN-01): Ein in der Klappliste gewählter Partner zählte beim Sichern erst nach Tab (UX-Test 16.10.).
REM Auswahlfelder der Ansicht übernehmen, deren Auswahl vom Wert im Datensatz abweicht – nur dann, damit kein
REM veralteter Wert geschrieben wird (Grund für „nur das fokussierte Feld“ in FokusWeg).
Sub AuswahlUebernehmen(oDoc As Object)
	Dim sB As String, a, i As Integer, sE As String, k As Integer, oF As Object, j As Integer, m As Object, n As Integer
	Dim sNeu As String, sAlt As String
	On Error Resume Next
	sB = AktuellerBereich(oDoc)
	a = Split(FORMBEREICHE, ";")
	For i = 0 To UBound(a)
		sE = a(i)
		k = InStr(sE, ":")
		If InStr("," & Mid(sE, k + 1) & ",", "," & sB & ",") > 0 Or InStr("," & Mid(sE, k + 1) & ",", "," & Left(sB, 2) & ",") > 0 Then
			oF = Fm(oDoc, Left(sE, k - 1))
			If oF.AllowUpdates Or oF.AllowInserts Then
				For j = 0 To oF.Count - 1
					m = oF.getByIndex(j)
					n = InStr(m.Name, "_")
					If n > 1 Then
						If m.supportsService("com.sun.star.form.component.ListBox") And m.DataField <> "" And _
							m.getPropertySetInfo().hasPropertyByName("SelectedValue") Then
							If Sichtbar(Left(m.Name, n - 1), sB) Then
								sNeu = "" : sAlt = ""
								sNeu = CStr(m.SelectedValue)
								sAlt = oF.Columns.getByName(m.DataField).getString()
								If sNeu <> sAlt Then m.commit()
							End If
						End If
					End If
				Next j
			End If
		End If
	Next i
End Sub

REM Übernimmt das gerade bearbeitete Feld und speichert den Datensatz. False, wenn die Prüfung ablehnt.
Function Speichern(oDoc As Object, oF As Object, Optional bOhneFokus) As Boolean
	Dim oFC As Object, bNeu As Boolean
	Speichern = True
	If IsMissing(bOhneFokus) Then FokusWeg(oDoc)
	On Error GoTo Fehler
	oFC = oDoc.CurrentController.getFormController(oF)
	If Not IsNull(oFC) Then
		Speichern = oFC.FormOperations.commitCurrentRecord(bNeu)
	ElseIf oF.IsModified Then
		If oF.IsNew Then oF.insertRow() Else oF.updateRow()
	End If
	Exit Function
Fehler:
	Speichern = False
	REM Eine Prüfung hat abgelehnt und ihre Meldung schon gezeigt (RowSetVetoException): keine zweite Meldung
	If InStr(Error$, "RowSetVetoException") > 0 Or InStr(Error$, "vetoed") > 0 Then Exit Function
	REM Datenbankfehler hat das Formularereignis „Fehler aufgetreten" schon verständlich gemeldet (DbFehler)
	If InStr(Error$, "SQLException") > 0 Or InStr(Error$, "firebird") > 0 Or InStr(Error$, "Error inserting") > 0 _
		Or InStr(Error$, "Error updating") > 0 Then Exit Function
	Fehlermeldung("Speichern (" & oF.Name & ")", Error$ & " (Zeile " & Erl & ")")
End Function

REM Knopf „Sichern": speichert die Formulare der aktuellen Ansicht. Ein Vertragsentwurf, der auf einen neuen Partner
REM wartet, bleibt dabei unberührt (V8-Test: Sichern im Partner versuchte den Vertrag ohne Partner zu speichern).
Function BereichSpeichern(oDoc As Object, sBereich As String) As Boolean
	Dim a, i As Integer, oF As Object
	BereichSpeichern = True
	FokusWeg(oDoc)
	a = Split(EDITIERBAR, ",")
	For i = 0 To UBound(a)
		If Left(FormBereich(a(i)), 2) = Left(sBereich, 2) Then
			oF = Fm(oDoc, a(i))
			If oF.isLoaded() Then
				If Not Speichern(oDoc, oF, True) Then
					BereichSpeichern = False
					Exit Function
				End If
			End If
		End If
	Next i
End Function

Sub AlleSichern(Optional oEvent)
	Dim oDoc As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If BereichSpeichern(oDoc, AktuellerBereich(oDoc)) Then
		DbDoc().store()
		StatusSetzen(oDoc, "Gespeichert um " & Format(Now(), "hh:mm"))
		BereichLaden(oDoc, AktuellerBereich(oDoc))
	End If
	Exit Sub
Fehler:
	Fehlermeldung("Sichern", Error$)
End Sub

REM Base schreibt die Daten erst beim Speichern der .odb in die Datei. Deshalb nach jedem Datensatz speichern.
Sub NachDatensatz(Optional oEvent)
	Gespeichert()
End Sub

Sub Gespeichert()
	On Error Resume Next
	MarkenAktualisieren()  ' V8.2a M08
	DbDoc().store()
	StatusSetzen(AppDoc(), "Gespeichert")  ' V8.8c: Uhrzeit steht davor
	SpiegelNachSpeichern(AppDoc())
	Spaeter("S")  ' V8.4-P04: Knöpfe (Sichern/Verwerfen/Löschen) nach jedem Speichern
End Sub

REM V8.7 (ORI-01): Ergebnis in die Hinweiszeile; bei abgeschalteter Zeile wie früher links unten (zweizeilig)
Sub StatusSetzen(oDoc As Object, s As String)
	On Error Resume Next
	If bHwVoll Then
		REM V8.8c (M13): mit Uhrzeit, damit klar ist, wann es geschah
		oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblStatus").Label = IIf(s = "", "", Format(Now(), "hh:mm") & "  " & s)
	Else
		HinweisSetzen(oDoc, s, 1)
	End If
End Sub

REM B1-R16: Ein Raster setzt den Cursor nach dem Öffnen manchmal zurück. Deshalb prüfen und notfalls wiederholen.
Sub NeueZeile(oF As Object)
	Dim i As Integer
	For i = 1 To 4
		If Not oF.IsNew Then oF.moveToInsertRow()
		Wait 60
		If oF.IsNew Then Exit Sub
	Next i
End Sub

REM Neuen oder geänderten Datensatz verwerfen („Löschen" bei einem neuen Eintrag).
Sub Verwerfen(oDoc As Object, oF As Object)
	Dim oFC As Object
	On Error Resume Next
	oFC = oDoc.CurrentController.getFormController(oF)
	oFC.FormOperations.execute(com.sun.star.form.runtime.FormFeature.UndoRecordChanges)
	If oF.IsNew Then
		oF.moveToCurrentRow()
		REM Neu laden, damit die Felder wieder den gespeicherten Datensatz zeigen (sonst bleiben sie leer)
		oF.reload()
	End If
	StatusSetzen(oDoc, "Eingabe verworfen")
End Sub

REM Zusatz zur Pflichtfeld-Meldung bei neuen Einträgen: wie man ihn wieder los wird.
Function NeuHinweis(oEvent, Optional bRaster) As String
	NeuHinweis = ""
	On Error Resume Next
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.INSERT Then
		If IsMissing(bRaster) Then
			NeuHinweis = Chr(10) & Chr(10) & "Doch keinen neuen Eintrag? Der rote Knopf „Verwerfen“ verwirft ihn."  ' V8.8 (KON-02)
		Else
			NeuHinweis = Chr(10) & Chr(10) & "Doch keine neue Zeile? Die Taste Esc verwirft sie."
		End If
	End If
End Function

REM Nachgelagert neu laden: Ein Formular darf in „nach Datensatzaktion" nicht selbst neu laden (blockiert).
Sub Spaeter(sWas As String, Optional v1)
	Dim oL As Object, w
	w = Empty
	If Not IsMissing(v1) Then w = v1
	oL = CreateUnoListener("Spaeter_", "com.sun.star.awt.XCallback")
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Array(sWas, AppDoc(), DbDoc(), w))
End Sub

Sub Spaeter_notify(aData)
	Dim oDoc As Object
	On Error Resume Next
	oDoc = aData(1)
	Select Case aData(0)
		Case "H"
			HAktualisieren(oDoc)  ' V8.2b-M19
			DienstReiterZeigen(oDoc)  ' V8.3-LEC
			TodoBestimmen(oDoc)  ' V8.7: Datensatz gewechselt
		Case "HW"
			HinweisBereich(oDoc, aData(3))  ' V8.7
		Case "TODO"
			TodoBestimmen(oDoc)  ' V8.7
		Case "TASTE"
			TasteAusfuehren(oDoc, aData(3))  ' V8.8
		Case "PFOKUS"
			PflichtFokusSetzen(oDoc, aData(3))  ' V8.8 (KON-02)
		Case "BEREICH"
			Bereich(oDoc, aData(3))  ' V8.8b (KON-04)
		Case "EINGABE"
			EingabeZurueck(oDoc, aData(3))  ' V8.8 (EIN-02, EIN-04)
		Case "PA"
			PartnerListenNeu(oDoc)  ' V8.3-E29
		Case "PAA"
			PartnerAnsicht(oDoc)
		Case "PAK"
			PartnerListeAbgleichen(oDoc, aData(3))
		Case "S"
			SichernFarbe(oDoc)    ' V8.2b-M06
			TodoBestimmen(oDoc)   ' V8.7: geändert/gespeichert
		Case "P"
			PartnerStand(oDoc)    ' V8.4-P03
		Case "D"
			DatumFormatSetzen(oDoc)  ' V8.4-E18
		Case "LM"
			LeistungListeNeu(oDoc)  ' V8.5-Q2
		Case "PRZ"
			ProtokollNeuLaden(oDoc, aData(3))  ' V8.6b
		Case "LAGE"
			LageHerstellen(oDoc)  ' V8.6
		Case "FERTIG"
			StartFertig(oDoc)  ' V8.6e
		Case "PRG"
			RasterNeuZeichnen(oDoc, "Protokoll", "PR_gridProtokoll")  ' V8.5-Q4
		Case "GS"
			GesamtSuchen(oDoc, aData(3))  ' V8.5-E23
		Case "PAAUF"
			PartnerAuf(oDoc, aData(3))  ' V8.5-E23: nach PartnerAnsicht
		Case "Vertrag"
			Fm(oDoc, "Info").reload()
			Fm(oDoc, "Verlauf").reload()
			Fm(oDoc, "Vertrag").getByName("VE1_lbErsetzt").refresh()
			PositionZeigen(oDoc)
		Case "Leistung"
			Fm(oDoc, "LeistungInfo").reload()
			Fm(oDoc, "LeistungProt").reload()
			Fm(oDoc, "Ereignis").getByName("PR_lbLeistung").refresh()
		Case "Ereignis"
			Fm(oDoc, "EreignisInfo").reload()
			ProtokollNeuLaden(oDoc, aData(3))
		Case "Vertretung"
			Fm(oDoc, "VtAenderung").reload()
	End Select
	oDoc.setModified(False)
	aData(2).setModified(False)
End Sub

REM ================================================================ Hilfen
REM V8: ThisComponent zeigt nach dem Speichern der .odb nicht mehr verlässlich auf das Formular (Xvfb-Test, Schritt I).
REM Deshalb das Formular über seine Bestandteile suchen: Textdokument mit den Formularen Nav und Vertrag.
Function AppDoc() As Object
	Dim oEnum As Object, oC As Object
	AppDoc = Nothing
	REM Zuerst das aktive Dokument (zwei offene Register: das angeklickte gewinnt), sonst suchen
	oC = StarDesktop.CurrentComponent
	If Not IsNull(oC) Then
		If HasUnoInterfaces(oC, "com.sun.star.text.XTextDocument") Then
			If oC.DrawPage.Forms.hasByName("Nav") And oC.DrawPage.Forms.hasByName("Vertrag") Then
				AppDoc = oC
				Exit Function
			End If
		End If
	End If
	oEnum = StarDesktop.Components.createEnumeration()
	Do While oEnum.hasMoreElements()
		oC = oEnum.nextElement()
		If HasUnoInterfaces(oC, "com.sun.star.text.XTextDocument") Then
			If oC.DrawPage.Forms.hasByName("Nav") Then
				If oC.DrawPage.Forms.hasByName("Vertrag") Then
					AppDoc = oC
					Exit Function
				End If
			End If
		End If
	Loop
End Function

REM Die .odb ist das übergeordnete Dokument des Formulars.
Function DbDoc() As Object
	DbDoc = AppDoc().Parent
End Function

Function FormSuchen(oCont As Object, sName As String) As Object
	Dim i As Integer, m As Object, r As Object
	FormSuchen = Nothing
	For i = 0 To oCont.Count - 1
		m = oCont.getByIndex(i)
		If m.supportsService("com.sun.star.form.component.Form") Then
			If m.Name = sName Then
				FormSuchen = m
				Exit Function
			End If
			r = FormSuchen(m, sName)
			If Not IsNull(r) Then
				FormSuchen = r
				Exit Function
			End If
		End If
	Next i
End Function

REM V8: direkter Pfad statt Suche. Die Suche fragt jedes Steuerelement ab und kostete 0,1 s je Aufruf.
Function Fm(oDoc As Object, sName As String) As Object
	Dim oFs As Object
	oFs = oDoc.DrawPage.Forms
	Select Case sName
		Case "Info", "Entscheidung", "Dokumente", "Leistung", "Verlauf"
			Fm = oFs.getByName("Vertrag").getByName(sName)
		Case "LeistungInfo", "LeistungProt"
			Fm = oFs.getByName("Vertrag").getByName("Leistung").getByName(sName)
		Case "EreignisInfo"
			Fm = oFs.getByName("Ereignis").getByName(sName)
		Case "PartnerVertraege"
			Fm = oFs.getByName("Partner").getByName(sName)
		Case "Punkte", "VtAenderung"
			Fm = oFs.getByName("Vertretung").getByName(sName)
		Case Else
			If oFs.hasByName(sName) Then Fm = oFs.getByName(sName) Else Fm = FormSuchen(oFs, sName)
	End Select
End Function

Sub FokusAuf(oDoc As Object, sForm As String, sName As String)
	On Error Resume Next
	oDoc.CurrentController.getControl(Fm(oDoc, sForm).getByName(sName)).setFocus()
End Sub

REM V8.2c-N11: neue Entscheidungszeile ohne gewählte Entscheidung (FokusWeg hat die Auswahl schon übernommen)
REM V8.3-E28: Verträge, deren Beginn erreicht ist, von „zukünftig“ auf „aktiv“ (der Trigger stellt um)
Sub StatusTagesstand()
	On Error Resume Next
	Verbindung().createStatement().executeUpdate("UPDATE ""Vertrag"" SET ""Status"" = 'aktiv' WHERE ""Status"" = 'zukünftig' AND ""Beginn"" <= CURRENT_DATE")
End Sub

Function LeereEntscheidung(oF As Object) As Boolean
	LeereEntscheidung = False
	On Error GoTo Ende
	LeereEntscheidung = (Trim(oF.Columns.getByName("Art").getString()) = "")
Ende:
End Function

Function Verbindung() As Object
	Verbindung = AppDoc().DrawPage.Forms.getByName("Nav").ActiveConnection
End Function

Function AktuelleID(oF As Object, Optional sSpalte) As Long
	Dim n As Long, sSp As String
	AktuelleID = 0
	sSp = "ID"
	If Not IsMissing(sSpalte) Then sSp = sSpalte
	On Error Resume Next
	If oF.IsNew Or oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then Exit Function
	n = oF.getLong(oF.findColumn(sSp))
	If oF.wasNull() Then n = 0
	AktuelleID = n
End Function

REM Meldung statt Basic-IDE (W5).
Sub Fehlermeldung(sWas As String, sTechnik As String)
	MsgBox "Das hat nicht geklappt: " & sWas & "." & Chr(10) & Chr(10) & _
		"Bitte versuche es noch einmal. Hilft das nicht, schließe das Register und öffne es neu. " & _
		"Gespeicherte Daten bleiben erhalten." & Chr(10) & Chr(10) & "Technischer Hinweis: " & sTechnik, 48, "Vertragsregister"
End Sub

REM Ereignis „Fehler aufgetreten" der Formulare: verständliche Meldung statt Datenbanktext.
Sub DbFehler(Optional oEvent)
	Dim s As String, t As String, oX
	On Error Resume Next
	s = oEvent.Reason.Message
	REM Die eigentliche Ursache steht oft in der verketteten Ausnahme
	oX = oEvent.Reason.NextException
	Do While Not IsEmpty(oX) And Not IsNull(oX)
		s = s & " | " & oX.Message
		oX = oX.NextException
	Loop
	s = s & " (" & oEvent.Source.Name & ")"
	REM Base meldet denselben Fehler beim Speichern zweimal (Xvfb-Test). Gleiche Meldung binnen 3 s nur einmal zeigen.
	Dim oMerk As Object
	oMerk = AppDoc().DrawPage.Forms.getByName("Nav").getByName("NA_txtHeute")
	If oMerk.Tag = s & "|" & Int(Timer / 3) Then Exit Sub
	oMerk.Tag = s & "|" & Int(Timer / 3)
	If InStr(s, "UNIQUE") > 0 Or InStr(s, "PRIMARY") > 0 Then
		t = "Diesen Eintrag gibt es schon (z. B. ein Partner mit gleichem Namen)."
	ElseIf InStr(s, "FOREIGN") > 0 Then
		t = "Der Eintrag wird noch verwendet, z. B. ein Partner mit Verträgen. Lösche oder ändere zuerst die Verwendung."
	ElseIf InStr(s, "CHECK") > 0 Then
		t = "Ein Wert liegt außerhalb des erlaubten Bereichs (z. B. Ende vor Beginn oder eine negative Zahl)."
	ElseIf InStr(s, "NULL") > 0 Then
		t = "Ein Pflichtfeld ist leer."
	Else
		t = "Die Datenbank hat die Eingabe nicht angenommen."
	End If
	MsgBox t & Chr(10) & Chr(10) & "Technischer Hinweis: " & Left(s, 300), 48, "Vertragsregister"
End Sub

Function Esc(s As String) As String
	Esc = Join(Split(s, "'"), "''")
End Function

Function Benutzer() As String
	Dim oCP As Object, oNode As Object, s As String
	Dim a(0) As New com.sun.star.beans.PropertyValue
	On Error Resume Next
	oCP = createUnoService("com.sun.star.configuration.ConfigurationProvider")
	a(0).Name = "nodepath"
	a(0).Value = "/org.openoffice.UserProfile/Data"
	oNode = oCP.createInstanceWithArguments("com.sun.star.configuration.ConfigurationAccess", a())
	s = Trim(oNode.givenname & " " & oNode.sn)
	If s = "" Then s = Environ("USERNAME")
	If s = "" Then s = "unbekannt"
	Benutzer = s
End Function

Function LetztePos(ByVal s As String, ByVal such As String) As Long
	Dim p As Long, q As Long
	p = 0
	q = InStr(1, s, such)
	Do While q > 0
		p = q
		q = InStr(p + 1, s, such)
	Loop
	LetztePos = p
End Function

Function DatumDe(d As Date) As String
	DatumDe = Right("0" & Day(d), 2) & "." & Right("0" & Month(d), 2) & "." & Year(d)
End Function

Function DatumIso(d As Date) As String
	DatumIso = Year(d) & Right("0" & Month(d), 2) & Right("0" & Day(d), 2)
End Function

Function MitTrenner(s As String) As String
	If Right(s, 1) = "\" Or Right(s, 1) = "/" Then
		MitTrenner = s
	ElseIf InStr(s, "\") > 0 Then
		MitTrenner = s & "\"
	Else
		MitTrenner = s & "/"
	End If
End Function

Function EinstellungText(sSpalte As String) As String
	Dim rs As Object
	EinstellungText = ""
	On Error Resume Next
	rs = Verbindung().createStatement().executeQuery("SELECT """ & sSpalte & """ FROM ""Einstellung"" WHERE ""ID"" = 1")
	If rs.next() Then EinstellungText = Trim(rs.getString(1))
End Function

Sub ShellOeffnen(sURL As String, sMeldung As String)
	Dim oShell As Object
	On Error GoTo Fehler
	oShell = createUnoService("com.sun.star.system.SystemShellExecute")
	oShell.execute(sURL, "", 0)
	Exit Sub
Fehler:
	REM V8.8 (KON-03): Meldung nennt, was zu tun ist
	MsgBox sMeldung & Chr(10) & ConvertFromURL(sURL) & Chr(10) & Chr(10) & _
		"Prüfe, ob das Laufwerk verbunden ist und der Ordner existiert." & Chr(10) & _
		"Den Ablagepfad änderst du unter Einstellungen › Ablage und Sicherung.", 48, "Vertragsregister"
End Sub

REM Ordner neben der .odb (Export, Sicherung); wird bei Bedarf angelegt.
Function OrdnerNebenDatei(oDb As Object, sName As String) As String
	Dim sDoc As String, sOrdner As String, oSFA As Object
	sDoc = oDb.URL
	sOrdner = Left(sDoc, LetztePos(sDoc, "/")) & sName & "/"
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	If Not oSFA.exists(sOrdner) Then oSFA.createFolder(sOrdner)
	OrdnerNebenDatei = sOrdner
End Function
