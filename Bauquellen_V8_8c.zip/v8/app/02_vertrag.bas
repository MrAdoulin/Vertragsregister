
REM ================================================================ Übersicht
Sub StartGeladen(Optional oEvent)
	Dim oF As Object
	On Error Resume Next
	oF = oEvent.Source
	FarbeZahl(oF, "ST_kpiRot", "Rot", RGB(215, 0, 21))
	FarbeZahl(oF, "ST_kpiGelb", "Gelb", RGB(201, 52, 0))
	FarbeZahl(oF, "ST_kpiLeistung", "LRot", RGB(215, 0, 21))
End Sub

Sub FarbeZahl(oF As Object, sName As String, sSpalte As String, nFarbe As Long)
	Dim n As Long
	On Error Resume Next
	n = oF.getLong(oF.findColumn(sSpalte))
	oF.getByName(sName).TextColor = IIf(n > 0, nFarbe, RGB(142, 142, 147))
End Sub

REM Doppelklick in „Offen" oder „Nächste Termine"
Sub StartDoppelklick(Optional oEvent)
	Dim oF As Object, nID As Long, nL As Long
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oF = oEvent.Source.Model.Parent
	nID = AktuelleID(oF)
	If nID = 0 Then Exit Sub
	nL = 0
	If oF.Name = "Heute" Then nL = AktuelleID(oF, "LeistungID")
	If nL > 0 Then
		If VertragOeffnen(AppDoc(), nID, "ST", FolgeAus(oF), "VE2") Then LeistungAuswaehlen(AppDoc(), nL)
	Else
		VertragOeffnen(AppDoc(), nID, "ST", FolgeAus(oF), "VE1")
	End If
	Exit Sub
Fehler:
	Fehlermeldung("Vertrag öffnen", Error$)
End Sub

REM Klick auf eine Kennzahl öffnet die passende Liste (B1-R12)
Sub KpiRot(Optional oEvent)
	ListeMitFilter("LI", "chipRot")
End Sub
Sub KpiGelb(Optional oEvent)
	ListeMitFilter("LI", "chipGelb")
End Sub
Sub KpiAktiv(Optional oEvent)
	ListeMitFilter("LI", "chipAktiv")
End Sub
Sub KpiLeistung(Optional oEvent)
	ListeMitFilter("LE", "chipRot")
End Sub

Sub ListeMitFilter(sBereich As String, sChip As String)
	Dim oDoc As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not Bereich(oDoc, sBereich) Then Exit Sub
	ChipAnwenden(oDoc, sBereich, sChip)
	Exit Sub
Fehler:
	Fehlermeldung("Liste öffnen", Error$)
End Sub

REM ================================================================ Suche und Filterknöpfe (Verträge, Leistungen, Protokoll, Änderungen)
Function ListenForm(sBereich As String) As String
	Select Case sBereich
		Case "LI" : ListenForm = "Liste"
		Case "LE" : ListenForm = "Leistungen"
		Case "PR" : ListenForm = "Protokoll"
		Case "AE" : ListenForm = "Aenderungen"
	End Select
End Function

Function ChipFilter(sBereich As String, sChip As String) As String
	Dim s As String
	Select Case sBereich & ":" & sChip
		Case "LI:chipRot", "LE:chipRot" : s = """Ampel"" = 'rot'"
		Case "LI:chipGelb", "LE:chipGelb" : s = """Ampel"" = 'gelb'"
		Case "LI:chipAktiv" : s = """Status"" = 'aktiv'"
		Case "LI:chipBeendet" : s = """Status"" NOT IN ('aktiv', 'zukünftig')"  ' V8.3-E28
		Case "PR:chipOffen" : s = """Offen"" IS NOT NULL"
		Case "PR:chipRechnung" : s = """Art"" = 'Rechnung erhalten'"
		Case "PR:chipStoerung" : s = """Art"" = 'Leistungsanfall'"
		REM Der Filter läuft durch den SQL-Parser von Base; Firebird-Funktionen wie DATEADD versteht er nicht.
		Case "AE:chip7" : s = """AlterTage"" <= 7"
		Case "AE:chip30" : s = """AlterTage"" <= 30"
		Case Else : s = ""
	End Select
	ChipFilter = s
End Function

Function ChipNamen(sBereich As String)
	Select Case sBereich
		Case "LI" : ChipNamen = Array("chipAlle", "chipRot", "chipGelb", "chipAktiv", "chipBeendet")
		Case "LE" : ChipNamen = Array("chipAlle", "chipRot", "chipGelb")
		Case "PR" : ChipNamen = Array("chipOffen", "chipRechnung", "chipStoerung", "chipAlle")
		Case "AE" : ChipNamen = Array("chipAlle", "chip7", "chip30")
	End Select
End Function

REM Der gewählte Filter steht in txtSuche.Tag (B1-R15).
Sub ChipAnwenden(oDoc As Object, sBereich As String, sChip As String)
	Dim oF As Object, a, i As Integer, oB As Object, sSuche As String
	oF = Fm(oDoc, ListenForm(sBereich))
	oF.getByName(sBereich & "_txtSuche").Tag = ChipFilter(sBereich, sChip)
	a = ChipNamen(sBereich)
	For i = 0 To UBound(a)
		oB = oF.getByName(sBereich & "_" & a(i))
		REM V8.8 (KOH-01): aktiver Filter hellblau statt blau gefüllt – sah aus wie die Hauptaktion
		If a(i) = sChip Then
			oB.BackgroundColor = RGB(229, 241, 255) : oB.TextColor = RGB(0, 122, 255)
		Else
			oB.BackgroundColor = RGB(255, 255, 255) : oB.TextColor = RGB(0, 122, 255)
		End If
	Next i
	On Error Resume Next
	sSuche = oDoc.CurrentController.getControl(oF.getByName(sBereich & "_txtSuche")).Text
	ListeFiltern(oF, sBereich, sSuche)
End Sub

Sub ListeFiltern(oF As Object, sBereich As String, sText As String)
	Dim s As String, sW As String, sChip As String
	sChip = oF.getByName(sBereich & "_txtSuche").Tag
	s = Esc(UCase(Trim(sText)))
	If s <> "" Then sW = SuchBedingung("""Suchtext""", s)  ' V8.8 (SPR-02)
	If sChip <> "" Then
		If sW <> "" Then sW = sW & " AND "
		sW = sW & sChip
	End If
	REM V8.4-E21: stornierte Einträge ausblenden, wenn der Schalter aus ist
	If sBereich = "PR" Then
		If oF.getByName("PR_chkStorno").State = 0 Then
			If sW <> "" Then sW = sW & " AND "
			sW = sW & """Storniert"" IS NOT TRUE"
		End If
	End If
	oF.Filter = sW
	oF.ApplyFilter = (sW <> "")
	oF.reload()
	REM V8.8 (ORI-03): leere Trefferliste erklärt sich
	If s <> "" And oF.RowCount = 0 Then
		StatusSetzen(AppDoc(), "Keine Treffer für „" & Trim(sText) & "“ – Suchfeld leeren zeigt wieder alle.")
	Else
		ErgebnisWeg(AppDoc(), "Keine Treffer")
	End If
End Sub

REM V8.8 (SPR-02): Suchwort auch mit ae/oe/ue/ss statt Umlaut finden (und umgekehrt). Nur LIKE: Funktionen wie
REM REPLACE im Formularfilter kennt der Parser von Base womöglich nicht (Fallstrick 3). Leerzeichen-tolerant: P5.
Function SuchBedingung(sSpalte As String, s As String) As String
	Dim s2 As String, s3 As String, sB As String
	s2 = Replace(Replace(Replace(Replace(s, "Ä", "AE"), "Ö", "OE"), "Ü", "UE"), "ß", "SS")
	s3 = Replace(Replace(Replace(s, "AE", "Ä"), "OE", "Ö"), "UE", "Ü")
	sB = sSpalte & " LIKE '%" & s & "%'"
	If s2 <> s Then sB = sB & " OR " & sSpalte & " LIKE '%" & s2 & "%'"
	If s3 <> s Then sB = sB & " OR " & sSpalte & " LIKE '%" & s3 & "%'"
	SuchBedingung = "(" & sB & ")"
End Function

Sub SucheText(oEvent, sBereich As String)
	On Error Resume Next
	ListeFiltern(oEvent.Source.Model.Parent, sBereich, oEvent.Source.Text)
End Sub
Sub ListeSuchen(Optional oEvent)
	SucheText(oEvent, "LI")
End Sub
Sub LeistungenSuchen(Optional oEvent)
	SucheText(oEvent, "LE")
End Sub
Sub ProtokollSuchen(Optional oEvent)
	SucheText(oEvent, "PR")
End Sub
Sub AenderungSuchen(Optional oEvent)
	SucheText(oEvent, "AE")
End Sub

Sub Chip(sBereich As String, sChip As String)
	On Error GoTo Fehler
	ChipAnwenden(AppDoc(), sBereich, sChip)
	Exit Sub
Fehler:
	Fehlermeldung("Filter", Error$)
End Sub
Sub LiChipAlle(Optional oEvent)
	Chip("LI", "chipAlle")
End Sub
Sub LiChipRot(Optional oEvent)
	Chip("LI", "chipRot")
End Sub
Sub LiChipGelb(Optional oEvent)
	Chip("LI", "chipGelb")
End Sub
Sub LiChipAktiv(Optional oEvent)
	Chip("LI", "chipAktiv")
End Sub
Sub LiChipBeendet(Optional oEvent)
	Chip("LI", "chipBeendet")
End Sub
Sub LeChipAlle(Optional oEvent)
	Chip("LE", "chipAlle")
End Sub
Sub LeChipRot(Optional oEvent)
	Chip("LE", "chipRot")
End Sub
Sub LeChipGelb(Optional oEvent)
	Chip("LE", "chipGelb")
End Sub
Sub PrChipOffen(Optional oEvent)
	Chip("PR", "chipOffen")
End Sub
Sub PrChipRechnung(Optional oEvent)
	Chip("PR", "chipRechnung")
End Sub
Sub PrChipStoerung(Optional oEvent)
	Chip("PR", "chipStoerung")
End Sub
Sub PrChipAlle(Optional oEvent)
	Chip("PR", "chipAlle")
End Sub
Sub AeChipAlle(Optional oEvent)
	Chip("AE", "chipAlle")
End Sub
Sub AeChip7(Optional oEvent)
	Chip("AE", "chip7")
End Sub
Sub AeChip30(Optional oEvent)
	Chip("AE", "chip30")
End Sub

Sub ListeDoppelklick(Optional oEvent)
	Dim oF As Object, nID As Long
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oF = oEvent.Source.Model.Parent
	nID = AktuelleID(oF)
	If nID > 0 Then VertragOeffnen(AppDoc(), nID, "LI", FolgeAus(oF), "VE1")
	Exit Sub
Fehler:
	Fehlermeldung("Vertrag öffnen", Error$)
End Sub

REM ================================================================ Blättern (B1-R13, R15)
REM Folge ",1,6,2," in VE_lblPosition.Tag: Vertrags-IDs in der Reihenfolge der Herkunftsliste.
Function FolgeAus(oF As Object, Optional sSpalte) As String
	Dim rs As Object, nID As Long, sSql As String, nSp As Long, s As String, sSp As String
	sSp = "ID"
	If Not IsMissing(sSpalte) Then sSp = sSpalte
	If oF.Name = "Leistungen" Then sSp = "VertragID"
	If oF.CommandType = com.sun.star.sdb.CommandType.COMMAND Then
		sSql = oF.Command
	Else
		sSql = "SELECT * FROM """ & oF.Command & """"
	End If
	sSql = "SELECT * FROM (" & sSql & ") x"
	If oF.ApplyFilter And oF.Filter <> "" Then sSql = sSql & " WHERE " & oF.Filter
	If oF.Order <> "" Then sSql = sSql & " ORDER BY " & oF.Order
	rs = oF.ActiveConnection.createStatement().executeQuery(sSql)
	nSp = rs.findColumn(sSp)
	s = ","
	Do While rs.next()
		nID = rs.getLong(nSp)
		If Not rs.wasNull() Then
			If InStr(s, "," & nID & ",") = 0 Then s = s & nID & ","
		End If
	Loop
	FolgeAus = s
End Function

Function FolgeAlle(oCon As Object) As String
	Dim rs As Object, s As String
	s = ","
	rs = oCon.createStatement().executeQuery("SELECT ""ID"" FROM ""Vertrag"" ORDER BY ""ID""")
	Do While rs.next()
		s = s & rs.getLong(1) & ","
	Loop
	FolgeAlle = s
End Function

Sub FolgeSetzen(oDoc As Object, s As String)
	Fm(oDoc, "Vertrag").getByName("VE_lblPosition").Tag = s
End Sub

Function FolgeLesen(oDoc As Object) As String
	FolgeLesen = Fm(oDoc, "Vertrag").getByName("VE_lblPosition").Tag
End Function

Function FolgeFeld(s As String)
	If Len(s) < 3 Then
		FolgeFeld = Array()
	Else
		FolgeFeld = Split(Mid(s, 2, Len(s) - 2), ",")
	End If
End Function

Sub PositionZeigen(oDoc As Object)
	Dim oF As Object, nID As Long, s As String, a, i As Long, n As Long, nPos As Long
	On Error Resume Next
	oF = Fm(oDoc, "Vertrag")
	s = FolgeLesen(oDoc)
	If Len(s) < 3 Then s = FolgeAlle(oF.ActiveConnection)
	nID = AktuelleID(oF)
	If nID > 0 And InStr(s, "," & nID & ",") = 0 Then s = s & nID & ","
	FolgeSetzen(oDoc, s)
	a = FolgeFeld(s)
	n = UBound(a) + 1
	nPos = -1
	For i = 0 To n - 1
		If CLng(a(i)) = nID Then nPos = i
	Next i
	oF.getByName("VE_lblPosition").Label = IIf(nPos >= 0, (nPos + 1) & " von " & n, IIf(oF.IsNew, "neuer Vertrag", ""))
	oF.getByName("VE_btnPfeilZurueck").Enabled = (nPos > 0)
	oF.getByName("VE_btnPfeilVor").Enabled = (nPos >= 0 And nPos < n - 1)
End Sub

Sub PfeilVor(Optional oEvent)
	Blaettern(1)
End Sub

Sub PfeilZurueck(Optional oEvent)
	Blaettern(-1)
End Sub

Sub Blaettern(nSchritt As Integer)
	Dim oDoc As Object, oF As Object, nID As Long, a, i As Long, n As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Vertrag")
	nID = AktuelleID(oF)
	a = FolgeFeld(FolgeLesen(oDoc))
	For i = 0 To UBound(a)
		If CLng(a(i)) = nID Then
			n = i + nSchritt
			If n >= 0 And n <= UBound(a) Then VertragZeigenIn(oDoc, CLng(a(n)))
			Exit Sub
		End If
	Next i
	Exit Sub
Fehler:
	Fehlermeldung("Blättern", Error$)
End Sub

REM ================================================================ Vertrag öffnen
Function VertragOeffnen(oDoc As Object, nID As Long, sVon As String, sFolge As String, sTab As String) As Boolean
	VertragOeffnen = False
	If Not Bereich(oDoc, sTab) Then Exit Function
	FolgeSetzen(oDoc, sFolge)
	ZurueckBeschriften(oDoc, sVon)
	VertragOeffnen = VertragZeigenIn(oDoc, nID)
End Function

Function VertragZeigenIn(oDoc As Object, nID As Long) As Boolean
	Dim oF As Object
	VertragZeigenIn = False
	oF = Fm(oDoc, "Vertrag")
	If oF.isLoaded() Then
		If Not Speichern(oDoc, oF) Then Exit Function
	End If
	oF.Filter = """ID"" = " & nID
	oF.ApplyFilter = True
	If oF.isLoaded() Then oF.reload() Else oF.load()
	PositionZeigen(oDoc)
	VertragZeigenIn = True
End Function

REM Die Herkunft steht in VE_btnZurueck.Tag (Bereichscode).
Sub ZurueckBeschriften(oDoc As Object, sVon As String)
	Dim oB As Object, s As String
	On Error Resume Next
	oB = Fm(oDoc, "Vertrag").getByName("VE_btnZurueck")
	Select Case Left(sVon, 2)
		Case "LI" : s = "Verträge"
		Case "LE" : s = "Leistungen"
		Case "PR" : s = "Protokoll"
		Case "PA" : s = "Partner"
		Case "AE" : s = "Änderungen"
		Case "VT" : s = "Vertretung"
		Case "GS" : s = "Suche"
		Case "AB" : s = "Ablage prüfen"
		Case Else : s = "Übersicht" : sVon = "ST"
	End Select
	oB.Tag = sVon
	oB.Label = "‹  " & s
End Sub

Sub VertragZurueck(Optional oEvent)
	Dim oDoc As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	Bereich(oDoc, Fm(oDoc, "Vertrag").getByName("VE_btnZurueck").Tag)
	Exit Sub
Fehler:
	Fehlermeldung("Zurück", Error$)
End Sub

Sub TabVertrag(Optional oEvent)
	Gehe("VE1")
End Sub
Sub TabLeistungen(Optional oEvent)
	Gehe("VE2")
End Sub
Sub TabDokumente(Optional oEvent)
	Gehe("VE3")
End Sub
Sub TabDienst(Optional oEvent)
	Gehe("VE4")  ' V8.3-LEC
End Sub

Sub NeuerVertrag(Optional oEvent)
	Dim oDoc As Object, oF As Object, sVon As String, sFolge As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	sVon = AktuellerBereich(oDoc)
	If sVon = "LI" Then
		sFolge = FolgeAus(Fm(oDoc, "Liste"))
	ElseIf Left(sVon, 2) = "VE" Then
		sFolge = FolgeLesen(oDoc)
		sVon = Fm(oDoc, "Vertrag").getByName("VE_btnZurueck").Tag
	Else
		sFolge = FolgeAlle(Verbindung())
	End If
	If Not Bereich(oDoc, "VE1") Then Exit Sub
	oF = Fm(oDoc, "Vertrag")
	NeueZeile(oF)
	FolgeSetzen(oDoc, sFolge)
	ZurueckBeschriften(oDoc, sVon)
	PositionZeigen(oDoc)
	FokusAuf(oDoc, "Vertrag", "VE_txtGegenstand")
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Vertrag", Error$)
End Sub

Sub VertragLoeschen(Optional oEvent)
	Dim oDoc As Object, oF As Object, s As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Vertrag")
	If oF.IsNew Then
		Verwerfen(oDoc, oF)
		Bereich(oDoc, oF.getByName("VE_btnZurueck").Tag, False)
		Exit Sub
	End If
	REM V8.4-P04: ungesicherte Änderungen → der Knopf heißt „Verwerfen“ und nimmt nur sie zurück
	If oF.IsModified Then
		Verwerfen(oDoc, oF)
		Spaeter("S")
		Exit Sub
	End If
	s = oF.getString(oF.findColumn("Gegenstand"))
	If MsgBox("Den Vertrag „" & s & "“ löschen?" & Chr(10) & Chr(10) & _
		"Leistungen, Protokoll, Entscheidungen und die Dokumentenliste werden mitgelöscht. " & _
		"Die Dateien im Ablagepfad bleiben erhalten. Alles bleibt 90 Tage im Papierkorb.", _
		4 + 32 + 256, "Vertrag löschen") <> 6 Then Exit Sub
	oF.deleteRow()
	Gespeichert()
	Bereich(oDoc, oF.getByName("VE_btnZurueck").Tag, False)
	Exit Sub
Fehler:
	Fehlermeldung("Vertrag löschen", Error$)
End Sub

REM ================================================================ Vertrag: Prüfung und Nachlauf
Function VertragPruefen(Optional oEvent) As Boolean
	Dim oF As Object, sFehlt As String, sFalsch As String, dB As Date, dE As Date, bB As Boolean, bE As Boolean
	Dim sNummer As String, nID As Long
	VertragPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	oF = oEvent.Source
	REM Die Spalten der Zeilenmenge tragen beim Speichern bereits die eingegebenen Werte.
	If Trim(oF.Columns.getByName("Gegenstand").getString()) = "" Then sFehlt = "den Gegenstand"
	oF.Columns.getByName("PartnerID").getInt()
	If oF.Columns.getByName("PartnerID").wasNull() Then
		If sFehlt <> "" Then sFehlt = sFehlt & " und "
		sFehlt = sFehlt & "den Vertragspartner"
	End If
	If oF.Columns.getByName("AutoVerl").getBoolean() Then
		oF.Columns.getByName("VerlMonate").getInt()
		If oF.Columns.getByName("VerlMonate").wasNull() Then
			If sFehlt <> "" Then sFehlt = sFehlt & " und "
			sFehlt = sFehlt & "die Verlängerung in Monaten"
		End If
	End If
	REM Leere Datumsfelder liefern 0.0.0; CDateFromUnoDate darauf bricht ab (V8-Test: Pflichtfeld-Meldung blieb aus).
	bB = SpalteDatum(oF.Columns.getByName("Beginn"), dB)
	bE = SpalteDatum(oF.Columns.getByName("ErstesEnde"), dE)
	If bB And bE Then
		If dE < dB Then sFalsch = "Das erste Vertragsende liegt vor dem Beginn."
	End If
	REM V8.1-P2: Vertragsnummer eindeutig und als Ordnername tauglich; anderer Aufbau nur als Hinweis
	sNummer = Trim(oF.Columns.getByName("Vertragsnummer").getString())
	If sFehlt = "" And sFalsch = "" And sNummer <> "" Then
		nID = 0
		If oEvent.Action <> com.sun.star.sdb.RowChangeAction.INSERT Then nID = oF.Columns.getByName("ID").getLong()
		sFalsch = NummerFehler(sNummer, nID)
		If sFalsch = "" And Not NummerAufbauOk(sNummer) And NummerAlt(nID) <> sNummer Then
			MsgBox "Die Vertragsnummer „" & sNummer & "“ ist anders aufgebaut als üblich (z. B. 12_132_01_2026)." & Chr(10) & _
				"Der Vertrag wird trotzdem gespeichert.", 64, "Vertrag"
		End If
	End If
	If sFehlt <> "" Then
		MsgBox "Bitte trag noch " & sFehlt & " ein." & Chr(10) & "Der Vertrag ist noch nicht gespeichert." & NeuHinweis(oEvent), 48, "Vertrag"
		Spaeter("PFOKUS", oF.Name)  ' V8.8 (KON-02)
		VertragPruefen = False
	ElseIf sFalsch <> "" Then
		MsgBox sFalsch & Chr(10) & "Der Vertrag ist noch nicht gespeichert.", 48, "Vertrag"
		VertragPruefen = False
	End If
Ende:
End Function

REM V8.1-P2: Fehlertext zur Vertragsnummer oder "" (Zeichen für Ordnernamen, Eindeutigkeit ohne Groß-/Kleinschreibung)
Function NummerFehler(sNummer As String, nID As Long) As String
	Dim i As Integer, rs As Object, sVerboten As String
	NummerFehler = ""
	sVerboten = "\/:*?""<>|"
	For i = 1 To Len(sVerboten)
		If InStr(sNummer, Mid(sVerboten, i, 1)) > 0 Then
			NummerFehler = "Die Vertragsnummer darf diese Zeichen nicht enthalten: \ / : * ? "" < > |" & Chr(10) & _
				"Sie ist Teil des Ordnernamens."
			Exit Function
		End If
	Next i
	rs = Verbindung().createStatement().executeQuery("SELECT FIRST 1 ""Nr"" || ' ' || ""Gegenstand"" FROM ""Vertrag"" " & _
		"WHERE UPPER(""Nr"") = UPPER('" & Esc(sNummer) & "') AND ""ID"" <> " & nID)
	If rs.next() Then NummerFehler = "Die Vertragsnummer „" & sNummer & "“ gibt es schon:" & Chr(10) & rs.getString(1)
End Function

REM Üblicher Aufbau: Typ_Art_lfd.Nr._Jahr, z. B. 12_132_01_2026
Function NummerAufbauOk(s As String) As Boolean
	Dim i As Integer, c As String
	NummerAufbauOk = False
	If Len(s) <> 14 Then Exit Function
	For i = 1 To 14
		c = Mid(s, i, 1)
		If i = 3 Or i = 7 Or i = 10 Then
			If c <> "_" Then Exit Function
		ElseIf c < "0" Or c > "9" Then
			Exit Function
		End If
	Next i
	NummerAufbauOk = True
End Function

REM Gespeicherte Vertragsnummer eines Vertrags ("" bei neuem Vertrag)
Function NummerAlt(nID As Long) As String
	Dim rs As Object
	NummerAlt = ""
	If nID = 0 Then Exit Function
	rs = Verbindung().createStatement().executeQuery("SELECT COALESCE(""Vertragsnummer"", '') FROM ""Vertrag"" WHERE ""ID"" = " & nID)
	If rs.next() Then NummerAlt = rs.getString(1)
End Function

REM Liest ein Datum aus einer Spalte. False, wenn leer.
Function SpalteDatum(oCol As Object, d As Date) As Boolean
	Dim u
	u = oCol.getDate()
	SpalteDatum = Not oCol.wasNull()
	If SpalteDatum Then d = CDateFromUnoDate(u)
End Function

Sub VertragGespeichert(Optional oEvent)
	On Error Resume Next
	Gespeichert()
	Spaeter("Vertrag")
End Sub

Sub InfoFaerben(Optional oEvent)
	Dim oF As Object, sAmpel As String
	On Error Resume Next
	oF = oEvent.Source
	sAmpel = ""
	REM V8.2a: Farbe des Hinweises (passt zum Text); Prüfung und Index zeigen eigene Markierungen
	If oF.RowCount > 0 And Not oF.isBeforeFirst() And Not oF.isAfterLast() Then sAmpel = oF.getString(oF.findColumn("HAmpel"))
	Pille(oF.getByName("VE_txtAnzeige"), sAmpel)
	VertragMarken(oF)  ' V8.2a E14
	NachfolgerZeigen(oF)  ' V8.3-E30
	DienstReiterZeigen(AppDoc())  ' V8.3-LEC
	Spaeter("H")  ' V8.2b-M19: nach dem Laden aller Unterformulare
End Sub

Sub Pille(oM As Object, sAmpel As String)
	Dim nFg As Long, nBg As Long
	Select Case sAmpel
		Case "rot"
			nFg = RGB(215, 0, 21) : nBg = RGB(255, 229, 227)
		Case "gelb"
			nFg = RGB(201, 52, 0) : nBg = RGB(255, 241, 219)
		Case "gruen"
			nFg = RGB(36, 138, 61) : nBg = RGB(227, 246, 232)
		Case Else
			nFg = RGB(28, 28, 30) : nBg = RGB(229, 229, 234)
	End Select
	oM.TextColor = nFg
	oM.BackgroundColor = nBg
End Sub

REM ================================================================ Entscheidung
Sub EntscheidungVerlaengern(Optional oEvent)
	EntscheidungAnlegen(AppDoc(), "verlängern")
End Sub

Sub EntscheidungKuendigen(Optional oEvent)
	EntscheidungAnlegen(AppDoc(), "kündigen")
End Sub

Function VertragGesichert(oDoc As Object, sWas As String) As Long
	Dim oF As Object
	VertragGesichert = 0
	oF = Fm(oDoc, "Vertrag")
	If Not Speichern(oDoc, oF) Then Exit Function
	If oF.IsNew Or oF.RowCount = 0 Then
		MsgBox "Sichere zuerst den Vertrag. Danach geht " & sWas & ".", 48, "Vertrag"
		Exit Function
	End If
	VertragGesichert = oF.getLong(oF.findColumn("ID"))
End Function

Sub EntscheidungAnlegen(oDoc As Object, sArt As String)
	Dim oF As Object, nID As Long
	On Error GoTo Fehler
	nID = VertragGesichert(oDoc, "die Entscheidung")
	If nID = 0 Then Exit Sub
	oF = Fm(oDoc, "Vertrag")
	If Not Speichern(oDoc, Fm(oDoc, "Entscheidung")) Then Exit Sub
	REM V8.2c-N15: dieselbe Entscheidung am selben Tag nicht noch einmal anlegen (Änderungsspur zeigte sie dreifach)
	Dim rsD As Object
	rsD = oF.ActiveConnection.createStatement().executeQuery("SELECT COUNT(*) FROM ""Entscheidung"" WHERE ""VertragID"" = " & nID & _
		" AND ""Art"" = '" & sArt & "' AND ""Datum"" = CURRENT_DATE")
	rsD.next()
	If rsD.getLong(1) > 0 Then
		StatusSetzen(oDoc, "„" & sArt & "“ ist heute schon eingetragen")
		If sArt = "kündigen" Then FokusAuf(oDoc, "Entscheidung", "VE1_txtVersandt")
		Exit Sub
	End If
	oF.ActiveConnection.createStatement().executeUpdate("INSERT INTO ""Entscheidung"" (""VertragID"", ""Art"", ""Datum"", " & _
		"""Verantwortlich"") VALUES (" & nID & ", '" & sArt & "', CURRENT_DATE, '" & Esc(Benutzer()) & "')")
	Fm(oDoc, "Entscheidung").reload()
	Fm(oDoc, "Info").reload()
	Gespeichert()
	If sArt = "kündigen" Then FokusAuf(oDoc, "Entscheidung", "VE1_txtVersandt")
	Exit Sub
Fehler:
	Fehlermeldung("Entscheidung anlegen", Error$)
End Sub

Function EntscheidungPruefen(Optional oEvent) As Boolean
	Dim oF As Object
	EntscheidungPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	oF = oEvent.Source
	If Trim(oF.Columns.getByName("Art").getString()) = "" Then
		MsgBox "Bitte wähle die Entscheidung (verlängern, kündigen oder neu verhandeln).", 48, "Entscheidung"
		EntscheidungPruefen = False
		Exit Function
	End If
	REM V8.2c-N11: Datum und Verantwortlich setzt die Datenbank (heute, angemeldeter Name), wenn leer
Ende:
End Function

Sub EntscheidungGespeichert(Optional oEvent)
	On Error Resume Next
	Gespeichert()
	Spaeter("Vertrag")
End Sub

Function DokumentPruefen(Optional oEvent) As Boolean
	DokumentPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	If Trim(oEvent.Source.Columns.getByName("Bezeichnung").getString()) = "" Then
		MsgBox "Bitte trag die Bezeichnung des Dokuments ein, z. B. Grundvertrag." & NeuHinweis(oEvent, True), 48, "Dokument"
		DokumentPruefen = False
	End If
Ende:
End Function

REM ================================================================ Ablage, Prüfdatum, Dateien
Sub HeuteGeprueft(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If VertragGesichert(oDoc, "das Prüfdatum") = 0 Then Exit Sub
	oF = Fm(oDoc, "Vertrag")
	oF.updateDate(oF.findColumn("ZuletztGeprueft"), CDateToUnoDate(Date()))
	oF.updateRow()
	Exit Sub
Fehler:
	Fehlermeldung("Prüfdatum setzen", Error$)
End Sub

Function VertragsOrdner(oF As Object) As String
	Dim sOrdner As String, sPfad As String
	VertragsOrdner = ""
	sOrdner = Trim(oF.getString(oF.findColumn("Ordner")))
	If sOrdner = "" Then
		MsgBox "Trag zuerst den Ordnernamen ein (Reiter „Vertrag“, Karte „Ablage und Prüfung“).", 48, "Ordner"
		Exit Function
	End If
	sPfad = EinstellungText("Ablagepfad")
	If sPfad = "" Then
		MsgBox "Trag zuerst den Ablagepfad ein: Einstellungen › Ablage und Sicherung.", 48, "Ordner"
		Exit Function
	End If
	VertragsOrdner = MitTrenner(sPfad) & sOrdner
End Function

Sub OrdnerOeffnen(Optional oEvent)
	Dim s As String
	s = VertragsOrdner(Fm(AppDoc(), "Vertrag"))
	If s <> "" Then ShellOeffnen(ConvertToURL(s), "Der Ordner ist nicht erreichbar:")
End Sub

Sub DokumentOeffnen(Optional oEvent)
	Dim oDoc As Object, oD As Object, sDatei As String, s As String
	oDoc = AppDoc()
	oD = Fm(oDoc, "Dokumente")
	If AktuelleID(oD) = 0 Then
		MsgBox "Markiere zuerst ein Dokument in der Liste.", 48, "Dokument"
		Exit Sub
	End If
	sDatei = Trim(oD.getString(oD.findColumn("Datei")))
	If sDatei = "" Then
		MsgBox "Bei diesem Dokument ist kein Dateiname eingetragen.", 48, "Dokument"
		Exit Sub
	End If
	s = VertragsOrdner(Fm(oDoc, "Vertrag"))
	If s <> "" Then ShellOeffnen(ConvertToURL(MitTrenner(s) & sDatei), "Die Datei ist nicht erreichbar:")
End Sub

REM ================================================================ Partner
REM „Neu" neben dem Partnerfeld: Name abfragen, Partner anlegen und im Vertrag auswählen.
REM V8: Ein Wechsel in die Ansicht Partner verschiebt den Fokus in ein anderes Formular. Base speichert dabei den Vertrag
REM und lehnt ihn ohne Partner ab (Xvfb-Test K). Deshalb bleibt der Vertrag offen und der Partner entsteht hier.
Sub PartnerNeu(Optional oEvent)
	Dim oDoc As Object, oV As Object, s As String, rs As Object, nID As Long, oCon As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	s = Trim(InputBox("Name des neuen Vertragspartners:" & Chr(10) & Chr(10) & _
		"Telefon, Hotline und weitere Angaben trägst du später unter „Partner“ ein.", "Neuer Partner"))
	If s = "" Then Exit Sub
	s = Left(s, 120)
	oCon = Verbindung()
	rs = oCon.createStatement().executeQuery("SELECT ""ID"" FROM ""Partner"" WHERE UPPER(""Name"") = UPPER('" & Esc(s) & "')")
	If rs.next() Then
		nID = rs.getLong(1)
		MsgBox "Diesen Partner gibt es schon. Er ist jetzt im Vertrag ausgewählt.", 64, "Neuer Partner"
	Else
		oCon.createStatement().executeUpdate("INSERT INTO ""Partner"" (""Name"") VALUES ('" & Esc(s) & "')")
		rs = oCon.createStatement().executeQuery("SELECT ""ID"" FROM ""Partner"" WHERE ""Name"" = '" & Esc(s) & "'")
		rs.next()
		nID = rs.getLong(1)
		Gespeichert()
	End If
	oV = Fm(oDoc, "Vertrag")
	oV.getByName("VE1_lbPartner").refresh()
	oV.updateLong(oV.findColumn("PartnerID"), nID)
	FokusAuf(oDoc, "Vertrag", "VE1_lbPartner")
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Partner", Error$)
End Sub

Sub PartnerNeuKlick(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Partner")
	If Not Speichern(oDoc, oF) Then Exit Sub
	NeueZeile(oF)
	FokusAuf(oDoc, "Partner", "PA_txtName")
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Partner", Error$)
End Sub

Function PartnerPruefen(Optional oEvent) As Boolean
	PartnerPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	If Trim(oEvent.Source.Columns.getByName("Name").getString()) = "" Then
		MsgBox "Bitte trag den Namen des Partners ein." & NeuHinweis(oEvent), 48, "Partner"
		PartnerPruefen = False
		Exit Function
	End If
	REM Doppelte Namen hier abfangen; die Datenbank würde mit einer technischen Meldung ablehnen
	Dim rs As Object, nID As Long
	nID = 0
	If oEvent.Action <> com.sun.star.sdb.RowChangeAction.INSERT Then nID = oEvent.Source.getLong(oEvent.Source.findColumn("ID"))
	rs = oEvent.Source.ActiveConnection.createStatement().executeQuery("SELECT COUNT(*) FROM ""Partner"" WHERE UPPER(""Name"") = UPPER('" & _
		Esc(Trim(oEvent.Source.Columns.getByName("Name").getString())) & "') AND ""ID"" <> " & nID)
	rs.next()
	If rs.getLong(1) > 0 Then
		MsgBox "Einen Partner mit diesem Namen gibt es schon." & NeuHinweis(oEvent), 48, "Partner"
		PartnerPruefen = False
	End If
Ende:
End Function

Sub PartnerGespeichert(Optional oEvent)
	On Error Resume Next
	Gespeichert()
	Spaeter("PA")  ' V8.3-E29: Name/Stand in den Listen
	Spaeter("P")   ' V8.4-P03: Stand der Kontaktdaten
	Fm(AppDoc(), "Vertrag").getByName("VE1_lbPartner").refresh()
	Fm(AppDoc(), "Ereignis").getByName("PR_lbLeistung").refresh()
End Sub

Sub PartnerLoeschen(Optional oEvent)
	Dim oDoc As Object, oF As Object, nID As Long, rs As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Partner")
	If oF.IsNew Or oF.IsModified Then
		Verwerfen(oDoc, oF)
		Spaeter("S")  ' V8.4-P04
		Exit Sub
	End If
	nID = AktuelleID(oF)
	If nID = 0 Then Exit Sub
	rs = oF.ActiveConnection.createStatement().executeQuery("SELECT COUNT(*) FROM ""Vertrag"" WHERE ""PartnerID"" = " & nID)
	rs.next()
	If rs.getLong(1) > 0 Then
		MsgBox "Dieser Partner hat noch " & rs.getLong(1) & " Vertrag/Verträge. Ändere oder lösche zuerst die Verträge.", _
			48, "Partner löschen"
		Exit Sub
	End If
	If MsgBox("Den Partner „" & oF.getString(oF.findColumn("Name")) & "“ löschen?" & Chr(10) & _
		"Er bleibt 90 Tage im Papierkorb.", 4 + 32 + 256, "Partner löschen") <> 6 Then Exit Sub
	oF.deleteRow()
	Gespeichert()
	Spaeter("PA")  ' V8.3-E29
	Exit Sub
Fehler:
	Fehlermeldung("Partner löschen", Error$)
End Sub

Sub PartnerVertragDoppelklick(Optional oEvent)
	Dim oF As Object, nID As Long
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oF = oEvent.Source.Model.Parent
	nID = AktuelleID(oF)
	If nID > 0 Then VertragOeffnen(AppDoc(), nID, "PA", FolgeAus(oF), "VE1")
	Exit Sub
Fehler:
	Fehlermeldung("Vertrag öffnen", Error$)
End Sub

REM V8.5-Q1: Eingaben der Karte „Entscheidung zum Stichtag“ verwerfen
Sub EntscheidungVerwerfen(Optional oEvent)
	Dim oDoc As Object, oE As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oE = Fm(oDoc, "Entscheidung")
	If oE.IsModified Then Verwerfen(oDoc, oE)
	SichernFarbe(oDoc)
	Exit Sub
Fehler:
	Fehlermeldung("Entscheidung verwerfen", Error$)
End Sub
