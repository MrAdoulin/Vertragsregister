
REM ================================================================ Leistungen im Vertrag (VE2)
Sub LeistungAuswaehlen(oDoc As Object, nLeistung As Long)
	Dim oL As Object
	On Error Resume Next
	oL = Fm(oDoc, "Leistung")
	oL.beforeFirst()
	Do While oL.next()
		If oL.getLong(oL.findColumn("ID")) = nLeistung Then Exit Do
	Loop
	If oL.isAfterLast() Then oL.first()
End Sub

Function LeistungPruefen(Optional oEvent) As Boolean
	Dim oF As Object, sFehlt As String
	LeistungPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	oF = oEvent.Source
	If Trim(oF.Columns.getByName("Bezeichnung").getString()) = "" Then sFehlt = "die Leistung (z. B. Entkalkung)"
	If Trim(oF.Columns.getByName("Abdeckung").getString()) = "" Then
		If sFehlt <> "" Then sFehlt = sFehlt & " und "
		sFehlt = sFehlt & "die Abdeckung"
	End If
	If sFehlt <> "" Then
		MsgBox "Bitte trag noch " & sFehlt & " ein." & Chr(10) & "Die Leistung ist noch nicht gespeichert." & NeuHinweis(oEvent), 48, "Leistung"
		Spaeter("PFOKUS", oF.Name)  ' V8.8 (KON-02)
		LeistungPruefen = False
	End If
Ende:
End Function

Sub LeistungGespeichert(Optional oEvent)
	On Error Resume Next
	Gespeichert()
	Spaeter("Leistung")
End Sub

Sub LeistungInfoFaerben(Optional oEvent)
	Dim oF As Object, sAmpel As String
	On Error Resume Next
	oF = oEvent.Source
	sAmpel = ""
	If oF.RowCount > 0 And Not oF.isBeforeFirst() And Not oF.isAfterLast() Then sAmpel = oF.getString(oF.findColumn("Ampel"))
	Pille(oF.getByName("VE2_txtLAnzeige"), sAmpel)
	REM V8.5-Q5: Tooltip erklärt den Stand
	If sAmpel <> "" Or oF.RowCount > 0 Then oF.getByName("VE2_txtLAnzeige").HelpText = oF.getString(oF.findColumn("AnzeigeTipp"))
	LeistungMarken(oF)  ' V8.2a E14
End Sub

Sub LeistungNeu(Optional oEvent)
	Dim oDoc As Object, oL As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If VertragGesichert(oDoc, "eine neue Leistung") = 0 Then Exit Sub
	oL = Fm(oDoc, "Leistung")
	If Not Speichern(oDoc, oL) Then Exit Sub
	NeueZeile(oL)
	FokusAuf(oDoc, "Leistung", "VE2_txtLeistung")
	Exit Sub
Fehler:
	Fehlermeldung("Neue Leistung", Error$)
End Sub

REM Liefert die ID der gewählten, gespeicherten Leistung oder 0 (mit Meldung).
Function LeistungGesichert(oDoc As Object) As Long
	Dim oL As Object
	LeistungGesichert = 0
	oL = Fm(oDoc, "Leistung")
	If Not Speichern(oDoc, oL) Then Exit Function
	LeistungGesichert = AktuelleID(oL)
	If LeistungGesichert = 0 Then MsgBox "Wähle zuerst eine Leistung oder lege sie mit „+ Neu“ an.", 48, "Leistung"
End Function

Sub LeistungLoeschen(Optional oEvent)
	Dim oDoc As Object, oL As Object, s As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oL = Fm(oDoc, "Leistung")
	If oL.IsNew Or oL.IsModified Then  ' V8.4-P04
		Verwerfen(oDoc, oL)
		Spaeter("S")
		Exit Sub
	End If
	If AktuelleID(oL) = 0 Then Exit Sub
	s = oL.getString(oL.findColumn("Bezeichnung"))
	If MsgBox("Die Leistung „" & s & "“ mit allen Protokolleinträgen löschen?" & Chr(10) & _
		"Sie bleibt 90 Tage im Papierkorb.", 4 + 32 + 256, "Leistung löschen") <> 6 Then Exit Sub
	oL.deleteRow()
	Gespeichert()
	Spaeter("Leistung")
	Exit Sub
Fehler:
	Fehlermeldung("Leistung löschen", Error$)
End Sub

REM Schnellaktion: „Leistung erbracht" mit heutigem Datum ins Protokoll
Sub LeistungErbracht(Optional oEvent)
	Dim oDoc As Object, nL As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	nL = LeistungGesichert(oDoc)
	If nL = 0 Then Exit Sub
	REM V8.5-Q3: Beschreibung = Leistung; „Angaben ergänzen“ bleibt offen, bis der Eintrag einmal gesichert wird
	Verbindung().createStatement().executeUpdate("INSERT INTO ""Ereignis"" (""LeistungID"", ""Datum"", ""Art"", ""Beschreibung"", ""Ergaenzen"") " & _
		"SELECT ""ID"", CURRENT_DATE, 'Leistung erbracht', LEFT(""Bezeichnung"" || COALESCE(' – ' || ""Objekt"", ''), 500), TRUE " & _
		"FROM ""Leistung"" WHERE ""ID"" = " & nL)
	Gespeichert()
	Fm(oDoc, "LeistungInfo").reload()
	Fm(oDoc, "LeistungProt").reload()
	Spaeter("LM")  ' V8.5-Q2: „!“ in der Leistungsliste neu lesen
	StatusSetzen(oDoc, "Leistung erbracht eingetragen – Angaben bei Gelegenheit ergänzen")
	Exit Sub
Fehler:
	Fehlermeldung("Leistung eintragen", Error$)
End Sub

Sub EintragNeuFuerLeistung(Optional oEvent)
	Dim oDoc As Object, nL As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	nL = LeistungGesichert(oDoc)
	If nL = 0 Then Exit Sub
	EintragAnlegen(oDoc, nL)
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Eintrag", Error$)
End Sub

Sub LeistungProtDoppelklick(Optional oEvent)
	Dim oF As Object, nID As Long
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oF = oEvent.Source.Model.Parent
	nID = AktuelleID(oF)
	If nID = 0 Then Exit Sub
	If Not Bereich(AppDoc(), "PR") Then Exit Sub
	ProtokollZeigen(AppDoc(), nID)  ' V8.8c (M1, M2)
	Exit Sub
Fehler:
	Fehlermeldung("Eintrag öffnen", Error$)
End Sub

REM ================================================================ Leistungen (alle)
Sub LeistungenDoppelklick(Optional oEvent)
	Dim oF As Object, nL As Long, nV As Long, oDoc As Object
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oDoc = AppDoc()
	oF = oEvent.Source.Model.Parent
	nL = AktuelleID(oF)
	nV = AktuelleID(oF, "VertragID")
	If nV = 0 Then Exit Sub
	If VertragOeffnen(oDoc, nV, "LE", FolgeAus(oF), "VE2") Then LeistungAuswaehlen(oDoc, nL)
	Exit Sub
Fehler:
	Fehlermeldung("Vertrag öffnen", Error$)
End Sub

REM ================================================================ Rechnungsverlauf (PR)
REM Die Liste links ist eine Sicht; rechts steht derselbe Eintrag als bearbeitbare Tabellenzeile.
REM V8.8c (M1–M3): Ziel beim Neuladen. Solange die Liste es sucht, zeigen die Zwischenzeilen rechts nichts an
REM (vorher lief rechts jeder Eintrag kurz durch – das orange „Blinken“ – und ein später Cursor-Sprung blieb stehen).
Global nPrZiel As Long

Sub ProtokollAuswahl(Optional oEvent)
	Dim oF As Object, nID As Long
	On Error Resume Next
	oF = oEvent.Source
	nID = AktuelleID(oF)
	If nPrZiel > 0 And nID <> nPrZiel Then Exit Sub
	If nID > 0 Then EreignisZeigen(AppDoc(), nID)
End Sub

REM V8.8c (M1, M2): Eintrag rechts zeigen und links markieren (Doppelklick im Vertrag, Gesamtsuche)
Sub ProtokollZeigen(oDoc As Object, nID As Long)
	nPrZiel = nID
	EreignisZeigen(oDoc, nID)
	ProtokollNeuLaden(oDoc, nID)
	Spaeter("PRZ", nID)
End Sub

Sub EreignisZeigen(oDoc As Object, nID As Long)
	Dim oE As Object
	oE = Fm(oDoc, "Ereignis")
	If Not oE.IsNew And Not oE.IsModified And AktuelleID(oE) = nID Then Exit Sub
	If Not Speichern(oDoc, oE) Then Exit Sub
	oE.Filter = """ID"" = " & nID
	oE.ApplyFilter = True
	oE.reload()
	Spaeter("S")  ' V8.4-E21: Korrigieren/Verwerfen nach dem Laden des Eintrags
End Sub

Sub ProtokollNeuLaden(oDoc As Object, vID)
	Dim oP As Object, nID As Long
	On Error Resume Next
	oP = Fm(oDoc, "Protokoll")
	If IsEmpty(vID) Then
		oP.reload()
		Exit Sub
	End If
	nID = vID
	nPrZiel = nID  ' V8.8c
	oP.reload()
	oP.beforeFirst()
	Do While oP.next()
		If oP.getLong(oP.findColumn("ID")) = nID Then
			nPrZiel = 0
			Exit Sub
		End If
	Loop
	nPrZiel = 0
	oP.first()
End Sub

Sub EintragNeu(Optional oEvent)
	On Error GoTo Fehler
	EintragAnlegen(AppDoc(), 0)
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Eintrag", Error$)
End Sub

REM Neuer Protokolleintrag, auf Wunsch mit vorbelegter Leistung und heutigem Datum.
Sub EintragAnlegen(oDoc As Object, nLeistung As Long)
	Dim oE As Object
	If Not Bereich(oDoc, "PR") Then Exit Sub
	oE = Fm(oDoc, "Ereignis")
	If Not Speichern(oDoc, oE) Then Exit Sub
	NeueZeile(oE)
	oE.updateDate(oE.findColumn("Datum"), CDateToUnoDate(Date()))
	If nLeistung > 0 Then
		oE.updateLong(oE.findColumn("LeistungID"), nLeistung)
		FokusAuf(oDoc, "Ereignis", "PR_lbArt")
	Else
		FokusAuf(oDoc, "Ereignis", "PR_lbLeistung")
	End If
End Sub

Function EreignisPruefen(Optional oEvent) As Boolean
	Dim oF As Object, c As Object, sFehlt As String, sFalsch As String, sArt As String
	Dim dG As Date, dR As Date, tG As Double, tR As Double
	EreignisPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	oF = oEvent.Source
	c = oF.Columns
	c.getByName("LeistungID").getInt()
	If c.getByName("LeistungID").wasNull() Then sFehlt = "die Leistung"
	c.getByName("Datum").getDate()
	If c.getByName("Datum").wasNull() Then sFehlt = sFehlt & IIf(sFehlt = "", "", ", ") & "das Datum"
	sArt = Trim(c.getByName("Art").getString())
	If sArt = "" Then sFehlt = sFehlt & IIf(sFehlt = "", "", ", ") & "das Ereignis"
	If sArt = "Rechnung erhalten" Then
		c.getByName("Betrag").getDouble()
		If c.getByName("Betrag").wasNull() Then sFehlt = sFehlt & IIf(sFehlt = "", "", ", ") & "den Rechnungsbetrag"
		c.getByName("FreigabeBetrag").getDouble()
		If Not c.getByName("FreigabeBetrag").wasNull() Then
			c.getByName("FreigabeDatum").getDate()
			If c.getByName("FreigabeDatum").wasNull() Then sFehlt = sFehlt & IIf(sFehlt = "", "", ", ") & "das Freigabedatum"
		End If
	End If
	If sArt = "Leistungsanfall" Then
		REM V8.2c-N19: leeres Meldedatum setzt die Datenbank auf heute
		If SpalteDatum(c.getByName("GemeldetAm"), dG) Then
			If SpalteDatum(c.getByName("ReagiertAm"), dR) Then
				tG = ZeitWert(c.getByName("GemeldetUm"))
				tR = ZeitWert(c.getByName("ReagiertUm"))
				If CDbl(dR) + tR < CDbl(dG) + tG Then sFalsch = "Die Erledigung liegt vor der Meldung."
			End If
		End If
	End If
	If sFehlt <> "" Then
		MsgBox "Bitte trag noch " & sFehlt & " ein." & Chr(10) & "Der Eintrag ist noch nicht gespeichert." & NeuHinweis(oEvent), 48, "Protokoll"
		Spaeter("PFOKUS", "Ereignis")  ' V8.8 (KON-02)
		EreignisPruefen = False
	ElseIf sFalsch <> "" Then
		MsgBox sFalsch & Chr(10) & "Der Eintrag ist noch nicht gespeichert.", 48, "Protokoll"
		EreignisPruefen = False
	End If
Ende:
End Function

Function ZeitWert(oCol As Object) As Double
	Dim t
	ZeitWert = 0
	On Error Resume Next
	t = oCol.getTime()
	If oCol.wasNull() Then Exit Function
	ZeitWert = (t.Hours * 60 + t.Minutes) / 1440
End Function

Sub EreignisGespeichert(Optional oEvent)
	Dim nE As Long
	On Error Resume Next
	REM V8.5-Q3: Einmal gesichert = Angaben ergänzt
	nE = AktuelleID(oEvent.Source)
	If nE > 0 Then Verbindung().createStatement().executeUpdate("UPDATE ""Ereignis"" SET ""Ergaenzen"" = FALSE WHERE ""Ergaenzen"" AND ""ID"" = " & nE)
	Gespeichert()
	Spaeter("LM")  ' V8.5-Q2
	Spaeter("Ereignis", AktuelleID(oEvent.Source))
	oEvent.Source.getByName("PR_cbFreiVon").refresh()  ' V8.2b-M20: neue Werte in die Vorschläge
	oEvent.Source.getByName("PR_cbBeleg").refresh()
End Sub

Sub EreignisInfoFaerben(Optional oEvent)
	Dim oF As Object, s As String, oM As Object
	On Error Resume Next
	oF = oEvent.Source
	s = ""
	If oF.RowCount > 0 And Not oF.isBeforeFirst() And Not oF.isAfterLast() Then s = oF.getString(oF.findColumn("Pruefergebnis"))
	oM = oF.getByName("PR_txtPruef")
	If s = "Zulässig" Or s = "Soll eingehalten" Or s = "Über der Grenze – zulässig" Then
		Pille(oM, "gruen")
	ElseIf s = "" Or InStr(s, "storniert") > 0 Or Left(s, 14) = "Erledigt nach " Then
		Pille(oM, "")
	ElseIf s = "Erledigung offen" Or s = "Betrag oder Datum fehlt" Or s = "Abdeckung fehlt" Then
		Pille(oM, "gelb")
	Else
		Pille(oM, "rot")
	End If
	EreignisMarken(oF)  ' V8.2a E14
	Spaeter("S")  ' V8.4-E21: Korrigieren/Verwerfen je Eintrag
	Spaeter("H")  ' V8.2b-M19
End Sub

REM V8.2b-M21: „Löschen" im Protokoll heißt „Verwerfen" und verwirft nur ungesicherte Eingaben.
REM Gesicherte Einträge korrigiert man über „Storniert" (später Storno-Zeile, Paket D).
Sub EintragVerwerfen(Optional oEvent)
	Dim oDoc As Object, oE As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oE = Fm(oDoc, "Ereignis")
	If oE.IsModified Or oE.IsNew Then Verwerfen(oDoc, oE)
	SichernFarbe(oDoc)
	Exit Sub
Fehler:
	Fehlermeldung("Eintrag verwerfen", Error$)
End Sub

Sub EintragZumVertrag(Optional oEvent)
	Dim oDoc As Object, oE As Object, nL As Long, nV As Long, rs As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oE = Fm(oDoc, "Ereignis")
	If Not Speichern(oDoc, oE) Then Exit Sub
	nL = AktuelleID(oE, "LeistungID")
	If nL = 0 Then
		MsgBox "Wähle zuerst einen Eintrag in der Liste.", 48, "Protokoll"
		Exit Sub
	End If
	rs = Verbindung().createStatement().executeQuery("SELECT ""VertragID"" FROM ""Leistung"" WHERE ""ID"" = " & nL)
	If rs.next() Then nV = rs.getLong(1)
	If nV = 0 Then Exit Sub
	If VertragOeffnen(oDoc, nV, "PR", FolgeAlle(Verbindung()), "VE2") Then LeistungAuswaehlen(oDoc, nL)
	Exit Sub
Fehler:
	Fehlermeldung("Zum Vertrag", Error$)
End Sub

REM ================================================================ Vertretung (VT)
Sub TabUebergabe(Optional oEvent)
	Gehe("VT1")
End Sub
Sub TabPunkte(Optional oEvent)
	Gehe("VT2")
End Sub

Sub VertretungNeu(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not Bereich(oDoc, "VT1") Then Exit Sub
	oF = Fm(oDoc, "Vertretung")
	NeueZeile(oF)
	oF.updateString(oF.findColumn("UebergebenVon"), Benutzer())
	oF.updateDate(oF.findColumn("UebergabeAm"), CDateToUnoDate(Date()))
	FokusAuf(oDoc, "Vertretung", "VT1_txtVertreter")
	Exit Sub
Fehler:
	Fehlermeldung("Neue Vertretung", Error$)
End Sub

Function VertretungPruefen(Optional oEvent) As Boolean
	Dim c As Object, sFehlt As String, dA As Date, dB As Date, dR As Date
	VertretungPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	c = oEvent.Source.Columns
	If Trim(c.getByName("Vertreter").getString()) = "" Then sFehlt = "wer vertritt"
	If Not SpalteDatum(c.getByName("Ab"), dA) Then
		sFehlt = sFehlt & IIf(sFehlt = "", "", " und ") & "ab wann"
	Else
		If SpalteDatum(c.getByName("Bis"), dB) And dB < dA Then
			MsgBox "„Bis“ liegt vor „Ab“. Bitte korrigiere das Datum.", 48, "Vertretung"
			VertretungPruefen = False
			Exit Function
		End If
		If SpalteDatum(c.getByName("RueckgabeAm"), dR) And dR < dA Then
			MsgBox "Die Rückgabe liegt vor dem Beginn der Vertretung. Bitte korrigiere das Datum.", 48, "Vertretung"
			VertretungPruefen = False
			Exit Function
		End If
	End If
	If sFehlt <> "" Then
		MsgBox "Bitte trag noch ein: " & sFehlt & "." & NeuHinweis(oEvent), 48, "Vertretung"
		VertretungPruefen = False
	End If
Ende:
End Function

Sub VertretungGespeichert(Optional oEvent)
	On Error Resume Next
	Gespeichert()
	Spaeter("Vertretung")
End Sub

Function PunktPruefen(Optional oEvent) As Boolean
	PunktPruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then Exit Function
	If Trim(oEvent.Source.Columns.getByName("Was").getString()) = "" Then
		MsgBox "Bitte beschreib den offenen Punkt in der Spalte „Was ist zu tun“." & NeuHinweis(oEvent, True), 48, "Vertretung"
		PunktPruefen = False
	End If
Ende:
End Function

Sub VertretungLoeschen(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Vertretung")
	If oF.IsNew Or oF.IsModified Then  ' V8.4-P04
		Verwerfen(oDoc, oF)
		Spaeter("S")
		Exit Sub
	End If
	If AktuelleID(oF) = 0 Then Exit Sub
	If MsgBox("Diese Vertretung mit ihren offenen Punkten löschen?" & Chr(10) & _
		"Sie bleibt 90 Tage im Papierkorb.", 4 + 32 + 256, "Vertretung löschen") <> 6 Then Exit Sub
	oF.deleteRow()
	Gespeichert()
	Exit Sub
Fehler:
	Fehlermeldung("Vertretung löschen", Error$)
End Sub

REM ================================================================ Einstellungen (EI)
Function EinstellungPruefen(Optional oEvent) As Boolean
	Dim c As Object, nW As Long, nV As Long, s As String
	EinstellungPruefen = True
	On Error GoTo Ende
	c = oEvent.Source.Columns
	nW = c.getByName("WarnTage").getLong()
	If c.getByName("WarnTage").wasNull() Then nW = -1
	nV = c.getByName("VorwarnTage").getLong()
	If c.getByName("VorwarnTage").wasNull() Then nV = -1
	If nW < 1 Or nW > 730 Then
		s = "„Rot ab … Tagen“ muss zwischen 1 und 730 liegen."
	ElseIf nV < nW Or nV > 1095 Then
		s = "„Gelb ab … Tagen“ muss mindestens so groß sein wie „Rot ab … Tagen“ (höchstens 1095)."
	ElseIf c.getByName("LeistungTage").getLong() > 365 Or c.getByName("LeistungTage").wasNull() Then
		s = "„Leistung bald fällig“ muss zwischen 0 und 365 Tagen liegen."
	ElseIf c.getByName("PruefMonate").getLong() < 1 Or c.getByName("PruefMonate").wasNull() Then
		s = "Das Prüfintervall muss mindestens 1 Monat sein."
	ElseIf c.getByName("IndexTage").getLong() > 365 Or c.getByName("IndexTage").wasNull() Then
		s = "Der Vorlauf für Indexanpassungen muss zwischen 0 und 365 Tagen liegen."
	ElseIf c.getByName("SicherungAnzahl").getLong() < 1 Or c.getByName("SicherungAnzahl").wasNull() Then
		s = "Es muss mindestens 1 Sicherung behalten werden."
	End If
	If s <> "" Then
		MsgBox s & Chr(10) & "Die Einstellungen sind noch nicht gespeichert.", 48, "Einstellungen"
		EinstellungPruefen = False
	End If
Ende:
End Function

Sub EinstellungGespeichert(Optional oEvent)
	Gespeichert()
	Spaeter("D")  ' V8.4-E18: Datumsanzeige übernehmen
End Sub

Function ListePruefen(Optional oEvent) As Boolean
	Dim c As Object, sTyp As String
	ListePruefen = True
	On Error GoTo Ende
	If oEvent.Action = com.sun.star.sdb.RowChangeAction.DELETE Then
		sTyp = oEvent.Source.getString(oEvent.Source.findColumn("Typ"))
		If sTyp = "Status" Or sTyp = "Zahlungsintervall" Or sTyp = "Ereignis" Or sTyp = "Abdeckung" Or sTyp = "Entscheidung" Then
			MsgBox "Werte der Liste „" & sTyp & "“ steuern Berechnungen. Sie lassen sich hier nicht löschen.", 48, "Auswahllisten"
			ListePruefen = False
		End If
		Exit Function
	End If
	c = oEvent.Source.Columns
	sTyp = Trim(c.getByName("Typ").getString())
	If sTyp = "" Or Trim(c.getByName("Wert").getString()) = "" Then
		MsgBox "Bitte trag Liste und Wert ein." & NeuHinweis(oEvent, True), 48, "Auswahllisten"
		ListePruefen = False
	ElseIf InStr(",Vertragsart,Status,Kuendigungstermin,Entscheidung,Versandart,Abdeckung,Ereignis,Zahlungsintervall,", "," & sTyp & ",") = 0 Then
		MsgBox "Diese Liste gibt es nicht. Erlaubt sind: Vertragsart, Versandart, Kuendigungstermin, Entscheidung, Status, " & _
			"Abdeckung, Ereignis, Zahlungsintervall.", 48, "Auswahllisten"
		ListePruefen = False
	End If
	If ListePruefen And oEvent.Action = com.sun.star.sdb.RowChangeAction.INSERT Then
		Dim rs As Object
		rs = oEvent.Source.ActiveConnection.createStatement().executeQuery("SELECT COUNT(*) FROM ""Liste"" WHERE ""Typ"" = '" & _
			Esc(sTyp) & "' AND ""Wert"" = '" & Esc(Trim(c.getByName("Wert").getString())) & "'")
		rs.next()
		If rs.getLong(1) > 0 Then
			MsgBox "Diesen Wert gibt es in der Liste schon." & NeuHinweis(oEvent, True), 48, "Auswahllisten"
			ListePruefen = False
		End If
	End If
Ende:
End Function

Sub BeispieleEntfernen(Optional oEvent)
	Dim oDoc As Object, oCon As Object, st As Object, rs As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oCon = Verbindung()
	rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM ""Vertrag"" WHERE ""Beispiel"" IS TRUE")
	rs.next()
	If rs.getLong(1) = 0 Then
		MsgBox "Es sind keine Beispieldaten mehr vorhanden.", 64, "Beispieldaten"
		Exit Sub
	End If
	If MsgBox("Alle Beispiel-Verträge mit Leistungen und Protokoll, die Beispiel-Partner und die Beispiel-Vertretung löschen?" & _
		Chr(10) & "Deine eigenen Einträge bleiben erhalten.", 4 + 32 + 256, "Beispieldaten") <> 6 Then Exit Sub
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	st = oCon.createStatement()
	REM Beispielzeilen der Änderungsspur entfernen; das Löschen selbst nicht aufzeichnen
	st.executeUpdate("DELETE FROM ""Aenderung"" WHERE ""VertragID"" IN (SELECT ""ID"" FROM ""Vertrag"" WHERE ""Beispiel"" IS TRUE) " & _
		"OR (""Tabelle"" = 'Partner' AND ""DatensatzID"" IN (SELECT ""ID"" FROM ""Partner"" WHERE ""Beispiel"" IS TRUE)) " & _
		"OR ""Benutzer"" = 'Anna Beispiel'")
	KeineSpur(oCon, True)
	st.executeUpdate("DELETE FROM ""Vertrag"" WHERE ""Beispiel"" IS TRUE")
	st.executeUpdate("DELETE FROM ""Partner"" p WHERE p.""Beispiel"" IS TRUE AND NOT EXISTS " & _
		"(SELECT 1 FROM ""Vertrag"" v WHERE v.""PartnerID"" = p.""ID"")")
	st.executeUpdate("DELETE FROM ""Vertretung"" WHERE ""Beispiel"" IS TRUE")
	st.executeUpdate("DELETE FROM ""AbgleichBefund""")
	KeineSpur(oCon, False)
	DbDoc().store()
	AlleNeuLaden(oDoc)
	StatusSetzen(oDoc, "Beispieldaten entfernt")
	MsgBox "Die Beispieldaten sind entfernt.", 64, "Beispieldaten"
	REM V8.1-P5: Löschen ohne Spur → beim nächsten Schließen einen neuen Basisstand der Textsicherung schreiben
	BasisErzwingen()
	Exit Sub
Fehler:
	On Error Resume Next
	KeineSpur(oCon, False)
	Fehlermeldung("Beispieldaten entfernen", Error$)
End Sub

Sub AlleNeuLaden(oDoc As Object)
	Dim a, i As Integer
	On Error Resume Next
	a = Array("Nav", "Heute", "Fristen", "Liste", "Vertrag", "Leistungen", "Protokoll", "Ereignis", "Partner", "Vertretung", _
		"Aenderungen", "Abgleich", "Einstellung", "Listen")
	For i = 0 To UBound(a)
		Fm(oDoc, a(i)).reload()
	Next i
End Sub


REM ================================================================ V8.1-P4 · Papierkorb

REM Beim Start: Einträge, die älter als 90 Tage sind, endgültig löschen (eine kurze Anweisung).
Sub PapierkorbAufraeumen()
	On Error Resume Next
	Verbindung().createStatement().executeUpdate("EXECUTE PROCEDURE ""P_PK_AUFRAEUMEN""(" & PK_TAGE & ")")
End Sub

Function PapierkorbAuswahl(oF As Object, sWas As String) As Long
	PapierkorbAuswahl = 0
	If oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then
		MsgBox "Der Papierkorb ist leer.", 64, "Papierkorb"
		Exit Function
	End If
	PapierkorbAuswahl = oF.getLong(oF.findColumn("Vorgang"))
	sWas = oF.getString(oF.findColumn("Art")) & " „" & oF.getString(oF.findColumn("Was")) & "“"
	If oF.getString(oF.findColumn("Dazu")) <> "" Then sWas = sWas & " " & oF.getString(oF.findColumn("Dazu"))
End Function

Sub PapierkorbZurueck(Optional oEvent)
	Dim oDoc As Object, oF As Object, nV As Long, sWas As String, sFehler As String
	oDoc = AppDoc()
	oF = Fm(oDoc, "Papierkorb")
	nV = PapierkorbAuswahl(oF, sWas)
	If nV = 0 Then Exit Sub
	On Error GoTo Fehler
	BenutzerSetzen(AppDoc())  ' V8.2c-N03
	Verbindung().createStatement().executeUpdate("EXECUTE PROCEDURE ""P_ZURUECK""(" & nV & ")")
	Gespeichert()
	AlleNeuLaden(oDoc)
	oF.reload()
	MsgBox "Zurückgeholt: " & sWas, 64, "Papierkorb"
	Exit Sub
Fehler:
	sFehler = Error$
	On Error Resume Next
	If InStr(sFehler, "UNIQUE") > 0 Then
		MsgBox "Zurückholen geht nicht: Es gibt inzwischen einen Eintrag mit derselben Nummer oder demselben Namen." & _
			Chr(10) & "Ändere zuerst diesen Eintrag. " & sWas, 48, "Papierkorb"
	ElseIf InStr(sFehler, "FOREIGN") > 0 Then
		MsgBox "Zurückholen geht nicht: Der übergeordnete Eintrag (z. B. der Vertrag oder der Partner) ist selbst gelöscht." & _
			Chr(10) & "Hol zuerst ihn aus dem Papierkorb zurück.", 48, "Papierkorb"
	Else
		Fehlermeldung("Zurückholen", sFehler)
	End If
End Sub

Sub PapierkorbEndgueltig(Optional oEvent)
	Dim oDoc As Object, oF As Object, nV As Long, sWas As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Papierkorb")
	nV = PapierkorbAuswahl(oF, sWas)
	If nV = 0 Then Exit Sub
	If MsgBox(sWas & " endgültig löschen?" & Chr(10) & "Das lässt sich nicht rückgängig machen.", 4 + 48 + 256, _
		"Endgültig löschen") <> 6 Then Exit Sub
	Verbindung().createStatement().executeUpdate("EXECUTE PROCEDURE ""P_PK_LOESCHEN""(" & nV & ")")
	Gespeichert()
	oF.reload()
	Exit Sub
Fehler:
	Fehlermeldung("Endgültig löschen", Error$)
End Sub

Sub BasisErzwingen()
	Dim oSFA As Object, sText As String
	On Error Resume Next
	sText = TextOrdner(DbDoc(), SichOrdner(DbDoc(), Verbindung()))  ' V8.4-F10
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	If Not oSFA.exists(sText) Then oSFA.createFolder(sText)
	DateiSchreiben(sText & "basis_erzwingen.txt", Format(Now(), "YYYY-MM-DD hh:mm:ss"))
End Sub

REM V8.5-Q2: Die Liste im Vertrag liest die Spalte „Marke“ der Tabelle. Nach „Heute erbracht“ oder einem gesicherten
REM Eintrag neu laden und die gewählte Leistung wieder auswählen (sonst blieb „!!“ stehen).
Sub LeistungListeNeu(oDoc As Object)
	Dim oF As Object, nID As Long
	On Error Resume Next
	REM Nur in der Ansicht des Vertrags; hat man sie schon verlassen (z. B. „+ Eintrag“), stört das Neuladen nur
	If oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag <> "VE2" Then Exit Sub
	oF = Fm(oDoc, "Leistung")
	If oF.IsModified Or oF.IsNew Then Exit Sub
	nID = AktuelleID(oF)
	oF.reload()
	If nID > 0 Then LeistungAuswaehlen(oDoc, nID)
End Sub

REM V8.5-Q7 (Nico 15.10. 15:10): „Neue Leistung“ in der Ansicht Leistungen – Vertrag im Dialog wählen
Sub LeistungNeuAusListe(Optional oEvent)
	Dim oDoc As Object, rs As Object, aID() As Long, aTxt() As String, n As Long, nVor As Long, nSel As Long, nV As Long
	Dim oDM As Object, oDlg As Object, o As Object, aSel, i As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	nVor = AktuelleID(Fm(oDoc, "Leistungen"), "VertragID")
	rs = Verbindung().createStatement().executeQuery("SELECT ""ID"", ""Nr"" || ' – ' || ""Gegenstand"" || COALESCE(' (' || ""Partner"" || ')', '') || " & _
		"IIF(""Status"" IN ('aktiv', 'zukünftig'), '', ' · ' || ""Status"") FROM ""V_Vertrag"" " & _
		"ORDER BY IIF(""Status"" IN ('aktiv', 'zukünftig'), 0, 1), ""Nr""")
	n = 0
	ReDim aID(500) As Long : ReDim aTxt(500) As String
	nSel = 0
	Do While rs.next()
		If n > 500 Then Exit Do
		aID(n) = rs.getLong(1) : aTxt(n) = rs.getString(2)
		If aID(n) = nVor Then nSel = n
		n = n + 1
	Loop
	If n = 0 Then
		MsgBox "Es gibt noch keinen Vertrag. Lege zuerst unter „Verträge“ einen Vertrag an.", 64, "Neue Leistung"
		Exit Sub
	End If
	ReDim Preserve aTxt(n - 1) As String
	oDM = createUnoService("com.sun.star.awt.UnoControlDialogModel")
	oDM.Width = 300 : oDM.Height = 200 : oDM.Title = "Neue Leistung"
	o = oDM.createInstance("com.sun.star.awt.UnoControlFixedTextModel")
	o.PositionX = 8 : o.PositionY = 6 : o.Width = 284 : o.Height = 12 : o.Label = "Für welchen Vertrag ist die Leistung?"
	oDM.insertByName("lblInfo", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlListBoxModel")
	o.PositionX = 8 : o.PositionY = 20 : o.Width = 284 : o.Height = 152 : o.Dropdown = False
	o.StringItemList = aTxt()
	o.SelectedItems = Array(nSel)
	oDM.insertByName("lbVertrag", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlButtonModel")
	o.PositionX = 172 : o.PositionY = 180 : o.Width = 58 : o.Height = 14 : o.Label = "Weiter" : o.PushButtonType = 1 : o.DefaultButton = True
	oDM.insertByName("btnOK", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlButtonModel")
	o.PositionX = 234 : o.PositionY = 180 : o.Width = 58 : o.Height = 14 : o.Label = "Abbrechen" : o.PushButtonType = 2
	oDM.insertByName("btnAbbrechen", o)
	oDlg = createUnoService("com.sun.star.awt.UnoControlDialog")
	oDlg.setModel(oDM)
	oDlg.createPeer(createUnoService("com.sun.star.awt.Toolkit"), Null)
	oDlg.getControl("lbVertrag").setFocus()
	If oDlg.execute() <> 1 Then
		oDlg.dispose()
		Exit Sub
	End If
	aSel = oDM.getByName("lbVertrag").SelectedItems
	oDlg.dispose()
	If UBound(aSel) < 0 Then Exit Sub
	nV = aID(aSel(0))
	If Not VertragOeffnen(oDoc, nV, "LE", "", "VE2") Then Exit Sub
	LeistungNeu()
	Exit Sub
Fehler:
	Fehlermeldung("Neue Leistung", Error$)
End Sub
