
REM ================================================================ B3 · Termine nach HCL Notes (Logik aus Fristen.bas, AP1–AP3)
REM Die Termine rechnet die Sicht V_NotesTermine. Hier wird nur die Kalenderdatei (.ics) geschrieben.
REM V8.4-E18: Einstellungen für den Notes-Export
Global bNotesGanz As Boolean
Global bNotesErinnerung As Boolean
Global nNotesStunde As Integer

Sub NotesEinstellungLesen()
	Dim rs As Object
	bNotesGanz = True : bNotesErinnerung = True : nNotesStunde = 9
	On Error Resume Next
	rs = Verbindung().createStatement().executeQuery("SELECT ""NotesGanztaegig"", ""NotesErinnerung"", ""NotesUhrzeit"" FROM ""Einstellung"" WHERE ""ID"" = 1")
	If rs.next() Then
		bNotesGanz = rs.getBoolean(1)
		bNotesErinnerung = rs.getBoolean(2)
		nNotesStunde = rs.getShort(3)
	End If
	If nNotesStunde < 0 Or nNotesStunde > 23 Then nNotesStunde = 9
End Sub

Sub NotesExport(Optional oEvent)
	Dim oDoc As Object, oDb As Object, rs As Object, sCal As String, n As Long, sZiel As String, d As Date
	On Error GoTo Fehler
	oDoc = AppDoc()
	oDb = DbDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	rs = Verbindung().createStatement().executeQuery("SELECT ""Uid"", ""Tag"", ""Titel"", ""Text"" FROM ""V_NotesTermine"" " & _
		"ORDER BY ""Tag"", ""Uid""")
	sCal = ""
	IcsZeile(sCal, "BEGIN:VCALENDAR")
	IcsZeile(sCal, "VERSION:2.0")
	IcsZeile(sCal, "PRODID:-//Vertragsregister//LibreOffice Base//DE")
	IcsZeile(sCal, "CALSCALE:GREGORIAN")
	IcsZeile(sCal, "METHOD:PUBLISH")
	IcsZeile(sCal, "X-WR-CALNAME:Vertragsfristen")
	NotesEinstellungLesen()  ' V8.4-E18
	n = 0
	Do While rs.next()
		d = CDateFromUnoDate(rs.getDate(2))
		IcsTermin(sCal, rs.getString(1), d, rs.getString(3), IcsEsc(rs.getString(4)))
		n = n + 1
	Loop
	IcsZeile(sCal, "END:VCALENDAR")
	sZiel = OrdnerNebenDatei(oDb, "Export") & "Vertragsfristen_" & Format(Date(), "YYYY-MM-DD") & ".ics"
	DateiSchreiben(sZiel, sCal)
	Verbindung().createStatement().executeUpdate("UPDATE ""Einstellung"" SET ""LetzterExport"" = CURRENT_TIMESTAMP WHERE ""ID"" = 1")
	oDb.store()
	StatusSetzen(oDoc, n & " Termine exportiert")
	MsgBox n & " Termine stehen in der Datei:" & Chr(10) & ConvertFromURL(sZiel) & Chr(10) & Chr(10) & _
		"In HCL Notes: Kalender öffnen › Datei › Importieren › Dateityp iCalendar › diese Datei wählen.", 64, "Termine nach Notes"
	Exit Sub
Fehler:
	Fehlermeldung("Termine exportieren", Error$)
End Sub

Sub IcsTermin(sCal As String, sUid As String, dTag As Date, sTitel As String, sText As String)
	Dim jetzt As Date
	jetzt = Now()
	IcsZeile(sCal, "BEGIN:VEVENT")
	IcsZeile(sCal, "UID:" & sUid & "@vertragsregister")
	REM V8.5: DTSTAMP in echter UTC-Zeit (vorher Ortszeit mit „Z“)
	jetzt = JetztUtc()
	IcsZeile(sCal, "DTSTAMP:" & DatumIso(jetzt) & "T" & Format(jetzt, "hhmmss") & "Z")
	REM V8.4-E18: ganztägig oder zur eingestellten Uhrzeit (Ortszeit, 1 Stunde)
	If bNotesGanz Then
		IcsZeile(sCal, "DTSTART;VALUE=DATE:" & DatumIso(dTag))
		IcsZeile(sCal, "DTEND;VALUE=DATE:" & DatumIso(dTag + 1))
	Else
		IcsZeile(sCal, "DTSTART:" & DatumIso(dTag) & "T" & Format(nNotesStunde, "00") & "0000")
		IcsZeile(sCal, "DTEND:" & DatumIso(dTag) & "T" & Format((nNotesStunde + 1) Mod 24, "00") & "0000")
	End If
	IcsZeile(sCal, "SUMMARY:" & IcsEsc(sTitel))
	IcsZeile(sCal, "DESCRIPTION:" & sText)
	IcsZeile(sCal, "CATEGORIES:Vertragsregister")
	IcsZeile(sCal, "TRANSP:TRANSPARENT")
	If bNotesErinnerung Then
		IcsZeile(sCal, "BEGIN:VALARM")
		IcsZeile(sCal, "ACTION:DISPLAY")
		IcsZeile(sCal, "DESCRIPTION:" & IcsEsc(sTitel))
		REM ganztägig: am Tag um die eingestellte Uhrzeit; sonst 15 Minuten vorher
		IcsZeile(sCal, IIf(bNotesGanz, "TRIGGER:PT" & nNotesStunde & "H", "TRIGGER:-PT15M"))
		IcsZeile(sCal, "END:VALARM")
	End If
	IcsZeile(sCal, "END:VEVENT")
End Sub

REM Hängt eine Zeile an und faltet sie nach RFC 5545 (höchstens 60 Zeichen je Teilzeile).
Sub IcsZeile(sCal As String, s As String)
	Dim rest As String
	rest = s
	sCal = sCal & Left(rest, 60)
	rest = Mid(rest, 61)
	Do While Len(rest) > 0
		sCal = sCal & Chr(13) & Chr(10) & " " & Left(rest, 59)
		rest = Mid(rest, 60)
	Loop
	sCal = sCal & Chr(13) & Chr(10)
End Sub

REM Maskiert Text für iCalendar; Zeilenumbrüche werden zu \n.
Function IcsEsc(s As String) As String
	Dim t As String
	t = Join(Split(s, "\"), "\\")
	t = Join(Split(t, ";"), "\;")
	t = Join(Split(t, ","), "\,")
	t = Join(Split(t, Chr(13) & Chr(10)), "\n")
	t = Join(Split(t, Chr(10)), "\n")
	IcsEsc = t
End Function

Sub DateiSchreiben(sURL As String, sInhalt As String)
	Dim oSFA As Object, oOut As Object, oText As Object
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	If oSFA.exists(sURL) Then oSFA.kill(sURL)
	oOut = oSFA.openFileWrite(sURL)
	oText = createUnoService("com.sun.star.io.TextOutputStream")
	oText.setOutputStream(oOut)
	oText.setEncoding("UTF-8")
	oText.writeString(sInhalt)
	oText.closeOutput()
End Sub

REM ================================================================ Exportieren je Ansicht
Sub ExportAnsicht(Optional oEvent)
	Dim oDoc As Object, s As String, sW As String, oF As Object, nID As Long, a
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	s = AktuellerBereich(oDoc)
	Select Case Left(s, 2)
		Case "ST"
			a = Array(Array("Offen", "SELECT ""Symbol"" AS ""Stufe"", ""DatumText"" AS ""Datum"", ""Aufgabe"", ""Gegenstand"" AS ""Vertrag"" " & _
				"FROM ""V_HeuteListe"" ORDER BY ""Prio"", ""Bezug"""), _
				Array("Nächste Termine (12 Monate)", "SELECT ""Datum"", ""Art"" AS ""Termin"", ""Gegenstand"" AS ""Vertrag"" " & _
				"FROM ""V_FristenListe"" ORDER BY ""Datum"", ""ID"""))
			ExportBloecke(oDoc, "Übersicht", a)
		Case "LI"
			sW = FilterVon(Fm(oDoc, "Liste"))
			ExportBloecke(oDoc, "Verträge", Array(Array("Verträge", "SELECT x.""Nr"", x.""Gegenstand"", x.""Partner"", x.""Art"", " & _
				"x.""Status"", x.""Anzeige"" AS ""Stand"", v.""Beginn"", v.""ErstesEnde"" AS ""Erstes Ende"", v.""Ende"" AS ""Laufzeitende"", " & _
				"v.""Stichtag"" AS ""Kündigungsstichtag"", v.""Kosten"" AS ""Betrag je Zahlung €"", v.""Intervall"", " & _
				"x.""Jahreskosten"" AS ""Jahreskosten €"", x.""Kostenstelle"" FROM ""V_Liste"" x JOIN ""V_Vertrag"" v ON v.""ID"" = x.""ID""" & _
				IIf(sW = "", "", " WHERE " & PraefixFilter(sW, "x.")) & " ORDER BY x.""Prio"", x.""Bezug""")))
		Case "VE"
			oF = Fm(oDoc, "Vertrag")
			nID = AktuelleID(oF)
			If nID = 0 Then
				MsgBox "Sichere zuerst den Vertrag.", 48, "Exportieren"
				Exit Sub
			End If
			ExportBloecke(oDoc, "Vertrag " & SpalteText(oF, "Nr"), Array( _
				Array("Vertrag", "SELECT ""Nr"", ""Gegenstand"", ""Partner"", ""Art"", ""Status"", ""Anzeige"" AS ""Stand"", ""Beginn"", " & _
				"""ErstesEnde"" AS ""Erstes Ende"", ""Ende"" AS ""Laufzeitende"", ""Stichtag"" AS ""Kündigungsstichtag"", " & _
				"""Kosten"" AS ""Betrag je Zahlung €"", ""Intervall"", ""Jahreskosten"" AS ""Jahreskosten €"" FROM ""V_Vertrag"" WHERE ""ID"" = " & nID), _
				Array("Leistungen", "SELECT ""Bezeichnung"" AS ""Leistung"", ""Objekt"", ""Umfang"", ""Abdeckung"", ""GrenzeJahr"" AS ""Grenze € je Jahr"", " & _
				"""SollStunden"" AS ""Erledigungszeit Soll h"", ""IntervallMonate"" AS ""Intervall Monate"", ""Zuletzt"" AS ""Zuletzt erbracht"", " & _
				"""Naechste"" AS ""Nächste Fälligkeit"", ""Anzeige"" AS ""Stand"" FROM ""V_Leistung"" WHERE ""VertragID"" = " & nID & " ORDER BY ""ID"""), _
				Array("Protokoll", "SELECT ""Datum"", ""Leistung"", ""Art"" AS ""Ereignis"", ""Beschreibung"", ""Rechnungsnr"", ""Betrag"" AS ""Betrag €"", " & _
				"""NV"" AS ""nicht verrechenbar €"", ""FreigabeBetrag"" AS ""freigegeben €"", ""Pruefergebnis"" AS ""Stand"", ""Offen"" " & _
				"FROM ""V_Ereignis"" WHERE ""VertragID"" = " & nID & " ORDER BY ""Datum"", ""ID"""), _
				Array("Entscheidungen", "SELECT ""Datum"", ""Art"" AS ""Entscheidung"", ""Verantwortlich"", ""Versandt"", ""Versandart"", ""Bestaetigt"" AS ""Bestätigt"", " & _
				"""Beleg"" FROM ""Entscheidung"" WHERE ""VertragID"" = " & nID & " ORDER BY ""Datum"" DESC"), _
				Array("Dokumente", "SELECT ""Datum"", ""Bezeichnung"", ""Datei"", ""Gilt"" FROM ""Dokument"" WHERE ""VertragID"" = " & nID & " ORDER BY ""Datum"" DESC")))
		Case "LE"
			sW = FilterVon(Fm(oDoc, "Leistungen"))
			ExportBloecke(oDoc, "Leistungen", Array(Array("Leistungen", "SELECT ""Nr"", ""Gegenstand"" AS ""Vertrag"", ""Bezeichnung"" AS ""Leistung"", ""Objekt"", " & _
				"""Umfang"", ""Abdeckung"", ""GrenzeJahr"" AS ""Grenze € je Jahr"", ""SollStunden"" AS ""Erledigungszeit Soll h"", " & _
				"""IntervallMonate"" AS ""Intervall Monate"", ""Zuletzt"" AS ""Zuletzt erbracht"", ""Naechste"" AS ""Nächste Fälligkeit"", " & _
				"""RechnungenJahr"" AS ""Rechnungen lfd. Jahr €"", ""NVJahr"" AS ""nicht verrechenbar €"", ""Anzeige"" AS ""Stand"" FROM ""V_Leistung""" & _
				IIf(sW = "", "", " WHERE " & sW) & " ORDER BY ""Prio"", ""Naechste"", ""Nr""")))
		Case "PR"
			sW = FilterVon(Fm(oDoc, "Protokoll"))
			ExportBloecke(oDoc, "Protokoll", Array(Array("Protokoll und Rechnungen", "SELECT ""Datum"", ""Nr"", ""Gegenstand"" AS ""Vertrag"", ""Leistung"", " & _
				"""Art"" AS ""Ereignis"", ""Beschreibung"", ""Reaktionszeit"" AS ""Erledigungszeit h"", ""Rechnungsnr"", ""Betrag"" AS ""Betrag €"", " & _
				"""NV"" AS ""nicht verrechenbar €"", ""FreigabeDatum"" AS ""Freigegeben am"", ""FreigabeBetrag"" AS ""freigegeben €"", " & _
				"""FreigabeVon"" AS ""Freigegeben von"", ""Storniert"", ""Pruefergebnis"" AS ""Stand"", ""Offen"", ""Bearbeiter"" FROM ""V_Ereignis""" & _
				IIf(sW = "", "", " WHERE " & sW) & " ORDER BY ""Datum"" DESC, ""ID"" DESC")))
		Case "PA"
			ExportBloecke(oDoc, "Partner", Array(Array("Partner", "SELECT ""Name"", ""Ansprechperson"", ""Telefon"", ""Email"" AS ""E-Mail"", " & _
				"""Hotline"", ""Kundennr"" AS ""Kundennummer"", ""Bemerkung"", (SELECT COUNT(*) FROM ""Vertrag"" v WHERE v.""PartnerID"" = p.""ID"") " & _
				"AS ""Verträge"" FROM ""Partner"" p ORDER BY ""Name""")))
		Case "VT"
			oF = Fm(oDoc, "Vertretung")
			nID = AktuelleID(oF)
			a = Array(Array("Vertretungen", "SELECT ""Vertreter"" AS ""Vertretung"", ""Ab"", ""Bis"", ""UebergebenVon"" AS ""Übergeben von"", " & _
				"""UebergabeAm"" AS ""Übergabe am"", ""RueckgabeAm"" AS ""Rückgabe am"", ""DurchgesehenAm"" AS ""Durchgesehen am"", ""Bemerkung"" " & _
				"FROM ""Vertretung"" ORDER BY ""Ab"" DESC"))
			If nID > 0 Then
				ReDim Preserve a(2)
				a(1) = Array("Offene Punkte der gewählten Vertretung", "SELECT p.""Was"", v.""Nr"" AS ""Vertrag"", p.""BisWann"" AS ""Bis wann"", " & _
					"p.""ErledigtAm"" AS ""Erledigt am"", p.""Bemerkung"" FROM ""VertretungPunkt"" p LEFT JOIN ""V_Liste"" v ON v.""ID"" = p.""VertragID"" " & _
					"WHERE p.""VertretungID"" = " & nID & " ORDER BY p.""ID""")
				a(2) = Array("Änderungen während der gewählten Vertretung", "SELECT ""ZeitText"" AS ""Zeit"", ""Benutzer"" AS ""Wer"", ""Bereich"", ""Nr"", " & _
					"""Was"", ""Alt"" AS ""Vorher"", ""Neu"" AS ""Nachher"" FROM ""V_AenderungVertretung"" WHERE ""VertretungID"" = " & nID & " ORDER BY ""Zeit""")
			End If
			ExportBloecke(oDoc, "Vertretung", a)
		Case "AE"
			sW = FilterVon(Fm(oDoc, "Aenderungen"))
			ExportBloecke(oDoc, "Änderungen", Array(Array("Änderungen", "SELECT ""ZeitText"" AS ""Zeit"", ""Benutzer"" AS ""Wer"", ""Bereich"", ""Nr"", " & _
				"""Gegenstand"" AS ""Vertrag"", ""Was"", ""Alt"" AS ""Vorher"", ""Neu"" AS ""Nachher"" FROM ""V_AenderungListe""" & _
				IIf(sW = "", "", " WHERE " & sW) & " ORDER BY ""Zeit"" DESC, ""ID"" DESC")))
		Case "AB"
			ExportBloecke(oDoc, "Ablage", Array(Array("Ablage prüfen", "SELECT ""Nr"", ""Befund"", ""WasTun"" AS ""Was tun"", ""Ort"", " & _
				"""Geaendert"" AS ""Geändert"" FROM ""AbgleichBefund"" ORDER BY ""Nr"", ""ID""")))
		Case Else
			MsgBox "In dieser Ansicht gibt es nichts zu exportieren.", 64, "Exportieren"
	End Select
	Exit Sub
Fehler:
	Fehlermeldung("Exportieren", Error$)
End Sub

Function FilterVon(oF As Object) As String
	FilterVon = ""
	If oF.ApplyFilter Then FilterVon = oF.Filter
End Function

REM Setzt vor die Spaltennamen des Listenfilters einen Tabellenvorsatz (x.).
Function PraefixFilter(s As String, p As String) As String
	Dim t As String
	t = s
	t = Join(Split(t, """Suchtext"""), p & """Suchtext""")
	t = Join(Split(t, """Ampel"""), p & """Ampel""")
	t = Join(Split(t, """Status"""), p & """Status""")
	PraefixFilter = t
End Function

REM Schreibt Blöcke (Überschrift, SQL) untereinander in eine neue Calc-Tabelle, speichert sie im Ordner „Export".
Sub ExportBloecke(oDoc As Object, sTitel As String, aBloecke)
	Dim oCalc As Object, oSh As Object, i As Integer, r As Long, rs As Object, md As Object, n As Integer, c As Integer
	Dim oCell As Object, t As Long, nDatum As Long, nGeld As Long, nZahl As Long, sZiel As String, nMax As Integer
	Dim aLeer(), d, x As Double, k As Long, b As Boolean, s As String
	oCalc = StarDesktop.loadComponentFromURL("private:factory/scalc", "_blank", 0, aLeer())
	oSh = oCalc.Sheets.getByIndex(0)
	oSh.Name = Left(sTitel, 31)
	nDatum = Format_(oCalc, "TT.MM.JJJJ")
	nGeld = Format_(oCalc, "#.##0,00")
	nZahl = Format_(oCalc, "0")
	oCell = oSh.getCellByPosition(0, 0)
	oCell.setString(sTitel)
	oCell.CharHeight = 14 : oCell.CharWeight = 150
	oSh.getCellByPosition(0, 1).setString("Stand " & DatumDe(Date()) & " " & Format(Now(), "hh:mm") & " · " & Benutzer())
	r = 3
	For i = 0 To UBound(aBloecke)
		rs = Verbindung().createStatement().executeQuery(aBloecke(i)(1))
		md = rs.getMetaData()
		n = md.getColumnCount()
		If n > nMax Then nMax = n
		oCell = oSh.getCellByPosition(0, r)
		oCell.setString(aBloecke(i)(0))
		oCell.CharHeight = 12 : oCell.CharWeight = 150
		r = r + 1
		For c = 1 To n
			oCell = oSh.getCellByPosition(c - 1, r)
			oCell.setString(md.getColumnLabel(c))
			oCell.CharWeight = 150
			oCell.CellBackColor = RGB(229, 229, 234)
		Next c
		r = r + 1
		Do While rs.next()
			For c = 1 To n
				oCell = oSh.getCellByPosition(c - 1, r)
				t = md.getColumnType(c)
				Select Case t
					Case 91, 93
						d = rs.getDate(c)
						If Not rs.wasNull() Then
							oCell.setValue(CDbl(CDateFromUnoDate(d)))
							oCell.NumberFormat = nDatum
						End If
					Case 2, 3, 6, 7, 8
						x = rs.getDouble(c)
						If Not rs.wasNull() Then
							oCell.setValue(x)
							oCell.NumberFormat = IIf(InStr(md.getColumnLabel(c), "€") > 0, nGeld, nZahl)
							If InStr(md.getColumnLabel(c), "€") = 0 And x <> Int(x) Then oCell.NumberFormat = 0
						End If
					Case 4, 5, -5, -6
						k = rs.getLong(c)
						If Not rs.wasNull() Then oCell.setValue(k)
					Case 16, -7
						b = rs.getBoolean(c)
						If Not rs.wasNull() Then oCell.setString(IIf(b, "ja", "nein"))
					Case Else
						s = rs.getString(c)
						If Not rs.wasNull() Then oCell.setString(s)
				End Select
			Next c
			r = r + 1
		Loop
		r = r + 1
	Next i
	For c = 0 To nMax - 1
		oSh.Columns.getByIndex(c).OptimalWidth = True
		If oSh.Columns.getByIndex(c).Width > 9000 Then oSh.Columns.getByIndex(c).Width = 9000
	Next c
	sZiel = OrdnerNebenDatei(DbDoc(), "Export") & DateiName(sTitel) & "_" & Format(Date(), "YYYY-MM-DD") & "_" & Format(Time(), "hhmm") & ".ods"
	oCalc.storeAsURL(sZiel, aLeer())
	oCalc.setModified(False)
	StatusSetzen(oDoc, "Exportiert: " & DateiName(sTitel))
End Sub

Function Format_(oCalc As Object, sFormat As String) As Long
	Dim oNF As Object, loc As New com.sun.star.lang.Locale, n As Long
	loc.Language = "de" : loc.Country = "AT"
	oNF = oCalc.NumberFormats
	n = oNF.queryKey(sFormat, loc, False)
	If n = -1 Then n = oNF.addNew(sFormat, loc)
	Format_ = n
End Function

Function DateiName(s As String) As String
	Dim i As Integer, ch As String, t As String
	For i = 1 To Len(s)
		ch = Mid(s, i, 1)
		If InStr("\/:*?""<>|", ch) > 0 Then ch = "-"
		t = t & ch
	Next i
	DateiName = t
End Function

REM ================================================================ B3 · Sicherung
REM V8.1-P5: Vollkopien mit Datum ersetzt durch Spiegel A/B und Textsicherung (05_sicherung.bas).

Sub SicherungOrdnerOeffnen(Optional oEvent)
	Dim s As String
	On Error GoTo Fehler
	s = SichOrdner(DbDoc(), Verbindung())
	ShellOeffnen(s, "Der Ordner ist nicht erreichbar:")
	Exit Sub
Fehler:
	Fehlermeldung("Ordner öffnen", Error$)
End Sub

Sub ExportOrdnerOeffnen(Optional oEvent)
	On Error GoTo Fehler
	ShellOeffnen(OrdnerNebenDatei(DbDoc(), "Export"), "Der Ordner ist nicht erreichbar:")
	Exit Sub
Fehler:
	Fehlermeldung("Ordner öffnen", Error$)
End Sub

REM ================================================================ B3 · Ablage prüfen (Logik aus Betrieb.bas, AP3)
REM Liest das Register aus der Datenbank, schreibt Befunde nur in die Tabelle AbgleichBefund.
Sub AbgleichStarten(Optional oEvent)
	Dim oDoc As Object, sPfad As String, n As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	sPfad = EinstellungText("Ablagepfad")
	If sPfad = "" Then
		MsgBox "Trag zuerst den Ablagepfad ein: Einstellungen › Ablage und Sicherung.", 48, "Ablage prüfen"
		Exit Sub
	End If
	n = AbgleichAusfuehren(sPfad)
	DbDoc().store()
	Fm(oDoc, "Abgleich").reload()
	AbgleichInfo(oDoc)
	If n = -1 Then
		MsgBox "Der Ablagepfad ist nicht erreichbar:" & Chr(10) & sPfad & Chr(10) & Chr(10) & _
			"Prüfe, ob das Laufwerk verbunden ist. Den Pfad änderst du unter Einstellungen › Ablage und Sicherung.", 48, "Ablage prüfen"  ' V8.8 (KON-03)
	ElseIf n = 0 Then
		MsgBox "Keine Abweichungen. Ablage und Register passen zusammen.", 64, "Ablage prüfen"
	End If
	Exit Sub
Fehler:
	Fehlermeldung("Ablage prüfen", Error$)
	REM V8.1-P1 (B-L7): Raster und Infozeile auch nach einem Abbruch auf den Stand der Tabelle bringen
	On Error Resume Next
	Fm(oDoc, "Abgleich").reload()
	AbgleichInfo(oDoc)
End Sub

Sub AbgleichInfo(oDoc As Object)
	Dim rs As Object, s As String, n As Long
	On Error Resume Next
	rs = Verbindung().createStatement().executeQuery("SELECT ""Ablagepfad"", ""LetzterAbgleich"", " & _
		"(SELECT COUNT(*) FROM ""AbgleichBefund"") FROM ""Einstellung"" WHERE ""ID"" = 1")
	rs.next()
	s = "Ablagepfad: " & rs.getString(1)
	rs.getTimestamp(2)
	If rs.wasNull() Then
		s = s & "   ·   noch nicht geprüft"
	Else
		With rs.getTimestamp(2)
			s = s & "   ·   zuletzt geprüft am " & DatumDe(DateSerial(.Year, .Month, .Day)) & " um " & _
				Right("0" & .Hours, 2) & ":" & Right("0" & .Minutes, 2)
		End With
		s = s & "   ·   " & rs.getLong(3) & " Befunde"
	End If
	Fm(oDoc, "Abgleich").getByName("AB_lblPfad").Label = s
End Sub

Sub AbgleichDoppelklick(Optional oEvent)
	Dim oF As Object, s As String
	On Error GoTo Fehler
	If oEvent.ClickCount < 2 Then Exit Sub
	oF = oEvent.Source.Model.Parent
	If AktuelleID(oF) = 0 Then Exit Sub
	s = oF.getString(oF.findColumn("Url"))
	If s = "" Then
		MsgBox "Zu diesem Befund gibt es keinen Ort zum Öffnen.", 64, "Ablage prüfen"
	Else
		ShellOeffnen(s, "Der Ort ist nicht erreichbar:")
	End If
	Exit Sub
Fehler:
	Fehlermeldung("Öffnen", Error$)
End Sub

REM Liefert die Anzahl der Befunde oder -1, wenn der Ordner fehlt.
Function AbgleichAusfuehren(sPfad As String) As Long
	Dim oSFA As Object, oCon As Object, oSt As Object, rs As Object, sBasisURL As String, aEintr(), e, sName As String
	Dim aNr() As String, aOrd() As String, aDocs() As String, aBeleg() As String, aGepr() As Double, aGef() As Boolean
	Dim nReg As Long, i As Long, k As Long, sNr As String
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sBasisURL = ConvertToURL(MitTrenner(sPfad))
	If Right(sBasisURL, 1) <> "/" Then sBasisURL = sBasisURL & "/"
	If Not oSFA.exists(sBasisURL) Then
		AbgleichAusfuehren = -1
		Exit Function
	End If
	If Not oSFA.isFolder(sBasisURL) Then
		AbgleichAusfuehren = -1
		Exit Function
	End If
	oCon = Verbindung()
	oSt = oCon.createStatement()
	oSt.executeUpdate("DELETE FROM ""AbgleichBefund""")
	REM Register: Nummer, Ordner, gültige Dokumente (Dateiname und Datum), zuletzt geprüft, letzter Beleg
	rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM ""Vertrag""")
	rs.next()
	nReg = rs.getLong(1)
	ReDim aNr(nReg) As String
	ReDim aOrd(nReg) As String
	ReDim aDocs(nReg) As String
	ReDim aBeleg(nReg) As String
	ReDim aGepr(nReg) As Double
	ReDim aGef(nReg) As Boolean
	REM V8.1-P2: Anzeige-Nummer (echte Vertragsnummer oder „unbenannt <ID>“) kommt aus der Spalte "Nr"
	rs = oCon.createStatement().executeQuery("SELECT v.""Nr"", COALESCE(v.""Ordner"", ''), " & _
		"COALESCE((SELECT LIST(COALESCE(d.""Datei"", '') || ' ' || COALESCE(CAST(d.""Datum"" AS VARCHAR(10)), ''), ' | ') " & _
		"FROM ""Dokument"" d WHERE d.""VertragID"" = v.""ID"" AND d.""Gilt"" IS TRUE), ''), v.""ZuletztGeprueft"", " & _
		"COALESCE((SELECT FIRST 1 e.""Beleg"" FROM ""Entscheidung"" e WHERE e.""VertragID"" = v.""ID"" " & _
		"ORDER BY e.""Datum"" DESC, e.""ID"" DESC), '') FROM ""Vertrag"" v ORDER BY v.""ID""")
	nReg = 0
	Do While rs.next()
		aNr(nReg) = rs.getString(1)
		aOrd(nReg) = Trim(rs.getString(2))
		aDocs(nReg) = rs.getString(3)
		rs.getDate(4)
		If Not rs.wasNull() Then aGepr(nReg) = CDbl(CDateFromUnoDate(rs.getDate(4)))
		aBeleg(nReg) = Trim(rs.getString(5))
		nReg = nReg + 1
	Loop
	aEintr = oSFA.getFolderContents(sBasisURL, True)
	For Each e In aEintr
		sName = NameAus(e)
		If oSFA.isFolder(e) Then
			If Left(sName, 1) <> "_" And Left(sName, 1) <> "." And sName <> "Sicherung" And sName <> "Export" Then
				k = -1
				For i = 0 To nReg - 1
					If aOrd(i) = sName Then
						k = i
						Exit For
					End If
				Next i
				If k < 0 Then
					REM V8.1-P2: Nummern enthalten selbst „_" (12_132_01_2026) → längste Nummer, mit der der Ordnername beginnt
					k = NummerImOrdner(sName, aNr, nReg)
					If k >= 0 Then
						Befund(oSt, oSFA, aNr(k), "Ordnername weicht vom Register ab", "Register: " & aOrd(k) & " – Ordnernamen angleichen", sName, e)
					Else
						Befund(oSt, oSFA, "", "Ordner ohne Vertrag im Register", "Vertrag anlegen oder Ordner verschieben", sName, e)
					End If
				End If
				If k >= 0 Then
					aGef(k) = True
					PruefeOrdner(oSt, oSFA, e, sName, aNr(k), aDocs(k), aGepr(k), aBeleg(k))
				End If
			End If
		ElseIf Not IstIgnoriert(sName) Then
			Befund(oSt, oSFA, "", "Datei außerhalb eines Vertragsordners", "In den passenden Vertragsordner verschieben", sName, e)
		End If
	Next e
	For i = 0 To nReg - 1
		If Not aGef(i) Then
			If aOrd(i) = "" Then
				Befund(oSt, oSFA, aNr(i), "Ordnername fehlt im Register", "Ordnernamen im Vertrag eintragen (Karte Ablage und Prüfung)", "", "")
			Else
				Befund(oSt, oSFA, aNr(i), "Ordner nicht gefunden", "Ordner anlegen oder Ordnernamen korrigieren", aOrd(i), "")
			End If
		End If
	Next i
	oSt.executeUpdate("UPDATE ""Einstellung"" SET ""LetzterAbgleich"" = CURRENT_TIMESTAMP WHERE ""ID"" = 1")
	rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM ""AbgleichBefund""")
	rs.next()
	AbgleichAusfuehren = rs.getLong(1)
End Function

Sub PruefeOrdner(oSt As Object, oSFA As Object, sURL, sOrdner As String, sNr As String, sDocs As String, dGepr As Double, sBeleg As String)
	Dim aE(), e, n As String, sBear As String, sKorr As String, sErs As String, aHaupt() As String, aHauptMod() As Double
	Dim nH As Long, i As Long, aB(), b, bn As String, basis As String, gefunden As Long, aX(), x, sOrt As String, sep As String
	Dim bErsetzt As Boolean
	sep = "\"
	If InStr(ConvertFromURL(sURL), "/") > 0 Then sep = "/"
	aE = oSFA.getFolderContents(sURL, True)
	ReDim aHaupt(UBound(aE) + 1) As String
	ReDim aHauptMod(UBound(aE) + 1) As Double
	nH = 0
	For Each e In aE
		n = NameAus(e)
		REM V8.1-P1 (B-L6): Ort innerhalb des Vertragsordners; die Spalte Nr. nennt den Vertrag
		sOrt = n
		If oSFA.isFolder(e) Then
			Select Case n
				Case "_bearbeitbar" : sBear = e
				Case "_korrespondenz" : sKorr = e
				Case "_ersetzt" : sErs = e
				Case Else
					Befund(oSt, oSFA, sNr, "Unbekannter Unterordner", "Inhalt in den Vertragsordner oder einen Standard-Unterordner verschieben", sOrt, e)
			End Select
		ElseIf Not IstIgnoriert(n) Then
			aHaupt(nH) = n
			aHauptMod(nH) = Geaendert(oSFA, e)
			nH = nH + 1
			If Not Datumsname(n) Then
				Befund(oSt, oSFA, sNr, "Dateiname ohne Datum vorne", "Umbenennen: JJJJ-MM-TT_Name", sOrt, e)
			ElseIf InStr(sDocs, n) = 0 And InStr(sDocs, Left(n, 10)) = 0 Then
				Befund(oSt, oSFA, sNr, "Datei fehlt unter Dokumente", "Im Vertrag unter Dokumente eintragen oder nach _ersetzt verschieben", sOrt, e)
			End If
			If dGepr > 0 And Geaendert(oSFA, e) >= dGepr + 1 Then
				Befund(oSt, oSFA, sNr, "Datei geändert nach letzter Prüfung", "Vertrag prüfen und „Heute geprüft“ setzen", sOrt, e)
			End If
		End If
	Next e
	If sBear <> "" Then
		aB = oSFA.getFolderContents(sBear, False)
		For Each b In aB
			bn = NameAus(b)
			If Not IstIgnoriert(bn) Then
				sOrt = "_bearbeitbar" & sep & bn
				If Not Datumsname(bn) Then Befund(oSt, oSFA, sNr, "Dateiname ohne Datum vorne", "Umbenennen: JJJJ-MM-TT_Name", sOrt, b)
				basis = OhneEndung(bn)
				gefunden = -1
				For i = 0 To nH - 1
					If LCase(OhneEndung(aHaupt(i))) = LCase(basis) Then
						gefunden = i
						Exit For
					End If
				Next i
				If gefunden < 0 Then
					REM V8.1-P1 (B-L1): Basic wertet „And" vollständig aus; EnthaeltBasis nur mit vorhandenem Ordner aufrufen
					bErsetzt = False
					If sErs <> "" Then bErsetzt = EnthaeltBasis(oSFA, sErs, basis)
					If bErsetzt Then
						Befund(oSt, oSFA, sNr, "Bearbeitbare Kopie eines ersetzten Dokuments", "Nach _ersetzt verschieben", sOrt, b)
					ElseIf InStr(LCase(bn), "entwurf") = 0 Then
						Befund(oSt, oSFA, sNr, "Unterschriebene Fassung fehlt", "PDF in den Vertragsordner legen oder Datei als Entwurf benennen", sOrt, b)
					End If
				ElseIf Geaendert(oSFA, b) > aHauptMod(gefunden) + 1 / 288 Then
					Befund(oSt, oSFA, sNr, "Bearbeitbare Datei neuer als die gültige Fassung", "Prüfen, ob die Fassung im Vertragsordner noch gilt", sOrt, b)
				End If
			End If
		Next b
	End If
	If sKorr <> "" Then
		aX = oSFA.getFolderContents(sKorr, False)
		For Each x In aX
			n = NameAus(x)
			If Not IstIgnoriert(n) Then
				sOrt = "_korrespondenz" & sep & n
				If Not Datumsname(n) Then Befund(oSt, oSFA, sNr, "Dateiname ohne Datum vorne", "Umbenennen: JJJJ-MM-TT_Name", sOrt, x)
				If dGepr > 0 And Geaendert(oSFA, x) >= dGepr + 1 Then
					Befund(oSt, oSFA, sNr, "Neue Korrespondenz seit letzter Prüfung", "Entscheidung prüfen und „Heute geprüft“ setzen", sOrt, x)
				End If
			End If
		Next x
	End If
	If sBeleg <> "" Then
		If sKorr = "" Then
			Befund(oSt, oSFA, sNr, "Beleg fehlt in _korrespondenz", "Beleg ablegen: " & sBeleg, sOrdner, sURL)
		ElseIf Not EnthaeltName(oSFA, sKorr, NurDateiname(sBeleg)) Then
			REM V8.1-P1 (B-L2): Namensvergleich statt selbst gebauter URL (Umlaute, Windows-Pfade)
			Befund(oSt, oSFA, sNr, "Beleg fehlt in _korrespondenz", "Beleg ablegen oder Namen bei der Entscheidung korrigieren: " & sBeleg, _
				"_korrespondenz", sKorr)
		End If
	End If
	If sErs <> "" Then
		aX = oSFA.getFolderContents(sErs, False)
		For Each x In aX
			n = NameAus(x)
			If Not IstIgnoriert(n) Then
				sOrt = "_ersetzt" & sep & n
				If Not Datumsname(n) Then
					Befund(oSt, oSFA, sNr, "Dateiname ohne Datum vorne", "Umbenennen: JJJJ-MM-TT_Name", sOrt, x)
				ElseIf InStr(sDocs, n) > 0 Then
					Befund(oSt, oSFA, sNr, "Ersetztes Dokument noch als gültig erfasst", "Im Vertrag bei diesem Dokument „Gilt“ abhaken", sOrt, x)
				End If
			End If
		Next x
	End If
End Sub

Sub Befund(oSt As Object, oSFA As Object, sNr As String, sBef As String, sVor As String, sOrt As String, sUrl)
	Dim sZeit As String, t
	sZeit = "NULL"
	If sUrl <> "" Then
		On Error Resume Next
		t = oSFA.getDateTimeModified(sUrl)
		If Err = 0 Then sZeit = "TIMESTAMP '" & t.Year & "-" & Right("0" & t.Month, 2) & "-" & Right("0" & t.Day, 2) & " " & _
			Right("0" & t.Hours, 2) & ":" & Right("0" & t.Minutes, 2) & ":00'"
		On Error GoTo 0
	End If
	REM V8.6-N14: intern (Register) oder extern (Dateien); interne Vorschläge mit eindeutiger Aktion lassen sich ausführen
	Dim sWo As String, sAkt As String, sWert As String
	sWo = "extern" : sAkt = "" : sWert = ""
	Select Case sBef
		Case "Datei geändert nach letzter Prüfung", "Neue Korrespondenz seit letzter Prüfung"
			sWo = "intern" : sAkt = "GEPRUEFT"
		Case "Ordnername weicht vom Register ab"
			sWo = "intern" : sAkt = "ORDNER" : sWert = sOrt
		Case "Ordnername fehlt im Register", "Bearbeitbare Datei neuer als die gültige Fassung"
			sWo = "intern" : sAkt = "VERTRAG"
		Case "Datei fehlt unter Dokumente"
			sWo = "intern" : sAkt = "DOKUMENT" : sWert = NameAus(sUrl)
		Case "Ersetztes Dokument noch als gültig erfasst"
			sWo = "intern" : sAkt = "GILT" : sWert = NameAus(sUrl)
	End Select
	sVor = IIf(sWo = "intern", "Intern: ", "Extern: ") & sVor
	oSt.executeUpdate("INSERT INTO ""AbgleichBefund"" (""Nr"", ""Befund"", ""WasTun"", ""Ort"", ""Geaendert"", ""Url"", ""Wo"", ""Aktion"", ""Wert"") VALUES ('" & _
		Esc(sNr) & "', '" & Esc(sBef) & "', '" & Esc(Left(sVor, 300)) & "', '" & Esc(Left(sOrt, 400)) & "', " & sZeit & ", '" & _
		Esc(Left(sUrl, 800)) & "', '" & sWo & "', '" & sAkt & "', '" & Esc(Left(sWert, 400)) & "')")
End Sub

Function Geaendert(oSFA As Object, sURL) As Double
	Dim t
	On Error GoTo Fehler
	t = oSFA.getDateTimeModified(sURL)
	Geaendert = CDbl(DateSerial(t.Year, t.Month, t.Day)) + CDbl(TimeSerial(t.Hours, t.Minutes, t.Seconds))
	Exit Function
Fehler:
	Geaendert = 0
End Function

Function NameAus(sURL) As String
	Dim s As String, p As Long, q As Long
	s = ConvertFromURL(sURL)
	p = LetztePos(s, "/")
	q = LetztePos(s, "\")
	If q > p Then p = q
	NameAus = Mid(s, p + 1)
End Function

Function OhneEndung(s As String) As String
	If LetztePos(s, ".") > 1 Then OhneEndung = Left(s, LetztePos(s, ".") - 1) Else OhneEndung = s
End Function

REM V8.1-P2: Index des Vertrags, dessen Nummer den Ordnernamen beginnt („Nummer_…" oder genau die Nummer); sonst -1.
Function NummerImOrdner(sName As String, aNr, nReg As Long) As Long
	Dim i As Long, nBest As Long, l As Long
	NummerImOrdner = -1
	nBest = 0
	For i = 0 To nReg - 1
		l = Len(aNr(i))
		If l > nBest Then
			If LCase(sName) = LCase(aNr(i)) Or LCase(Left(sName, l + 1)) = LCase(aNr(i) & "_") Then
				NummerImOrdner = i
				nBest = l
			End If
		End If
	Next i
End Function

Function EnthaeltBasis(oSFA As Object, sOrdnerURL, sBasis As String) As Boolean
	Dim a(), x
	EnthaeltBasis = False
	a = oSFA.getFolderContents(sOrdnerURL, False)
	For Each x In a
		If LCase(OhneEndung(NameAus(x))) = LCase(sBasis) Then
			EnthaeltBasis = True
			Exit Function
		End If
	Next x
End Function

Function Datumsname(n As String) As Boolean
	Datumsname = False
	If Len(n) < 12 Then Exit Function
	If Mid(n, 5, 1) <> "-" Or Mid(n, 8, 1) <> "-" Or Mid(n, 11, 1) <> "_" Then Exit Function
	If Not IsNumeric(Left(n, 4)) Or Not IsNumeric(Mid(n, 6, 2)) Or Not IsNumeric(Mid(n, 9, 2)) Then Exit Function
	Datumsname = True
End Function

REM Dateien, die der Abgleich übergeht: Sperrdateien, versteckte Dateien, Register, Exporte und Sicherungen
Function IstIgnoriert(n As String) As Boolean
	Dim l As String
	l = LCase(n)
	IstIgnoriert = False
	If Left(n, 1) = "." Or Left(n, 1) = "~" Then IstIgnoriert = True
	If Right(l, 4) = ".ics" Or l = "thumbs.db" Or l = "desktop.ini" Then IstIgnoriert = True
	If (Right(l, 4) = ".ods" Or Right(l, 4) = ".odb") And Left(l, 16) = "vertragsregister" Then IstIgnoriert = True
End Function

REM V8.1-P1 (B-L2): Liegt eine Datei dieses Namens im Ordner? Vergleich ohne Groß-/Kleinschreibung.
Function EnthaeltName(oSFA As Object, sOrdnerURL, sName As String) As Boolean
	Dim a(), x
	EnthaeltName = False
	If sName = "" Then Exit Function
	a = oSFA.getFolderContents(sOrdnerURL, False)
	For Each x In a
		If LCase(NameAus(x)) = LCase(sName) Then
			EnthaeltName = True
			Exit Function
		End If
	Next x
End Function

Function NurDateiname(s As String) As String
	Dim p As Long, q As Long
	p = LetztePos(s, "/")
	q = LetztePos(s, "\")
	If q > p Then p = q
	NurDateiname = Trim(Mid(s, p + 1))
End Function

REM V8.5: Ortszeit → UTC. Windows: Abstand zur UTC aus der Registry (ActiveTimeBias, Minuten, UTC = Ortszeit + Bias).
REM Ohne Windows-Registry (Testumgebung) bleibt die Ortszeit.
Function JetztUtc() As Date
	Dim oSh As Object, v, nBias As Double
	JetztUtc = Now()
	If GetGUIType() <> 1 Then Exit Function
	On Error GoTo Ende
	oSh = CreateObject("WScript.Shell")
	v = oSh.RegRead("HKLM\SYSTEM\CurrentControlSet\Control\TimeZoneInformation\ActiveTimeBias")
	nBias = CDbl(v)
	If nBias > 2147483647 Then nBias = nBias - 4294967296
	If Abs(nBias) > 900 Then Exit Function
	JetztUtc = Now() + nBias / 1440
Ende:
End Function

REM ============================================================ V8.6-N14 · Vorschlag als Link (Ablage prüfen)
REM Zeile wählen → unter der Liste steht der Vorschlag als Link. Intern: Rückfrage, dann Aktion im Register.
REM Extern: öffnet nur den Ordner; Dateien fasst das Register nicht an.
Sub AbgleichAuswahl(Optional oEvent)
	Dim oF As Object, oL As Object, sWo As String, sAkt As String, sTun As String
	On Error Resume Next
	oF = Fm(AppDoc(), "Abgleich")
	oL = oF.getByName("AB_lnkAktion")
	If oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then
		oL.Label = ""
		Exit Sub
	End If
	sWo = oF.getString(oF.findColumn("Wo"))
	sAkt = oF.getString(oF.findColumn("Aktion"))
	sTun = Mid(oF.getString(oF.findColumn("WasTun")), 9)
	Select Case sAkt
		Case "GEPRUEFT", "ORDNER", "DOKUMENT", "GILT"
			oL.Label = "Jetzt umsetzen: " & AktionText(sAkt, oF.getString(oF.findColumn("Wert"))) & "  ›"
		Case "VERTRAG"
			oL.Label = "Vertrag öffnen: " & sTun & "  ›"
		Case Else
			oL.Label = IIf(oF.getString(oF.findColumn("Url")) = "", "Extern: " & sTun, "Ordner öffnen (" & sTun & ")  ›")
	End Select
End Sub

Sub AbgleichAktion(Optional oEvent)
	Dim oDoc As Object, oF As Object, sAkt As String, sNr As String, sWert As String, sTun As String, nBef As Long
	Dim st As Object, rs As Object, nV As Long, sUrl As String, sDat As String, sBez As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Abgleich")
	If oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then Exit Sub
	sAkt = oF.getString(oF.findColumn("Aktion"))
	sNr = oF.getString(oF.findColumn("Nr"))
	sWert = oF.getString(oF.findColumn("Wert"))
	sUrl = oF.getString(oF.findColumn("Url"))
	sTun = Mid(oF.getString(oF.findColumn("WasTun")), 9)
	nBef = AktuelleID(oF)
	st = Verbindung().createStatement()
	nV = 0
	If sNr <> "" Then
		rs = st.executeQuery("SELECT ""ID"" FROM ""Vertrag"" WHERE ""Nr"" = '" & Esc(sNr) & "'")
		If rs.next() Then nV = rs.getLong(1)
	End If
	Select Case sAkt
		Case "VERTRAG"
			If nV > 0 Then VertragOeffnen(oDoc, nV, "AB", "", "VE1")
			Exit Sub
		Case "GEPRUEFT", "ORDNER", "DOKUMENT", "GILT"
			If nV = 0 Then Exit Sub
			If MsgBox(sNr & ": " & AktionText(sAkt, sWert) & Chr(10) & Chr(10) & "Jetzt umsetzen?", 4 + 32, "Ablage prüfen") <> 6 Then Exit Sub
			BenutzerSetzen(oDoc)
			Select Case sAkt
				Case "GEPRUEFT"
					st.executeUpdate("UPDATE ""Vertrag"" SET ""ZuletztGeprueft"" = CURRENT_DATE WHERE ""ID"" = " & nV)
				Case "ORDNER"
					st.executeUpdate("UPDATE ""Vertrag"" SET ""Ordner"" = '" & Esc(sWert) & "' WHERE ""ID"" = " & nV)
				Case "DOKUMENT"
					sDat = "NULL"
					If Datumsname(sWert) Then sDat = "DATE '" & Left(sWert, 10) & "'"
					sBez = sWert
					If Datumsname(sBez) Then sBez = Mid(sBez, 12)
					If InStr(sBez, ".") > 0 Then sBez = Left(sBez, LetztePos(sBez, ".") - 1)
					st.executeUpdate("INSERT INTO ""Dokument"" (""VertragID"", ""Datum"", ""Bezeichnung"", ""Datei"", ""Gilt"") VALUES (" & nV & ", " & _
						sDat & ", '" & Esc(Left(Replace(sBez, "-", " "), 120)) & "', '" & Esc(Left(sWert, 200)) & "', TRUE)")
				Case "GILT"
					st.executeUpdate("UPDATE ""Dokument"" SET ""Gilt"" = FALSE WHERE ""VertragID"" = " & nV & " AND ""Datei"" = '" & Esc(sWert) & "'")
			End Select
			st.executeUpdate("DELETE FROM ""AbgleichBefund"" WHERE ""ID"" = " & nBef)
			Gespeichert()
			oF.reload()
			AbgleichInfo(oDoc)
			StatusSetzen(oDoc, sNr & ": umgesetzt")
		Case Else
			If sUrl = "" Then Exit Sub
			ShellOeffnen(Left(sUrl, LetztePos(sUrl, "/")), "Der Ort ist nicht erreichbar:")
	End Select
	Exit Sub
Fehler:
	Fehlermeldung("Vorschlag umsetzen", Error$)
End Sub

Function AktionText(sAkt As String, sWert As String) As String
	Select Case sAkt
		Case "GEPRUEFT" : AktionText = "„Heute geprüft“ setzen"
		Case "ORDNER" : AktionText = "Ordnername im Register auf „" & sWert & "“ setzen"
		Case "DOKUMENT" : AktionText = "„" & sWert & "“ unter Dokumente eintragen (gilt)"
		Case "GILT" : AktionText = "bei „" & sWert & "“ den Haken „Gilt“ entfernen"
		Case Else : AktionText = ""
	End Select
End Function
