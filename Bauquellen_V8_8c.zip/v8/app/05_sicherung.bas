REM ================================================================ V8.1-P5 · Sicherung
REM Drei Schichten: Papierkorb (P4), Textsicherung (CSV in ZIP, Basisstand alle 30 Tage + Tagesdatei mit den Änderungen
REM seit dem Basisstand), Spiegel (Vollkopie der .odb, zwei Fächer im Wechsel, wöchentliche Probe).
REM Ablauf im Alltag: Spiegel höchstens alle 2 Minuten nach dem Speichern; Textsicherung und Probe beim Schließen,
REM nachdem das Fenster weg ist. Zustand liegt in Dateien im Sicherungsordner (stand.txt, basis.txt, pruefung.txt).

Function TxTabellen()
	TxTabellen = Array("Einstellung", "Liste", "Partner", "Vertrag", "Entscheidung", "Dokument", "Leistung", "Ereignis", _
		"Vertretung", "VertretungPunkt", "Aenderung")
End Function

Function TxZurueck()
	TxZurueck = Array("Partner", "Vertrag", "Entscheidung", "Dokument", "Leistung", "Ereignis", "Vertretung", "VertretungPunkt")
End Function

REM ---------------------------------------------------------------- Ordner, Dateien, Protokoll
Function SichOrdner(oDb As Object, oCon As Object) As String
	Dim rs As Object, s As String, oSFA As Object
	s = ""
	On Error Resume Next
	rs = oCon.createStatement().executeQuery("SELECT ""SicherungOrdner"" FROM ""Einstellung"" WHERE ""ID"" = 1")
	If rs.next() Then s = Trim(rs.getString(1))
	On Error GoTo 0
	If s = "" Then
		SichOrdner = OrdnerNebenDatei(oDb, "Sicherung")
		Exit Function
	End If
	s = ConvertToURL(MitTrenner(s))
	If Right(s, 1) <> "/" Then s = s & "/"
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	If Not oSFA.exists(s) Then oSFA.createFolder(s)
	SichOrdner = s
End Function

Function DateiLesen(sURL As String) As String
	Dim oSFA As Object, oIn As Object, s As String
	DateiLesen = ""
	On Error GoTo Ende
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	If Not oSFA.exists(sURL) Then Exit Function
	oIn = createUnoService("com.sun.star.io.TextInputStream")
	oIn.setInputStream(oSFA.openFileRead(sURL))
	oIn.setEncoding("UTF-8")
	Do While Not oIn.isEOF()
		If s <> "" Then s = s & Chr(10)
		s = s & Zeile(oIn)
	Loop
	oIn.closeInput()
	DateiLesen = Trim(s)
Ende:
End Function

REM Eine Zeile mit Zeitstempel an protokoll.txt im Sicherungsordner anhängen (für Rückfragen bei Störungen)
Sub SichProtokoll(sOrdner As String, sText As String)
	Dim n As Integer
	On Error Resume Next
	n = FreeFile
	Open ConvertFromURL(sOrdner & "protokoll.txt") For Append As #n
	Print #n, Format(Now(), "YYYY-MM-DD hh:mm:ss") & "  " & sText
	Close #n
End Sub

Function IsoDatum(s As String) As Date
	IsoDatum = CDateFromIso(Left(Replace(s, "-", ""), 8))
End Function

Function DtZahl(t) As Double
	DtZahl = CDbl(DateSerial(t.Year, t.Month, t.Day)) + CDbl(TimeSerial(t.Hours, t.Minutes, t.Seconds))
End Function

Function UrlDateiname(sURL As String) As String
	UrlDateiname = Mid(sURL, LetztePos(sURL, "/") + 1)
End Function

Function OdbBasisName(oDb As Object) As String
	Dim s As String
	s = ConvertFromURL(UrlDateiname(oDb.URL))
	OdbBasisName = Left(s, LetztePos(s, ".") - 1)
End Function

Function IstSpiegel(oDb As Object) As Boolean
	IstSpiegel = InStr(LCase(UrlDateiname(oDb.URL)), "_spiegel_") > 0
End Function

REM ---------------------------------------------------------------- Spiegel
REM Kopiert die gespeicherte .odb in das ältere der Fächer A/B: erst unter Hilfsnamen, dann umbenennen.
Function SpiegelSchreiben(oDb As Object, sOrdner As String) As String
	Dim oSFA As Object, sBasis As String, sA As String, sB As String, sZiel As String, sTmp As String, aLeer()
	SpiegelSchreiben = ""
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sBasis = ConvertToURL("/" & OdbBasisName(oDb))
	sBasis = Mid(sBasis, LetztePos(sBasis, "/") + 1)
	sA = sOrdner & sBasis & "_Spiegel_A.odb"
	sB = sOrdner & sBasis & "_Spiegel_B.odb"
	If Not oSFA.exists(sA) Then
		sZiel = sA
	ElseIf Not oSFA.exists(sB) Then
		sZiel = sB
	ElseIf DtZahl(oSFA.getDateTimeModified(sA)) <= DtZahl(oSFA.getDateTimeModified(sB)) Then
		sZiel = sA
	Else
		sZiel = sB
	End If
	sTmp = sZiel & ".tmp"
	On Error Resume Next
	If oSFA.exists(sTmp) Then oSFA.kill(sTmp)
	oSFA.copy(oDb.URL, sTmp)
	If Err <> 0 Or Not oSFA.exists(sTmp) Then
		REM Datei gesperrt: LibreOffice schreibt die Kopie selbst
		Err.Clear
		oDb.storeToURL(sTmp, aLeer())
	End If
	If Not oSFA.exists(sTmp) Then
		SichProtokoll(sOrdner, "Spiegel FEHLER: Kopie nicht geschrieben (" & Error$ & ")")
		Exit Function
	End If
	If oSFA.exists(sZiel) Then oSFA.kill(sZiel)
	oSFA.move(sTmp, sZiel)
	If Err <> 0 Then
		SichProtokoll(sOrdner, "Spiegel FEHLER beim Umbenennen: " & Error$)
		Exit Function
	End If
	DateiSchreiben(sOrdner & "Spiegel_Herkunft.txt", oDb.URL)
	SpiegelSchreiben = sZiel
End Function

REM Nach jedem Speichern: Spiegel, wenn der letzte älter als 2 Minuten ist (Zeit im Tag von NA_lblBenutzer).
Sub SpiegelNachSpeichern(oDoc As Object)
	Dim oDb As Object, oL As Object, dLetzt As Double
	On Error Resume Next
	oDb = oDoc.Parent
	If IstSpiegel(oDb) Then Exit Sub
	oL = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblBenutzer")
	If oL.Tag <> "" Then dLetzt = CDbl(oL.Tag)
	If CDbl(Now()) - dLetzt < 2 / 1440 Then Exit Sub
	If SpiegelSchreiben(oDb, SichOrdner(oDb, Verbindung())) <> "" Then oL.Tag = CStr(CDbl(Now()))
End Sub

REM ---------------------------------------------------------------- Textsicherung
Function TxBedingung(sTab As String, sSeit As String) As String
	TxBedingung = ""
	If sSeit = "" Then Exit Function
	Select Case sTab
		Case "Einstellung", "Liste"
			TxBedingung = ""
		Case "Aenderung"
			TxBedingung = " WHERE ""ID"" IN (SELECT a.""ID"" FROM ""Aenderung"" a WHERE a.""Zeit"" > TIMESTAMP '" & sSeit & "')"
		Case Else
			TxBedingung = " WHERE ""ID"" IN (SELECT a.""DatensatzID"" FROM ""Aenderung"" a WHERE a.""Tabelle"" = '" & sTab & _
				"' AND a.""Zeit"" > TIMESTAMP '" & sSeit & "')"
	End Select
End Function

REM Zeichen ohne Zeilenumbrüche: Lesen in Zeilen verliert CR/LF, deshalb zählen beide Seiten ohne sie
Function ZeichenOhneUmbruch(s As String) As Long
	ZeichenOhneUmbruch = Len(Replace(Replace(s, Chr(13), ""), Chr(10), ""))
End Function

REM Schreibt einen Stand als ZIP (eine CSV je Tabelle). sSeit = "" → alles, sonst Änderungen seit diesem Zeitpunkt.
REM Prüft dreifach: Fingerabdruck der Datenbank = Summen beim Schreiben = Summen beim Zurücklesen. Liefert "" oder Fehlertext.
Function ZipStand(oCon As Object, sZiel As String, sSeit As String, sInfo As String) As String
	Dim oFac As Object, oSt As Object, oStream As Object, oOut As Object, rs As Object, rsK As Object, aArg(0) As New com.sun.star.beans.PropertyValue
	Dim aT, i As Integer, t As String, sW As String, sKopf As String, sZeile As String, n As Double, sid As Double, sid2 As Double
	Dim nZ As Double, h As Double, d(4) As Double, sMan As String, sGel As String, nId As Double, sTmp As String, oSFA As Object
	Dim sFehler As String, aZ
	ZipStand = ""
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sTmp = sZiel & ".tmp"
	If oSFA.exists(sTmp) Then oSFA.kill(sTmp)
	aArg(0).Name = "StorageFormat"
	aArg(0).Value = "ZipFormat"
	oFac = createUnoService("com.sun.star.embed.StorageFactory")
	oSt = oFac.createInstanceWithArguments(Array(sTmp, 13, aArg()))
	sMan = "Tabelle;Zeilen;SummeID;SummeID2;Zeichen;Pruefwert" & Chr(10)
	aT = TxTabellen()
	For i = 0 To UBound(aT)
		t = aT(i)
		sW = TxBedingung(t, sSeit)
		rs = oCon.createStatement().executeQuery("SELECT COUNT(*), COALESCE(SUM(""ID""), 0), COALESCE(SUM(CAST(""ID"" AS BIGINT) * ""ID""), 0), " & _
			"COALESCE(SUM(CHAR_LENGTH(REPLACE(REPLACE(""Zeile"", ASCII_CHAR(13), ''), ASCII_CHAR(10), ''))), 0), " & _
			"COALESCE(SUM(MOD(HASH(""Zeile""), 1000000007)), 0) FROM ""VX_" & t & """" & sW)
		rs.next()
		d(0) = rs.getDouble(1) : d(1) = rs.getDouble(2) : d(2) = rs.getDouble(3) : d(3) = rs.getDouble(4) : d(4) = rs.getDouble(5)
		rsK = oCon.createStatement().executeQuery("SELECT ""Kopf"" FROM ""VX_Kopf"" WHERE ""Tabelle"" = '" & t & "'")
		rsK.next()
		oStream = oSt.openStreamElement(t & ".csv", 12)
		oOut = createUnoService("com.sun.star.io.TextOutputStream")
		oOut.setOutputStream(oStream.getOutputStream())
		oOut.setEncoding("UTF-8")
		oOut.writeString(rsK.getString(1) & Chr(10))
		n = 0 : sid = 0 : sid2 = 0 : nZ = 0 : h = 0
		rs = oCon.createStatement().executeQuery("SELECT ""ID"", ""Zeile"", MOD(HASH(""Zeile""), 1000000007) FROM ""VX_" & t & """" & sW & " ORDER BY ""ID""")
		Do While rs.next()
			nId = rs.getDouble(1)
			sZeile = rs.getString(2)
			oOut.writeString(sZeile & Chr(10))
			n = n + 1 : sid = sid + nId : sid2 = sid2 + nId * nId : nZ = nZ + ZeichenOhneUmbruch(sZeile) : h = h + rs.getDouble(3)
		Loop
		oOut.closeOutput()
		If n <> d(0) Or sid <> d(1) Or sid2 <> d(2) Or nZ <> d(3) Or h <> d(4) Then
			sFehler = t & ": Datenbank " & d(0) & "/" & d(1) & "/" & d(3) & ", geschrieben " & n & "/" & sid & "/" & nZ
			Exit For
		End If
		sMan = sMan & t & ";" & n & ";" & sid & ";" & sid2 & ";" & nZ & ";" & h & Chr(10)
	Next i
	If sFehler = "" And sSeit <> "" Then
		REM Löschvermerke: seit dem Basisstand gelöschte Datensätze
		sGel = "Tabelle;ID" & Chr(10)
		aT = TxZurueck()
		For i = 0 To UBound(aT)
			rs = oCon.createStatement().executeQuery("SELECT DISTINCT a.""DatensatzID"" FROM ""Aenderung"" a WHERE a.""Tabelle"" = '" & aT(i) & _
				"' AND a.""Zeit"" > TIMESTAMP '" & sSeit & "' AND a.""DatensatzID"" IS NOT NULL AND NOT EXISTS " & _
				"(SELECT 1 FROM """ & aT(i) & """ x WHERE x.""ID"" = a.""DatensatzID"")")
			Do While rs.next()
				sGel = sGel & aT(i) & ";" & rs.getLong(1) & Chr(10)
			Loop
		Next i
		ZipText(oSt, "Geloescht.csv", sGel)
	End If
	If sFehler = "" Then
		ZipText(oSt, "Pruefung.csv", sMan)
		ZipText(oSt, "Info.csv", sInfo)
		oSt.commit()
	End If
	oSt.dispose()
	If sFehler = "" Then sFehler = ZipNachpruefen(sTmp, sMan)
	If sFehler <> "" Then
		REM fehlerhafte Datei zur Untersuchung behalten (wird bei der Aufbewahrung nicht gelöscht, Endung .fehler)
		On Error Resume Next
		If oSFA.exists(sZiel & ".fehler") Then oSFA.kill(sZiel & ".fehler")
		oSFA.move(sTmp, sZiel & ".fehler")
		ZipStand = sFehler
		Exit Function
	End If
	If oSFA.exists(sZiel) Then oSFA.kill(sZiel)
	REM V8.1-F1: Umbenennen; scheitert es, kopieren und .tmp entfernen
	On Error GoTo Kopieren
	oSFA.move(sTmp, sZiel)
	Exit Function
Kopieren:
	On Error GoTo 0
	oSFA.copy(sTmp, sZiel)
	On Error Resume Next
	oSFA.kill(sTmp)
End Function

Sub ZipText(oSt As Object, sName As String, sText As String)
	Dim oStream As Object, oOut As Object
	oStream = oSt.openStreamElement(sName, 12)
	oOut = createUnoService("com.sun.star.io.TextOutputStream")
	oOut.setOutputStream(oStream.getOutputStream())
	oOut.setEncoding("UTF-8")
	oOut.writeString(sText)
	oOut.closeOutput()
End Sub

Function ZipLeser(sZip As String) As Object
	Dim oZ As Object
	oZ = createUnoService("com.sun.star.packages.zip.ZipFileAccess")
	oZ.initialize(Array(sZip))
	ZipLeser = oZ
End Function

REM V8.1-F1: ZIP wieder freigeben. Windows sperrt die Datei sonst bis zum Beenden, dann scheitert das Umbenennen.
Sub ZipFrei(oZ As Object)
	On Error Resume Next
	If Not IsNull(oZ) Then oZ.dispose()
End Sub

Function ZipEintragLesen(oZ As Object, sName As String) As Object
	Dim oIn As Object
	oIn = createUnoService("com.sun.star.io.TextInputStream")
	oIn.setInputStream(oZ.getByName(sName))
	oIn.setEncoding("UTF-8")
	ZipEintragLesen = oIn
End Function

REM readLine liefert die letzte Zeile mit dem Zeilenende, wenn danach die Datei endet [GEFUNDEN: dbg_p5b.py]
Function Zeile(oIn As Object) As String
	Dim s As String
	s = oIn.readLine()
	Do While Len(s) > 0
		If Right(s, 1) = Chr(10) Or Right(s, 1) = Chr(13) Then s = Left(s, Len(s) - 1) Else Exit Do
	Loop
	Zeile = s
End Function

Function AnfZaehlen(s As String) As Long
	AnfZaehlen = Len(s) - Len(Replace(s, """", ""))
End Function

REM Liest die ZIP zurück und vergleicht je Tabelle Zeilen, Summe der IDs, Summe der Quadrate und Zeichen mit dem Manifest.
Function ZipNachpruefen(sZip As String, sMan As String) As String
	Dim oZ As Object, oIn As Object, aZ, i As Integer, f, n As Double, sid As Double, sid2 As Double, nZ As Double
	Dim sZ As String, nQ As Long, sRec As String, nId As Double, p As Long
	ZipNachpruefen = ""
	On Error GoTo Fehler
	oZ = ZipLeser(sZip)
	aZ = Split(sMan, Chr(10))
	For i = 1 To UBound(aZ)
		If aZ(i) <> "" Then
			f = Split(aZ(i), ";")
			oIn = ZipEintragLesen(oZ, f(0) & ".csv")
			Zeile(oIn)
			n = 0 : sid = 0 : sid2 = 0 : nZ = 0 : nQ = 0
			Do While Not oIn.isEOF()
				sZ = Zeile(oIn)
				If nQ Mod 2 = 0 Then
					REM neuer Datensatz: erstes Feld ist die ID
					n = n + 1
					p = InStr(sZ, ";")
					If p > 0 Then nId = Val(Left(sZ, p - 1)) Else nId = Val(sZ)
					sid = sid + nId : sid2 = sid2 + nId * nId
					nQ = 0
				End If
				nQ = nQ + AnfZaehlen(sZ)
				nZ = nZ + Len(sZ)
			Loop
			oIn.closeInput()
			If n <> CDbl(f(1)) Or sid <> CDbl(f(2)) Or sid2 <> CDbl(f(3)) Or nZ <> CDbl(f(4)) Then
				ZipNachpruefen = f(0) & ": Datei " & n & "/" & sid & "/" & nZ & ", erwartet " & f(1) & "/" & f(2) & "/" & f(4)
				ZipFrei(oZ)
				Exit Function
			End If
		End If
	Next i
	ZipFrei(oZ)
	Exit Function
Fehler:
	ZipNachpruefen = "Zurücklesen: " & Error$
	ZipFrei(oZ)
End Function

Function ZeitText(dZ As Double) As String
	ZeitText = Format(CDate(dZ), "YYYY-MM-DD") & " " & Format(CDate(dZ), "hh:mm:ss")
End Function

REM V8.4-F10: Jede Registerdatei hat ihren eigenen Textordner. „Text/“ gehört der Datei, die in Text/datei.txt steht
REM (ältere Ordner ohne datei.txt übernimmt die erste Datei); jede weitere Datei im selben Ordner nutzt „Text_<Dateiname>/“.
Function TextOrdner(oDb As Object, sOrdner As String) As String
	Dim oSFA As Object, sT As String, sName As String, sEig As String
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sName = OdbBasisName(oDb)
	sT = sOrdner & "Text/"
	If Not oSFA.exists(sT) Then oSFA.createFolder(sT)
	sEig = Trim(DateiLesen(sT & "datei.txt"))
	If sEig = "" Then
		DateiSchreiben(sT & "datei.txt", sName)
		sEig = sName
	End If
	If sEig <> sName Then
		sT = sOrdner & "Text_" & sName & "/"
		If Not oSFA.exists(sT) Then oSFA.createFolder(sT)
	End If
	TextOrdner = sT
End Function

REM Textsicherung beim Schließen (oder „Jetzt sichern"): nur wenn sich seit der letzten etwas geändert hat (bImmer: immer).
REM Neuer Basisstand, wenn keiner da ist, er 30 Tage alt ist oder ein Vorgang ohne Spur ihn erzwingt.
Function TextSicherung(oCon As Object, sOrdner As String, bImmer As Boolean, oDb As Object) As String
	Dim oSFA As Object, sText As String, sStand As String, sBasisInfo As String, aB, sBasisZeit As String, sBasisDatei As String
	Dim rs As Object, sJetzt As String, sLetzte As String, bNeu As Boolean, sDatei As String, sFehler As String, sInfo As String
	TextSicherung = ""
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sText = TextOrdner(oDb, sOrdner)  ' V8.4-F10
	sStand = DateiLesen(sText & "stand.txt")
	sBasisInfo = DateiLesen(sText & "basis.txt")
	rs = oCon.createStatement().executeQuery("SELECT CAST(CAST(CURRENT_TIMESTAMP AS TIMESTAMP) AS VARCHAR(24)), " & _
		"COALESCE(CAST(MAX(""Zeit"") AS VARCHAR(24)), '') FROM ""Aenderung""")
	rs.next()
	sJetzt = Left(rs.getString(1), 19)
	sLetzte = rs.getString(2)
	If Not bImmer And sStand <> "" And sLetzte <= sStand And Not oSFA.exists(sText & "basis_erzwingen.txt") Then Exit Function
	bNeu = True
	If sBasisInfo <> "" Then
		aB = Split(sBasisInfo, ";")
		If UBound(aB) >= 1 Then
			sBasisZeit = aB(0)
			sBasisDatei = aB(1)
			bNeu = Not oSFA.exists(sText & sBasisDatei)
			If Not bNeu Then bNeu = (IsoDatum(sJetzt) - IsoDatum(sBasisZeit) >= 30)
		End If
	End If
	If oSFA.exists(sText & "basis_erzwingen.txt") Then bNeu = True
	If bNeu Then
		sDatei = "Basis_" & Left(sJetzt, 10) & "_" & Mid(sJetzt, 12, 2) & Mid(sJetzt, 15, 2) & ".zip"
		sInfo = "Art;Basis" & Chr(10) & "Erstellt;" & sJetzt & Chr(10) & "Basisdatei;" & sDatei & Chr(10)
		sFehler = ZipStand(oCon, sText & sDatei, "", sInfo)
		If sFehler = "" Then
			DateiSchreiben(sText & "basis.txt", sJetzt & ";" & sDatei)
			If oSFA.exists(sText & "basis_erzwingen.txt") Then oSFA.kill(sText & "basis_erzwingen.txt")
		End If
	Else
		sDatei = "Tag_" & Left(sJetzt, 10) & ".zip"
		sInfo = "Art;Tag" & Chr(10) & "Erstellt;" & sJetzt & Chr(10) & "Basisdatei;" & sBasisDatei & Chr(10) & "Seit;" & sBasisZeit & Chr(10)
		sFehler = ZipStand(oCon, sText & sDatei, sBasisZeit, sInfo)
	End If
	If sFehler <> "" Then
		SichProtokoll(sOrdner, "Textsicherung FEHLER " & sDatei & ": " & sFehler)
		TextSicherung = "FEHLER: " & sFehler
		Exit Function
	End If
	DateiSchreiben(sText & "stand.txt", sJetzt)
	SichProtokoll(sOrdner, "Textsicherung " & sDatei)
	TextAufbewahrung(sText)
	TextSicherung = sText & sDatei
End Function

REM V8.1-F1: Ein Fehler der Textsicherung hält Spiegel und Probe nicht mehr auf.
Function TextSicherungGeschuetzt(oCon As Object, sOrdner As String, bImmer As Boolean, oDb As Object) As String
	On Error GoTo Fehler
	TextSicherungGeschuetzt = TextSicherung(oCon, sOrdner, bImmer, oDb)
	Exit Function
Fehler:
	TextSicherungGeschuetzt = "FEHLER: " & Error$
	On Error Resume Next
	SichProtokoll(sOrdner, "Textsicherung FEHLER: " & Error$)
End Function

REM Tagesdateien älter als 30 Tage löschen; Basisstände: die letzten 12 und der erste jedes Kalenderjahres bleiben.
Sub TextAufbewahrung(sText As String)
	Dim oSFA As Object, a(), i As Long, j As Long, n As Long, s As String, aB() As String, t As String, sJahr As String
	On Error Resume Next
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	a = oSFA.getFolderContents(sText, False)
	ReDim aB(UBound(a) + 1) As String
	n = 0
	For i = 0 To UBound(a)
		s = UrlDateiname(a(i))
		If Left(s, 4) = "Tag_" And Right(s, 4) = ".zip" Then
			If Date() - IsoDatum(Mid(s, 5, 10)) > 30 Then oSFA.kill(a(i))
		ElseIf Left(s, 6) = "Basis_" And Right(s, 4) = ".zip" Then
			aB(n) = s
			n = n + 1
		ElseIf Right(s, 4) = ".tmp" Then
			oSFA.kill(a(i))
		End If
	Next i
	For i = 0 To n - 2
		For j = 0 To n - 2 - i
			If aB(j) > aB(j + 1) Then
				t = aB(j) : aB(j) = aB(j + 1) : aB(j + 1) = t
			End If
		Next j
	Next i
	sJahr = ""
	For i = 0 To n - 13
		If Mid(aB(i), 7, 4) <> sJahr Then
			REM erster Basisstand dieses Jahres bleibt
			sJahr = Mid(aB(i), 7, 4)
		Else
			oSFA.kill(sText & aB(i))
		End If
	Next i
End Sub

REM ---------------------------------------------------------------- Beim Schließen und „Jetzt sichern"
REM Läuft in Zu_notify, nachdem das Fenster des Formulars zu ist. Liefert für die Probe: Ordner|Spiegel|Zählstand.
Function SicherungBeimSchliessen(oDb As Object) As String
	Dim oCon As Object, sOrdner As String, sSpiegel As String, sZaehl As String, sPruef As String, aP, bFaellig As Boolean
	SicherungBeimSchliessen = ""
	On Error GoTo Fehler
	If IstSpiegel(oDb) Then Exit Function
	oCon = oDb.DataSource.getConnection("", "")
	sOrdner = SichOrdner(oDb, oCon)
	TextSicherungGeschuetzt(oCon, sOrdner, False, oDb)
	sZaehl = Zaehlstand(oCon)
	oCon.close()
	sSpiegel = SpiegelSchreiben(oDb, sOrdner)
	REM Probe einmal je Woche
	sPruef = DateiLesen(sOrdner & "pruefung.txt")
	aP = Split(sPruef & ";", ";")
	REM Basic wertet „Or" vollständig aus: IsoDatum nur mit vorhandenem Datum aufrufen
	bFaellig = (aP(0) = "")
	If Not bFaellig Then bFaellig = (InStr(sPruef, "FEHLER") > 0)
	If Not bFaellig Then bFaellig = (Date() >= IsoDatum(aP(0)) + 7)
	If sSpiegel <> "" And bFaellig Then SicherungBeimSchliessen = sOrdner & "|" & sSpiegel & "|" & sZaehl
	Exit Function
Fehler:
	Dim sFehler As String
	sFehler = Error$ & " (Zeile " & Erl & ")"
	On Error Resume Next
	If sOrdner = "" Then sOrdner = OrdnerNebenDatei(oDb, "Sicherung")
	SichProtokoll(sOrdner, "Sicherung beim Schließen FEHLER: " & sFehler)
	REM V8.1-F2: Verbindung auch im Fehlerfall schließen (eine offene Verbindung bricht das Beenden ab)
	If Not IsNull(oCon) Then oCon.close()
End Function

Function Zaehlstand(oCon As Object) As String
	Dim aT, i As Integer, rs As Object, s As String
	aT = TxZurueck()
	For i = 0 To UBound(aT)
		rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM """ & aT(i) & """")
		rs.next()
		s = s & aT(i) & "=" & rs.getLong(1) & ","
	Next i
	Zaehlstand = s
End Function

REM Öffnet den Spiegel unsichtbar und ohne Makros, zählt die Datensätze und vergleicht sie mit dem Stand beim Schließen.
Sub SpiegelProbe(sAuftrag As String)
	Dim a, sOrdner As String, sSpiegel As String, sSoll As String, oD As Object, oCon As Object, aArg(2) As New com.sun.star.beans.PropertyValue
	Dim sIst As String, sErg As String
	a = Split(sAuftrag, "|")
	sOrdner = a(0) : sSpiegel = a(1) : sSoll = a(2)
	On Error GoTo Fehler
	aArg(0).Name = "Hidden" : aArg(0).Value = True
	aArg(1).Name = "MacroExecutionMode" : aArg(1).Value = 0
	aArg(2).Name = "ReadOnly" : aArg(2).Value = True
	oD = StarDesktop.loadComponentFromURL(sSpiegel, "_blank", 0, aArg())
	oCon = oD.DataSource.getConnection("", "")
	sIst = Zaehlstand(oCon)
	oCon.close()
	oD.close(True)
	If sIst = sSoll Then sErg = "OK" Else sErg = "FEHLER: Spiegel " & sIst & " statt " & sSoll
	DateiSchreiben(sOrdner & "pruefung.txt", Format(Date(), "YYYY-MM-DD") & ";" & sErg & ";" & UrlDateiname(sSpiegel))
	SichProtokoll(sOrdner, "Probe " & UrlDateiname(sSpiegel) & ": " & sErg)
	Exit Sub
Fehler:
	sErg = "FEHLER: Spiegel nicht lesbar (" & Error$ & ")"
	On Error Resume Next
	REM V8.1-F2: Verbindung und Spiegel auch im Fehlerfall schließen
	If Not IsNull(oCon) Then oCon.close()
	If Not IsNull(oD) Then oD.close(True)
	DateiSchreiben(sOrdner & "pruefung.txt", Format(Date(), "YYYY-MM-DD") & ";" & sErg & ";" & UrlDateiname(sSpiegel))
	SichProtokoll(sOrdner, "Probe " & UrlDateiname(sSpiegel) & ": " & sErg)
End Sub

Sub SicherungJetzt(Optional oEvent)
	Dim oDoc As Object, oDb As Object, sOrdner As String, sT As String, sS As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	oDb = DbDoc()
	oDb.store()
	sOrdner = SichOrdner(oDb, Verbindung())
	sT = TextSicherungGeschuetzt(Verbindung(), sOrdner, True, oDb)
	sS = SpiegelSchreiben(oDb, sOrdner)
	oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblBenutzer").Tag = CStr(CDbl(Now()))
	StatusSetzen(oDoc, "Sicherung " & Format(Now(), "hh:mm"))
	SicherungInfo(oDoc)
	If Left(sT, 7) = "FEHLER:" Or sS = "" Then
		MsgBox "Die Sicherung ist nicht vollständig." & Chr(10) & "Textsicherung: " & sT & Chr(10) & "Spiegel: " & _
			IIf(sS = "", "nicht geschrieben", ConvertFromURL(sS)) & Chr(10) & "Einzelheiten: protokoll.txt im Sicherungsordner.", 48, "Sicherung"
	Else
		MsgBox "Gesichert." & Chr(10) & "Textsicherung: " & ConvertFromURL(sT) & Chr(10) & "Spiegel: " & ConvertFromURL(sS), 64, "Sicherung"
	End If
	Exit Sub
Fehler:
	Fehlermeldung("Sicherung", Error$)
End Sub

REM Beim Start: Warnung, wenn die letzte Probe fehlschlug.
Sub ProbeWarnung(oDb As Object)
	Dim s As String, oCon As Object
	On Error Resume Next
	If IstSpiegel(oDb) Then Exit Sub
	REM V8.1-F2: Die Verbindung blieb offen; LibreOffice brach dann beim Beenden ab [GEFUNDEN: Versuch B4, exp_pur.py]
	oCon = oDb.DataSource.getConnection("", "")
	s = DateiLesen(SichOrdner(oDb, oCon) & "pruefung.txt")
	oCon.close()
	If InStr(s, "FEHLER") > 0 Then
		MsgBox "Achtung: Die letzte Probe der Sicherungskopie ist fehlgeschlagen." & Chr(10) & Mid(s, InStr(s, ";") + 1) & Chr(10) & _
			"Klick in „Papierkorb & Sicherung“ auf „Jetzt sichern“. Hilft das nicht, melde dich bei der Betreuung.", 48, "Sicherung"
	End If
End Sub

REM Wird die Spiegeldatei selbst geöffnet (Notfall), bietet sie an, das Register zu ersetzen.
Sub SpiegelUebernahmeFragen(oDb As Object)
	Dim oSFA As Object, sOrdner As String, sZiel As String, sDefekt As String, sDatum As String
	On Error GoTo Fehler
	If Not IstSpiegel(oDb) Then Exit Sub
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sOrdner = Left(oDb.URL, LetztePos(oDb.URL, "/"))
	sZiel = DateiLesen(sOrdner & "Spiegel_Herkunft.txt")
	sDatum = Format(CDate(DtZahl(oSFA.getDateTimeModified(oDb.URL))), "DD.MM.YYYY hh:mm")
	If sZiel = "" Then
		MsgBox "Diese Datei ist eine Sicherungskopie vom " & sDatum & "." & Chr(10) & _
			"Der Ort des Registers ist nicht bekannt. Kopiere die Datei selbst an seinen Platz.", 48, "Sicherungskopie"
		Exit Sub
	End If
	If MsgBox("Diese Datei ist eine Sicherungskopie vom " & sDatum & "." & Chr(10) & Chr(10) & _
		"Als Register übernehmen?" & Chr(10) & "Sie ersetzt dann " & ConvertFromURL(sZiel) & "." & Chr(10) & _
		"Die bisherige Datei bleibt mit dem Zusatz „_defekt“ liegen.", 4 + 32 + 256, "Sicherungskopie") <> 6 Then
		MsgBox "Die Sicherungskopie ist nur zum Ansehen geöffnet. Änderungen hier gehen nicht ins Register.", 64, "Sicherungskopie"
		Exit Sub
	End If
	sDefekt = Left(sZiel, LetztePos(sZiel, ".") - 1) & "_defekt_" & Format(Date(), "YYYY-MM-DD") & "_" & Format(Time(), "hhmm") & ".odb"
	If oSFA.exists(sZiel) Then oSFA.move(sZiel, sDefekt)
	oSFA.copy(oDb.URL, sZiel)
	MsgBox "Erledigt. Das Register ist ersetzt." & Chr(10) & "Diese Kopie schließt sich jetzt. Öffne danach wie gewohnt:" & Chr(10) & _
		ConvertFromURL(sZiel), 64, "Sicherungskopie"
	AppBeenden()
	Exit Sub
Fehler:
	Fehlermeldung("Sicherungskopie übernehmen", Error$)
End Sub

REM ---------------------------------------------------------------- Stand von Tag … zurückholen
REM Liste der Stände: Tagesdateien und Basisstände, neueste zuerst. Dateinamen im Tag der Liste (gleiche Reihenfolge).
Sub SicherungInfo(oDoc As Object)
	Dim oF As Object, oSFA As Object, sOrdner As String, sText As String, a(), i As Long, j As Long, n As Long
	Dim aN() As String, aL() As String, s As String, t As String, sInfo As String, oDb As Object, sBasis As String
	On Error Resume Next
	oF = Fm(oDoc, "Vergleich")
	oDb = oDoc.Parent
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	sOrdner = SichOrdner(oDb, Verbindung())
	sText = TextOrdner(oDb, sOrdner)  ' V8.4-F10
	a = oSFA.getFolderContents(sText, False)
	ReDim aN(UBound(a) + 1) As String
	n = 0
	For i = 0 To UBound(a)
		s = UrlDateiname(a(i))
		If (Left(s, 4) = "Tag_" Or Left(s, 6) = "Basis_") And Right(s, 4) = ".zip" Then
			aN(n) = IIf(Left(s, 4) = "Tag_", Mid(s, 5, 10) & "_9999", Mid(s, 7, 15)) & "|" & s
			n = n + 1
		End If
	Next i
	For i = 0 To n - 2
		For j = 0 To n - 2 - i
			If aN(j) < aN(j + 1) Then
				t = aN(j) : aN(j) = aN(j + 1) : aN(j + 1) = t
			End If
		Next j
	Next i
	If n = 0 Then
		ReDim aL(0) As String
		aL(0) = "(noch keine Textsicherung)"
		oF.getByName("PK_lbStand").Tag = ""
	Else
		ReDim aL(n - 1) As String
		s = ""
		For i = 0 To n - 1
			t = Mid(aN(i), InStr(aN(i), "|") + 1)
			If Left(t, 4) = "Tag_" Then
				aL(i) = DatumDe(IsoDatum(Mid(t, 5, 10))) & "  ·  Tagesstand"
			Else
				aL(i) = DatumDe(IsoDatum(Mid(t, 7, 10))) & " " & Mid(t, 18, 2) & ":" & Mid(t, 20, 2) & "  ·  Vollstand"
			End If
			s = s & t & "|"
		Next i
		oF.getByName("PK_lbStand").Tag = s
	End If
	oF.getByName("PK_lbStand").StringItemList = aL()
	oF.getByName("PK_lbStand").SelectedItems = Array(0)
	sInfo = "Spiegel A: " & DateiZeit(sOrdner, OdbBasisName(oDb) & "_Spiegel_A.odb") & "   ·   Spiegel B: " & _
		DateiZeit(sOrdner, OdbBasisName(oDb) & "_Spiegel_B.odb") & "   ·   Letzte Probe: " & ProbeText(sOrdner)
	oF.getByName("PK_lblSichInfo").Label = sInfo
End Sub

Function DateiZeit(sOrdner As String, sName As String) As String
	Dim oSFA As Object, u As String
	DateiZeit = "—"
	On Error Resume Next
	oSFA = createUnoService("com.sun.star.ucb.SimpleFileAccess")
	u = ConvertToURL("/" & sName)
	u = sOrdner & Mid(u, LetztePos(u, "/") + 1)
	If oSFA.exists(u) Then DateiZeit = Format(CDate(DtZahl(oSFA.getDateTimeModified(u))), "DD.MM.YYYY hh:mm")
End Function

Function ProbeText(sOrdner As String) As String
	Dim a
	ProbeText = "noch keine"
	a = Split(DateiLesen(sOrdner & "pruefung.txt") & ";;", ";")
	If a(0) <> "" Then ProbeText = DatumDe(IsoDatum(a(0))) & " " & IIf(Left(a(1), 2) = "OK", "in Ordnung", "FEHLER")
End Function

REM CSV-Datensatz in Felder zerlegen (Text in "…", "" = ")
Function CsvFelder(sRec As String)
	Dim aT, aF() As String, i As Long, n As Long, sAkt As String, bOffen As Boolean
	aT = Split(sRec, ";")
	ReDim aF(UBound(aT)) As String
	n = -1
	bOffen = False
	For i = 0 To UBound(aT)
		If bOffen Then
			sAkt = sAkt & ";" & aT(i)
		Else
			sAkt = aT(i)
		End If
		bOffen = (AnfZaehlen(sAkt) Mod 2 = 1)
		If Not bOffen Then
			n = n + 1
			aF(n) = sAkt
		End If
	Next i
	ReDim Preserve aF(n) As String
	CsvFelder = aF
End Function

REM CSV-Feld → SQL-Literal nach Spaltentyp (java.sql.Types)
Function CsvLiteral(sFeld As String, nTyp As Long) As String
	If sFeld = "" Then
		CsvLiteral = "NULL"
	ElseIf Left(sFeld, 1) = """" Then
		CsvLiteral = "'" & Replace(Replace(Mid(sFeld, 2, Len(sFeld) - 2), """""", """"), "'", "''") & "'"
	Else
		Select Case nTyp
			Case 91 : CsvLiteral = "DATE '" & sFeld & "'"
			Case 92 : CsvLiteral = "TIME '" & sFeld & "'"
			Case 93 : CsvLiteral = "TIMESTAMP '" & sFeld & "'"
			Case Else : CsvLiteral = sFeld
		End Select
	End If
End Function

REM Lädt eine CSV-Datei aus der ZIP in R_<Tabelle>. bErsetzen: vorhandene Zeilen gleicher ID vorher entfernen (Tagesdatei).
Sub CsvLaden(oCon As Object, oZ As Object, sTab As String, bErsetzen As Boolean)
	Dim oIn As Object, aKopf, sCols As String, i As Integer, rs As Object, md As Object, aTyp() As Long, sRec As String
	Dim aF, sWerte As String, sBlock As String, nBlock As Long, oSt As Object, sZ As String
	oIn = ZipEintragLesen(oZ, sTab & ".csv")
	aKopf = CsvFelder(Zeile(oIn))
	sCols = Join(aKopf, ", ")
	rs = oCon.createStatement().executeQuery("SELECT " & sCols & " FROM ""R_" & sTab & """ WHERE 1 = 0")
	md = rs.getMetaData()
	ReDim aTyp(UBound(aKopf)) As Long
	For i = 0 To UBound(aKopf)
		aTyp(i) = md.getColumnType(i + 1)
	Next i
	oSt = oCon.createStatement()
	sBlock = ""
	nBlock = 0
	sRec = ""
	Do While Not oIn.isEOF()
		sZ = Zeile(oIn)
		If sRec = "" Then sRec = sZ Else sRec = sRec & Chr(10) & sZ
		If AnfZaehlen(sRec) Mod 2 = 0 Then
			aF = CsvFelder(sRec)
			sWerte = ""
			For i = 0 To UBound(aKopf)
				If i > 0 Then sWerte = sWerte & ", "
				If i <= UBound(aF) Then sWerte = sWerte & CsvLiteral(aF(i), aTyp(i)) Else sWerte = sWerte & "NULL"
			Next i
			If bErsetzen Then sBlock = sBlock & "DELETE FROM ""R_" & sTab & """ WHERE ""ID"" = " & aF(0) & ";" & Chr(10)
			sBlock = sBlock & "INSERT INTO ""R_" & sTab & """ (" & sCols & ") VALUES (" & sWerte & ");" & Chr(10)
			nBlock = nBlock + 1
			If Len(sBlock) > 12000 Or nBlock >= 50 Then
				oSt.executeUpdate("EXECUTE BLOCK AS BEGIN" & Chr(10) & sBlock & "END")
				sBlock = "" : nBlock = 0
			End If
			sRec = ""
		End If
	Loop
	If sBlock <> "" Then oSt.executeUpdate("EXECUTE BLOCK AS BEGIN" & Chr(10) & sBlock & "END")
	oIn.closeInput()
End Sub

REM Gewählten Stand laden und mit heute vergleichen
Sub StandVergleichen(Optional oEvent)
	Dim oDoc As Object, oF As Object, oLb As Object, aDateien, nSel As Integer, sOrdner As String, sText As String, sDatei As String
	Dim oCon As Object, oZ As Object, oZB As Object, aT, i As Integer, sInfo As String, sBasis As String, oIn As Object, aZ, sZ As String
	Dim rs As Object, n As Long, sStand As String
	oDoc = AppDoc()
	On Error GoTo Fehler
	oF = Fm(oDoc, "Vergleich")
	oLb = oF.getByName("PK_lbStand")
	If oLb.Tag = "" Then
		MsgBox "Es gibt noch keine Textsicherung. Sie entsteht beim ersten Schließen nach einer Änderung oder mit „Jetzt sichern“.", 64, "Stand vergleichen"
		Exit Sub
	End If
	aDateien = Split(oLb.Tag, "|")
	nSel = 0
	If UBound(oLb.SelectedItems) >= 0 Then nSel = oLb.SelectedItems(0)
	sDatei = aDateien(nSel)
	sStand = oLb.StringItemList(nSel)
	oCon = Verbindung()
	sOrdner = SichOrdner(DbDoc(), oCon)
	sText = TextOrdner(DbDoc(), sOrdner)  ' V8.4-F10
	StatusSetzen(oDoc, "Vergleiche … bitte warten")
	aT = TxZurueck()
	For i = 0 To UBound(aT)
		oCon.createStatement().executeUpdate("DELETE FROM ""R_" & aT(i) & """")
	Next i
	oZ = ZipLeser(sText & sDatei)
	If Left(sDatei, 4) = "Tag_" Then
		REM Basisstand dieser Tagesdatei laden, dann die Änderungen darüberlegen
		oIn = ZipEintragLesen(oZ, "Info.csv")
		Do While Not oIn.isEOF()
			sZ = Zeile(oIn)
			If Left(sZ, 11) = "Basisdatei;" Then sBasis = Mid(sZ, 12)
		Loop
		oIn.closeInput()
		oZB = ZipLeser(sText & sBasis)
		For i = 0 To UBound(aT)
			CsvLaden(oCon, oZB, aT(i), False)
		Next i
		For i = 0 To UBound(aT)
			CsvLaden(oCon, oZ, aT(i), True)
		Next i
		oIn = ZipEintragLesen(oZ, "Geloescht.csv")
		Zeile(oIn)
		Do While Not oIn.isEOF()
			aZ = Split(Zeile(oIn), ";")
			If UBound(aZ) >= 1 Then oCon.createStatement().executeUpdate("DELETE FROM ""R_" & aZ(0) & """ WHERE ""ID"" = " & aZ(1))
		Loop
		oIn.closeInput()
	Else
		For i = 0 To UBound(aT)
			CsvLaden(oCon, oZ, aT(i), False)
		Next i
	End If
	oCon.createStatement().executeUpdate("DELETE FROM ""R_Vergleich""")
	oCon.createStatement().executeUpdate("INSERT INTO ""R_Vergleich"" (""Tabelle"", ""DatensatzID"", ""Rang"", ""Art"", ""Was"", ""Unterschied"") " & _
		"SELECT ""Tabelle"", ""DatensatzID"", ""Rang"", ""Art"", ""Was"", ""Unterschied"" FROM ""V_Vergleich""")
	ZipFrei(oZ) : ZipFrei(oZB)
	oF.reload()
	StatusSetzen(oDoc, "Verglichen mit " & sStand)
	rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM ""R_Vergleich""")
	rs.next()
	n = rs.getLong(1)
	oF.getByName("PK_lblVergleich").Label = "Verglichen mit " & sStand & ":  " & n & IIf(n = 1, " Unterschied", " Unterschiede")
	If n = 0 Then MsgBox "Keine Unterschiede: Gegenüber " & sStand & " fehlt nichts und nichts ist anders.", 64, "Stand vergleichen"
	Exit Sub
Fehler:
	ZipFrei(oZ) : ZipFrei(oZB)
	Fehlermeldung("Stand vergleichen", Error$)
End Sub

Sub StandAlleFehlenden(Optional oEvent)
	Dim oCon As Object
	On Error GoTo Fehler
	oCon = Verbindung()
	oCon.createStatement().executeUpdate("UPDATE ""R_Vergleich"" SET ""Zurueck"" = (""Unterschied"" = 'fehlt heute')")
	StandZurueckholen(AppDoc())
	Exit Sub
Fehler:
	Fehlermeldung("Zurückholen", Error$)
End Sub

Sub StandAusgewaehlte(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Vergleich")
	If oF.IsModified Then oF.updateRow()
	StandZurueckholen(oDoc)
	Exit Sub
Fehler:
	Fehlermeldung("Zurückholen", Error$)
End Sub

Sub StandZurueckholen(oDoc As Object)
	Dim oCon As Object, rs As Object, n As Long, sFehler As String
	oCon = Verbindung()
	rs = oCon.createStatement().executeQuery("SELECT COUNT(*) FROM ""R_Vergleich"" WHERE ""Zurueck"" IS TRUE AND ""Unterschied"" IN ('fehlt heute', 'geändert')")
	rs.next()
	n = rs.getLong(1)
	If n = 0 Then
		MsgBox "Nichts ausgewählt. Hake in der Spalte „Zurück“ an, was zurückkommen soll, oder nimm „Alle fehlenden zurückholen“.", 64, "Zurückholen"
		Exit Sub
	End If
	On Error GoTo Fehler
	BenutzerSetzen(oDoc)  ' V8.2c-N03: Spur zeigte „unbekannt"
	oCon.createStatement().executeUpdate("EXECUTE PROCEDURE ""P_TEXT_ZURUECK""")
	Gespeichert()
	AlleNeuLaden(oDoc)
	Fm(oDoc, "Vergleich").reload()
	MsgBox n & IIf(n = 1, " Eintrag", " Einträge") & " zurückgeholt.", 64, "Zurückholen"
	Exit Sub
Fehler:
	sFehler = Error$
	On Error Resume Next
	oCon.createStatement().executeUpdate("UPDATE ""R_Vergleich"" SET ""Zurueck"" = FALSE")
	Fm(oDoc, "Vergleich").reload()
	If InStr(sFehler, "UNIQUE") > 0 Then
		MsgBox "Zurückholen geht nicht: Es gibt inzwischen einen Eintrag mit derselben Nummer oder demselben Namen.", 48, "Zurückholen"
	ElseIf InStr(sFehler, "FOREIGN") > 0 Then
		MsgBox "Zurückholen geht nicht: Ein übergeordneter Eintrag (Vertrag, Leistung oder Partner) fehlt." & Chr(10) & _
			"Hake ihn mit an oder nimm „Alle fehlenden zurückholen“.", 48, "Zurückholen"
	Else
		Fehlermeldung("Zurückholen", sFehler)
	End If
End Sub
