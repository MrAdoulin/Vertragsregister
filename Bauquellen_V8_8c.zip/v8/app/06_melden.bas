REM ================================================================ V8.1-P6 · Fehler/Wunsch melden
REM „Melden" → das nächste angeklickte Steuerelement wird technisch erfasst → Dialog mit Art und Kommentar →
REM Block in Meldungen/meldungen.txt neben der .odb. Nochmal „Melden" bricht ab.
REM Zustand: NA_btnMelden.Tag = "warte" während der Auswahl.

Function MeldenKnopf(oDoc As Object) As Object
	MeldenKnopf = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_btnMelden")
End Function

REM Alle sichtbaren Steuerelemente (außer dem Meldeknopf) bekommen kurz einen Mausbeobachter
Sub MeldenBeobachter(oDoc As Object, bAn As Boolean)
	Dim oDP As Object, i As Long, oS As Object, oM As Object, oC As Object
	On Error Resume Next
	REM V8.1-P6: Ein Klickbeobachter am ganzen Dokument verschluckte unter Xvfb jeden zweiten Knopfklick → nicht verwendet.
	REM Für Flächen ohne Element liegt jeder Meldung ein Bild der Ansicht bei.
	If bAn Then oMeldenL = CreateUnoListener("MeldenM_", "com.sun.star.awt.XMouseListener")
	oDP = oDoc.DrawPage
	For i = 0 To oDP.Count - 1
		oS = oDP.getByIndex(i)
		oM = Nothing
		oM = oS.Control
		If Not IsNull(oM) Then
			If oM.Name <> "NA_btnMelden" Then
				If oM.EnableVisible Then
					oC = oDoc.CurrentController.getControl(oM)
					If bAn Then oC.addMouseListener(oMeldenL) Else oC.removeMouseListener(oMeldenL)
				End If
			End If
		End If
	Next i
End Sub

Sub MeldenStart(Optional oEvent)
	Dim oDoc As Object, oB As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oB = MeldenKnopf(oDoc)
	REM Abbruch kam schon beim Drücken (MeldenM_mousePressed); das Loslassen löst nur noch diese Aktion aus
	If Left(oB.Tag, 7) = "abbruch" Then
		REM Gilt nur für das Loslassen direkt nach dem Abbruch (unter 1,5 s); danach startet ein Klick neu
		If CDbl(Now()) - CDbl(Mid(oB.Tag, 9)) < 1.5 / 86400 Then
			oB.Tag = ""
			Exit Sub
		End If
		oB.Tag = ""
	End If
	If oB.Tag = "warte" Then
		MeldenEnde(oDoc)
		StatusSetzen(oDoc, "Melden abgebrochen")
		Exit Sub
	End If
	oB.Tag = "warte"
	KaestchenMerken(oDoc)  ' V8.2b-F9
	REM V8.2b-M04: Der Knopf ist ein Symbol; den Hinweis zeigt die Statuszeile. Gelb = Melden wartet.
	oB.BackgroundColor = RGB(255, 236, 179)
	MeldenBeobachter(oDoc, True)
	StatusSetzen(oDoc, "Klick auf das Element, das du meinst. Nochmal auf den Käfer = abbrechen.")
	Exit Sub
Fehler:
	Fehlermeldung("Melden", Error$)
End Sub

Sub MeldenEnde(oDoc As Object)
	Dim oB As Object
	On Error Resume Next
	MeldenBeobachter(oDoc, False)
	oB = MeldenKnopf(oDoc)
	oB.Tag = ""
	oB.BackgroundColor = RGB(255, 255, 255)
End Sub

Sub MeldenM_mousePressed(oEvent)
	Dim oDoc As Object, oM As Object, sInfo As String, oL As Object
	On Error Resume Next
	oDoc = AppDoc()
	If MeldenKnopf(oDoc).Tag <> "warte" Then Exit Sub
	oM = oEvent.Source.Model
	If oM.Name = "NA_btnMelden" Then
		MeldenEnde(oDoc)
		MeldenKnopf(oDoc).Tag = "abbruch|" & CStr(CDbl(Now()))
		StatusSetzen(oDoc, "Melden abgebrochen")
		Exit Sub
	End If
	sInfo = ElementBeschreiben(oDoc, oM, oEvent)
	MeldenEnde(oDoc)
	REM V8.1-F3: Bis der Dialog zu ist, brechen alle Knopf-Makros sofort ab (MeldenLaeuft) [lokaler Test 14.10.]
	MeldenKnopf(oDoc).Tag = "gemeldet|" & CStr(CDbl(Now()))
	REM Dialog erst nach dem Mausereignis öffnen (sonst bleibt die Maus im Element gefangen)
	oL = CreateUnoListener("MeldenD_", "com.sun.star.awt.XCallback")
	REM V8.2b-F9: Ein Kontrollkästchen schaltet beim Loslassen trotzdem um; Zustand merken, nach dem Dialog zurück
	Dim nState As Integer, bMod As Boolean
	nState = -1
	If oM.supportsService("com.sun.star.form.component.CheckBox") Then
		REM Das Kästchen schaltet schon vor diesem Ereignis um: Zustand von „Melden"-Start nehmen
		nState = KaestchenVorher(oM)
		bMod = InStr(sMeldenForms, "," & oM.Parent.Name & ",") > 0
		REM Ein zweites Umschalten (Loslassen) bis nach dem Dialog verhindern
		If oM.Enabled Then oM.Enabled = False
	End If
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Array(sInfo, oM.Name, nState, oM, bMod))
End Sub

REM V8.1-F3: Der Bau setzt „If MeldenLaeuft() Then Exit Sub" an den Anfang jedes Knopf-Makros (außer MeldenStart).
REM Wahr, solange Melden auf den Klick wartet oder der Meldedialog offen ist (höchstens 120 s).
Function MeldenLaeuft() As Boolean
	Dim s As String
	MeldenLaeuft = False
	On Error GoTo Ende
	s = MeldenKnopf(AppDoc()).Tag
	If s = "warte" Then
		MeldenLaeuft = True
	ElseIf Left(s, 9) = "gemeldet|" Then
		MeldenLaeuft = (CDbl(Now()) - CDbl(Mid(s, 10)) < 120 / 86400)
	End If
Ende:
End Function
REM V8.5: toter Code MeldenK_* und FlaecheBeschreiben entfernt (nie angemeldet; Flächenklick meldet das Element daneben).

Sub MeldenM_mouseReleased(oEvent)
End Sub
Sub MeldenM_mouseEntered(oEvent)
End Sub
Sub MeldenM_mouseExited(oEvent)
End Sub
Sub MeldenM_disposing(oEvent)
End Sub

Sub MeldenD_notify(aData)
	On Error Resume Next
	MeldenDialog(aData(0), aData(1))
	If aData(2) >= 0 Then KaestchenZurueck(aData(3), aData(2), aData(4))  ' V8.2b-F9
	If Not IsNull(aData(3)) Then aData(3).Enabled = True
	REM V8.1-F3: Knopf-Makros wieder zulassen
	If Left(MeldenKnopf(AppDoc()).Tag, 9) = "gemeldet|" Then MeldenKnopf(AppDoc()).Tag = ""
End Sub

REM V8.2b-F9: Zustand aller sichtbaren Kästchen und geänderte Formulare beim Start von „Melden"
Global sMeldenK As String
Global sMeldenForms As String

Sub KaestchenMerken(oDoc As Object)
	On Error Resume Next
	sMeldenK = ";"
	sMeldenForms = ","
	KaestchenSammeln(oDoc.DrawPage.Forms)
End Sub

Sub KaestchenSammeln(oCont As Object)
	Dim i As Integer, m As Object
	For i = 0 To oCont.Count - 1
		m = oCont.getByIndex(i)
		If m.supportsService("com.sun.star.form.component.Form") Then
			If m.IsModified Or m.IsNew Then sMeldenForms = sMeldenForms & m.Name & ","
			KaestchenSammeln(m)
		ElseIf m.supportsService("com.sun.star.form.component.CheckBox") Then
			If m.EnableVisible Then sMeldenK = sMeldenK & oCont.Name & "|" & m.Name & "=" & m.State & ";"
		End If
	Next i
End Sub

Function KaestchenVorher(oM As Object) As Integer
	Dim k As Integer, sS As String
	KaestchenVorher = -1
	On Error GoTo Ende
	sS = ";" & oM.Parent.Name & "|" & oM.Name & "="
	k = InStr(sMeldenK, sS)
	If k > 0 Then KaestchenVorher = CInt(Mid(sMeldenK, k + Len(sS), 1))
Ende:
End Function

REM V8.2b-F9: Melden darf keine Daten ändern. War der Datensatz vorher unverändert, Änderung ganz zurücknehmen.
Sub KaestchenZurueck(oM As Object, nState As Integer, bMod As Boolean)
	On Error Resume Next
	oM.Enabled = True
	If oM.State = nState Then Exit Sub
	If Not bMod Then
		oM.Parent.cancelRowUpdates()
	Else
		oM.State = nState
		oM.commit()
	End If
	SichernFarbe(AppDoc())
End Sub

Function SpalteText(oF As Object, sSpalte As String) As String
	SpalteText = ""
	On Error GoTo Ende
	SpalteText = oF.getString(oF.findColumn(sSpalte))
Ende:
End Function

Function EigText(o As Object, sProp As String) As String
	Dim v
	EigText = ""
	On Error Resume Next
	v = o.getPropertyValue(sProp)
	If Not IsEmpty(v) And Not IsNull(v) Then EigText = CStr(v)
End Function

REM Technische Beschreibung: Name, Art, Formular, Datenfeld, Inhalt, Datensatz, Bereich, Fenster
Function ElementBeschreiben(oDoc As Object, oM As Object, oEvent) As String
	Dim s As String, oF As Object, sArt As String, sInhalt As String, nID As Long, sNr As String, oW As Object
	Dim oVS As Object, aSel, sZusatz As String
	On Error Resume Next
	sArt = oM.ImplementationName
	sArt = Mid(sArt, LetztePos(sArt, ".") + 1)
	s = "Element:    " & oM.Name & "  (" & sArt & ")" & Chr(10)
	oF = oM.Parent
	s = s & "Formular:   " & oF.Name & "  (Quelle " & EigText(oF, "Command") & ")" & Chr(10)
	If EigText(oM, "DataField") <> "" Then s = s & "Datenfeld:  " & EigText(oM, "DataField") & Chr(10)
	sInhalt = EigText(oM, "Label")
	If sInhalt = "" Then sInhalt = EigText(oM, "Text")
	If sInhalt = "" And EigText(oM, "Value") <> "" Then sInhalt = EigText(oM, "Value")
	If sInhalt = "" Then
		aSel = oM.SelectedItems
		If UBound(aSel) >= 0 Then sInhalt = oM.StringItemList(aSel(0))
	End If
	If sInhalt <> "" Then s = s & "Inhalt:     " & Chr(34) & Trim(Replace(sInhalt, Chr(10), " / ")) & Chr(34) & Chr(10)
	If EigText(oM, "HelpText") <> "" Then s = s & "Hilfetext:  " & EigText(oM, "HelpText") & Chr(10)
	REM Datensatz des Formulars (bei Rastern: die markierte Zeile)
	nID = AktuelleID(oF)
	If nID > 0 Then
		sZusatz = ""
		If SpalteText(oF, "Nr") <> "" Then sZusatz = ", Nr " & SpalteText(oF, "Nr")
		If SpalteText(oF, "Gegenstand") <> "" Then
			sZusatz = sZusatz & ", " & SpalteText(oF, "Gegenstand")
		ElseIf SpalteText(oF, "Bezeichnung") <> "" Then
			sZusatz = sZusatz & ", " & SpalteText(oF, "Bezeichnung")
		ElseIf SpalteText(oF, "Name") <> "" Then
			sZusatz = sZusatz & ", " & SpalteText(oF, "Name")
		End If
		s = s & "Datensatz:  ID " & nID & sZusatz & Chr(10)
	ElseIf oF.IsNew Then
		s = s & "Datensatz:  neu (noch nicht gespeichert)" & Chr(10)
	End If
	If sArt = "OGridControlModel" Then s = s & "Raster:     Spalte " & (oEvent.Source.getCurrentColumnPosition() + 1) & Chr(10)
	s = s & "Bereich:    " & oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag & Chr(10)
	oW = oDoc.CurrentController.Frame.ContainerWindow
	oVS = oDoc.CurrentController.ViewSettings
	s = s & "Fenster:    " & oW.getPosSize().Width & " × " & oW.getPosSize().Height & ", Zoom " & oVS.ZoomValue & " %" & _
		", Klick bei " & oEvent.X & "/" & oEvent.Y & Chr(10)
	ElementBeschreiben = s
End Function

REM Dialog: erfasstes Element, Art, Kommentar. Speichern hängt einen Block an meldungen.txt an.
Sub MeldenDialog(sInfo As String, sName As String)
	Dim oDM As Object, oDlg As Object, o As Object, sDatei As String, sAlt As String, sBlock As String, sArt As String
	Dim oDoc As Object, aSel, sBild As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oDM = createUnoService("com.sun.star.awt.UnoControlDialogModel")
	oDM.Width = 300 : oDM.Height = 230 : oDM.Title = "Fehler oder Wunsch melden"
	o = oDM.createInstance("com.sun.star.awt.UnoControlFixedTextModel")
	o.PositionX = 8 : o.PositionY = 6 : o.Width = 284 : o.Height = 78 : o.MultiLine = True : o.Label = sInfo
	oDM.insertByName("lblInfo", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlFixedTextModel")
	o.PositionX = 8 : o.PositionY = 88 : o.Width = 40 : o.Height = 10 : o.Label = "Art"
	oDM.insertByName("lblArt", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlListBoxModel")
	o.PositionX = 50 : o.PositionY = 86 : o.Width = 120 : o.Height = 12 : o.Dropdown = True
	o.StringItemList = Array("Fehler", "Änderungswunsch", "Frage")
	o.SelectedItems = Array(0)
	oDM.insertByName("lbArt", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlFixedTextModel")
	o.PositionX = 8 : o.PositionY = 104 : o.Width = 284 : o.Height = 10 : o.Label = "Was ist falsch oder was soll anders sein?"
	oDM.insertByName("lblKommentar", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlEditModel")
	o.PositionX = 8 : o.PositionY = 116 : o.Width = 284 : o.Height = 88 : o.MultiLine = True : o.VScroll = True
	oDM.insertByName("txtKommentar", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlButtonModel")
	o.PositionX = 172 : o.PositionY = 210 : o.Width = 58 : o.Height = 14 : o.Label = "Speichern" : o.PushButtonType = 1
	o.DefaultButton = False
	oDM.insertByName("btnOK", o)
	o = oDM.createInstance("com.sun.star.awt.UnoControlButtonModel")
	o.PositionX = 234 : o.PositionY = 210 : o.Width = 58 : o.Height = 14 : o.Label = "Abbrechen" : o.PushButtonType = 2
	oDM.insertByName("btnAbbrechen", o)
	oDlg = createUnoService("com.sun.star.awt.UnoControlDialog")
	oDlg.setModel(oDM)
	oDlg.createPeer(createUnoService("com.sun.star.awt.Toolkit"), Null)
	oDlg.getControl("txtKommentar").setFocus()
	If oDlg.execute() <> 1 Then
		oDlg.dispose()
		StatusSetzen(oDoc, "Meldung verworfen")
		Exit Sub
	End If
	aSel = oDM.getByName("lbArt").SelectedItems
	sArt = "Fehler"
	If UBound(aSel) >= 0 Then sArt = oDM.getByName("lbArt").StringItemList(aSel(0))
	sBlock = "==== Meldung " & Format(Date(), "YYYY-MM-DD") & " " & Format(Time(), "hh:mm:ss") & "  ·  " & Benutzer() & _
		"  ·  " & VERSION & Chr(10) & "Art:        " & sArt & Chr(10) & sInfo & "Kommentar:" & Chr(10) & _
		"  " & Replace(oDM.getByName("txtKommentar").Text, Chr(10), Chr(10) & "  ") & Chr(10) & Chr(10)
	oDlg.dispose()
	sDatei = OrdnerNebenDatei(DbDoc(), "Meldungen") & "meldungen.txt"
	REM Bild der Ansicht (ganze Seite, wie gerade sichtbar) neben die Textdatei
	sBild = MeldenBild(oDoc, OrdnerNebenDatei(DbDoc(), "Meldungen"))
	If sBild <> "" Then sBlock = Replace(sBlock, "Kommentar:" & Chr(10), "Bild:       " & sBild & Chr(10) & "Kommentar:" & Chr(10), 1, 1)
	sAlt = DateiLesen(sDatei)
	If sAlt <> "" Then sAlt = sAlt & Chr(10) & Chr(10)
	DateiSchreiben(sDatei, sAlt & sBlock)
	StatusSetzen(oDoc, "Meldung gespeichert")
	MsgBox "Gespeichert in:" & Chr(10) & ConvertFromURL(sDatei), 64, "Melden"
	Exit Sub
Fehler:
	Fehlermeldung("Melden", Error$)
End Sub

Sub MeldungenOrdnerOeffnen(Optional oEvent)
	On Error Resume Next
	ShellOeffnen(OrdnerNebenDatei(DbDoc(), "Meldungen"), "Der Ordner ist nicht erreichbar:")
End Sub

REM Bild der Ansicht; liefert den Dateinamen oder ""
REM V8.2b-F6: Der PNG-Export zeichnet die Pfeile von Auswahllisten über den Text (LibreOffice). Unter Windows
REM deshalb ein Bildschirmfoto nur vom Registerfenster (PowerShell); sonst oder wenn das scheitert: Export wie bisher.
Function MeldenBild(oDoc As Object, sOrdner As String) As String
	Dim aArg(0) As New com.sun.star.beans.PropertyValue, sName As String
	MeldenBild = ""
	On Error GoTo Ende
	sName = "meldung_" & Format(Date(), "YYYY-MM-DD") & "_" & Format(Time(), "hhmmss") & ".png"
	REM V8.5-F6: kein Fensterfoto per PowerShell mehr. Auf Nicos PC lief das Skript nie (kein „ok“, kein Fehler im Log),
	REM der Start kostete aber jedes Mal etwa 10 s (fensterfoto.log 15.10.: 11 s zwischen Meldung und Start).
	aArg(0).Name = "FilterName" : aArg(0).Value = "writer_png_Export"
	oDoc.storeToURL(sOrdner & sName, aArg())
	MeldenBild = sName
Ende:
End Function

