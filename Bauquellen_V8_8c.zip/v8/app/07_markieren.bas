REM ================================================================ V8.2a Markierung am Lösungsort (E14)
REM Ist etwas zu tun, wird das Feld oder der Knopf, mit dem man es löst, rot (dringend) oder gelb (offen).
REM Die Beschriftung bekommt ein „!", Feld und Beschriftung einen Tooltip mit dem, was zu tun ist.
REM Die ursprünglichen Werte stehen solange im Tag des Elements („M|Tag|Hintergrund|Schrift|Text|Hilfe").

Function ZielModell(oDoc As Object, sForm As String, sName As String) As Object
	Dim oF As Object
	ZielModell = Nothing
	On Error GoTo Ende
	oF = Fm(oDoc, sForm)
	If oF.hasByName(sName) Then ZielModell = oF.getByName(sName)
Ende:
End Function

REM Merkt die ursprünglichen Werte einmal im Tag
Sub MarkeMerken(oM As Object)
	Dim sTxt As String
	If Left(oM.Tag, 2) = "M|" Then Exit Sub
	sTxt = ""
	If oM.supportsService("com.sun.star.form.component.FixedText") Or oM.supportsService("com.sun.star.form.component.CommandButton") Then sTxt = oM.Label
	oM.Tag = "M|" & oM.Tag & "|" & oM.BackgroundColor & "|" & oM.TextColor & "|" & sTxt & "|" & oM.HelpText
End Sub

Sub MarkeZurueck(oM As Object)
	Dim a
	On Error Resume Next
	If IsNull(oM) Then Exit Sub
	If Left(oM.Tag, 2) <> "M|" Then Exit Sub
	a = Split(oM.Tag, "|", 6)
	REM Reiter färbt TabMarkieren selbst; dort nur Text und Tooltip zurück
	If InStr(oM.Name, "_tab") = 0 Then
		oM.BackgroundColor = CLng(a(2))
		oM.TextColor = CLng(a(3))
	End If
	If oM.supportsService("com.sun.star.form.component.FixedText") Or oM.supportsService("com.sun.star.form.component.CommandButton") Then oM.Label = a(4)
	oM.HelpText = a(5)
	oM.Tag = a(1)
End Sub

REM sAmpel „rot" oder „gelb"; das Feld sName im Formular sForm und seine Beschriftung sName & "L"
Sub MarkeSetzen(oDoc As Object, sForm As String, sName As String, sAmpel As String, sTipp As String)
	Dim oM As Object, oL As Object, nFg As Long, nBg As Long, a
	On Error Resume Next
	If sAmpel = "rot" Then
		nFg = RGB(215, 0, 21) : nBg = RGB(255, 214, 211)
	Else
		nFg = RGB(178, 80, 0) : nBg = RGB(255, 236, 199)
	End If
	oM = ZielModell(oDoc, sForm, sName)
	If IsNull(oM) Then Exit Sub
	MarkeMerken(oM)
	a = Split(oM.Tag, "|", 6)
	oM.HelpText = "! " & sTipp
	If InStr(oM.Name, "_tab") > 0 Then
		oM.Label = "! " & a(4)
	ElseIf oM.supportsService("com.sun.star.form.component.CommandButton") Then
		oM.Label = "! " & a(4)
		oM.BackgroundColor = nBg
		oM.TextColor = nFg
	Else
		oM.BackgroundColor = nBg
	End If
	oL = ZielModell(oDoc, sForm, sName & "L")
	If Not IsNull(oL) Then
		MarkeMerken(oL)
		a = Split(oL.Tag, "|", 6)
		oL.Label = a(4) & "   !"
		oL.TextColor = nFg
		oL.HelpText = "! " & sTipp
	End If
End Sub

Sub MarkeLoeschen(oDoc As Object, sForm As String, sName As String)
	MarkeZurueck(ZielModell(oDoc, sForm, sName))
	MarkeZurueck(ZielModell(oDoc, sForm, sName & "L"))
End Sub

Function InfoText(oF As Object, sSpalte As String) As String
	InfoText = ""
	On Error GoTo Ende
	If oF.RowCount > 0 And Not oF.isBeforeFirst() And Not oF.isAfterLast() Then InfoText = oF.getString(oF.findColumn(sSpalte))
Ende:
End Function

REM ---------------------------------------------------------------- Vertrag (aus InfoFaerben)
Sub VertragMarken(oInfo As Object)
	Dim oDoc As Object, sH As String, sA As String, sAnz As String, sF As String, sZ As String, sT As String
	Dim aZiele, i As Integer, oCon As Object, rs As Object, nP As Long
	On Error Resume Next
	oDoc = AppDoc()
	aZiele = Array("Entscheidung|VE1_btnVerl", "Entscheidung|VE1_btnKuend", "Entscheidung|VE1_txtVersandt", _
		"Entscheidung|VE1_txtBestaetigt", "Vertrag|VE1_lbStatus", "Vertrag|VE1_txtFrist", "Vertrag|VE1_btnGeprueft", _
		"Vertrag|VE1_txtIndex", "Vertrag|VE_tab1", "Vertrag|VE_tab2")
	For i = 0 To UBound(aZiele)
		MarkeLoeschen(oDoc, Split(aZiele(i), "|")(0), Split(aZiele(i), "|")(1))
	Next i
	sH = InfoText(oInfo, "Hinweis")
	sA = InfoText(oInfo, "HAmpel")
	sAnz = InfoText(oInfo, "Anzeige")
	If sA = "rot" Or sA = "gelb" Then
		sT = sAnz & ". "
		Select Case sH
			Case "KÜNDIGUNG PRÜFEN", "Stichtag naht"
				sT = sT & "Entscheide: „Verlängern“ oder „Kündigen“. Danach ist der Punkt erledigt."
				MarkeSetzen(oDoc, "Entscheidung", "VE1_btnVerl", sA, sT)
				MarkeSetzen(oDoc, "Entscheidung", "VE1_btnKuend", sA, sT)
			Case "ENDET BALD", "Ende naht"
				sT = sT & "Entscheide: „Verlängern“ (neu abschließen) oder „Kündigen“ (auslaufen lassen)."
				MarkeSetzen(oDoc, "Entscheidung", "VE1_btnVerl", sA, sT)
				MarkeSetzen(oDoc, "Entscheidung", "VE1_btnKuend", sA, sT)
			Case "KÜNDIGUNG VERSENDEN"
				MarkeSetzen(oDoc, "Entscheidung", "VE1_txtVersandt", sA, sT & "Kündigung versenden und hier das Versanddatum eintragen.")
			Case "STICHTAG VERPASST"
				MarkeSetzen(oDoc, "Entscheidung", "VE1_txtVersandt", sA, sT & "Kündigung sofort versenden, Datum hier eintragen und mit dem Partner klären, ob sie noch gilt.")
			Case "VERSAND NACH STICHTAG"
				MarkeSetzen(oDoc, "Entscheidung", "VE1_txtBestaetigt", sA, sT & "Mit dem Partner klären, ob die Kündigung gilt, und seine Bestätigung hier eintragen.")
			Case "Bestätigung fehlt"
				MarkeSetzen(oDoc, "Entscheidung", "VE1_txtBestaetigt", sA, sT & "Bestätigung des Partners einholen und hier das Datum eintragen.")
			Case "ABGELAUFEN"
				MarkeSetzen(oDoc, "Vertrag", "VE1_lbStatus", sA, sT & "Status auf „beendet“ setzen oder ein neues Vertragsende eintragen.")
			Case "Frist fehlt"
				MarkeSetzen(oDoc, "Vertrag", "VE1_txtFrist", sA, sT & "Kündigungsfrist in Monaten eintragen. Ohne Frist rechnet das Register keinen Stichtag.")
			Case "Prüfung fällig"
				MarkeSetzen(oDoc, "Vertrag", "VE1_btnGeprueft", sA, sT & "Vertrag durchsehen, dann „Heute geprüft“ klicken.")
			Case "Indexanpassung prüfen"
				MarkeSetzen(oDoc, "Vertrag", "VE1_txtIndex", sA, sT & "Neuen Betrag nach Index prüfen und eintragen, dann das nächste Anpassungsdatum setzen.")
		End Select
	End If
	REM Prüfung und Indexanpassung: eigene Aufgaben neben dem Hinweis
	sF = InfoText(oInfo, "PAmpel")
	If sF <> "" Then MarkeSetzen(oDoc, "Vertrag", "VE1_btnGeprueft", sF, "Prüfung fällig (nächste Prüfung: " & _
		Format(oInfo.getDate(oInfo.findColumn("NaechstePruefung")).Day, "00") & "." & Format(oInfo.getDate(oInfo.findColumn("NaechstePruefung")).Month, "00") & "." & _
		oInfo.getDate(oInfo.findColumn("NaechstePruefung")).Year & "). Vertrag durchsehen, dann „Heute geprüft“ klicken.")
	sF = InfoText(oInfo, "IAmpel")
	If sF <> "" Then MarkeSetzen(oDoc, "Vertrag", "VE1_txtIndex", sF, "Indexanpassung steht an. Neuen Betrag prüfen und eintragen, dann das nächste Anpassungsdatum setzen.")
	sF = InfoText(oInfo, "Ampel")
	If sF = "rot" Or sF = "gelb" Then MarkeSetzen(oDoc, "Vertrag", "VE_tab1", sF, "In diesem Reiter ist etwas zu tun (rote oder gelbe Felder mit „!“).")
	REM Reiter „Leistungen & Protokoll": dringendste Leistung dieses Vertrags
	sZ = InfoText(oInfo, "ID")
	If sZ <> "" Then
		oCon = Verbindung()
		rs = oCon.createStatement().executeQuery("SELECT MIN(""Prio"") FROM ""V_Leistung"" WHERE ""VertragID"" = " & sZ)
		If rs.next() Then
			nP = rs.getLong(1)
			If Not rs.wasNull() Then
				If nP = 1 Then
					MarkeSetzen(oDoc, "Vertrag", "VE_tab2", "rot", "Bei einer Leistung ist etwas dringend zu tun (Spalte „!“).")
				ElseIf nP = 2 Then
					MarkeSetzen(oDoc, "Vertrag", "VE_tab2", "gelb", "Bei einer Leistung ist etwas offen (Spalte „!“).")
				End If
			End If
		End If
	End If
End Sub

REM ---------------------------------------------------------------- Leistung (aus LeistungInfoFaerben)
Sub LeistungMarken(oInfo As Object)
	Dim oDoc As Object, sH As String, sA As String, sAnz As String, sN As String, oF As Object, oB As Object
	Dim nOff As Long
	On Error Resume Next
	oDoc = AppDoc()
	MarkeLoeschen(oDoc, "Leistung", "VE2_btnErbracht")
	MarkeLoeschen(oDoc, "Leistung", "VE2_btnOffenes")
	MarkeLoeschen(oDoc, "Leistung", "VE2_lbAbdeckung")
	sH = InfoText(oInfo, "Hinweis")
	sA = InfoText(oInfo, "Ampel")
	sAnz = InfoText(oInfo, "Anzeige")
	sN = InfoText(oInfo, "Bezeichnung")
	REM Titel nennen die gewählte Leistung (M07, M17, M18, M05)
	oF = Fm(oDoc, "Vertrag")
	oF.getByName("VE2_lblLeiDetail").Label = IIf(sN = "", "DETAIL ZUR LEISTUNG", "DETAIL ZUR LEISTUNG: " & UCase(sN))
	REM V8.6: schmale Karte – lange Namen gekürzt (Text lief sonst unter die Knöpfe)
	oF.getByName("VE2_lblLeiProt").Label = IIf(sN = "", "PROTOKOLL", "PROTOKOLL: " & UCase(IIf(Len(sN) > 18, Left(sN, 17) & "…", sN)))
	oF.getByName("VE2_lblLeiStand").Label = IIf(sN = "", "STAND", "STAND: " & UCase(sN))
	REM Knopf zum offenen Eintrag nur aktiv, wenn es einen gibt
	nOff = 0
	If InfoText(oInfo, "OffeneRechnungen") <> "" Then nOff = CLng(InfoText(oInfo, "OffeneRechnungen")) + CLng(InfoText(oInfo, "OffeneStoerungen")) + CLng(InfoText(oInfo, "OffeneErgaenzen"))
	oB = Fm(oDoc, "Leistung").getByName("VE2_btnOffenes")
	oB.Enabled = (nOff > 0)
	If sA = "rot" Or sA = "gelb" Then
		Select Case sH
			Case "ÜBERFÄLLIG", "bald fällig", "noch nie erbracht"
				MarkeSetzen(oDoc, "Leistung", "VE2_btnErbracht", sA, sAnz & ". Nach Erledigung „Heute erbracht“ klicken oder mit „+ Eintrag“ das Datum erfassen.")
			Case "LEISTUNGSANFALL OFFEN"
				MarkeSetzen(oDoc, "Leistung", "VE2_btnOffenes", sA, "Leistungsanfall ohne Erledigung. Eintrag öffnen und die Erledigung durch den Partner mit Datum und Uhrzeit eintragen.")
			Case "RECHNUNG PRÜFEN"
				MarkeSetzen(oDoc, "Leistung", "VE2_btnOffenes", sA, sAnz & ". Eintrag öffnen, Stand lesen, dann Freigabe (Datum, Betrag, Name) eintragen.")
			Case "Angaben ergänzen"
				MarkeSetzen(oDoc, "Leistung", "VE2_btnOffenes", sA, sAnz & ". Eintrag öffnen, Beschreibung oder Beleg ergänzen und sichern.")
		End Select
	End If
	REM M22: ausgeschlossene Leistung immer rot markieren
	If InfoText(oInfo, "Abdeckung") = "ausgeschlossen" Then
		MarkeSetzen(oDoc, "Leistung", "VE2_lbAbdeckung", "rot", "Nicht Teil des Vertrags. Rechnungen dafür nicht freigeben; vorher klären, wer den Auftrag gegeben hat.")
	End If
End Sub

REM M15: ältesten offenen Eintrag der gewählten Leistung in „Rechnungsverlauf" öffnen
Sub OffenenEintragOeffnen(Optional oEvent)
	Dim oDoc As Object, nL As Long, rs As Object, nE As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	nL = AktuelleID(Fm(oDoc, "Leistung"))
	If nL = 0 Then Exit Sub
	rs = Verbindung().createStatement().executeQuery("SELECT FIRST 1 ""ID"" FROM ""V_Ereignis"" WHERE ""LeistungID"" = " & nL & _
		" AND ""Offen"" IS NOT NULL ORDER BY ""Entstanden"", ""ID""")
	If Not rs.next() Then
		MsgBox "Bei dieser Leistung ist kein Eintrag offen.", 64, "Offener Eintrag"
		Exit Sub
	End If
	nE = rs.getLong(1)
	If Not Bereich(oDoc, "PR") Then Exit Sub
	EreignisZeigen(oDoc, nE)
	Exit Sub
Fehler:
	Fehlermeldung("Offener Eintrag", Error$)
End Sub

REM ---------------------------------------------------------------- Protokolleintrag (aus EreignisInfoFaerben)
Sub EreignisMarken(oInfo As Object)
	Dim oDoc As Object, sO As String, sA As String, aZ, i As Integer, sMax As String
	On Error Resume Next
	oDoc = AppDoc()
	aZ = Array("PR_txtDatum", "PR_txtBetrag", "PR_txtFreiDatum", "PR_txtFreiBetrag", "PR_txtReaAm", "PR_txtBeschreibung")
	For i = 0 To UBound(aZ)
		MarkeLoeschen(oDoc, "Ereignis", aZ(i))
	Next i
	sO = InfoText(oInfo, "Offen")
	sA = InfoText(oInfo, "Ampel")
	If sO = "" Or (sA <> "rot" And sA <> "gelb") Then Exit Sub
	sMax = InfoText(oInfo, "MaxFreigabe")
	Select Case sO
		Case "Betrag oder Datum fehlt"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtBetrag", sA, "Rechnungsbetrag und Rechnungsdatum eintragen. Erst dann prüft das Register die Rechnung.")
			MarkeSetzen(oDoc, "Ereignis", "PR_txtDatum", sA, "Rechnungsdatum eintragen.")
		Case "Freigabe offen"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtFreiDatum", sA, "Stand lesen, dann Freigabedatum, freigegebenen Betrag und Namen eintragen. Zurückgewiesen: Betrag 0.")
		Case "Freigabebetrag fehlt"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtFreiBetrag", sA, "Freigegebenen Betrag eintragen (höchstens " & sMax & " €). Zurückgewiesen: 0.")
		Case "ZU VIEL FREIGEGEBEN"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtFreiBetrag", sA, "Freigegeben ist mehr als zulässig. Höchstens " & sMax & " € freigeben und den Betrag korrigieren.")
		Case "Erledigung offen"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtReaAm", sA, "Leistungsanfall ohne Erledigung. Datum und Uhrzeit der Erledigung des Partners eintragen.")
		Case "Angaben ergänzen"
			MarkeSetzen(oDoc, "Ereignis", "PR_txtBeschreibung", sA, "Mit „Heute erbracht“ angelegt. Beschreibung oder Beleg ergänzen und sichern. Danach ist der Eintrag erledigt.")
	End Select
End Sub

REM ---------------------------------------------------------------- „!" in der Leistungsliste (M08)
REM Die Liste im Vertrag liest die Tabelle; die Spalte „Marke" hält die Ampel der Leistung (ohne Änderungsspur).
Sub MarkenAktualisieren()
	On Error Resume Next
	Verbindung().createStatement().executeUpdate("UPDATE ""Leistung"" l SET ""Marke"" = " & _
		"(SELECT NULLIF(v.""Marke"", '') FROM ""V_Leistung"" v WHERE v.""ID"" = l.""ID"") " & _
		"WHERE ""Marke"" IS DISTINCT FROM (SELECT NULLIF(v.""Marke"", '') FROM ""V_Leistung"" v WHERE v.""ID"" = l.""ID"")")
End Sub

REM ---------------------------------------------------------------- Sortieren in der Übersicht (E25)
Sub SortWechseln(sForm As String, sKnopf As String, aOrder, aText)
	Dim oDoc As Object, oF As Object, oB As Object, n As Integer
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, sForm)
	oB = oDoc.DrawPage.Forms.getByName("Nav").getByName(sKnopf)
	n = 0
	If IsNumeric(oB.Tag) Then n = CInt(oB.Tag)
	n = (n + 1) Mod (UBound(aOrder) + 1)
	oB.Tag = CStr(n)
	oB.Label = "Sortiert: " & aText(n) & " ▾"
	oF.Order = aOrder(n)
	oF.reload()
	Exit Sub
Fehler:
	Fehlermeldung("Sortieren", Error$)
End Sub

Sub SortHeute(Optional oEvent)
	SortWechseln("Heute", "ST_btnSortHeute", _
		Array("""Prio"", ""Bezug""", """DatumSort"", ""Prio""", """Gegenstand"", ""Prio""", """Aufgabe"", ""Prio"""), _
		Array("Dringlichkeit", "Datum", "Vertrag", "Aufgabe"))
End Sub

Sub SortFristen(Optional oEvent)
	SortWechseln("Fristen", "ST_btnSortFristen", _
		Array("""Datum"", ""ID""", """Gegenstand"", ""Datum""", """Art"", ""Datum"""), _
		Array("Datum", "Vertrag", "Termin"))
End Sub

