REM ============================================================ V8.2b · Knopf „H" über leeren Datumsfeldern (M19, E19)
REM Der Knopf heißt <Bereich>h_<Feld>, sein Tag nennt das Datumsfeld. Zweig() kennt das Präfix nicht.

Private Const HFORMS = ""

REM Bereich des Feldes aus dem Namen (VE1_txtBeginn → VE1)
Function HBereich(sName As String) As String
	Dim k As Integer
	k = InStr(sName, "_")
	If k > 1 Then HBereich = Left(sName, k - 1) Else HBereich = ""
End Function

Function HName(sFeld As String) As String
	Dim k As Integer
	k = InStr(sFeld, "_")
	HName = Left(sFeld, k - 1) & "h_" & Mid(sFeld, k + 1)
End Function

REM Leer = Modell ohne Datum UND Anzeige ohne Text. Das Modell allein irrt bei neuen Zeilen mit Vorgabedatum,
REM der Anzeigetext allein bei gefüllten Feldern kurz nach dem Laden (beides Versuch 15.10.).
Function DatumLeer(m As Object) As Boolean
	Dim v, c As Object, bModell As Boolean
	On Error Resume Next
	v = m.Date
	bModell = IsEmpty(v) Or IsNull(v)
	DatumLeer = bModell
	If Not bModell Then Exit Function
	c = AppDoc().CurrentController.getControl(m)
	If Not IsNull(c) Then DatumLeer = (Trim(c.Text) = "")
End Function

Function HAktuell() As String
	On Error Resume Next
	HAktuell = AppDoc().DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag
End Function

REM Zeigt „H" nur, wenn der Bereich des Feldes sichtbar und das Feld leer ist
Sub HSetzen(oF As Object, oFeld As Object, bLeer As Boolean, sAkt As String)
	Dim sH As String, oB As Object, b As Boolean
	sH = HName(oFeld.Name)
	If Not oF.hasByName(sH) Then Exit Sub
	oB = oF.getByName(sH)
	b = bLeer And Sichtbar(HBereich(oFeld.Name), sAkt) And Not oFeld.ReadOnly
	REM V8.4-P02: „H“ liegt neben dem Feld (Beschriftungszeile); kein Neu-Einblenden mehr nötig
	If oB.EnableVisible <> b Then
		oB.EnableVisible = b
	End If
End Sub

Sub HAktualisieren(Optional oDoc)
	Dim a, i As Integer, j As Integer, oF As Object, m As Object, sAkt As String, d As Object
	On Error Resume Next
	If IsMissing(oDoc) Then d = AppDoc() Else d = oDoc
	sAkt = d.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag
	a = Split(HFORMS, ",")
	For i = 0 To UBound(a)
		oF = Fm(d, a(i))
		For j = 0 To oF.Count - 1
			m = oF.getByIndex(j)
			If InStr(m.Name, "h_") > 0 And m.Tag <> "" Then HSetzen(oF, oF.getByName(m.Tag), DatumLeer(oF.getByName(m.Tag)), sAkt)
		Next j
	Next i
End Sub

REM Tippen im Datumsfeld: „H" verschwindet, sobald etwas drinsteht
Sub HText(oEv As Object)
	REM Nachgelagert: Änderungen an Steuerelementen direkt im Tippen verschluckten Eingaben (flow-Test I, 14.10.)
	On Error Resume Next
	Spaeter("H")
End Sub

Sub HeuteSetzen(oEv As Object)
	Dim oB As Object, oF As Object, m As Object, d As New com.sun.star.util.Date
	oB = oEv.Source.Model
	oF = oB.Parent
	m = oF.getByName(oB.Tag)
	If m.ReadOnly Then Exit Sub
	d.Year = Year(Date()) : d.Month = Month(Date()) : d.Day = Day(Date())
	m.Date = d
	m.commit()
	oB.EnableVisible = False
	FokusAuf(AppDoc(), oF.Name, m.Name)
End Sub

REM Datensatzwechsel in Formularen ohne eigenen Handler (Vertretung)
Sub HNachWechsel(Optional oEvent)
	On Error Resume Next
	Spaeter("H")
End Sub
