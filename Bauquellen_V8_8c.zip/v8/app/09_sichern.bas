REM ============================================================ V8.2b · Sichern-Knöpfe grau, solange nichts geändert ist (M06)
REM Die Knöpfe bleiben anklickbar; nur die Farbe zeigt, ob es etwas zu sichern gibt.

Global oAendL As Object

REM Beim Start: Jedes bearbeitbare Formular meldet Änderungen an IsModified (Ereignis im Formular kam nicht an, Versuch 14.10.)
Sub AenderungBeobachten(oDoc As Object)
	Dim a, i As Integer, oF As Object
	On Error Resume Next
	oAendL = CreateUnoListener("Aend_", "com.sun.star.beans.XPropertyChangeListener")
	a = Split(EDITIERBAR, ",")
	For i = 0 To UBound(a)
		oF = Fm(oDoc, a(i))
		If Not IsNull(oF) Then oF.addPropertyChangeListener("IsModified", oAendL)
	Next i
	SichernFarbe(oDoc)
End Sub

REM Nachgelagert: direkt im Ereignis verschluckte das Feld die gerade getippte Eingabe (flow-Test I, 14.10.)
Sub Aend_propertyChange(oEv)
	On Error Resume Next
	Spaeter("S")
End Sub

Sub Aend_disposing(oEv)
End Sub

Function BereichGeaendert(oDoc As Object, sAkt As String) As Boolean
	Dim a, i As Integer, k As Integer, sE As String, sB As String, oF As Object
	On Error Resume Next
	BereichGeaendert = False
	a = Split(FORMBEREICHE, ";")
	For i = 0 To UBound(a)
		sE = a(i)
		k = InStr(sE, ":")
		sB = "," & Mid(sE, k + 1) & ","
		If InStr(sB, "," & sAkt & ",") > 0 Or InStr(sB, "," & Left(sAkt, 2) & ",") > 0 Then
			oF = Fm(oDoc, Left(sE, k - 1))
			If Not IsNull(oF) Then
				If oF.IsModified Then
					BereichGeaendert = True
					Exit Function
				End If
			End If
		End If
	Next i
End Function

Sub SichernFarbe(oDoc As Object)
	Dim sAkt As String, b As Boolean, a, i As Integer, k As Integer, sE As String, oF As Object, j As Integer, m As Object
	On Error Resume Next
	sAkt = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag
	b = BereichGeaendert(oDoc, sAkt)
	a = Split(FORMBEREICHE, ";")
	For i = 0 To UBound(a)
		sE = a(i)
		k = InStr(sE, ":")
		oF = Fm(oDoc, Left(sE, k - 1))
		For j = 0 To oF.Count - 1
			m = oF.getByIndex(j)
			If m.Name Like "*_btn*Sichern" Then
				REM V8.8 (KOH-01): nur der Sichern-Knopf oben ist blau gefüllt, die in den Karten (VE1, VE2) hellblau
				If Sichtbar(Left(m.Name, InStr(m.Name, "_") - 1), sAkt) Then KnopfAktiv(m, b, (m.Name = "VE1_btnEntSichern" Or m.Name = "VE2_btnLeiSichern"))
			ElseIf m.Name = "VE_btnLoeschen" Or m.Name = "VE2_btnLeiLoeschen" Or m.Name = "PA_btnLoeschen" Or m.Name = "VT_btnLoeschen" Then
				REM V8.4-P04: „Verwerfen“ bei ungesicherten Änderungen, sonst „Löschen“ (Vertrag: „Vertrag löschen“)
				If Sichtbar(Left(m.Name, InStr(m.Name, "_") - 1), sAkt) Then
					Dim oZ As Object
					oZ = Fm(oDoc, LoeschFormular(m.Name))
					LoeschKnopf(m, oZ.IsModified Or oZ.IsNew)
				End If
			ElseIf m.Name = "PRv_btnKorrigieren" Then
				REM V8.4-E21: nur bei gesichertem, nicht storniertem Eintrag
				Dim bK As Boolean
				bK = False
				REM V8.5-Q6: auch mit ungesicherten Änderungen sichtbar – genau dann wird korrigiert
				If sAkt = "PR" And Not oF.IsNew And oF.RowCount > 0 And AktuelleID(oF) > 0 Then bK = Not StorniertInDb(AktuelleID(oF))
				If m.EnableVisible <> bK Then m.EnableVisible = bK
			ElseIf m.Name = "VE1_btnEntVerwerfen" Then
				REM V8.5-Q1: rot, wenn die Karte ungesicherte Eingaben hat, sonst grau
				If Sichtbar("VE1", sAkt) Then VerwerfenAktiv(m, oF.IsModified)
			ElseIf m.Name = "PRv_btnVerwerfen" Then
				REM V8.2b-M21: nur sichtbar, wenn der Eintrag ungesicherte Eingaben hat
				If m.EnableVisible <> (sAkt = "PR" And oF.IsModified) Then m.EnableVisible = (sAkt = "PR" And oF.IsModified)
			End If
		Next j
	Next i
End Sub

Sub KnopfAktiv(m As Object, b As Boolean, Optional bLeicht)
	If b And Not IsMissing(bLeicht) Then
		If bLeicht Then
			If m.BackgroundColor <> RGB(229, 241, 255) Then m.BackgroundColor = RGB(229, 241, 255) : m.TextColor = RGB(0, 122, 255)
			m.HelpText = "Speichert alle Änderungen. (Strg+S)"
			Exit Sub
		End If
	End If
	If b Then
		If m.BackgroundColor <> RGB(0, 122, 255) Then m.BackgroundColor = RGB(0, 122, 255) : m.TextColor = RGB(255, 255, 255)
		m.HelpText = "Speichert alle Änderungen. (Strg+S)"
	Else
		If m.BackgroundColor <> RGB(229, 229, 234) Then m.BackgroundColor = RGB(229, 229, 234) : m.TextColor = RGB(110, 110, 115)
		m.HelpText = "Nichts geändert. Gespeichert ist alles."
	End If
End Sub

Sub AenderungAbmelden(oDoc As Object)
	Dim a, i As Integer, oF As Object
	On Error Resume Next
	If IsNull(oAendL) Then Exit Sub
	a = Split(EDITIERBAR, ",")
	For i = 0 To UBound(a)
		oF = Fm(oDoc, a(i))
		If Not IsNull(oF) Then oF.removePropertyChangeListener("IsModified", oAendL)
	Next i
	oAendL = Nothing
End Sub

Sub LoeschKnopf(m As Object, bAenderung As Boolean)
	Dim sL As String, sH As String
	If bAenderung Then
		sL = "Verwerfen"
		sH = "Nimmt die ungesicherten Änderungen zurück. Gespeichertes bleibt."
	Else
		sL = IIf(m.Name = "VE_btnLoeschen", "Vertrag löschen", "Löschen")
		sH = "Löscht den gespeicherten Datensatz (mit Rückfrage, 90 Tage im Papierkorb)."
	End If
	If m.Label <> sL Then m.Label = sL
	If m.HelpText <> sH Then m.HelpText = sH
End Sub

REM Das Formular, dessen Datensatz der Knopf löscht (der Knopf selbst kann in einem anderen Formular liegen)
Function LoeschFormular(sName As String) As String
	Select Case sName
		Case "VE_btnLoeschen" : LoeschFormular = "Vertrag"
		Case "VE2_btnLeiLoeschen" : LoeschFormular = "Leistung"
		Case "PA_btnLoeschen" : LoeschFormular = "Partner"
		Case "VT_btnLoeschen" : LoeschFormular = "Vertretung"
	End Select
End Function

REM V8.5-Q6: Storno-Stand aus der Tabelle (der Haken im Formular kann ungesichert geändert sein)
Function StorniertInDb(nID As Long) As Boolean
	Dim rs As Object
	StorniertInDb = False
	On Error Resume Next
	rs = Verbindung().createStatement().executeQuery("SELECT ""Storniert"" FROM ""Ereignis"" WHERE ""ID"" = " & nID)
	If rs.next() Then StorniertInDb = rs.getBoolean(1)
End Function

Sub VerwerfenAktiv(m As Object, b As Boolean)
	If b Then
		If m.BackgroundColor <> RGB(255, 229, 227) Then m.BackgroundColor = RGB(255, 229, 227) : m.TextColor = RGB(215, 0, 21)
		m.HelpText = "Nimmt ungesicherte Eingaben in dieser Karte zurück."
	Else
		If m.BackgroundColor <> RGB(229, 229, 234) Then m.BackgroundColor = RGB(229, 229, 234) : m.TextColor = RGB(110, 110, 115)
		m.HelpText = "Nichts zu verwerfen. Gespeichert ist alles."
	End If
End Sub
