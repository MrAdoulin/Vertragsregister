REM ============================================================ V8.3-E30 · „Ersetzt Vertrag“ mit Links in beide Richtungen
REM Der neue Vertrag speichert den alten (ErsetztVertrag). Der alte zeigt rechts „Wird ersetzt durch: <Link>“.

Sub ZumVorgaenger(Optional oEvent)
	Dim oDoc As Object, oF As Object, n As Long
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Vertrag")
	n = oF.getLong(oF.findColumn("ErsetztVertrag"))
	If oF.wasNull() Or n = 0 Then
		StatusSetzen(oDoc, "Kein alter Vertrag gewählt")
		Exit Sub
	End If
	VertragZeigenIn(oDoc, n)
	Exit Sub
Fehler:
	Fehlermeldung("Alten Vertrag öffnen", Error$)
End Sub

Sub ZumNachfolger(Optional oEvent)
	Dim n As Long
	On Error GoTo Fehler
	If MeldenLaeuft() Then Exit Sub
	n = Val(oEvent.Source.Model.Tag)
	If n > 0 Then VertragZeigenIn(AppDoc(), n)
	Exit Sub
Fehler:
	Fehlermeldung("Neuen Vertrag öffnen", Error$)
End Sub

REM Aufruf aus InfoFaerben (Datensatzwechsel). Ohne Nachfolger bleiben Beschriftung und Link leer.
Sub NachfolgerZeigen(oInfo As Object)
	Dim oF As Object, nV As Long, rs As Object, oL As Object, oT As Object
	On Error Resume Next
	oF = Fm(AppDoc(), "Vertrag")
	oL = oF.getByName("VE1_lblNachfolger")
	oT = oF.getByName("VE1_lblNachfolgerL")
	nV = AktuelleID(oF)
	oL.Label = "" : oL.Tag = "" : oT.Label = ""
	If nV = 0 Then Exit Sub
	rs = oF.ActiveConnection.createStatement().executeQuery("SELECT FIRST 1 ""ID"", ""Nr"", ""Gegenstand"" FROM ""Vertrag"" " & _
		"WHERE ""ErsetztVertrag"" = " & nV & " ORDER BY ""ID""")
	If rs.next() Then
		oT.Label = "Wird ersetzt durch"
		oL.Label = rs.getString(2) & "  ›"
		oL.HelpText = "Öffnet den neuen Vertrag: " & rs.getString(2) & " " & rs.getString(3)
		oL.Tag = CStr(rs.getLong(1))
	End If
End Sub

REM ============================================================ V8.3-LEC · Reiter „Dienstvertrag“
REM Sichtbar nur im Vertrag (VE1–VE4) und nur bei Vertragsart „Dienstvertrag (LEC)“. Steht man auf VE4 und die Art
REM passt nicht mehr, geht es zurück auf den Reiter „Vertrag“.
Sub DienstReiterZeigen(oDoc As Object)
	Dim oF As Object, oT As Object, sAkt As String, b As Boolean, sArt As String
	On Error Resume Next
	oF = Fm(oDoc, "Vertrag")
	oT = oF.getByName("VEt_tab4")
	sAkt = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag
	REM Auswahl im Feld (auch vor dem Sichern), nicht die gespeicherte Spalte
	Dim m As Object, a
	sArt = ""
	m = oF.getByName("VE1_lbArt")
	a = m.SelectedItems
	If UBound(a) >= 0 Then sArt = m.StringItemList(a(0))
	b = (Left(sAkt, 2) = "VE") And (sArt = "Dienstvertrag (LEC)")
	If oT.EnableVisible <> b Then oT.EnableVisible = b
	If sAkt = "VE4" And Not b Then Gehe("VE1")
End Sub

Sub ArtGeaendert(Optional oEvent)
	On Error Resume Next
	Spaeter("H")  ' V8.3-LEC: Reiter „Dienstvertrag“ ein-/ausblenden
End Sub
