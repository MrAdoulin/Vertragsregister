REM ============================================================ V8.3-E29 · Partner in zwei Listen
REM Oben Partner mit laufendem Vertrag, unten (grau) ohne. Beide Listen sind Leseformulare; ein Klick stellt das
REM bearbeitbare Formular „Partner“ (rechts) auf denselben Partner. Beim Neuladen der Listen ruht der Abgleich.

Global bPartnerRuhe As Boolean

Sub PartnerListeGewaehlt(Optional oEvent)
	Dim oL As Object, nID As Long
	On Error Resume Next
	If bPartnerRuhe Then Exit Sub
	oL = oEvent.Source
	If oL.RowCount = 0 Or oL.isBeforeFirst() Or oL.isAfterLast() Then Exit Sub
	nID = oL.getLong(oL.findColumn("ID"))
	If nID > 0 Then PartnerAuf(AppDoc(), nID)
End Sub

REM Stellt das Formular „Partner“ auf die ID (Reihenfolge wie im Formular: nach Name)
Sub PartnerAuf(oDoc As Object, nID As Long)
	Dim oF As Object, rs As Object, k As Long
	On Error GoTo Ende
	oF = Fm(oDoc, "Partner")
	If Not oF.isLoaded() Then oF.load()
	If oF.IsModified Or oF.IsNew Then
		If Not Speichern(oDoc, oF) Then Exit Sub
	End If
	If AktuelleID(oF) = nID Then Exit Sub
	rs = oF.ActiveConnection.createStatement().executeQuery("SELECT COUNT(*) FROM ""Partner"" WHERE ""Name"" < " & _
		"(SELECT ""Name"" FROM ""Partner"" WHERE ""ID"" = " & nID & ")")
	rs.next()
	k = rs.getLong(1)
	oF.absolute(k + 1)
	If AktuelleID(oF) <> nID Then
		REM Rückfall: suchen
		oF.first()
		Do While Not oF.isAfterLast()
			If AktuelleID(oF) = nID Then Exit Do
			oF.next()
		Loop
	End If
Ende:
End Sub

REM Listen neu laden, ohne das Partnerformular zu verstellen
Sub PartnerListenNeu(oDoc As Object)
	On Error Resume Next
	bPartnerRuhe = True
	Fm(oDoc, "PartnerAktiv").reload()
	Fm(oDoc, "PartnerInaktiv").reload()
	bPartnerRuhe = False
End Sub

REM Beim Öffnen der Ansicht: Listen neu, rechts der erste Partner mit laufendem Vertrag
Sub PartnerAnsicht(oDoc As Object)
	Dim oA As Object
	On Error Resume Next
	PartnerListenNeu(oDoc)
	oA = Fm(oDoc, "PartnerAktiv")
	If oA.RowCount > 0 Then
		oA.first()
		PartnerAuf(oDoc, oA.getLong(oA.findColumn("ID")))
	End If
End Sub

REM Jeder Klick in eine der Listen (auch auf die schon aktuelle Zeile): nachgelagert abgleichen
Sub PartnerGridKlick(Optional oEvent)
	On Error Resume Next
	If MeldenLaeuft() Then Exit Sub
	Spaeter("PAK", oEvent.Source.Model.Parent.Name)
End Sub

Sub PartnerListeAbgleichen(oDoc As Object, sForm As String)
	Dim oL As Object
	On Error Resume Next
	oL = Fm(oDoc, sForm)
	If oL.RowCount = 0 Or oL.isBeforeFirst() Or oL.isAfterLast() Then Exit Sub
	PartnerAuf(oDoc, oL.getLong(oL.findColumn("ID")))
End Sub
