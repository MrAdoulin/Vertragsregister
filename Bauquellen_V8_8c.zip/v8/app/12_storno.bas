REM ============================================================ V8.4 · Storno-Zeile (M16, E21)
REM „Korrigieren“ (V8.5-Q6): geänderte Werte sichern, bisherigen Stand als stornierte Zeile festhalten.

Sub EintragKorrigieren(Optional oEvent)
	REM V8.5-Q6 (Nico 15.10. 15:06): Wert ändern, „Korrigieren“ klicken, bestätigen – fertig. Der Eintrag behält seine
	REM Nummer und bekommt die neuen Werte; der bisherige Stand wird als stornierte Zeile (✕) festgehalten.
	Dim oDoc As Object, oE As Object, nID As Long, oSt As Object, rs As Object, nAlt As Long, sBem As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oE = Fm(oDoc, "Ereignis")
	If oE.IsNew Then
		MsgBox "Ein neuer Eintrag wird mit „Sichern“ gespeichert. „Korrigieren“ gilt für gesicherte Einträge.", 64, "Korrigieren"
		Exit Sub
	End If
	nID = AktuelleID(oE)
	If nID = 0 Then Exit Sub
	rs = Verbindung().createStatement().executeQuery("SELECT ""Storniert"" FROM ""Ereignis"" WHERE ""ID"" = " & nID)
	If Not rs.next() Then Exit Sub
	If rs.getBoolean(1) Then
		MsgBox "Dieser Eintrag ist storniert und lässt sich nicht mehr korrigieren.", 64, "Korrigieren"
		Exit Sub
	End If
	REM V8.6c-K1: getippten Wert übernehmen, sonst ist IsModified ohne Feldwechsel False (Windows-Test 16.10.)
	FokusWeg(oDoc)
	If Not oE.IsModified Then
		MsgBox "Ändere zuerst die falschen Werte in diesem Eintrag (z. B. den Betrag)." & Chr(10) & _
			"Klick dann auf „Korrigieren“.", 64, "Korrigieren"
		Exit Sub
	End If
	If MsgBox("Eintrag " & nID & " mit den geänderten Werten korrigieren?" & Chr(10) & Chr(10) & _
		"Der bisherige Stand bleibt als stornierte Zeile (✕) erhalten und zählt nicht mehr.", 4 + 32, "Korrigieren") <> 6 Then Exit Sub
	BenutzerSetzen(oDoc)
	oSt = Verbindung().createStatement()
	REM 1. bisherigen Stand (noch unverändert in der Tabelle) als stornierte Zeile festhalten
	oSt.executeUpdate("INSERT INTO ""Ereignis"" (""LeistungID"", ""Datum"", ""Art"", ""Beschreibung"", ""GemeldetAm"", ""GemeldetUm"", " & _
		"""ReagiertAm"", ""ReagiertUm"", ""Rechnungsnr"", ""Betrag"", ""FreigabeDatum"", ""FreigabeBetrag"", ""FreigabeVon"", ""Bearbeiter"", ""Beleg"", ""Storniert"", ""Bemerkung"") " & _
		"SELECT ""LeistungID"", ""Datum"", ""Art"", ""Beschreibung"", ""GemeldetAm"", ""GemeldetUm"", ""ReagiertAm"", ""ReagiertUm"", " & _
		"""Rechnungsnr"", ""Betrag"", ""FreigabeDatum"", ""FreigabeBetrag"", ""FreigabeVon"", ""Bearbeiter"", ""Beleg"", TRUE, " & _
		"LEFT('✕ storniert: Stand vor der Korrektur von Eintrag ' || ""ID"" || IIF(""Bemerkung"" IS NULL, '', ' · ' || ""Bemerkung""), 1000) " & _
		"FROM ""Ereignis"" WHERE ""ID"" = " & nID)
	rs = oSt.executeQuery("SELECT MAX(""ID"") FROM ""Ereignis""")
	rs.next()
	nAlt = rs.getLong(1)
	REM 2. neue Werte sichern, mit Verweis auf den alten Stand
	sBem = oE.Columns.getByName("Bemerkung").getString()
	If InStr(sBem, "Korrigiert, alter Stand: Eintrag ") = 1 Then sBem = Mid(sBem, InStr(sBem, " · ") + 3)
	sBem = "Korrigiert, alter Stand: Eintrag " & nAlt & IIf(Trim(sBem) = "", "", " · " & sBem)
	oE.Columns.getByName("Bemerkung").updateString(Left(sBem, 1000))
	On Error GoTo Abgelehnt
	oE.updateRow()
	On Error GoTo Fehler
	ProtokollNeuLaden(oDoc, nID)
	Spaeter("PRZ", nID)  ' V8.6b: nach den übrigen Ereignissen erneut auf den korrigierten Eintrag stellen (Windows-Test 16.10.)
	StatusSetzen(oDoc, "Eintrag " & nID & " korrigiert; alter Stand als Eintrag " & nAlt & " storniert")
	Exit Sub
Abgelehnt:
	REM Prüfung lehnte die neuen Werte ab (Meldung kam schon): alten Stand wieder entfernen, Eingaben bleiben stehen
	On Error Resume Next
	Verbindung().createStatement().executeUpdate("DELETE FROM ""Ereignis"" WHERE ""ID"" = " & nAlt & " AND ""Storniert""")
	Exit Sub
Fehler:
	Fehlermeldung("Korrigieren", Error$)
End Sub

Sub StornoSchalter(Optional oEvent)
	Dim oF As Object, s As String
	On Error Resume Next
	oF = Fm(AppDoc(), "Protokoll")
	s = AppDoc().CurrentController.getControl(oF.getByName("PR_txtSuche")).Text
	ListeFiltern(oF, "PR", s)
	Spaeter("PRG")  ' V8.5-Q4: Raster unter Windows neu zeichnen (Meldung 14:58: Fläche blieb verdeckt)
End Sub

REM V8.5-Q4: Nach dem Filtern schrumpft die Liste; Windows ließ alte Zeilen als Fläche stehen. Aus- und Einblenden zeichnet neu.
Sub RasterNeuZeichnen(oDoc As Object, sForm As String, sGrid As String)
	Dim c As Object
	On Error Resume Next
	c = oDoc.CurrentController.getControl(Fm(oDoc, sForm).getByName(sGrid))
	c.setVisible(False)
	c.setVisible(True)
End Sub

REM V8.8c (M10, Nico 16.10.): „Stornieren“ – wirkt rückwirkend auf einen Eintrag wie Korrigieren, aber ohne Nachfolgeeintrag.
REM Das Kästchen „Storniert“ ist nur noch über diesen Knopf setzbar.
Sub EintragStornieren(Optional oEvent)
	Dim oDoc As Object, oE As Object, nID As Long, rs As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oE = Fm(oDoc, "Ereignis")
	FokusWeg(oDoc)
	If oE.IsNew Then
		MsgBox "Ein neuer Eintrag ist noch nicht gesichert. Der rote Knopf „Verwerfen“ verwirft ihn.", 64, "Stornieren"
		Exit Sub
	End If
	nID = AktuelleID(oE)
	If nID = 0 Then
		MsgBox "Wähle zuerst links den Eintrag, der storniert werden soll.", 64, "Stornieren"
		Exit Sub
	End If
	rs = Verbindung().createStatement().executeQuery("SELECT ""Storniert"" FROM ""Ereignis"" WHERE ""ID"" = " & nID)
	If Not rs.next() Then Exit Sub
	If rs.getBoolean(1) Then
		MsgBox "Eintrag " & nID & " ist schon storniert.", 64, "Stornieren"
		Exit Sub
	End If
	If oE.IsModified Then
		MsgBox "Dieser Eintrag hat ungesicherte Änderungen." & Chr(10) & "Erst „Sichern“ oder „Verwerfen“, dann stornieren.", 48, "Stornieren"
		Exit Sub
	End If
	If MsgBox("Eintrag " & nID & " stornieren?" & Chr(10) & Chr(10) & _
		"Er bleibt als stornierte Zeile (✕) im Verlauf, zählt aber nicht mehr zur Kostengrenze und ist nicht mehr offen." & Chr(10) & _
		"Das lässt sich nicht rückgängig machen.", 4 + 32 + 256, "Stornieren") <> 6 Then Exit Sub
	BenutzerSetzen(oDoc)
	Verbindung().createStatement().executeUpdate("UPDATE ""Ereignis"" SET ""Storniert"" = TRUE, ""Bemerkung"" = " & _
		"LEFT('✕ storniert am " & Format(Date(), "DD.MM.YY") & "' || IIF(""Bemerkung"" IS NULL, '', ' · ' || ""Bemerkung""), 1000) WHERE ""ID"" = " & nID)
	Gespeichert()
	oE.reload()
	Fm(oDoc, "EreignisInfo").reload()
	ProtokollNeuLaden(oDoc, nID)
	Spaeter("PRZ", nID)
	StatusSetzen(oDoc, "Eintrag " & nID & " storniert")
	Exit Sub
Fehler:
	Fehlermeldung("Stornieren", Error$)
End Sub
