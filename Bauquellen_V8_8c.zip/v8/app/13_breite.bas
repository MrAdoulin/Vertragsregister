REM ============================================================ V8.4 · Seite füllt das Fenster (M02, E17)
REM Die Seite (32000 × 18000) bekommt das Seitenverhältnis des Fensters. Alle Elemente und Spaltenbreiten werden
REM waagrecht mitgestreckt (gemessen an der gebauten Lage), die Schrift bleibt gleich.
REM V8.6e (Nico 16.10.: „Außenkanten wirklich nach außen“): auch senkrecht (Fenster höher als 16:9) und ohne 5-%-Schwelle;
REM der Zoom „Seitenbreite exakt“ (ZoomAnpassen) legt die Seite dann randlos ins Fenster. „Ganze Seite“ ließ grauen Rand.

Global aBreiteX() As Long
Global aBreiteW() As Long
Global aBreiteY() As Long
Global aBreiteH() As Long
Global aUnten() As Integer
Global bHwLage As Boolean
Global aSpalteW() As Long
Global nBreiteN As Long
Global dBreiteF As Double
Global dHoeheF As Double
Global sBreiteDoc As String

Private Const SEITE_B = 32000
Private Const SEITE_H = 18000
REM V8.6e: Elemente ab dieser Höhe (Raster, mehrzeilige Felder) wachsen senkrecht mit, kleinere behalten ihre Höhe
Private Const HOCH_AB = 1500
REM V8.7: so viel tiefer reichen Karten und Raster bei abgeschalteter Hinweiszeile (formkit.UNTEN_PLUS)
Private Const HW_PLUS = 300

Sub BreiteMerken(oDoc As Object)
	Dim oDP As Object, i As Long, n As Long, oS As Object, m As Object, j As Integer, k As Long
	Dim dF As Double, dH As Double, bVoll As Boolean, oSt As Object
	REM V8.8c (Windows 16.10.: Elemente nach rechts verschoben, Versatz ≈ dF²): Waren die Elemente beim Merken schon
	REM gestreckt (zweites Register, Wiederherstellung nach Absturz), wurde doppelt gestreckt. Deshalb die Baulage aus
	REM der aktuellen Seitengröße zurückrechnen (Seite und Elemente werden immer gemeinsam gestreckt).
	oDP = oDoc.DrawPage
	n = oDP.Count
	oSt = oDoc.StyleFamilies.getByName("PageStyles").getByName("Standard")
	dF = oSt.Width / SEITE_B
	dH = oSt.Height / SEITE_H
	If dF < 0.5 Or dF > 3 Then dF = 1
	If dH < 0.5 Or dH > 3 Then dH = 1
	bVoll = (Right(oDoc.Text.getStart().PageDescName, 5) = "_voll")
	ReDim aBreiteX(n - 1) As Long
	ReDim aBreiteW(n - 1) As Long
	ReDim aBreiteY(n - 1) As Long
	ReDim aBreiteH(n - 1) As Long
	ReDim aUnten(n - 1) As Integer
	ReDim aSpalteW(n * 10) As Long
	k = 0
	For i = 0 To n - 1
		oS = oDP.getByIndex(i)
		aUnten(i) = UntenArt(oS)  ' V8.7
		aBreiteX(i) = CLng(oS.Position.X / dF)
		aBreiteW(i) = CLng(oS.Size.Width / dF)
		aBreiteY(i) = oS.Position.Y
		If bVoll And aUnten(i) = 2 Then aBreiteY(i) = aBreiteY(i) - CLng(HW_PLUS * dH)
		aBreiteY(i) = CLng(aBreiteY(i) / dH)
		aBreiteH(i) = oS.Size.Height
		If bVoll And aUnten(i) = 1 Then aBreiteH(i) = aBreiteH(i) - CLng(HW_PLUS * dH)
		If aBreiteH(i) / dH >= HOCH_AB Then aBreiteH(i) = CLng(aBreiteH(i) / dH)
		m = RasterSpalten(oS)
		If Not IsNull(m) Then
			For j = 0 To m.Count - 1
				aSpalteW(k) = m.getByIndex(j).Width
				k = k + 1
			Next j
		End If
	Next i
	nBreiteN = n
	dBreiteF = dF
	dHoeheF = dH
	bHwLage = bVoll
	sBreiteDoc = oDoc.RuntimeUID
End Sub

Function RasterSpalten(oS As Object) As Object
	RasterSpalten = Nothing
	On Error GoTo Ende
	If oS.Control.supportsService("com.sun.star.form.component.GridControl") Then RasterSpalten = oS.Control
Ende:
End Function

REM V8.7: 1 = wächst, 2 = wandert bei abgeschalteter Hinweiszeile (Liste UNTEN aus dem Bau), sonst 0
Function UntenArt(oS As Object) As Integer
	Dim sNm As String
	On Error Resume Next
	UntenArt = 0
	sNm = oS.Control.Name
	If sNm = "" Then Exit Function
	If InStr(UNTEN, ",W:" & sNm & ",") > 0 Then UntenArt = 1
	If InStr(UNTEN, ",V:" & sNm & ",") > 0 Then UntenArt = 2
End Function

REM V8.7: Lage und Höhe mit Faktor dH und abgeschalteter Hinweiszeile
Function LageY(i As Long, dH As Double) As Long
	LageY = CLng(aBreiteY(i) * dH)
	If bHwVoll And aUnten(i) = 2 Then LageY = LageY + CLng(HW_PLUS * dH)
End Function

Function LageH(i As Long, dH As Double) As Long
	LageH = HoeheBei(i, dH)
	If bHwVoll And aUnten(i) = 1 Then LageH = LageH + CLng(HW_PLUS * dH)
End Function

REM V8.6e: Höhe eines Elements bei Faktor dH
Function HoeheBei(i As Long, dH As Double) As Long
	If aBreiteH(i) >= HOCH_AB Then HoeheBei = CLng(aBreiteH(i) * dH) Else HoeheBei = aBreiteH(i)
End Function

Sub BreiteAnpassen(oDoc As Object)
	Dim r As Object, dF As Double, dH As Double, nW As Long, nH As Long, oDP As Object, i As Long, oS As Object
	Dim p As Object, sz As Object, g As Object, j As Integer, oSt As Object, a, k As Long, q As Integer
	Dim nSum As Long, dCol As Double
	On Error GoTo Ende
	r = oDoc.CurrentController.Frame.ComponentWindow.getPosSize()
	If r.Height < 200 Or r.Width < 300 Then Exit Sub
	REM Breiter als 16:9 → Seite breiter; höher → Seite höher. Die andere Richtung bleibt wie gebaut.
	If r.Width * SEITE_H >= r.Height * SEITE_B Then
		nH = SEITE_H
		nW = CLng(SEITE_H * r.Width / r.Height)
	Else
		nW = SEITE_B
		nH = CLng(SEITE_B * r.Height / r.Width)
	End If
	If nW > 56000 Then nW = 56000
	If nH > 40000 Then nH = 40000
	dF = nW / SEITE_B
	dH = nH / SEITE_H
	If nBreiteN = 0 Or sBreiteDoc <> oDoc.RuntimeUID Then BreiteMerken(oDoc)  ' V8.8c
	If Abs(dF - dBreiteF) < 0.0005 And Abs(dH - dHoeheF) < 0.0005 And bHwLage = bHwVoll Then Exit Sub
	oDP = oDoc.DrawPage
	If oDP.Count <> nBreiteN Then Exit Sub
	oDoc.lockControllers()
	k = 0
	For i = 0 To nBreiteN - 1
		oS = oDP.getByIndex(i)
		p = oS.Position : p.X = CLng(aBreiteX(i) * dF) : p.Y = LageY(i, dH) : oS.Position = p
		sz = oS.Size : sz.Width = CLng(aBreiteW(i) * dF) : sz.Height = LageH(i, dH) : oS.Size = sz
		g = RasterSpalten(oS)
		If Not IsNull(g) Then
			REM V8.8 (GER-01): Spalten füllen genau die Rasterbreite (abzüglich Zeilenkopf und Rollbalken ~900) –
			REM vorher wuchsen sie nur mit dF, die letzte Spalte lag oft hinter einem waagrechten Rollbalken.
			REM Spaltenbreite in 1/10 mm, Form in 1/100 mm.
			nSum = 0
			For j = 0 To g.Count - 1
				nSum = nSum + aSpalteW(k + j)
			Next j
			dCol = dF
			If nSum > 0 Then dCol = (CLng(aBreiteW(i) * dF) - 900) / (nSum * 10#)
			For j = 0 To g.Count - 1
				g.getByIndex(j).Width = CLng(aSpalteW(k) * dCol)
				k = k + 1
			Next j
		End If
	Next i
	REM Seitenvorlagen aus dem Bau: Standard und B_<Bereich>[_voll] (Kartenbild wird gestreckt)
	a = oDoc.StyleFamilies.getByName("PageStyles").getElementNames()
	For q = 0 To UBound(a)
		If a(q) = "Standard" Or Left(a(q), 2) = "B_" Then
			oSt = oDoc.StyleFamilies.getByName("PageStyles").getByName(a(q))
			oSt.Width = nW
			oSt.Height = nH
		End If
	Next q
	oDoc.unlockControllers()
	dBreiteF = dF
	dHoeheF = dH
	bHwLage = bHwVoll
	oDoc.setModified(False)
	Exit Sub
Ende:
	On Error Resume Next
	oDoc.unlockControllers()
End Sub

REM V8.6: LibreOffice verschiebt beim Laden einzelne Elemente am rechten Rand (gemessen 16.10.: „H“ der Entscheidung,
REM Löschen-Knöpfe in Partner/Vertretung). Gemerkte Lage wiederherstellen, wo sie abweicht.
Sub LageHerstellen(oDoc As Object)
	Dim oDP As Object, i As Long, oS As Object, p As Object, sz As Object, nX As Long, nW As Long, n As Long
	Dim nY As Long, nH As Long
	On Error Resume Next
	If nBreiteN = 0 Or sBreiteDoc <> oDoc.RuntimeUID Then BreiteMerken(oDoc)  ' V8.8c
	oDP = oDoc.DrawPage
	If oDP.Count <> nBreiteN Then Exit Sub
	For i = 0 To nBreiteN - 1
		oS = oDP.getByIndex(i)
		nX = CLng(aBreiteX(i) * dBreiteF)
		nW = CLng(aBreiteW(i) * dBreiteF)
		nY = LageY(i, dHoeheF)
		nH = LageH(i, dHoeheF)
		If Abs(oS.Position.X - nX) > 5 Or Abs(oS.Size.Width - nW) > 5 Or Abs(oS.Position.Y - nY) > 5 Or Abs(oS.Size.Height - nH) > 5 Then
			p = oS.Position : p.X = nX : p.Y = nY : oS.Position = p
			sz = oS.Size : sz.Width = nW : sz.Height = nH : oS.Size = sz
			n = n + 1
		End If
	Next i
	If n > 0 Then oDoc.setModified(False)
End Sub
