REM ============================================================ V8.4 · Kontaktdaten mit „(Stand: Datum)“ (P03)
REM Datum = letzte Änderung des Feldes laut Änderungsspur, sonst Anlage des Partners. Unbekannt: kein Zusatz.

Sub PartnerStandSpaeter(Optional oEvent)
	On Error Resume Next
	Spaeter("P")
End Sub

Sub PartnerStand(oDoc As Object)
	Dim oF As Object, nID As Long, a, i As Integer, oL As Object, rs As Object, sD As String, sFeld As String, b, t
	On Error Resume Next
	oF = Fm(oDoc, "Partner")
	nID = AktuelleID(oF)
	a = Array("txtAnsprech|Ansprechperson", "txtTelefon|Telefon", "txtEmail|E-Mail", "txtHotline|Hotline", "txtKundennr|Kundennummer")
	For i = 0 To UBound(a)
		b = Split(a(i), "|")
		oL = oF.getByName("PA_" & b(0) & "L")
		If oL.Tag = "" Then oL.Tag = oL.Label
		sD = ""
		If nID > 0 Then
			sFeld = b(1)
			rs = oF.ActiveConnection.createStatement().executeQuery("SELECT MAX(""Zeit"") FROM ""Aenderung"" WHERE ""Tabelle"" = 'Partner' " & _
				"AND ""DatensatzID"" = " & nID & " AND (""Feld"" = '" & sFeld & "' OR ""Aktion"" IN ('neu', 'zurück', 'zurückS'))")
			rs.next()
			t = rs.getTimestamp(1)
			If Not rs.wasNull() Then sD = Format(t.Day, "00") & "." & Format(t.Month, "00") & "." & t.Year
		End If
		oL.Label = oL.Tag & IIf(sD = "", "", "  (Stand: " & sD & ")")
	Next i
End Sub
