REM ============================================================ V8.4 · Datumsanzeige einstellbar (M10, E18)
REM Einstellung.DatumFormat = LibreOffice-DateFormat: 2 = TT.MM.JJJJ (System kurz, vierstellig), 1 = TT.MM.JJ, 11 = JJJJ-MM-TT.

Sub DatumFormatSetzen(oDoc As Object)
	Dim rs As Object, n As Integer
	On Error Resume Next
	n = 1  ' V8.8c (M14): kurz als Vorgabe
	rs = Verbindung().createStatement().executeQuery("SELECT ""DatumFormat"" FROM ""Einstellung"" WHERE ""ID"" = 1")
	If rs.next() Then n = rs.getShort(1)
	If n <> 1 And n <> 2 And n <> 11 Then n = 1
	DatumFormatIn(oDoc.DrawPage.Forms, n)
	oDoc.setModified(False)
End Sub

Sub DatumFormatIn(oCont As Object, n As Integer)
	Dim i As Integer, m As Object, j As Integer, c As Object
	REM Rasterspalten kennen supportsService nicht („illegal object given“); daher ColumnServiceName
	On Error Resume Next
	For i = 0 To oCont.Count - 1
		m = oCont.getByIndex(i)
		If m.supportsService("com.sun.star.form.component.Form") Then
			DatumFormatIn(m, n)
		ElseIf m.supportsService("com.sun.star.form.component.DateField") Then
			If m.DateFormat <> n Then m.DateFormat = n
		ElseIf m.supportsService("com.sun.star.form.component.GridControl") Then
			For j = 0 To m.Count - 1
				c = m.getByIndex(j)
				If c.ColumnServiceName = "DateField" Then
					If c.DateFormat <> n Then c.DateFormat = n
				End If
			Next j
		End If
	Next i
End Sub
