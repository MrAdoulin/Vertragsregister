REM ============================================================ V8.5 · Auswahllisten mit Knopfleiste (M11, M12, E22)
REM „+ Neu“, „Entfernen“, „▲“, „▼“ wirken auf die markierte Zeile. Die Reihenfolge steht in „Sort“ (Spalte nicht mehr sichtbar).

Private Const GESCHUETZT = ",Status,Zahlungsintervall,Ereignis,Abdeckung,Entscheidung,"

Function ListeAktuell(oF As Object, sTyp As String, sWert As String) As Boolean
	ListeAktuell = False
	On Error Resume Next
	If oF.IsNew Or oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then Exit Function
	sTyp = oF.getString(oF.findColumn("Typ"))
	sWert = oF.getString(oF.findColumn("Wert"))
	ListeAktuell = (sTyp <> "")
End Function

Sub ListeZeigen(oF As Object, sTyp As String, sWert As String)
	On Error Resume Next
	oF.reload()
	oF.beforeFirst()
	Do While oF.next()
		If oF.getString(oF.findColumn("Typ")) = sTyp And oF.getString(oF.findColumn("Wert")) = sWert Then Exit Do
	Loop
	If oF.isAfterLast() Then oF.first()
End Sub

Sub ListeNeu(Optional oEvent)
	Dim oDoc As Object, oF As Object, sTyp As String, sWert As String, s As String, rs As Object, st As Object
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Listen")
	If Not Speichern(oDoc, oF) Then Exit Sub
	If Not ListeAktuell(oF, sTyp, sWert) Then
		MsgBox "Markiere zuerst eine Zeile der Liste, die einen neuen Wert bekommen soll.", 64, "Auswahllisten"
		Exit Sub
	End If
	s = Trim(InputBox("Neuer Wert für die Liste „" & sTyp & "“:", "Auswahllisten"))
	If s = "" Then Exit Sub
	If Len(s) > 40 Then
		MsgBox "Ein Wert hat höchstens 40 Zeichen.", 48, "Auswahllisten"
		Exit Sub
	End If
	st = Verbindung().createStatement()
	rs = st.executeQuery("SELECT COUNT(*), COALESCE(MAX(""Sort""), 0) FROM ""Liste"" WHERE ""Typ"" = '" & Esc(sTyp) & "' AND ""Wert"" = '" & Esc(s) & "'")
	rs.next()
	If rs.getLong(1) > 0 Then
		MsgBox "Diesen Wert gibt es in der Liste schon.", 48, "Auswahllisten"
		Exit Sub
	End If
	rs = st.executeQuery("SELECT COALESCE(MAX(""Sort""), 0) FROM ""Liste"" WHERE ""Typ"" = '" & Esc(sTyp) & "'")
	rs.next()
	st.executeUpdate("INSERT INTO ""Liste"" (""Typ"", ""Wert"", ""Sort"") VALUES ('" & Esc(sTyp) & "', '" & Esc(s) & "', " & (rs.getLong(1) + 1) & ")")
	Gespeichert()
	ListeZeigen(oF, sTyp, s)
	ListenAuswahlNeu(oDoc)
	StatusSetzen(oDoc, "„" & s & "“ in „" & sTyp & "“ aufgenommen")
	Exit Sub
Fehler:
	Fehlermeldung("Neuer Listenwert", Error$)
End Sub

Sub ListeEntfernen(Optional oEvent)
	Dim oDoc As Object, oF As Object, sTyp As String, sWert As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Listen")
	If oF.IsNew Or oF.IsModified Then
		Verwerfen(oDoc, oF)
		Exit Sub
	End If
	If Not ListeAktuell(oF, sTyp, sWert) Then Exit Sub
	If InStr(GESCHUETZT, "," & sTyp & ",") > 0 Then
		MsgBox "Werte der Liste „" & sTyp & "“ steuern Berechnungen. Sie lassen sich hier nicht entfernen.", 48, "Auswahllisten"
		Exit Sub
	End If
	If MsgBox("„" & sWert & "“ aus der Liste „" & sTyp & "“ entfernen?" & Chr(10) & Chr(10) & _
		"Einträge, die den Wert schon tragen, behalten ihn.", 4 + 32, "Auswahllisten") <> 6 Then Exit Sub
	Verbindung().createStatement().executeUpdate("DELETE FROM ""Liste"" WHERE ""Typ"" = '" & Esc(sTyp) & "' AND ""Wert"" = '" & Esc(sWert) & "'")
	Gespeichert()
	ListeZeigen(oF, sTyp, "")
	ListenAuswahlNeu(oDoc)
	StatusSetzen(oDoc, "„" & sWert & "“ entfernt")
	Exit Sub
Fehler:
	Fehlermeldung("Listenwert entfernen", Error$)
End Sub

Sub ListeHoch(Optional oEvent)
	ListeSchieben(-1)
End Sub

Sub ListeRunter(Optional oEvent)
	ListeSchieben(1)
End Sub

REM Reihenfolge der Liste neu durchnummerieren und den markierten Wert mit dem Nachbarn tauschen
Sub ListeSchieben(nRichtung As Integer)
	Dim oDoc As Object, oF As Object, sTyp As String, sWert As String, rs As Object, st As Object
	Dim a() As String, n As Long, i As Long, k As Long, t As String
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Listen")
	If Not Speichern(oDoc, oF) Then Exit Sub
	If Not ListeAktuell(oF, sTyp, sWert) Then Exit Sub
	st = Verbindung().createStatement()
	rs = st.executeQuery("SELECT ""Wert"" FROM ""Liste"" WHERE ""Typ"" = '" & Esc(sTyp) & "' ORDER BY ""Sort"", ""Wert""")
	n = 0
	ReDim a(200) As String
	k = -1
	Do While rs.next()
		If n > 200 Then Exit Do
		a(n) = rs.getString(1)
		If a(n) = sWert Then k = n
		n = n + 1
	Loop
	If k < 0 Then Exit Sub
	If k + nRichtung < 0 Or k + nRichtung > n - 1 Then Exit Sub
	t = a(k) : a(k) = a(k + nRichtung) : a(k + nRichtung) = t
	For i = 0 To n - 1
		st.executeUpdate("UPDATE ""Liste"" SET ""Sort"" = " & (i + 1) & " WHERE ""Typ"" = '" & Esc(sTyp) & "' AND ""Wert"" = '" & Esc(a(i)) & "'")
	Next i
	Gespeichert()
	ListeZeigen(oF, sTyp, sWert)
	ListenAuswahlNeu(oDoc)
	Exit Sub
Fehler:
	Fehlermeldung("Reihenfolge ändern", Error$)
End Sub

REM Auswahllisten in den Formularen lesen die Liste beim Laden; nach einer Änderung neu lesen
Sub ListenAuswahlNeu(oDoc As Object)
	Dim a, i As Integer
	On Error Resume Next
	a = Split(EDITIERBAR, ",")
	For i = 0 To UBound(a)
		ListenIn(Fm(oDoc, a(i)))
	Next i
End Sub

Sub ListenIn(oF As Object)
	Dim j As Integer, m As Object
	On Error Resume Next
	For j = 0 To oF.Count - 1
		m = oF.getByIndex(j)
		If m.supportsService("com.sun.star.form.component.ListBox") Then
			If InStr(m.ListSource(0), """Liste""") > 0 Then m.refresh()
		End If
	Next j
End Sub
