REM ============================================================ V8.5 · Gesamtsuche (M09, M13, M23, E23, E24)
REM Suchfeld in der Seitenleiste. Enter füllt „Treffer“ und zeigt die Ansicht GS: Liste (Herkunft | Titel | Ausschnitt)
REM und Vorschau des markierten Treffers mit fettem Trefferwort. Doppelklick oder „Öffnen ›“ springt zur Fundstelle.

Private sSuchWort As String
REM V8.8c (M5): Fundstelle der letzten Fundstelle-Suche: Länge im Originaltext
Private nFundLen As Long
Private aSuchIdx() As Long

REM Enter im Suchfeld (Seitenleiste oder Ansicht GS)
Sub SucheTaste(oEv As Object)
	If oEv.KeyCode <> com.sun.star.awt.Key.RETURN Then Exit Sub
	Spaeter("GS", oEv.Source.Text)
End Sub

Sub SucheKnopf(Optional oEvent)
	Dim oDoc As Object
	On Error Resume Next
	oDoc = AppDoc()
	Spaeter("GS", oDoc.CurrentController.getControl(Fm(oDoc, "Nav").getByName("NA_txtGesamt")).Text)
End Sub

Sub GesamtSuchen(oDoc As Object, sWort As String)
	Dim st As Object, ps As Object, n As Long
	On Error GoTo Fehler
	sWort = Trim(sWort)
	If Len(sWort) < 2 Then
		MsgBox "Gib mindestens zwei Zeichen ein.", 64, "Alles durchsuchen"
		Exit Sub
	End If
	If Not Bereich(oDoc, "GS") Then Exit Sub
	sSuchWort = sWort
	Fm(oDoc, "Treffer").getByName("GS_txtSuche").Text = sWort
	oDoc.CurrentController.getControl(Fm(oDoc, "Nav").getByName("NA_txtGesamt")).Text = sWort
	st = Verbindung().createStatement()
	st.executeUpdate("DELETE FROM ""Treffer""")
	ps = Verbindung().prepareStatement("INSERT INTO ""Treffer"" (""Rang"", ""Herkunft"", ""Titel"", ""Ausschnitt"", ""Feld"", ""Ziel"", ""ZielID"", ""ZielID2"", ""Pos"", ""Wort"") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)")
	n = 0
	n = n + QuelleSuchen(ps, sWort, 1, "Vertrag", "VE1", "SELECT v.""ID"", 0, COALESCE(v.""Nr"", 'unbenannt ' || v.""ID"") || ' – ' || v.""Gegenstand"", " & _
		"v.""Gegenstand"", p.""Name"", v.""Nr"", v.""Art"", v.""PartnerVertragsnr"", v.""Kostenstelle"", v.""Ordner"", v.""IndexBasis"", v.""Angestellte"", v.""Dienstort"", v.""Bemerkung"" " & _
		"FROM ""Vertrag"" v JOIN ""Partner"" p ON p.""ID"" = v.""PartnerID""", _
		Array("Gegenstand", "Partner", "Vertragsnummer", "Vertragsart", "Vertragsnr. beim Partner", "Kostenstelle", "Ordner", "Index und Basis", "Angestellte/r", "Dienstort", "Bemerkung"))
	n = n + QuelleSuchen(ps, sWort, 2, "Entscheidung", "VE1", "SELECT e.""VertragID"", e.""ID"", COALESCE(v.""Nr"", 'unbenannt ' || v.""ID"") || ' – ' || v.""Gegenstand"" || ': ' || e.""Art"", " & _
		"e.""Art"", e.""Verantwortlich"", e.""Versandart"", e.""Beleg"", e.""Bemerkung"" FROM ""Entscheidung"" e JOIN ""Vertrag"" v ON v.""ID"" = e.""VertragID""", _
		Array("Entscheidung", "Verantwortlich", "Versandart", "Beleg", "Bemerkung"))
	n = n + QuelleSuchen(ps, sWort, 3, "Leistung", "VE2", "SELECT l.""VertragID"", l.""ID"", l.""Nr"" || ' – ' || l.""Bezeichnung"" || COALESCE(' – ' || l.""Objekt"", ''), " & _
		"l.""Bezeichnung"", l.""Objekt"", l.""Umfang"", l.""Quelle"", l.""Bemerkung"", l.""Anzeige"" FROM ""V_Leistung"" l", _
		Array("Leistung", "Objekt", "Umfang", "Quelle", "Bemerkung", "Stand"))
	n = n + QuelleSuchen(ps, sWort, 4, "Protokoll", "PR", "SELECT e.""ID"", e.""LeistungID"", e.""DatumText"" || ' ' || e.""Art"" || ' – ' || e.""Nr"" || ' ' || e.""Leistung"", " & _
		"e.""Beschreibung"", e.""Rechnungsnr"", e.""FreigabeVon"", e.""Beleg"", e.""Bemerkung"", e.""Stand"", e.""Bearbeiter"" FROM ""V_Ereignis"" e", _
		Array("Beschreibung", "Rechnungsnr.", "Freigegeben von", "Beleg", "Bemerkung", "Stand", "Bearbeiter"))
	n = n + QuelleSuchen(ps, sWort, 5, "Partner", "PA", "SELECT ""ID"", 0, ""Name"", ""Name"", ""Ansprechperson"", ""Telefon"", ""Email"", ""Hotline"", ""Kundennr"", ""Bemerkung"" FROM ""Partner""", _
		Array("Name", "Ansprechperson", "Telefon", "E-Mail", "Hotline", "Kundennummer", "Bemerkung"))
	n = n + QuelleSuchen(ps, sWort, 6, "Dokument", "VE3", "SELECT d.""VertragID"", d.""ID"", COALESCE(v.""Nr"", 'unbenannt ' || v.""ID"") || ' – ' || v.""Gegenstand"", " & _
		"d.""Bezeichnung"", d.""Datei"" FROM ""Dokument"" d JOIN ""Vertrag"" v ON v.""ID"" = d.""VertragID""", _
		Array("Bezeichnung", "Datei"))
	n = n + HilfeSuchen(oDoc, ps, sWort)
	Gespeichert()
	Fm(oDoc, "Treffer").reload()
	Fm(oDoc, "Treffer").getByName("GS_lblAnzahl").Label = IIf(n = 0, "Keine Treffer für „" & sWort & "“.", n & IIf(n = 1, " Treffer", " Treffer") & " für „" & sWort & "“")
	If n = 0 Then TrefferVorschauLeer(oDoc)
	StatusSetzen(oDoc, n & " Treffer")
	Exit Sub
Fehler:
	Fehlermeldung("Suche", Error$)
End Sub

REM Durchsucht die Spalten 4… einer Abfrage (1 = ZielID, 2 = ZielID2, 3 = Titel). Je Datensatz und Feld ein Treffer.
Function QuelleSuchen(ps As Object, sWort As String, nRang As Integer, sHerkunft As String, sZiel As String, sSql As String, aFeld) As Long
	Dim rs As Object, i As Integer, s As String, k As Long, n As Long
	n = 0
	rs = Verbindung().createStatement().executeQuery(sSql)
	Do While rs.next()
		For i = 0 To UBound(aFeld)
			s = rs.getString(i + 4)
			k = Fundstelle(s, sWort)
			If k > 0 Then
				TrefferSchreiben(ps, nRang, sHerkunft, rs.getString(3), aFeld(i), sZiel, rs.getLong(1), rs.getLong(2), s, k, Mid(s, k, nFundLen))
				n = n + 1
			End If
		Next i
	Loop
	QuelleSuchen = n
End Function

REM Hilfe: jede Zeile der Anleitung mit dem Wort; Titel = Abschnitt, Pos = Stelle im ganzen Text (für den Sprung)
Function HilfeSuchen(oDoc As Object, ps As Object, sWort As String) As Long
	Dim sT As String, a, i As Long, nOff As Long, sAbschnitt As String, k As Long, n As Long, z As String
	n = 0
	sT = Fm(oDoc, "Nav").getByName("HI_txtAnleitung").Text
	If sT = "" Then sT = Fm(oDoc, "Nav").getByName("HI_txtAnleitung").DefaultText
	a = Split(sT, Chr(10))
	nOff = 0
	sAbschnitt = "Anleitung"
	For i = 0 To UBound(a)
		z = a(i)
		If Len(z) > 3 And IsNumeric(Left(z, 1)) And InStr(z, "  ") > 0 And InStr(z, "  ") < 4 Then sAbschnitt = Trim(Mid(z, InStr(z, "  ") + 2))
		k = Fundstelle(z, sWort)
		If k > 0 Then
			TrefferSchreiben(ps, 7, "Hilfe", "Hilfe › " & sAbschnitt, "", "HI", 0, nOff + k - 1, z, k, Mid(z, k, nFundLen))
			n = n + 1
		End If
		nOff = nOff + Len(z) + 1
	Next i
	HilfeSuchen = n
End Function

Sub TrefferSchreiben(ps As Object, nRang As Integer, sHerkunft As String, sTitel As String, sFeld As String, sZiel As String, _
		nID As Long, nID2 As Long, sText As String, k As Long, sWort As String)
	Dim sA As String, nVon As Long, nPos As Long, sVor As String, sNach As String
	sText = Replace(Replace(Replace(sText, Chr(13), " "), Chr(10), " "), Chr(9), " ")
	nVon = k - 70
	If nVon < 1 Then nVon = 1
	sVor = IIf(nVon > 1, "… ", "")
	sA = sVor & Mid(sText, nVon, 160 + Len(sWort))
	If nVon + 160 + Len(sWort) < Len(sText) Then sA = sA & " …"
	nPos = Len(sVor) + k - nVon + 1
	ps.setShort(1, nRang)
	ps.setString(2, sHerkunft)
	ps.setString(3, Left(sTitel, 200))
	ps.setString(4, Left(sA, 400))
	ps.setString(5, Left(sFeld, 40))
	ps.setString(6, sZiel)
	ps.setInt(7, nID)
	ps.setInt(8, nID2)
	ps.setInt(9, nPos)
	ps.setString(10, Left(Mid(sText, k, Len(sWort)), 100))
	ps.executeUpdate()
End Sub

REM Vorschau: Herkunft, Titel, Feld, dann „Ausschnitt“ mit fettem Trefferwort
Sub TrefferVorschau(Optional oEvent)
	Dim oDoc As Object, oF As Object
	On Error Resume Next
	oDoc = AppDoc()
	oF = Fm(oDoc, "Treffer")
	If oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then
		TrefferVorschauLeer(oDoc)
		Exit Sub
	End If
	VorschauSetzen(oDoc, oF.getString(oF.findColumn("Herkunft")) & IIf(oF.getString(oF.findColumn("Feld")) <> "", " · " & oF.getString(oF.findColumn("Feld")), ""), _
		oF.getString(oF.findColumn("Titel")), oF.getString(oF.findColumn("Ausschnitt")), oF.getLong(oF.findColumn("Pos")), Len(oF.getString(oF.findColumn("Wort"))))
End Sub

Sub TrefferVorschauLeer(oDoc As Object)
	VorschauSetzen(oDoc, "", "", "", 0, 0)
End Sub

REM Fundstelle öffnen (Doppelklick in der Liste oder Knopf „Öffnen ›“)
Sub TrefferDoppelklick(Optional oEvent)
	On Error Resume Next
	If oEvent.ClickCount < 2 Then Exit Sub
	TrefferOeffnen()
End Sub

Sub TrefferOeffnen(Optional oEvent)
	Dim oDoc As Object, oF As Object, sZiel As String, nID As Long, nID2 As Long, c As Object, oSel As New com.sun.star.awt.Selection
	On Error GoTo Fehler
	oDoc = AppDoc()
	oF = Fm(oDoc, "Treffer")
	If oF.RowCount = 0 Or oF.isBeforeFirst() Or oF.isAfterLast() Then Exit Sub
	sZiel = oF.getString(oF.findColumn("Ziel"))
	nID = oF.getLong(oF.findColumn("ZielID"))
	nID2 = oF.getLong(oF.findColumn("ZielID2"))
	Select Case sZiel
		Case "VE1", "VE3"
			VertragOeffnen(oDoc, nID, "GS", "", sZiel)
		Case "VE2"
			If VertragOeffnen(oDoc, nID, "GS", "", "VE2") Then LeistungAuswaehlen(oDoc, nID2)
		Case "PR"
			If Bereich(oDoc, "PR") Then ProtokollZeigen(oDoc, nID)  ' V8.8c
		Case "PA"
			If Bereich(oDoc, "PA") Then Spaeter("PAAUF", nID)
		Case "HI"
			If Bereich(oDoc, "HI") Then
				c = oDoc.CurrentController.getControl(Fm(oDoc, "Nav").getByName("HI_txtAnleitung"))
				c.setFocus()
				oSel.Min = nID2 : oSel.Max = nID2 + Len(oF.getString(oF.findColumn("Wort")))
				c.setSelection(oSel)
			End If
	End Select
	Exit Sub
Fehler:
	Fehlermeldung("Treffer öffnen", Error$)
End Sub

REM Vorschau schreiben: „Ausschnitt“, Trefferwort ab nPos (1-basiert) fett (E24)
Sub VorschauSetzen(oDoc As Object, sHerkunft As String, sTitel As String, sText As String, nPos As Long, nLen As Long)
	Dim oF As Object, m As Object, cur As Object
	On Error Resume Next
	oF = Fm(oDoc, "Treffer")
	oF.getByName("GS_lblVorHerkunft").Label = UCase(sHerkunft)
	oF.getByName("GS_lblVorTitel").Label = sTitel
	m = oF.getByName("GS_txtVorschau")
	If sText = "" Then
		m.setString("")
		Exit Sub
	End If
	m.setString("„" & sText & "“")
	cur = m.createTextCursor()
	cur.gotoStart(False)
	cur.gotoEnd(True)
	cur.CharWeight = com.sun.star.awt.FontWeight.NORMAL
	cur.CharFontName = m.FontDescriptor.Name
	cur.CharHeight = 11.5
	If nPos > 0 And nLen > 0 Then
		cur.gotoStart(False)
		cur.goRight(nPos, False)
		cur.goRight(nLen, True)
		cur.CharWeight = com.sun.star.awt.FontWeight.BOLD
	End If
End Sub

REM V8.8c (M5, M7): Gesamtsuche ohne Groß-/Kleinschreibung, Leerzeichen und Bindestriche egal („kaffee service“ findet
REM „Kaffeeservice“). Mit „Ähnliche Schreibweisen“ (Schalter unter der Suche, Vorgabe an) auch ä/ae, ß/ss/s, c/k/č,
REM doppelte Buchstaben. Liefert die Stelle im Originaltext (0 = kein Treffer); die Länge steht in nFundLen.
Function Fundstelle(s As String, sWort As String) As Long
	Dim b As Boolean, sN As String, sQ As String, k As Long
	Fundstelle = 0
	If s = "" Then Exit Function
	b = AehnlichAn()
	sQ = SuchNorm(sWort, b)
	If sQ = "" Then Exit Function
	sN = SuchNorm(s, b)
	k = InStr(1, sN, sQ, 0)
	If k = 0 Then Exit Function
	Fundstelle = aSuchIdx(k)
	nFundLen = aSuchIdx(k + Len(sQ) - 1) - aSuchIdx(k) + 1
End Function

REM Vergleichsform: klein, ohne Leerzeichen/Bindestrich; aSuchIdx(j) = Stelle des j-ten Zeichens im Original
Function SuchNorm(s As String, bAehnlich As Boolean) As String
	Dim i As Long, c As String, r As String, n As Long, j As Integer, sAus As String
	ReDim aSuchIdx(Len(s) * 2 + 1) As Long
	n = 0
	For i = 1 To Len(s)
		c = LCase(Mid(s, i, 1))
		If c = " " Or c = "-" Or c = Chr(160) Or c = Chr(9) Or c = Chr(10) Or c = Chr(13) Then
			sAus = ""
		ElseIf bAehnlich Then
			sAus = AehnlichZeichen(c)
		Else
			sAus = c
		End If
		For j = 1 To Len(sAus)
			c = Mid(sAus, j, 1)
			REM doppelte Buchstaben zählen einfach („Kafe“ findet „Kaffee“)
			If bAehnlich And n > 0 Then
				If Right(r, 1) = c Then GoTo Weiter
			End If
			r = r & c
			n = n + 1
			aSuchIdx(n) = i
Weiter:
		Next j
	Next i
	SuchNorm = r
End Function

Function AehnlichZeichen(c As String) As String
	Select Case c
		Case "ä" : AehnlichZeichen = "ae"
		Case "ö" : AehnlichZeichen = "oe"
		Case "ü" : AehnlichZeichen = "ue"
		Case "ß", "š", "ś", "z", "ž", "ź", "ż" : AehnlichZeichen = "s"
		Case "c", "č", "ć", "ç", "k", "q" : AehnlichZeichen = "k"
		Case "đ" : AehnlichZeichen = "d"
		Case "á", "à", "â", "ã", "å" : AehnlichZeichen = "a"
		Case "é", "è", "ê", "ë", "ě" : AehnlichZeichen = "e"
		Case "í", "ì", "î", "ï", "y", "ý" : AehnlichZeichen = "i"
		Case "ó", "ò", "ô", "õ", "ø" : AehnlichZeichen = "o"
		Case "ú", "ù", "û", "ů" : AehnlichZeichen = "u"
		Case "ř" : AehnlichZeichen = "r"
		Case "ň", "ñ" : AehnlichZeichen = "n"
		Case "v", "w" : AehnlichZeichen = "f"
		Case Else : AehnlichZeichen = c
	End Select
End Function

REM Schalter „Ähnliche Schreibweisen“ unter der Suche (Seitenleiste); fehlt er, gilt an
Function AehnlichAn() As Boolean
	AehnlichAn = True
	On Error Resume Next
	AehnlichAn = (Fm(AppDoc(), "Nav").getByName("NA_chkAehnlich").State = 1)
End Function
