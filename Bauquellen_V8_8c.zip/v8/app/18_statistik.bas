REM ============================================================ V8.6 · Statistik (N16)
REM „Statistik“ erzeugt eine Calc-Datei: Blatt „Daten“ (ein Vertrag je Zeile) und Blatt „Auswertung“ mit Pivot-Tabelle
REM (Start: Kosten je Vertragsart) und Balkendiagramm. Die Gliederung stellt man in Calc um (Pivot-Tabelle › Bearbeiten).

Sub StatistikErzeugen(Optional oEvent)
	Dim oDoc As Object, oCalc As Object, oD As Object, oA As Object, rs As Object, aLeer(), aZ(), a(), n As Long, i As Integer
	Dim oDesc As Object, oFlds As Object, oF As Object, oZiel As New com.sun.star.table.CellAddress, oDPs As Object, oDP As Object
	Dim oRng As Object, oRect As New com.sun.star.awt.Rectangle, aAdr(0) As New com.sun.star.table.CellRangeAddress
	Dim nGeld As Long, sZiel As String, aKopf, aDaten, oBer As New com.sun.star.table.CellRangeAddress
	On Error GoTo Fehler
	oDoc = AppDoc()
	If Not AlleSpeichernIn(oDoc) Then Exit Sub
	StatusSetzen(oDoc, "Statistik wird erstellt …")
	aKopf = Array("Vertrag", "Gegenstand", "Partner", "Vertragsart", "Status", "Kostenstelle", "Jahreskosten €", _
		"Kosten dieses Jahr (Prognose) €", "Rechnungen lfd. Jahr €", "nicht verrechenbar lfd. Jahr €", _
		"Leistungsanfälle 12 Monate", "Erledigungszeit verfehlt 12 Monate")
	rs = Verbindung().createStatement().executeQuery("SELECT v.""Nr"", v.""Gegenstand"", v.""Partner"", COALESCE(v.""Art"", '(ohne)'), v.""Status"", " & _
		"COALESCE(v.""Kostenstelle"", '(ohne)'), COALESCE(v.""Jahreskosten"", 0), COALESCE(v.""KostenJahr"", 0), " & _
		"COALESCE((SELECT SUM(l.""RechnungenJahr"") FROM ""V_Leistung"" l WHERE l.""VertragID"" = v.""ID""), 0), " & _
		"COALESCE((SELECT SUM(l.""NVJahr"") FROM ""V_Leistung"" l WHERE l.""VertragID"" = v.""ID""), 0), " & _
		"COALESCE((SELECT SUM(l.""Stoerungen12"") FROM ""V_Leistung"" l WHERE l.""VertragID"" = v.""ID""), 0), " & _
		"COALESCE((SELECT SUM(l.""SollVerfehlt12"") FROM ""V_Leistung"" l WHERE l.""VertragID"" = v.""ID""), 0) " & _
		"FROM ""V_Vertrag"" v ORDER BY v.""Nr""")
	ReDim aDaten(0)
	aDaten(0) = aKopf
	n = 0
	Do While rs.next()
		n = n + 1
		ReDim Preserve aDaten(n)
		aZ = Array(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), _
			rs.getDouble(7), rs.getDouble(8), rs.getDouble(9), rs.getDouble(10), CDbl(rs.getLong(11)), CDbl(rs.getLong(12)))
		aDaten(n) = aZ
	Loop
	If n = 0 Then
		MsgBox "Es gibt noch keine Verträge für eine Statistik.", 64, "Statistik"
		Exit Sub
	End If
	oCalc = StarDesktop.loadComponentFromURL("private:factory/scalc", "_blank", 0, aLeer())
	oD = oCalc.Sheets.getByIndex(0)
	oD.Name = "Daten"
	oRng = oD.getCellRangeByPosition(0, 0, 11, n)
	oRng.setDataArray(aDaten)
	nGeld = Format_(oCalc, "#.##0,00")
	oD.getCellRangeByPosition(6, 1, 9, n).NumberFormat = nGeld
	oD.getCellRangeByPosition(0, 0, 11, 0).CharWeight = 150
	oD.getCellRangeByPosition(0, 0, 11, 0).CellBackColor = RGB(229, 229, 234)
	For i = 0 To 11
		oD.Columns.getByIndex(i).OptimalWidth = True
	Next i
	oCalc.Sheets.insertNewByName("Auswertung", 0)
	oA = oCalc.Sheets.getByName("Auswertung")
	oA.getCellByPosition(0, 0).setString("Statistik Vertragsregister · Stand " & DatumDe(Date()))
	oA.getCellByPosition(0, 0).CharHeight = 14
	oA.getCellByPosition(0, 0).CharWeight = 150
	oA.getCellByPosition(0, 1).setString("Gliederung ändern: in die Tabelle klicken › Daten › Pivot-Tabelle › Bearbeiten (z. B. Partner statt Vertragsart).")
	oDPs = oA.getDataPilotTables()
	oDesc = oDPs.createDataPilotDescriptor()
	oDesc.setSourceRange(oRng.getRangeAddress())
	oFlds = oDesc.getDataPilotFields()
	oF = oFlds.getByName("Vertragsart")
	oF.Orientation = com.sun.star.sheet.DataPilotFieldOrientation.ROW
	oF = oFlds.getByName("Jahreskosten €")
	oF.Orientation = com.sun.star.sheet.DataPilotFieldOrientation.DATA
	oF.Function = com.sun.star.sheet.GeneralFunction.SUM
	oF = oFlds.getByName("Rechnungen lfd. Jahr €")
	oF.Orientation = com.sun.star.sheet.DataPilotFieldOrientation.DATA
	oF.Function = com.sun.star.sheet.GeneralFunction.SUM
	REM Datenfelder nebeneinander (Spalten), nicht untereinander
	On Error Resume Next
	oFlds.getByName("Data").Orientation = com.sun.star.sheet.DataPilotFieldOrientation.COLUMN
	On Error GoTo Fehler
	REM V8.6b: keine Gesamtsumme, sonst steht "Summe Ergebnis" als Balken im Diagramm (Windows-Test 16.10.)
	oDesc.RowGrand = False
	oDesc.ColumnGrand = False
	oZiel.Sheet = 0 : oZiel.Column = 0 : oZiel.Row = 3
	oDPs.insertNewByName("Kosten", oZiel, oDesc)
	oDP = oDPs.getByName("Kosten")
	REM V8.6c-S1: Diagramm erst ab der Zeile mit den Spaltentiteln („Vertragsart“); Filter- und „Daten“-Zeile
	REM wurden sonst leere Kategorien (Windows-Test 16.10.)
	REM V8.6d: über eine eigene Variable – aAdr(0).StartRow = n änderte nur eine Kopie (Windows-Test V8.6c)
	oBer = oDP.getOutputRange()
	For n = oBer.StartRow To oBer.EndRow
		If oA.getCellByPosition(oBer.StartColumn, n).getString() = "Vertragsart" Then
			oBer.StartRow = n
			Exit For
		End If
	Next n
	aAdr(0) = oBer
	REM V8.6b: feste Spaltenbreiten, Diagramm rechts neben der Pivot-Tabelle (verdeckte vorher Spalte B/C)
	REM V8.6c: Spalte C 5600, Titel „Summe - Rechnungen lfd. Jahr €“ ragte unter Windows über den Rand
	oA.Columns.getByIndex(0).Width = 6000
	oA.Columns.getByIndex(1).Width = 4500
	oA.Columns.getByIndex(2).Width = 5600
	oRect.X = 16500 : oRect.Y = 2000 : oRect.Width = 16000 : oRect.Height = 9000
	oA.Charts.addNewByName("Diagramm", oRect, aAdr(), True, True)
	REM V8.6c-S2: Legende, damit die Farben den Spalten zuzuordnen sind
	oA.Charts.getByName("Diagramm").EmbeddedObject.HasLegend = True
	oCalc.CurrentController.setActiveSheet(oA)
	sZiel = OrdnerNebenDatei(DbDoc(), "Export") & "Statistik_" & Format(Date(), "YYYY-MM-DD") & "_" & Format(Time(), "hhmm") & ".ods"
	oCalc.storeAsURL(sZiel, aLeer())
	oCalc.setModified(False)
	StatusSetzen(oDoc, "Statistik erstellt")
	Exit Sub
Fehler:
	Fehlermeldung("Statistik", Error$)
End Sub
