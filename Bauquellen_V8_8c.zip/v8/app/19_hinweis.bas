REM ============================================================ V8.7 · Hinweiszeile (HIL-01, ORI-01)
REM Eine Zeile unter den Karten (NA_lblHinweis) zeigt genau einen Satz, in dieser Rangfolge:
REM   1 Ergebnis einer Aktion (StatusSetzen) – Hover verdrängt es erst nach 8 s, ein Ansichtswechsel löscht es
REM   2 Hover/Fokus: Hilfetext des Elements unter der Maus
REM   3 To Do: was hier zu tun ist und wo (TodoBestimmen)
REM   4 Standardhinweis der Ansicht (ANSICHT_HINWEIS aus dem Bau)
REM Abschaltbar (Einstellungen › chkHinweis): Zeile weg, Karten reichen 300 tiefer (13_breite: UNTEN), Ergebnisse
REM stehen dann wie früher in NA_lblStatus. Stand in den Dokumenteigenschaften der .odb (keine neue DB-Spalte).
REM Plan: Plan_Hinweiszeile_HIL-01_ORI-01.md; Versuch S0 (16.10.): Beobachter erst nach dem Anzeigen und je Bereich.

REM Werden beim Bau gefüllt (build_base.py)
Private Const ANSICHT_HINWEIS = ""
Private Const PFLICHT = ""
Private Const UNTEN = ""

Private Const HW_ERGEBNIS = 1
Private Const HW_HOVER = 2
Private Const HW_TODO = 3

REM Ausnahme von der Tag-Regel: Beobachter-Objekte müssen leben; Schalter und angehängte Präfixe liest 13_breite oft
Global oHwM As Object
Global oHwF As Object
Global bHwVoll As Boolean
Global sHwPraefixe As String
Global sHwBereiche As String
REM V8.8c (W2, M13): Stufe 0 = aus, 1 = nur Status und To Do, 2 = mit Bedienhinweisen; Farben an/aus; Tooltip-Verzögerung
Global nHwStufe As Integer
Global bHwFarbe As Boolean
Global nTippMs As Long

REM ---------------------------------------------------------------- Zustand im Tag von NA_lblHinweis
REM Teile: 0 Ergebnis, 1 Zeit (Now als Zahl), 2 Ton (0 neutral, 1 erledigt, 2 Problem), 3 Hover-Element, 4 Hover-Text, 5 To Do
Function HwLabel(oDoc As Object) As Object
	HwLabel = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblHinweis")
End Function

Function HwTeile(oL As Object)
	Dim a
	a = Split(oL.Tag & String(6, Chr(1)), Chr(1))
	ReDim Preserve a(5)
	HwTeile = a
End Function

Sub HwSpeichern(oL As Object, a)
	oL.Tag = Join(a, Chr(1))
End Sub

REM ---------------------------------------------------------------- Setzen und Anzeigen
Sub HinweisSetzen(oDoc As Object, sText As String, nArt As Integer, Optional sQuelle)
	Dim oL As Object, a
	On Error Resume Next
	oL = HwLabel(oDoc)
	a = HwTeile(oL)
	Select Case nArt
		Case HW_ERGEBNIS
			a(0) = sText : a(1) = CStr(CDbl(Now())) : a(2) = CStr(ErgebnisTon(sText))
			REM V8.8c (M13): nach 10 s verschwindet das Ergebnis von selbst und kommt nicht wieder
			If sText <> "" Then Zeitgeber(10200, "HwAblauf", a(1))
		Case HW_HOVER
			a(3) = ""
			If Not IsMissing(sQuelle) Then a(3) = sQuelle
			a(4) = sText
		Case HW_TODO
			a(5) = sText
	End Select
	HwSpeichern(oL, a)
	HinweisZeigen(oDoc)
End Sub

Sub HinweisZeigen(oDoc As Object)
	Dim oL As Object, a, s As String, nFarbe As Long, nGew As Double, dAlter As Double, sZeit As String
	On Error Resume Next
	If bHwVoll Then Exit Sub
	oL = HwLabel(oDoc)
	a = HwTeile(oL)
	REM V8.8c (M13): Ergebnis mit Uhrzeit, höchstens 10 s, in der Zeit kein Wechsel mit Hover (vorher „Flackern“)
	If a(0) <> "" Then
		dAlter = 99
		If a(1) <> "" Then dAlter = (CDbl(Now()) - CDbl(a(1))) * 86400
		If dAlter >= 10 Then
			a(0) = "" : a(1) = "" : a(2) = ""
			HwSpeichern(oL, a)
		Else
			sZeit = Format(CDate(CDbl(a(1))), "hh:mm") & "  "
		End If
	End If
	nGew = 100
	If a(0) <> "" Then
		Select Case a(2)
			Case "1" : s = "✓  " & sZeit & a(0) : nFarbe = RGB(36, 138, 61) : nGew = 150
			Case "2" : s = "!  " & sZeit & a(0) : nFarbe = RGB(201, 52, 0) : nGew = 150
			Case Else : s = sZeit & a(0) : nFarbe = RGB(28, 28, 30)
		End Select
	ElseIf nHwStufe = 2 And a(4) <> "" And Not (Left(a(3), 2) = "F:" And a(5) <> "") Then
		REM V8.8 (F1): Fokushinweis („F:“) steht unter dem To Do, Mauszeiger („M:“) darüber – beim Tippen bleibt das To Do sichtbar
		s = a(4) : nFarbe = RGB(110, 110, 115)
	ElseIf a(5) <> "" Then
		s = "To Do: " & a(5) : nFarbe = RGB(28, 28, 30) : nGew = 150
	ElseIf nHwStufe = 2 Then
		s = AnsichtHinweis(AktuellerBereich(oDoc)) : nFarbe = RGB(110, 110, 115)
	Else
		REM V8.8c (W2): Stufe „Nur Status und To Do“ – keine Bedienhinweise (die stehen im Tooltip)
		s = ""
	End If
	REM V8.8c (W2): Farben aus – alles dunkelgrau, Zeichen ✓ und ! bleiben
	If Not bHwFarbe And nFarbe <> RGB(110, 110, 115) Then nFarbe = RGB(60, 60, 67)
	If oL.Label <> s Then oL.Label = s
	If oL.TextColor <> nFarbe Then oL.TextColor = nFarbe
	If oL.FontWeight <> nGew Then oL.FontWeight = nGew
	REM Tooltip trägt den ganzen Satz, falls er bei schmalem Fenster abgeschnitten wird
	If oL.HelpText <> s Then oL.HelpText = s
End Sub

REM V8.8c (M13): Zeitgeber nach 10 s – Ergebnis weg, wenn es noch dasselbe ist
Sub HwAblauf(sZeit)
	Dim oDoc As Object
	On Error Resume Next
	oDoc = AppDoc()
	If IsNull(oDoc) Then Exit Sub
	If bHwVoll Then Exit Sub
	If HwTeile(HwLabel(oDoc))(1) = sZeit Then HinweisZeigen(oDoc)
	oDoc.setModified(False)
End Sub

Function AnsichtHinweis(sB As String) As String
	Dim a, i As Integer, k As Integer, sBest As String
	a = Split(ANSICHT_HINWEIS, "~")
	For i = 0 To UBound(a)
		k = InStr(a(i), "^")
		If Left(a(i), k - 1) = sB Then
			AnsichtHinweis = Mid(a(i), k + 1)
			Exit Function
		End If
		If Left(a(i), k - 1) = Left(sB, 2) Then sBest = Mid(a(i), k + 1)
	Next i
	AnsichtHinweis = sBest
End Function

REM 1 = erledigt (✓), 2 = Problem (!), 0 = neutral (Fortschritt, Anleitung, Trefferzahl)
Function ErgebnisTon(s As String) As Integer
	Dim l As String
	l = LCase(s)
	If Left(l, 4) = "kein" Then
		ErgebnisTon = 2  ' V8.8: „Keine Treffer …“ vor der Prüfung auf „Treffer“
	ElseIf s = "" Or InStr(s, "…") > 0 Or Left(l, 5) = "klick" Or InStr(l, "treffer") > 0 Or InStr(l, "abgebrochen") > 0 Then
		ErgebnisTon = 0
	ElseIf InStr(l, "nicht") > 0 Or InStr(l, "schon") > 0 Or InStr(l, "fehl") > 0 Then
		ErgebnisTon = 2
	Else
		ErgebnisTon = 1
	End If
End Function

REM Ansichtswechsel: altes Ergebnis, Hover und To Do sofort weg (sonst stand „2 Treffer“ in „Ablage prüfen“, ORI-01)
Sub HinweisBereichNeu(oDoc As Object)
	Dim oL As Object
	On Error Resume Next
	oL = HwLabel(oDoc)
	oL.Tag = ""
	HinweisZeigen(oDoc)
End Sub

REM Nachgelagert nach dem Ansichtswechsel (Spaeter "HW"): Beobachter des Bereichs, To Do
Sub HinweisBereich(oDoc As Object, sB As String)
	On Error Resume Next
	HoverAnhaengen(oDoc, sB)  ' V8.8c: auch ohne Zeile (eigener Tooltip)
	TodoBestimmen(oDoc)
End Sub

REM ---------------------------------------------------------------- Hover und Fokus (Versuch S0: ~2,3 ms je Element)
Function GehoertZu(ByVal p As String, sB As String) As Boolean
	REM „VE1h“ (H-Knöpfe) gehört zu VE1, „VE“ zu VE1/VE2/VE3
	If Right(p, 1) = "h" And Len(p) > 2 Then p = Left(p, Len(p) - 1)
	GehoertZu = Sichtbar(p, sB)
End Function

Sub HoverAnhaengen(oDoc As Object, sB As String)
	Dim oDP As Object, i As Long, oS As Object, oM As Object, oC As Object, sNm As String, p As String, n As Integer
	Dim sNeu As String
	On Error Resume Next
	If InStr(sHwBereiche, "," & sB & ",") > 0 Then Exit Sub
	If IsNull(oHwM) Then
		oHwM = CreateUnoListener("HwM_", "com.sun.star.awt.XMouseListener")
		oHwF = CreateUnoListener("HwF_", "com.sun.star.awt.XFocusListener")
		sHwPraefixe = ","
		sHwBereiche = ","
	End If
	oDP = oDoc.DrawPage
	For i = 0 To oDP.Count - 1
		oS = oDP.getByIndex(i)
		oM = Nothing
		oM = oS.Control
		If Not IsNull(oM) Then
			sNm = oM.Name
			n = InStr(sNm, "_")
			If n > 1 Then
				p = Left(sNm, n - 1)
				If InStr(sHwPraefixe, "," & p & ",") = 0 And GehoertZu(p, sB) Then
					If InStr(sNeu, "," & p & ",") = 0 Then sNeu = sNeu & "," & p & ","
					If TippText(oM) <> "" Then
						oC = Nothing
						oC = oDoc.CurrentController.getControl(oM)
						If Not IsNull(oC) Then
							oC.addMouseListener(oHwM)
							oC.addFocusListener(oHwF)
						End If
					End If
				End If
			End If
		End If
	Next i
	sHwPraefixe = sHwPraefixe & Replace(sNeu, ",,", ",")
	sHwBereiche = sHwBereiche & sB & ","
End Sub

REM Vor dem Schließen (FormZu), sonst Absturzgefahr beim Beenden (V8.3-F2); Versuch S0: ~570 ms bei allen Elementen
Sub HoverAbmelden(oDoc As Object)
	Dim oDP As Object, i As Long, oS As Object, oM As Object, oC As Object, sNm As String, n As Integer
	On Error Resume Next
	If IsNull(oHwM) Then Exit Sub
	oDP = oDoc.DrawPage
	For i = 0 To oDP.Count - 1
		oS = oDP.getByIndex(i)
		oM = Nothing
		oM = oS.Control
		If Not IsNull(oM) Then
			sNm = oM.Name
			n = InStr(sNm, "_")
			If n > 1 Then
				If InStr(sHwPraefixe, "," & Left(sNm, n - 1) & ",") > 0 Then
					oC = Nothing
					oC = oDoc.CurrentController.getControl(oM)
					If Not IsNull(oC) Then
						oC.removeMouseListener(oHwM)
						oC.removeFocusListener(oHwF)
					End If
				End If
			End If
		End If
	Next i
	oHwM = Nothing
	oHwF = Nothing
	sHwPraefixe = ""
	sHwBereiche = ""
End Sub

Sub HwBetreten(e, Optional bFokus)
	Dim oM As Object, s As String, sArt As String
	On Error Resume Next
	If nHwStufe <> 2 Then Exit Sub  ' V8.8c: Hover in der Zeile nur bei „Mit Bedienhinweisen“
	oM = e.Source.getModel()
	s = TippText(oM)
	sArt = "M:"
	If Not IsMissing(bFokus) Then sArt = "F:"
	If s <> "" Then HinweisSetzen(AppDoc(), s, HW_HOVER, sArt & oM.Name)
End Sub

REM Versuch S0: „Verlassen“ des alten Elements kommt nach „Betreten“ des neuen → nur zurücksetzen, wenn es noch angezeigt ist
Sub HwVerlassen(e)
	Dim oDoc As Object, oL As Object, a
	On Error Resume Next
	If nHwStufe <> 2 Then Exit Sub
	oDoc = AppDoc()
	oL = HwLabel(oDoc)
	a = HwTeile(oL)
	If Mid(a(3), 3) = e.Source.getModel().Name Then
		a(3) = "" : a(4) = ""
		HwSpeichern(oL, a)
		HinweisZeigen(oDoc)
	End If
End Sub

Sub HwM_mouseEntered(e)
	TippBetreten(e)  ' V8.8c (W1)
	HwBetreten(e)
End Sub
Sub HwM_mouseExited(e)
	TippVerlassen(e)
	HwVerlassen(e)
End Sub
Sub HwM_mousePressed(e)
	TippWeg(AppDoc())
End Sub
Sub HwM_mouseReleased(e)
End Sub
Sub HwM_disposing(e)
End Sub
Sub HwF_focusGained(e)
	HwBetreten(e, True)
End Sub
Sub HwF_focusLost(e)
	HwVerlassen(e)
	REM Eingabe kann ein Pflichtfeld gefüllt haben
	Spaeter("TODO")
End Sub
Sub HwF_disposing(e)
End Sub

REM ---------------------------------------------------------------- To Do
Sub TodoBestimmen(oDoc As Object)
	Dim sB As String, s As String, v As String
	On Error Resume Next
	If bHwVoll Then Exit Sub
	sB = AktuellerBereich(oDoc)
	s = PflichtTodo(oDoc, sB)
	If s = "" Then
		If BereichGeaendert(oDoc, sB) Then s = "Änderungen sichern – oben rechts „Sichern“ (oder „Verwerfen“)."
	End If
	If s = "" Then
		Select Case sB
			Case "ST"
				v = InfoText(oDoc.DrawPage.Forms.getByName("Nav"), "Rot")
				If v <> "" And v <> "0" Then s = v & IIf(v = "1", " Vertrag", " Verträge") & _
					" mit dringendem Handlungsbedarf – Doppelklick auf eine Zeile „!! dringend“ unter „Offen“ öffnet den Vertrag."
			Case "VE1"
				s = VertragTodo(InfoText(Fm(oDoc, "Info"), "Anzeige"))
			Case "VE2"
				s = LeistungTodo(InfoText(Fm(oDoc, "LeistungInfo"), "Anzeige"))
			Case "PR"
				s = ProtokollTodo(InfoText(Fm(oDoc, "EreignisInfo"), "Offen"))
			Case "AB"
				If InStr(Fm(oDoc, "Abgleich").getByName("AB_lblPfad").Label, "noch nicht geprüft") > 0 Then _
					s = "Ablage prüfen – oben rechts „Jetzt prüfen“."
			Case "EI"
				If oDoc.DrawPage.Forms.getByName("Nav").getByName("ST_txtBeispiel").Text <> "" Then _
					s = "Beispieldaten entfernen – Karte „Beispieldaten und Anzeige“, roter Knopf."
		End Select
	End If
	HinweisSetzen(oDoc, s, HW_TODO)
End Sub

REM „Pflichtfeld ‚X‘ befüllen vor dem Sichern“ (Nico 16.10.) – nur bei geänderten oder neuen, begonnenen Einträgen
Function PflichtTodo(oDoc As Object, sB As String) As String
	Dim a, i As Integer, t, oF As Object, m As Object, sFehlt As String, n As Integer, p As String
	On Error Resume Next
	a = Split(PFLICHT, "~")
	For i = 0 To UBound(a)
		t = Split(a(i), "^")
		If UBound(t) = 2 Then
			p = Left(t(1), InStr(t(1), "_") - 1)
			If GehoertZu(p, sB) Then
				oF = Nothing
				oF = Fm(oDoc, t(0))
				If Not IsNull(oF) Then
					If oF.IsModified Then
						m = oF.getByName(t(1))
						If FeldLeer(m) Then
							sFehlt = sFehlt & IIf(n > 0, " und ", "") & "„" & t(2) & "“"
							n = n + 1
						End If
					End If
				End If
			End If
		End If
	Next i
	If n = 1 Then PflichtTodo = "Pflichtfeld " & sFehlt & " befüllen vor dem Sichern."
	If n > 1 Then PflichtTodo = "Pflichtfelder " & sFehlt & " befüllen vor dem Sichern."
End Function

Function FeldLeer(m As Object) As Boolean
	Dim v
	On Error Resume Next
	FeldLeer = False
	If m.supportsService("com.sun.star.form.component.ListBox") Then
		v = m.SelectedItems
		FeldLeer = (UBound(v) < 0)
	ElseIf m.supportsService("com.sun.star.form.component.DateField") Then
		v = m.Date
		FeldLeer = IsEmpty(v) Or IsNull(v)
	ElseIf m.supportsService("com.sun.star.form.component.NumericField") Then
		v = m.Value
		FeldLeer = IsEmpty(v) Or IsNull(v)
	Else
		FeldLeer = (Trim(m.Text) = "")
	End If
End Function

REM Vertrag: Anzeige (V_Vertrag) → was und wo
Function VertragTodo(s As String) As String
	Dim l As String
	l = LCase(s)
	If InStr(l, "bestätigung") > 0 And InStr(l, "fehlt") > 0 Then
		VertragTodo = "Bestätigung eintragen – Karte „Entscheidung zum Stichtag“, Feld „Bestätigt am“."
	ElseIf InStr(l, "kündigung versenden") > 0 Then
		VertragTodo = "Kündigung versenden und „Versandt am“ eintragen – Karte „Entscheidung zum Stichtag“."
	ElseIf InStr(l, "kündigung prüfen") > 0 Then
		VertragTodo = "Entscheiden – Karte „Entscheidung zum Stichtag“: „Verlängern“ oder „Kündigen“."
	ElseIf InStr(l, "frist fehlt") > 0 Then
		VertragTodo = "„Kündigungsfrist (Mon.)“ eintragen – Karte „Laufzeit und Kündigung“."
	ElseIf InStr(l, "prüfung fällig") > 0 Then
		VertragTodo = "Vertrag prüfen, dann „Heute geprüft“ – Karte „Ablage und Prüfung“."
	ElseIf InStr(l, "indexanpassung prüfen") > 0 Then
		VertragTodo = "Indexanpassung prüfen – Karte „Kosten und Wertsicherung“, Feld „Anpassung am“."
	ElseIf InStr(l, "stichtag verpasst") > 0 Then
		VertragTodo = "Stichtag verpasst – Entscheidung in der Karte „Entscheidung zum Stichtag“ festhalten."
	End If
End Function

REM Leistung: Anzeige (V_Leistung) → was und wo
Function LeistungTodo(s As String) As String
	Dim l As String
	l = LCase(s)
	If InStr(l, "angaben ergänzen") > 0 Then
		LeistungTodo = "Angaben ergänzen – „Offenen Eintrag öffnen ›“, Beschreibung oder Beleg ergänzen, sichern."
	ElseIf InStr(l, "rechnung") > 0 And InStr(l, "prüfen") > 0 Then
		LeistungTodo = "Rechnung prüfen und freigeben – Eintrag im Protokoll darunter öffnen."
	ElseIf InStr(l, "ohne erledigung") > 0 Then
		LeistungTodo = "Erledigung eintragen – Leistungsanfall im Protokoll darunter öffnen, „Erledigt am“."
	ElseIf InStr(l, "überfällig") > 0 Then
		LeistungTodo = "Leistung überfällig – eintragen, sobald sie erbracht ist."
	End If
End Function

REM Protokoll: Offen (V_Ereignis) → was und wo
Function ProtokollTodo(s As String) As String
	Dim l As String
	l = LCase(s)
	If l = "" Then Exit Function
	If InStr(l, "erledigung") > 0 Then
		ProtokollTodo = "Erledigung eintragen – rechts „Erledigt am“ („H“ = heute)."
	ElseIf InStr(l, "freigabebetrag") > 0 Then
		ProtokollTodo = "„Freigegebener Betrag (€)“ eintragen – rechts."
	ElseIf InStr(l, "freigabe") > 0 Then
		ProtokollTodo = "Rechnung freigeben – rechts „Freigegeben am“, „Freigegeben von“ und „Freigegebener Betrag (€)“."
	ElseIf InStr(l, "betrag oder datum") > 0 Then
		ProtokollTodo = "„Rechnungsbetrag (€)“ und „Datum“ eintragen – rechts."
	ElseIf InStr(l, "angaben ergänzen") > 0 Then
		ProtokollTodo = "Angaben ergänzen – rechts Beschreibung oder Beleg, dann „Sichern“."
	Else
		ProtokollTodo = s & " – rechts im Eintrag."
	End If
End Function

REM ---------------------------------------------------------------- Schalter (Dokumenteigenschaften der .odb)
REM V8.8c: „HinweisStufe“ (0/1/2), „HinweisFarben“, „TippVerzoegerung“ (Sekunden). Alte Dateien: „Hinweiszeile“ (an/aus).
Function DokWert(oDb As Object, sName As String, vVorgabe)
	Dim oP As Object
	On Error Resume Next
	DokWert = vVorgabe
	oP = oDb.DocumentProperties.UserDefinedProperties
	If oP.getPropertySetInfo().hasPropertyByName(sName) Then DokWert = oP.getPropertyValue(sName)
End Function

Sub DokWertMerken(oDb As Object, sName As String, v)
	Dim oP As Object
	On Error Resume Next
	oP = oDb.DocumentProperties.UserDefinedProperties
	If oP.getPropertySetInfo().hasPropertyByName(sName) Then
		oP.setPropertyValue(sName, v)
	Else
		oP.addProperty(sName, com.sun.star.beans.PropertyAttribute.REMOVEABLE, v)
	End If
	oDb.store()
End Sub

Sub AnzeigeLesen(oDb As Object)
	Dim v
	REM D6 (Plan V8.8): Vorgabe „Nur Status und To Do“, Tooltip nach 1,0 s
	nHwStufe = 1
	If Not DokWert(oDb, "Hinweiszeile", True) Then nHwStufe = 0
	v = DokWert(oDb, "HinweisStufe", -1)
	If v >= 0 And v <= 2 Then nHwStufe = v
	bHwFarbe = DokWert(oDb, "HinweisFarben", True)
	v = DokWert(oDb, "TippVerzoegerung", 1#)
	If v < 0 Or v > 10 Then v = 1
	nTippMs = CLng(v * 1000)
	bHwVoll = (nHwStufe = 0)
End Sub

REM Zeile ein/aus, Statuszeile, Seitenvorlage und Lage (13_breite) – beim Umschalten
Sub HinweiszeileAnwenden(oDoc As Object)
	Dim oNav As Object, oCur As Object, sB As String
	On Error Resume Next
	oNav = oDoc.DrawPage.Forms.getByName("Nav")
	oNav.getByName("NA_lblHinweis").EnableVisible = Not bHwVoll
	If Not bHwVoll Then oNav.getByName("NA_lblStatus").Label = ""
	sB = AktuellerBereich(oDoc)
	oCur = oDoc.Text.createTextCursor()
	oCur.PageDescName = "B_" & sB & HwSuffix()
	REM Lage neu rechnen (13_breite liest bHwVoll)
	dBreiteF = -1
	ZoomAnpassen(oDoc)
End Sub

REM Einstellungen › Anzeige: Steuerelemente auf den gelesenen Stand
Sub AnzeigeZeigen(oDoc As Object)
	Dim oF As Object
	On Error Resume Next
	oF = Fm(oDoc, "Einstellung")
	oF.getByName("EI_lbHinweis").SelectedItems = Array(nHwStufe)
	oF.getByName("EI_chkFarben").State = IIf(bHwFarbe, 1, 0)
	oF.getByName("EI_chkFarben").Enabled = (nHwStufe > 0)
	oF.getByName("EI_numTipp").Value = nTippMs / 1000
	oF.getByName("EI_numTipp").Enabled = (nHwStufe < 2)
End Sub

Sub HinweisStufeGewaehlt(oEvent)
	Dim oDoc As Object, n As Integer, bAlt As Boolean
	On Error GoTo Fehler
	n = oEvent.Source.getModel().SelectedItems(0)
	If n = nHwStufe Or n < 0 Then Exit Sub
	oDoc = AppDoc()
	bAlt = bHwVoll
	nHwStufe = n
	bHwVoll = (n = 0)
	DokWertMerken(oDoc.Parent, "HinweisStufe", n)
	If bAlt <> bHwVoll Then
		oDoc.lockControllers()
		HinweiszeileAnwenden(oDoc)
		oDoc.unlockControllers()
	End If
	AnzeigeZeigen(oDoc)
	HoverAnhaengen(oDoc, AktuellerBereich(oDoc))
	HoverAnhaengen(oDoc, "NA")
	TodoBestimmen(oDoc)
	StatusSetzen(oDoc, "Hinweiszeile: " & Array("aus", "nur Status und To Do", "mit Bedienhinweisen")(n))
	oDoc.setModified(False)
	Exit Sub
Fehler:
	On Error Resume Next
	oDoc.unlockControllers()
	Fehlermeldung("Hinweiszeile", Error$)
End Sub

Sub HinweisFarbenUmschalten(oEvent)
	Dim oDoc As Object
	On Error Resume Next
	If bHwFarbe = (oEvent.Source.getModel().State = 1) Then Exit Sub
	oDoc = AppDoc()
	bHwFarbe = Not bHwFarbe
	DokWertMerken(oDoc.Parent, "HinweisFarben", bHwFarbe)
	HinweisZeigen(oDoc)
	oDoc.setModified(False)
End Sub

REM Tooltip-Verzögerung in Sekunden (Dezimal, z. B. 0,3 oder 1,5); gemerkt beim Verlassen des Feldes
Sub TippVerzoegerungMerken(oEvent)
	Dim oDoc As Object, v
	On Error Resume Next
	v = oEvent.Source.getModel().Value
	If IsEmpty(v) Or IsNull(v) Then Exit Sub
	If v < 0 Then v = 0
	If v > 10 Then v = 10
	If CLng(v * 1000) = nTippMs Then Exit Sub
	oDoc = AppDoc()
	nTippMs = CLng(v * 1000)
	DokWertMerken(oDoc.Parent, "TippVerzoegerung", CDbl(v))
	StatusSetzen(oDoc, "Tooltip erscheint nach " & Format(v, "0.0") & " s")
	oDoc.setModified(False)
End Sub

Function HwSuffix() As String
	HwSuffix = IIf(bHwVoll, "_voll", "")
End Function

Sub HinweiszeileUmschalten(oEvent)
	Dim oDoc As Object, bNeuVoll As Boolean
	On Error GoTo Fehler
	bNeuVoll = (oEvent.Source.getModel().State = 0)
	If bNeuVoll = bHwVoll Then Exit Sub
	oDoc = AppDoc()
	bHwVoll = bNeuVoll
	HinweiszeileMerken(oDoc.Parent, Not bHwVoll)
	oDoc.lockControllers()
	HinweiszeileAnwenden(oDoc)
	oDoc.unlockControllers()
	If Not bHwVoll Then
		HoverAnhaengen(oDoc, AktuellerBereich(oDoc))
		HoverAnhaengen(oDoc, "NA")
		TodoBestimmen(oDoc)
	End If
	StatusSetzen(oDoc, IIf(bHwVoll, "Hinweiszeile ausgeschaltet", "Hinweiszeile eingeschaltet"))
	oDoc.setModified(False)
	Exit Sub
Fehler:
	On Error Resume Next
	oDoc.unlockControllers()
	Fehlermeldung("Hinweiszeile", Error$)
End Sub

REM V8.8 (KON-02): nach der Pflichtfeld-Meldung den Cursor ins erste leere Pflichtfeld des Formulars (Liste PFLICHT)
Sub PflichtFokusSetzen(oDoc As Object, sForm As String)
	Dim a, i As Integer, t, m As Object
	On Error Resume Next
	a = Split(PFLICHT, "~")
	For i = 0 To UBound(a)
		t = Split(a(i), "^")
		If UBound(t) = 2 Then
			If t(0) = sForm Then
				m = Nothing
				m = Fm(oDoc, sForm).getByName(t(1))
				If Not IsNull(m) Then
					If FeldLeer(m) Then
						FokusAuf(oDoc, sForm, t(1))
						Exit Sub
					End If
				End If
			End If
		End If
	Next i
End Sub

REM V8.8: ein Ergebnis wegnehmen, das nicht mehr stimmt (z. B. „Keine Treffer“ nach weiterem Tippen)
Sub ErgebnisWeg(oDoc As Object, sAnfang As String)
	Dim oL As Object, a
	On Error Resume Next
	If bHwVoll Then
		If Left(oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblStatus").Label, Len(sAnfang)) = sAnfang Then _
			oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblStatus").Label = ""
		Exit Sub
	End If
	oL = HwLabel(oDoc)
	a = HwTeile(oL)
	If Left(a(0), Len(sAnfang)) = sAnfang Then
		a(0) = "" : a(1) = "" : a(2) = ""
		HwSpeichern(oL, a)
		HinweisZeigen(oDoc)
	End If
End Sub
