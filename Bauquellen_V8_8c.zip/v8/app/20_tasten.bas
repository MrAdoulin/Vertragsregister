REM ============================================================ V8.8 · Tastenkürzel (TAS-01, KON-01, Nico 16.10.)
REM Ein Tasten-Handler am Controller (Versuch S1: kommt auch bei Fokus in Feld und Raster an). Belegte Tasten werden
REM verbraucht, damit LibreOffice nichts Eigenes tut (Strg+N öffnete ein neues Writer-Dokument, Strg+1 eine Überschrift,
REM Strg+F eine leere Suchleiste, F1 den Dialog „Hilfe nicht installiert“). Die Aktion läuft nachgelagert (Spaeter).
REM   Strg+1 … Strg+9   Ansichten der Seitenleiste von oben    Strg+,   Einstellungen     F1   Hilfe
REM   Strg+S            Sichern                                 Strg+N   Neu (Vertrag, Leistung, Eintrag, Partner …)
REM   Strg+F            Suche dieser Ansicht                    Strg+Umschalt+F   Alles durchsuchen
REM   Strg+Bild↑/Bild↓  voriger/nächster Vertrag                Alt+←    zurück zur Vertragsliste

Global oTastenK As Object

Private Const NAV_TASTEN = "ST,LI,LE,PR,PA,VT,AE,AB,PK"

Sub TastenAn(oDoc As Object)
	On Error Resume Next
	If Not IsNull(oTastenK) Then Exit Sub
	oTastenK = CreateUnoListener("TastK_", "com.sun.star.awt.XKeyHandler")
	oDoc.CurrentController.addKeyHandler(oTastenK)
End Sub

REM Vor dem Schließen (FormZu), wie alle Basic-Beobachter (V8.3-F2)
Sub TastenAus(oDoc As Object)
	On Error Resume Next
	REM V8.8: Größenbeobachter am Inhaltsfenster (KON-01) ebenfalls abmelden
	oDoc.CurrentController.Frame.ComponentWindow.removeWindowListener(oZoomL)
	If IsNull(oTastenK) Then Exit Sub
	oDoc.CurrentController.removeKeyHandler(oTastenK)
	oTastenK = Nothing
End Sub

Function TastK_keyPressed(e) As Boolean
	Dim nMod As Integer, k As Integer, sAktion As String, a
	On Error Resume Next
	TastK_keyPressed = False
	If MeldenLaeuft() Then Exit Function
	nMod = e.Modifiers
	k = e.KeyCode
	If nMod = com.sun.star.awt.KeyModifier.MOD1 Then
		If k >= com.sun.star.awt.Key.NUM1 And k <= com.sun.star.awt.Key.NUM9 Then
			a = Split(NAV_TASTEN, ",")
			sAktion = "NAV:" & a(k - com.sun.star.awt.Key.NUM1)
		ElseIf k = com.sun.star.awt.Key.NUM0 Then
			sAktion = "NAV:HI"
		ElseIf k = com.sun.star.awt.Key.COMMA Then
			sAktion = "NAV:EI"
		ElseIf k = com.sun.star.awt.Key.S Then
			sAktion = "SICHERN"
		ElseIf k = com.sun.star.awt.Key.N Then
			sAktion = "NEU"
		ElseIf k = com.sun.star.awt.Key.F Or k = com.sun.star.awt.Key.H Then
			sAktion = "SUCHE"
		ElseIf k = com.sun.star.awt.Key.PAGEUP Then
			sAktion = "VOR:-1"
		ElseIf k = com.sun.star.awt.Key.PAGEDOWN Then
			sAktion = "VOR:1"
		ElseIf (k >= com.sun.star.awt.Key.NUM0 And k <= com.sun.star.awt.Key.NUM9) Or k = com.sun.star.awt.Key.P Then
			REM übrige Strg+Ziffer und Strg+P (Absatzvorlagen, Drucken des Formulars) sinnlos im Register
			sAktion = "NICHTS"
		End If
	ElseIf nMod = com.sun.star.awt.KeyModifier.MOD1 + com.sun.star.awt.KeyModifier.SHIFT And k = com.sun.star.awt.Key.F Then
		sAktion = "GESAMT"
	ElseIf nMod = com.sun.star.awt.KeyModifier.MOD2 And k = com.sun.star.awt.Key.LEFT Then
		sAktion = "ZURUECK"
	ElseIf nMod = 0 And k = com.sun.star.awt.Key.F1 Then
		sAktion = "NAV:HI"
	End If
	If sAktion = "" Then Exit Function
	TastK_keyPressed = True
	If sAktion <> "NICHTS" Then Spaeter("TASTE", sAktion)
End Function

Function TastK_keyReleased(e) As Boolean
	TastK_keyReleased = False
End Function

Sub TastK_disposing(e)
End Sub

REM Nachgelagert (Spaeter "TASTE"): dieselben Makros wie die Knöpfe
Sub TasteAusfuehren(oDoc As Object, sAktion As String)
	Dim sB As String, oC As Object
	On Error Resume Next
	sB = AktuellerBereich(oDoc)
	Select Case Left(sAktion, InStr(sAktion & ":", ":") - 1)
		Case "NAV"
			Select Case Mid(sAktion, 5)
				Case "ST" : NavStart()
				Case "LI" : NavListe()
				Case "LE" : NavLeistung()
				Case "PR" : NavProtokoll()
				Case "PA" : NavPartner()
				Case "VT" : NavVertretung()
				Case "AE" : NavAenderung()
				Case "AB" : NavAbgleich()
				Case "PK" : NavPapierkorb()
				Case "EI" : NavEinstellung()
				Case "HI" : NavHilfe()
			End Select
		Case "SICHERN"
			AlleSichern()
		Case "NEU"
			Select Case Left(sB, 2)
				Case "LI", "VE" : If sB = "VE2" Then LeistungNeu() Else NeuerVertrag()
				Case "LE" : LeistungNeuAusListe()
				Case "PR" : EintragNeu()
				Case "PA" : PartnerNeuKlick()
				Case "VT" : VertretungNeu()
				Case Else : StatusSetzen(oDoc, "Strg+N legt in Verträge, Leistungen, Rechnungsverlauf, Partner und Vertretung neu an.")
			End Select
		Case "SUCHE"
			If sB = "LI" Or sB = "LE" Or sB = "PR" Or sB = "AE" Then
				oC = oDoc.CurrentController.getControl(Fm(oDoc, ListenForm(sB)).getByName(sB & "_txtSuche"))
				oC.setFocus()
				oC.setSelection(MakeSelection(0, Len(oC.Text)))
			Else
				TasteAusfuehren(oDoc, "GESAMT")
			End If
		Case "GESAMT"
			oC = oDoc.CurrentController.getControl(oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_txtGesamt"))
			oC.setFocus()
		Case "VOR"
			If Left(sB, 2) = "VE" Then
				If Mid(sAktion, 5) = "1" Then PfeilVor() Else PfeilZurueck()
			End If
		Case "ZURUECK"
			If Left(sB, 2) = "VE" Then VertragZurueck()
	End Select
End Sub

Function MakeSelection(a As Long, b As Long) As Object
	Dim s As New com.sun.star.awt.Selection
	s.Min = a : s.Max = b
	MakeSelection = s
End Function
