REM ============================================================ V8.8 · Ungültige Eingaben melden (EIN-02, EIN-04)
REM UX-Test 16.10.: „31.02.2026“ wurde still zu 01.01.2023, „abc“ im Betrag verschwand, „-5“ Monate wurde 0.
REM Datums- und Zahlenfelder (Bau: formkit.field) melden beim Verlassen, wenn der getippte Text nicht übernommen werden
REM konnte, und stellen den Wert von vorher wieder her. Meldung in der Hinweiszeile (bzw. links unten), Fokus zurück.
REM Ausnahme von der Tag-Regel: nur das gerade bearbeitete Feld, kurzlebig.
Global sEinFeld As String
Global sEinAlt As String
Global sEinRoh As String
Global sEinRohVor As String
Global nEinZeit As Long

Sub EingabeMerken(oEv As Object)
	On Error Resume Next
	sEinFeld = oEv.Source.Model.Name
	sEinAlt = oEv.Source.Text
	sEinRoh = sEinAlt
	sEinRohVor = sEinAlt
	nEinZeit = 0
End Sub

Sub EingabeText(oEv As Object)
	On Error Resume Next
	REM Nur während das Feld bearbeitet wird (die Korrektur beim Verlassen soll den Rohtext nicht überschreiben)
	REM V8.8b: LibreOffice korrigiert beim Verlassen und meldet das als Textänderung (Test 16.10.: Rohtext überschrieben).
	REM Deshalb auch den Text davor und die Zeit merken; EingabePruefen nimmt den älteren, wenn die letzte Änderung
	REM unmittelbar vor dem Verlassen kam.
	If oEv.Source.Model.Name = sEinFeld Then
		sEinRohVor = sEinRoh
		sEinRoh = oEv.Source.Text
		nEinZeit = GetSystemTicks()
	End If
	If oEv.Source.Model.supportsService("com.sun.star.form.component.DateField") Then Spaeter("H")
End Sub

Sub EingabePruefen(oEv As Object)
	Dim m As Object, sFehler As String, sRoh As String
	On Error Resume Next
	m = oEv.Source.Model
	If m.Name <> sEinFeld Then Exit Sub
	sRoh = Trim(sEinRoh)
	REM Korrektur erkennen: kam kurz vor dem Verlassen und setzt den vorigen Text nicht fort (Tippen hängt nur an)
	If nEinZeit > 0 And GetSystemTicks() - nEinZeit < 150 And Left(sEinRoh, Len(sEinRohVor)) <> sEinRohVor Then sRoh = Trim(sEinRohVor)
	If sRoh = "" Or sRoh = Trim(sEinAlt) Then Exit Sub
	If m.supportsService("com.sun.star.form.component.DateField") Then
		If Not DatumGueltig(sRoh) Then sFehler = "„" & sRoh & "“ ist kein gültiges Datum"
	Else
		sFehler = ZahlFehler(sRoh, m)
	End If
	sEinFeld = ""
	If sFehler = "" Then Exit Sub
	REM Wert von vorher wiederherstellen und melden (nachgelagert: LibreOffice korrigiert das Feld beim Verlassen selbst)
	Spaeter("EINGABE", m.Parent.Name & "|" & m.Name & "|" & sEinAlt & "|" & sFehler)
End Sub

Sub EingabeZurueck(oDoc As Object, sDaten As String)
	Dim a, oF As Object, m As Object, oC As Object, sFeld As String
	On Error Resume Next
	a = Split(sDaten, "|")
	oF = Fm(oDoc, a(0))
	m = oF.getByName(a(1))
	oC = oDoc.CurrentController.getControl(m)
	oC.Text = a(2)
	m.commit()
	sFeld = oF.getByName(a(1) & "L").Label
	If sFeld = "" Then sFeld = a(1)
	StatusSetzen(oDoc, a(3) & " – „" & sFeld & "“ ist unverändert. Bitte neu eingeben.")
	FokusAuf(oDoc, a(0), a(1))
End Sub

REM Tag.Monat.Jahr (auch 1.3.26) oder Jahr-Monat-Tag; Tage je Monat und Schaltjahr geprüft
Function DatumGueltig(s As String) As Boolean
	Dim t, d As Integer, mo As Integer, y As Integer, x As String
	On Error GoTo Nein
	DatumGueltig = False
	x = Replace(Replace(s, "/", "."), "-", ".")
	t = Split(x, ".")
	If UBound(t) = 2 Then
		If Len(t(0)) = 4 Then
			y = CInt(t(0)) : mo = CInt(t(1)) : d = CInt(t(2))
		Else
			d = CInt(t(0)) : mo = CInt(t(1)) : y = CInt(t(2))
		End If
	ElseIf UBound(t) = 1 Then
		d = CInt(t(0)) : mo = CInt(t(1)) : y = Year(Date())
	Else
		Exit Function
	End If
	If y < 100 Then y = y + 2000
	If mo < 1 Or mo > 12 Or d < 1 Or y < 1900 Or y > 2200 Then Exit Function
	DatumGueltig = (Day(DateSerial(y, mo, d)) = d)
Nein:
End Function

Function ZahlFehler(s As String, m As Object) As String
	Dim v As Double, x As String
	On Error GoTo Keine
	ZahlFehler = ""
	x = Replace(Replace(s, ".", ""), " ", "")
	If Not IsNumeric(x) Then GoTo Keine
	v = CDbl(x)
	If m.getPropertySetInfo().hasPropertyByName("ValueMin") Then
		If v < m.ValueMin Then ZahlFehler = "Kleinster Wert ist " & m.ValueMin & ", „" & s & "“ geht nicht"
	End If
	If m.getPropertySetInfo().hasPropertyByName("ValueMax") Then
		If v > m.ValueMax Then ZahlFehler = "Größter Wert ist " & m.ValueMax & ", „" & s & "“ geht nicht"
	End If
	Exit Function
Keine:
	ZahlFehler = "„" & s & "“ ist keine Zahl"
End Function
