REM ============================================================ V8.8c · Eigener Tooltip mit Verzögerung (W1, Plan V8.8 P1.6)
REM LibreOffice kennt keine einstellbare Tooltip-Verzögerung (nur Hilfe-Tipps global an/aus). Deshalb: Beim Betreten eines
REM Elements wird der LibreOffice-Tooltip am Fenster des Elements geleert (das Modell behält den HelpText), und nach der
REM eingestellten Zeit zeigt NA_lblTipp den Text unter dem Element. Bei „Mit Bedienhinweisen“ steht der Text in der
REM Hinweiszeile, dann gibt es keinen Tooltip. Zeitgeber: py/zeitgeber.py in der .odb (Versuch S0b, 16.10.).
REM Fehlt Python, erscheint der normale LibreOffice-Tooltip (ohne einstellbare Verzögerung).

Global nTippNr As Long
Global oTippCtl As Object
Global oTippS As Object
Global sTippDoc As String
Global nTippPy As Integer  ' 0 = noch nicht versucht, 1 = Python da, 2 = fehlt

REM Ruft Standard.App.<sMakro>(sArg) nach nMs im Hauptthread auf. False, wenn Python fehlt.
Function Zeitgeber(nMs As Long, sMakro As String, sArg As String) As Boolean
	Dim oS As Object
	Zeitgeber = False
	If nTippPy = 2 Then Exit Function
	On Error GoTo Fehlt
	oS = DbDoc().getScriptProvider().getScript("vnd.sun.star.script:zeitgeber.py$spaeter?language=Python&location=document")
	oS.invoke(Array(nMs, sMakro, sArg), Array(), Array())
	nTippPy = 1
	Zeitgeber = True
	Exit Function
Fehlt:
	nTippPy = 2
End Function

REM Hilfetext eines Elements (Modell); der LibreOffice-Tooltip liest dasselbe – darum nur am Fenster leeren
Function TippText(oM As Object) As String
	TippText = EigText(oM, "HelpText")
End Function

Sub TippBetreten(e)
	Dim s As String, oP As Object
	On Error Resume Next
	s = TippText(e.Source.getModel())
	If s = "" Then Exit Sub
	REM Python fehlt: LibreOffice-Tooltip lassen (nur bei Stufe 2 aus, dort steht der Text in der Zeile)
	If nTippPy = 2 And nHwStufe <> 2 Then Exit Sub
	oP = e.Source.getPeer()
	oP.setProperty("HelpText", "")
	nTippNr = nTippNr + 1
	If nHwStufe = 2 Then Exit Sub
	oTippCtl = e.Source
	If nTippMs <= 0 Then
		TippZeigen(CStr(nTippNr))
	ElseIf Not Zeitgeber(nTippMs, "TippZeigen", CStr(nTippNr)) Then
		oP.setProperty("HelpText", s)  ' Rückfall: LibreOffice-Tooltip
	End If
End Sub

Sub TippVerlassen(e)
	On Error Resume Next
	If IsNull(oTippCtl) Then Exit Sub
	If Not EqualUnoObjects(e.Source, oTippCtl) Then Exit Sub
	nTippNr = nTippNr + 1
	oTippCtl = Nothing
	TippWeg(AppDoc())
End Sub

Function TippLabel(oDoc As Object) As Object
	TippLabel = oDoc.DrawPage.Forms.getByName("Nav").getByName("NA_lblTipp")
End Function

Sub TippWeg(oDoc As Object)
	Dim m As Object
	On Error Resume Next
	m = TippLabel(oDoc)
	If m.EnableVisible Then
		m.EnableVisible = False
		REM Windows-Test 16.10.: ohne Neuzeichnen blieb der alte Tooltip als Bildrest stehen (O4)
		oDoc.CurrentController.Frame.ComponentWindow.invalidate(com.sun.star.awt.InvalidateStyle.CHILDREN + com.sun.star.awt.InvalidateStyle.UPDATE)
		oDoc.setModified(False)
	End If
End Sub

REM Vom Zeitgeber: nur wenn die Maus noch auf demselben Element steht (Nummer gleich)
Sub TippZeigen(sNr)
	Dim oDoc As Object, m As Object, s As String, r As Object, f As Double, nW As Long, nH As Long
	Dim w As Long, h As Long, x As Long, y As Long, nZ As Long, oSt As Object, p As Object, sz As Object
	On Error Resume Next
	If CLng(sNr) <> nTippNr Or IsNull(oTippCtl) Then Exit Sub
	oDoc = AppDoc()
	If IsNull(oDoc) Then Exit Sub
	s = TippText(oTippCtl.getModel())
	If s = "" Then Exit Sub
	If IsNull(TippForm(oDoc)) Then Exit Sub
	oSt = oDoc.StyleFamilies.getByName("PageStyles").getByName("Standard")
	nW = oSt.Width : nH = oSt.Height
	REM Bildpunkte → Seite: die Seite füllt das Fenster in der Breite (Zoom „Seitenbreite exakt“)
	f = nW / oDoc.CurrentController.Frame.ComponentWindow.getPosSize().Width
	r = oTippCtl.getPosSize()
	REM Breite nach Textlänge, höchstens 9 cm; Höhe nach geschätzten Zeilen (9,5 pt ≈ 170 je Zeichen)
	w = Len(s) * 170 + 500
	If w > 9000 Then w = 9000
	nZ = Int(Len(s) * 170 / (w - 400)) + 1
	h = nZ * 430 + 230
	x = CLng(r.X * f)
	y = CLng((r.Y + r.Height) * f) + 120
	If y + h > nH - 100 Then y = CLng(r.Y * f) - h - 120
	If x + w > nW - 200 Then x = nW - w - 200
	If x < 100 Then x = 100
	If y < 100 Then y = 100
	TippWeg(oDoc)
	m = TippLabel(oDoc)
	m.Label = s
	p = oTippS.Position : p.X = x : p.Y = y : oTippS.Position = p
	sz = oTippS.Size : sz.Width = w : sz.Height = h : oTippS.Size = sz
	m.EnableVisible = True
	oDoc.setModified(False)
End Sub

REM Form des Tooltip-Labels (Zeichnungsobjekt) einmal je Dokument suchen
Function TippForm(oDoc As Object) As Object
	Dim oDP As Object, i As Long, oS As Object, sNm As String
	On Error Resume Next
	TippForm = Nothing
	If Not IsNull(oTippS) And sTippDoc = oDoc.RuntimeUID Then
		TippForm = oTippS
		Exit Function
	End If
	oDP = oDoc.DrawPage
	For i = oDP.Count - 1 To 0 Step -1
		oS = oDP.getByIndex(i)
		sNm = ""
		sNm = oS.Control.Name
		If sNm = "NA_lblTipp" Then
			oTippS = oS
			sTippDoc = oDoc.RuntimeUID
			TippForm = oS
			Exit Function
		End If
	Next i
End Function
