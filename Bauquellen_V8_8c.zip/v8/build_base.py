"""V8 · baut Vertragsregister.odb: Datenbank, ein Formular mit allen Bereichen, Makromodul App, Startereignis.
Aufruf: python3 build_base.py <ziel.odb> [--ohne-beispiele] [--start=XX] [--ohne-makros]"""
import sys, os, uno
from uno_util import Office, pv, url
import db_build, forms_def
from odb_patch import patch_zip

dst = os.path.abspath(sys.argv[1])
samples = "--ohne-beispiele" not in sys.argv
start = ([a.split("=", 1)[1] for a in sys.argv if a.startswith("--start=")] or ["ST"])[0]
makros = "--ohne-makros" not in sys.argv
tmp = os.path.abspath("_odt")
os.makedirs(tmp, exist_ok=True)
SCRIPT = "vnd.sun.star.script:Standard.App.{}?language=Basic&location=document"

o = Office(2020)
try:
    doc, con = db_build.create_db(o, dst, samples=samples)
    fdocs = doc.FormDocuments
    for name, fn in forms_def.FORMS:
        odt = os.path.join(tmp, name.replace(" ", "_") + ".odt")
        n, formbereiche = fn(o, odt, start)
        print("Steuerelemente:", n)
        defn = fdocs.createInstanceWithArguments(
            "com.sun.star.sdb.DocumentDefinition",
            (pv("Name", name), pv("ActiveConnection", con), pv("URL", url(odt))))
        fdocs.insertByName(name, defn)
        print("Formular:", name)
    libs = doc.BasicLibraries
    if not libs.hasByName("Standard"):
        libs.createLibrary("Standard")
    lib = libs.getByName("Standard")
    if lib.hasByName("App"):
        lib.removeByName("App")
    if makros:
        import glob
        teile = [open(t, encoding="utf-8").read() for t in sorted(glob.glob("app/*.bas"))]
        # V8.1 (§19.1): doppelt vergebene Sub-/Function-Namen brechen den Bau ab
        import re, collections
        namen = collections.Counter(m.group(1).lower() for t in teile
                                    for m in re.finditer(r"^(?:Sub|Function)\s+(\w+)", t, re.M))
        doppelt = [n for n, k in namen.items() if k > 1]
        if doppelt:
            raise RuntimeError(f"Doppelte Makronamen: {doppelt}")
        # V8.1-F3: Sperre gegen Knopfaktionen während „Melden" an den Anfang jedes Knopf-Makros
        import formkit
        gefunden = set()
        for k, t in enumerate(teile):
            def _sperre(m):
                if m.group(2) == "MeldenStart" or m.group(2) not in formkit.KNOPF_SUBS:
                    return m.group(0)
                gefunden.add(m.group(2))
                return m.group(1) + "\tIf MeldenLaeuft() Then Exit Sub  ' V8.1-F3\n"
            teile[k] = re.sub(r"^(Sub\s+(\w+)\s*\([^\n]*\)[^\n]*\n)", _sperre, t, flags=re.M)
        fehlt = sorted(formkit.KNOPF_SUBS - gefunden - {"MeldenStart"})
        print("Melden-Sperre in Knopf-Makros:", len(gefunden), "· nicht als Sub gefunden:", fehlt)
        teile[0] = teile[0].replace('Private Const FORMBEREICHE = ""', f'Private Const FORMBEREICHE = "{formbereiche}"')
        # V8.2b-M19: Formulare mit „H"-Knöpfen
        teile = [t.replace('Private Const HFORMS = ""', f'Private Const HFORMS = "{",".join(sorted(formkit.HFORMS))}"') for t in teile]
        print("H-Knöpfe in Formularen:", sorted(formkit.HFORMS))
        # V8.7 (HIL-01): Standardhinweise, Pflichtfelder und Unterkanten-Liste als Konstanten
        q = lambda s: s.replace('"', '""')
        hw = "~".join(f"{k}^{v}" for k, v in sorted(formkit.HINWEIS.items()))
        teile = [t.replace('Private Const ANSICHT_HINWEIS = ""', f'Private Const ANSICHT_HINWEIS = "{q(hw)}"')
                  .replace('Private Const PFLICHT = ""', f'Private Const PFLICHT = "{q("~".join(formkit.PFLICHT))}"')
                  .replace('Private Const UNTEN = ""', f'Private Const UNTEN = ",{",".join(formkit.UNTEN)},"')
                 for t in teile]
        print("Beschriftung neben H zu lang:", formkit.H_ZU_LANG)
        open("App.bas", "w", encoding="utf-8").write("\n".join(teile))
        lib.insertByName("App", "\n".join(teile))
    props = uno.Any("[]com.sun.star.beans.PropertyValue",
                    (pv("EventType", "Script"), pv("Script", SCRIPT.format("AppStart"))))
    uno.invoke(doc.Events, "replaceByName", ("OnLoad", props))
    doc.store()
    if makros:
        # V8.1: Syntaxprüfung des Makromoduls (ein Fehler öffnete sonst erst beim Start einen Dialog)
        sp = doc.getScriptProvider().getScript(SCRIPT.format("BauProbe"))
        ergebnis = sp.invoke((), (), ())
        print("Makromodul übersetzt:", ergebnis[0] == 1)
        if ergebnis[0] != 1:
            raise RuntimeError("Makromodul App enthält einen Syntaxfehler (BauProbe lief nicht).")
    con.close()
    doc.close(True)
finally:
    o.close()

# B1-R1 (W1): LibreOffice 26.2 kippt in Base-Formularen die gespeicherte Ausrichtung „start" nach rechts.
# „left"/„right" bleiben stabil [Experiment 13.10.2026]. Base exportiert beim Einfügen neu, daher erst hier.
zaehler = {"n": 0}
def _ausrichtung(name, text):
    if not (name.startswith("forms/") and name.endswith("content.xml")):
        return None
    zaehler["n"] += text.count('fo:text-align="start"') + text.count('fo:text-align="end"')
    return text.replace('fo:text-align="start"', 'fo:text-align="left"').replace('fo:text-align="end"', 'fo:text-align="right"')
patch_zip(dst, _ausrichtung)
print("Ausrichtung ersetzt:", zaehler["n"])

# V8.8c (W1): Zeitgeber für den Tooltip (Basic hat keinen) als Python-Skript in der .odb (Versuch S0b, 16.10.)
if makros:
    import zipfile, shutil
    neu = dst + ".py.tmp"
    with zipfile.ZipFile(dst) as zi, zipfile.ZipFile(neu, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            d = zi.read(it.filename)
            if it.filename == "META-INF/manifest.xml":
                d = d.decode("utf8").replace("</manifest:manifest>",
                    ' <manifest:file-entry manifest:full-path="Scripts/python/zeitgeber.py" manifest:media-type=""/>'
                    ' <manifest:file-entry manifest:full-path="Scripts/python/" manifest:media-type="application/binary"/>'
                    ' <manifest:file-entry manifest:full-path="Scripts/" manifest:media-type="application/binary"/>'
                    '</manifest:manifest>').encode("utf8")
            zo.writestr(it, d)
        zo.write("py/zeitgeber.py", "Scripts/python/zeitgeber.py")
    shutil.move(neu, dst)
    print("Zeitgeber (Python) eingebettet")
print("gespeichert:", dst, os.path.getsize(dst), "Bytes")
