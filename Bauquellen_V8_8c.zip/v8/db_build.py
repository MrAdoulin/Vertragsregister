"""B1/V8 · legt die Firebird-Datenbank in einer .odb an: Tabellen, Trigger, Sichten, Auswahllisten,
optional Beispieldaten. Wird von build_base.py und den Tests genutzt."""
import os
from datetime import date, datetime, time as dtime
import uno
import schema


def lit(v):
    """Python-Wert als SQL-Literal. Firebird wandelt Literale selbst in den Spaltentyp um;
    vorbereitete Anweisungen verlangen dagegen exakt passende Setter (setShort bei SMALLINT usw.)."""
    if v is None:
        return "NULL"
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, datetime):
        return f"TIMESTAMP '{v:%Y-%m-%d %H:%M:%S}'"
    if isinstance(v, dtime):
        return f"TIME '{v:%H:%M:%S}'"
    if isinstance(v, date):
        return f"DATE '{v:%Y-%m-%d}'"
    if isinstance(v, (int, float)):
        return repr(v)
    return "'" + str(v).replace("'", "''") + "'"

def run(con, sql, *rows):
    """Führt eine Anweisung aus; mit rows wird jedes ? der Reihe nach durch ein Literal ersetzt."""
    st = con.createStatement()
    texte = [sql] if not rows else []
    for row in rows:
        teile = sql.split("?")
        assert len(teile) == len(row) + 1, (sql, row)
        texte.append("".join(t + (lit(v) if i < len(row) else "") for i, (t, v) in
                             enumerate(zip(teile, list(row) + [None]))))
    for t in texte:
        if t.lstrip().upper().startswith(("CREATE", "ALTER", "DROP", "RECREATE")):
            st.execute(t)
        else:
            st.executeUpdate(t)

def create_db(office, path, samples=True, checks=True):
    """Erzeugt die .odb mit Datenbank. Gibt (DatabaseDocument, Verbindung) zurück; Verbindung bleibt offen,
    weil Base die Daten nur bei offener Verbindung in die .odb schreibt."""
    if os.path.exists(path):
        os.remove(path)
    dbc = office.create("com.sun.star.sdb.DatabaseContext")
    ds = dbc.createInstance()
    ds.URL = "sdbc:embedded:firebird"
    # Firebird kennt keine benannten Parameter (:link_from_ID). Ohne diese Einstellung laden Unterformulare nicht.
    ds.Settings.ParameterNameSubstitution = True
    ds.DatabaseDocument.storeAsURL(uno.systemPathToFileUrl(os.path.abspath(path)), ())
    con = ds.getConnection("", "")
    for sql in schema.TABLES + schema.TRIGGERS + schema.VIEWS + (schema.CHECKS if checks else []):
        run(con, sql)
    kontext(con, "KEINE_SPUR", "1")
    run(con, 'INSERT INTO "Einstellung" ("ID") VALUES (1)')
    rows = [(t, w, i, None) for t, ws in schema.LISTS.items() for i, w in enumerate(ws)]
    rows += [("Zahlungsintervall", w, i, f) for i, (w, f) in enumerate(schema.FAKTOR)]
    run(con, 'INSERT INTO "Liste" ("Typ", "Wert", "Sort", "Faktor") VALUES (?, ?, ?, ?)', *rows)
    if samples:
        insert_samples(con)
    # V8.3-LEC: nach den Beispielen, damit deren Partnernummern gleich bleiben
    run(con, 'INSERT INTO "Partner" ("Name", "Bemerkung") VALUES (?, ?)', schema.LEC_PARTNER)
    kontext(con, "KEINE_SPUR", None)
    ds.DatabaseDocument.store()
    return ds.DatabaseDocument, con

def kontext(con, name, wert):
    """Setzt eine Firebird-Sitzungsvariable. Die Ergebniszeile muss abgeholt werden, sonst wirkt sie nicht (V8-R4)."""
    w = "NULL" if wert is None else lit(wert)
    rs = con.createStatement().executeQuery(f"SELECT RDB$SET_CONTEXT('USER_SESSION', '{name}', {w}) FROM RDB$DATABASE")
    rs.next()

def insert_samples(con):
    # V8: Beispieldaten erzeugen keine Einträge in der Änderungsspur; die Spur bekommt eigene Beispielzeilen
    kontext(con, "KEINE_SPUR", "1")
    run(con, 'INSERT INTO "Partner" ("Name", "Ansprechperson", "Telefon", "Email", "Hotline", "Kundennr", "Beispiel") '
             'VALUES (?, ?, ?, ?, ?, ?, TRUE)', *schema.PARTNER)
    cols = ('"Gegenstand", "Art", "PartnerID", "PartnerVertragsnr", "Beginn", "ErstesEnde", "AutoVerl", "VerlMonate", '
            '"FristMonate", "KTermin", "Status", "ErsetztVertrag", "Kosten", "Intervall", "Kostenstelle", "Wertsicherung", '
            '"IndexBasis", "NaechsteAnpassung", "ZuletztGeprueft", "Ordner", "Bemerkung", "Beispiel"')
    sql = f'INSERT INTO "Vertrag" ({cols}) VALUES ({", ".join(["?"] * 21)}, TRUE)'
    # Erst ohne Verweis auf Nachfolger, dann nachtragen
    rows = [r[:11] + (None,) + r[12:] for r in schema.VERTRAEGE]
    run(con, sql, *rows)
    for i, n in schema.NUMMERN.items():
        run(con, 'UPDATE "Vertrag" SET "Vertragsnummer" = ? WHERE "ID" = ?', (n, i))
    for i, r in enumerate(schema.VERTRAEGE, start=1):
        if r[11]:
            run(con, 'UPDATE "Vertrag" SET "ErsetztVertrag" = ? WHERE "ID" = ?', (r[11], i))
    run(con, 'INSERT INTO "Entscheidung" ("VertragID", "Art", "Datum", "Verantwortlich", "Versandt", "Versandart", '
             '"Bestaetigt", "Beleg") VALUES (?, ?, ?, ?, ?, ?, ?, ?)', *schema.ENTSCHEIDUNGEN)
    run(con, 'INSERT INTO "Dokument" ("VertragID", "Datum", "Bezeichnung", "Datei", "Gilt") VALUES (?, ?, ?, ?, ?)',
        *schema.DOKUMENTE)
    run(con, 'INSERT INTO "Leistung" ("VertragID", "Objekt", "Bezeichnung", "Umfang", "Abdeckung", "GrenzeJahr", '
             '"SollStunden", "IntervallMonate", "Quelle", "Bemerkung") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        *schema.LEISTUNGEN)
    run(con, 'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Beschreibung", "GemeldetAm", "GemeldetUm", '
             '"ReagiertAm", "ReagiertUm", "Rechnungsnr", "Betrag", "FreigabeDatum", "FreigabeBetrag", "FreigabeVon", '
             '"Bearbeiter", "Beleg", "Storniert", "Bemerkung") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        *schema.EREIGNISSE)
    run(con, 'INSERT INTO "Vertretung" ("Vertreter", "Ab", "Bis", "UebergebenVon", "UebergabeAm", "C1", "C2", "C3", "C4", '
             '"C5", "C6", "RueckgabeAm", "DurchgesehenAm", "Bemerkung", "Beispiel") '
             'VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)', *schema.VERTRETUNGEN)
    run(con, 'INSERT INTO "VertretungPunkt" ("VertretungID", "Was", "VertragID", "BisWann", "ErledigtAm", "Bemerkung") '
             'VALUES (?, ?, ?, ?, ?, ?)', *schema.PUNKTE)
    run(con, 'INSERT INTO "Aenderung" ("Zeit", "Benutzer", "Tabelle", "DatensatzID", "VertragID", "Aktion", "Feld", '
             '"Alt", "Neu") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', *schema.SPUR_DEMO)
    kontext(con, "KEINE_SPUR", None)

def query(con, sql):
    rs = con.createStatement().executeQuery(sql)
    md = rs.getMetaData()
    n = md.getColumnCount()
    names = [md.getColumnLabel(i) for i in range(1, n + 1)]
    out = []
    while rs.next():
        row = {}
        for i in range(1, n + 1):
            s = rs.getString(i)
            row[names[i - 1]] = None if rs.wasNull() else s
        out.append(row)
    return out
