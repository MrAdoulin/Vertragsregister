"""V8 · Bilder für die Einrichtungsanleitung: LibreOffice-Dialoge auf Deutsch (Xvfb), wichtige Stelle rot umrandet.
Ausgabe: einr/1_optionen_sicherheit.png, 2_makrosicherheit_quellen.png, 3_benutzerdaten.png"""
import os, time, subprocess, threading, uno
from PIL import Image, ImageDraw
from uno_util import pv

DISP, PORT = ":99", 2033
PROF = os.path.abspath("_profile/2033_de")
OUT = os.path.abspath("einr")
os.makedirs(OUT, exist_ok=True)


def start():
    try:
        os.remove(os.path.join(PROF, ".lock"))
    except FileNotFoundError:
        pass
    env = dict(os.environ, DISPLAY=DISP, SAL_USE_VCLPLUGIN="gen", LANGUAGE="de_AT:de", LC_MESSAGES="de_AT.UTF-8")
    p = subprocess.Popen(["soffice", f"-env:UserInstallation=file://{PROF}", "--norestore", "--nologo", "--nodefault",
                          f"--accept=socket,host=localhost,port={PORT};urp;"], env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    local = uno.getComponentContext()
    res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
    for _ in range(240):
        try:
            ctx = res.resolve(f"uno:socket,host=localhost,port={PORT};urp;StarOffice.ComponentContext")
            break
        except Exception:
            time.sleep(0.5)
    return p, ctx, ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)


def konfig(ctx, pfad, **werte):
    cp = ctx.ServiceManager.createInstanceWithContext("com.sun.star.configuration.ConfigurationProvider", ctx)
    acc = cp.createInstanceWithArguments("com.sun.star.configuration.ConfigurationUpdateAccess", (pv("nodepath", pfad),))
    for k, v in werte.items():
        acc.setPropertyValue(k, v)
    acc.commitChanges()


def ende(p, desk):
    try:
        desk.terminate()
    except Exception:
        pass
    time.sleep(1.5)
    p.kill()
    subprocess.run(["bash", "-c", "pgrep -f 'port=203[3]' | xargs -r kill -9"], check=False)


def dialoge(ctx):
    tk = ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", ctx)
    out = []
    for i in range(tk.getTopWindowCount()):
        w = tk.getTopWindow(i)
        try:
            if w.isVisible() and w.getAccessibleContext().getAccessibleRole() in (1, 12):
                out.append(w)
        except Exception:
            pass
    return out


def suche(ac, name, rollen=None):
    if ac is None:
        return None
    c = ac.getAccessibleContext()
    n = (c.getAccessibleName() or "").replace("~", "")
    if n.startswith(name) and (rollen is None or c.getAccessibleRole() in rollen):
        return c
    for i in range(c.getAccessibleChildCount()):
        r = suche(c.getAccessibleChild(i), name, rollen)
        if r is not None:
            return r


def waehle(c):
    """Wählt einen Eintrag in Baum oder Reiterleiste über die Auswahl des Elternelements."""
    par = c.getAccessibleParent().getAccessibleContext()
    try:
        par.selectAccessibleChild(c.getAccessibleIndexInParent())
    except Exception as e:
        print("Auswahl:", e)
        if c.getAccessibleActionCount():
            c.doAccessibleAction(0)


def rahmen(c):
    p, s = c.getLocationOnScreen(), c.getSize()
    return (p.X, p.Y, p.X + s.Width, p.Y + s.Height)


def foto(w, datei, markierungen=()):
    tmp = os.path.join(OUT, "_ganz.png")
    subprocess.run(["import", "-display", DISP, "-window", "root", tmp], check=True)
    img = Image.open(tmp).convert("RGB")
    r = w.getPosSize()
    # Fensterrahmen: Position auf dem Bildschirm aus der Bedienungshilfe des Fensters
    pos = w.getAccessibleContext().getLocationOnScreen()
    box = (pos.X, pos.Y, pos.X + r.Width, pos.Y + r.Height)
    d = ImageDraw.Draw(img)
    for (x0, y0, x1, y1) in markierungen:
        for k in range(3):
            d.rectangle([x0 - 4 - k, y0 - 4 - k, x1 + 4 + k, y1 + 4 + k], outline=(215, 0, 21))
    img.crop((box[0] - 8, box[1] - 8, box[2] + 8, box[3] + 8)).save(os.path.join(OUT, datei))
    print("Bild:", datei)


def dispatch_in_thread(ctx, desk, cmd):
    def lauf():
        try:
            disp = ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.DispatchHelper", ctx)
            disp.executeDispatch(desk.getCurrentFrame(), cmd, "", 0, ())
        except Exception as e:
            print("dispatch:", e)
    th = threading.Thread(target=lauf, daemon=True)
    th.start()
    return th


if __name__ == "__main__":
    # 1. Profil auf Deutsch (Oberfläche) und Österreich (Gebietsschema) stellen, Namen eintragen
    p, ctx, desk = start()
    konfig(ctx, "/org.openoffice.Setup/L10N", ooLocale="de", ooSetupSystemLocale="de-AT")
    konfig(ctx, "/org.openoffice.Office.Linguistic/General", UILocale="de-DE")
    konfig(ctx, "/org.openoffice.UserProfile/Data", givenname="Max", sn="Muster")
    ende(p, desk)
    p, ctx, desk = start()
    try:
        doc = desk.loadComponentFromURL("private:factory/swriter", "_blank", 0, ())
        doc.CurrentController.Frame.ContainerWindow.IsMaximized = True
        time.sleep(2)
        dispatch_in_thread(ctx, desk, ".uno:OptionsTreeDialog")
        time.sleep(3)
        dl = dialoge(ctx)
        opt = dl[0]
        print("Dialog:", opt.getAccessibleContext().getAccessibleName())
        # Benutzerdaten (erste Seite unter LibreOffice)
        vn = suche(opt, "Vor-/Nachname")
        marks = [rahmen(vn)] if vn is not None else []
        foto(opt, "3_benutzerdaten.png", marks)
        # Sicherheit
        item = suche(opt, "Sicherheit")
        waehle(item)
        time.sleep(1.5)
        knopf = suche(opt, "Makrosicherheit", (44, 42))
        foto(opt, "1_optionen_sicherheit.png", [rahmen(item), rahmen(knopf)])
        # Der Knopf öffnet einen modalen Dialog; die Aktion kehrt erst nach dessen Schließen zurück
        threading.Thread(target=lambda: knopf.doAccessibleAction(0), daemon=True).start()
        time.sleep(3)
        dl = dialoge(ctx)
        print("Dialoge:", [w.getAccessibleContext().getAccessibleName() for w in dl])
        ms = [w for w in dl if "Makro" in (w.getAccessibleContext().getAccessibleName() or "")]
        ms = ms[0] if ms else dl[-1]
        tab = suche(ms, "Vertrauenswürdige Quellen")
        if tab is not None:
            waehle(tab)
        time.sleep(1.5)
        hinzu = suche(ms, "Hinzufügen", (44, 42))
        alle = []
        # Der Knopf „Hinzufügen …" der Speicherorte ist der zweite mit diesem Namen (der erste gehört zu den Zertifikaten)
        def alle_suchen(ac):
            if ac is None:
                return
            c = ac.getAccessibleContext()
            if (c.getAccessibleName() or "").replace("~", "").startswith("Hinzufügen") and c.getAccessibleRole() in (44, 42):
                alle.append(c)
            for i in range(c.getAccessibleChildCount()):
                alle_suchen(c.getAccessibleChild(i))
        alle_suchen(ms)
        marks = [rahmen(tab)] if tab is not None else []
        if alle:
            marks.append(rahmen(alle[-1]))
        foto(ms, "2_makrosicherheit_quellen.png", marks)
        for w in (ms, opt):
            b = suche(w, "Abbrechen", (44, 42))
            if b is not None:
                threading.Thread(target=lambda: b.doAccessibleAction(0), daemon=True).start()
                time.sleep(1.5)
    finally:
        ende(p, desk)
