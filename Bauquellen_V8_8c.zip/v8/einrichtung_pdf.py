"""V8 · Einrichtungsanleitung als PDF (eine Doppelseite A4) aus Text und den Bildern in einr/."""
import os, sys, uno
from PIL import Image
from com.sun.star.awt import Size
from uno_util import Office, pv, url

AS_CHAR = uno.Enum("com.sun.star.text.TextContentAnchorType", "AS_CHARACTER")
PARA_BREAK = uno.getConstantByName("com.sun.star.text.ControlCharacter.PARAGRAPH_BREAK")

TEXT = [
    ("h1", "Vertragsregister einrichten"),
    ("sub", "Einmal je PC. Dauer: etwa 5 Minuten. Danach öffnet ein Doppelklick das Register."),
    ("h2", "1  Datei ablegen"),
    ("p", "Kopiere „Vertragsregister.odb“ in einen festen Ordner, z. B. Z:\\Verträge\\Register\\."),
    ("p", "Alle, die mit dem Register arbeiten, öffnen diese eine Datei. Die Ordner „Sicherung“ und „Export“ legt das Register daneben selbst an."),
    ("h2", "2  Ordner als vertrauenswürdig eintragen"),
    ("p", "Das Register braucht Makros. LibreOffice führt sie nur in vertrauenswürdigen Ordnern aus."),
    ("p", "a)  LibreOffice öffnen. Menü Extras › Optionen."),
    ("p", "b)  Links „LibreOffice › Sicherheit“ wählen. Rechts auf „Makrosicherheit …“ klicken."),
    ("img", "1_optionen_sicherheit.png", 13.0),
    ("p", "c)  Reiter „Vertrauenswürdige Quellen“ wählen. Unten bei „Vertrauenswürdige Speicherorte“ auf „Hinzufügen …“ klicken."),
    ("img", "2_makrosicherheit_quellen.png", 8.0),
    ("p", "d)  Den Ordner aus Schritt 1 wählen. Dann dreimal „OK“."),
    ("p", "Die Sicherheitsstufe bleibt auf „Hoch“. Stell sie nicht auf „Niedrig“: Das würde Makros aus allen Dateien erlauben."),
    ("h2", "3  Namen eintragen"),
    ("p", "Extras › Optionen › LibreOffice › Benutzerdaten. Vor- und Nachname eintragen, dann „OK“. Das Register schreibt diesen Namen zu jeder Änderung."),
    ("img", "3_benutzerdaten.png", 10.5),
    ("h2", "4  Register öffnen"),
    ("p", "Doppelklick auf „Vertragsregister.odb“. Die Übersicht öffnet sich im ganzen Fenster."),
    ("p", "Beim ersten Mal: Einstellungen › „Beispieldaten entfernen“. Danach unter Einstellungen den Ablagepfad eintragen, z. B. Z:\\Verträge\\."),
    ("h2", "Wenn etwas nicht geht"),
    ("p", "•  Nur die Übersicht ist zu sehen und kein Knopf reagiert: Die Makros sind aus. Prüfe Schritt 2, schließe die Datei und öffne sie neu."),
    ("p", "•  LibreOffice meldet, dass die Datei gesperrt ist: Eine andere Person hat das Register offen. Warte, bis sie es schließt."),
    ("p", "•  Weitere Fragen: im Register links auf „Hilfe“."),
    ("small", "Bilder: LibreOffice 24.2. In neueren Fassungen sehen die Dialoge ähnlich aus; die Namen der Menüpunkte sind gleich."),
]


def bauen(o, ziel_pdf, bilder):
    doc = o.desktop.loadComponentFromURL("private:factory/swriter", "_blank", 0, (pv("Hidden", True),))
    st = doc.StyleFamilies.getByName("PageStyles").getByName("Standard")
    st.Width, st.Height = 21000, 29700
    st.LeftMargin = st.RightMargin = 1800
    st.TopMargin, st.BottomMargin = 1500, 1300
    ps = doc.StyleFamilies.getByName("ParagraphStyles")
    std = ps.getByName("Standard")
    std.CharFontName, std.CharHeight = "Liberation Sans", 10.5
    text = doc.Text
    cur = text.createTextCursor()
    erste = True
    for art, wert, *rest in TEXT:
        if not erste:
            text.insertControlCharacter(cur, PARA_BREAK, False)
        erste = False
        cur.ParaStyleName = "Standard"
        cur.CharHeight, cur.CharWeight, cur.CharColor = 10.5, 100, 0x1C1C1E
        cur.ParaTopMargin, cur.ParaBottomMargin = 0, 120
        if art == "img":
            img = Image.open(os.path.join(bilder, wert))
            breite = int(rest[0] * 1000)
            hoehe = int(breite * img.height / img.width)
            g = doc.createInstance("com.sun.star.text.TextGraphicObject")
            gp = o.create("com.sun.star.graphic.GraphicProvider")
            g.Graphic = gp.queryGraphic((pv("URL", url(os.path.join(bilder, wert))),))
            g.AnchorType = AS_CHAR
            g.Size = Size(breite, hoehe)
            cur.ParaAdjust = uno.Enum("com.sun.star.style.ParagraphAdjust", "LEFT")
            text.insertTextContent(cur, g, False)
            continue
        if art == "h1":
            cur.CharHeight, cur.CharWeight, cur.ParaBottomMargin = 20, 150, 80
        elif art == "sub":
            cur.CharColor, cur.ParaBottomMargin = 0x6E6E73, 300
        elif art == "h2":
            cur.CharHeight, cur.CharWeight, cur.CharColor, cur.ParaTopMargin = 13, 150, 0x007AFF, 250
        elif art == "small":
            cur.CharHeight, cur.CharColor, cur.ParaTopMargin = 8.5, 0x6E6E73, 300
        text.insertString(cur, wert, False)
    doc.storeToURL(url(ziel_pdf), (pv("FilterName", "writer_pdf_Export"),))
    doc.storeToURL(url(ziel_pdf[:-4] + ".odt"), (pv("FilterName", "writer8"),))
    doc.close(True)


if __name__ == "__main__":
    bilder = os.path.abspath("einr")
    # Bild 2: linken Rand ohne fremde Fensterteile
    p2 = os.path.join(bilder, "2_makrosicherheit_quellen.png")
    im = Image.open(p2)
    if im.width > 490:
        im.crop((9, 0, im.width, im.height)).save(p2)
    o = Office(2020)
    try:
        bauen(o, os.path.abspath(sys.argv[1]), bilder)
    finally:
        o.close()
    print("PDF:", sys.argv[1])
