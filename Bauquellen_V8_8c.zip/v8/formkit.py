"""V8 · Baukasten für das Ein-Fenster-Formular (ein Writer-Formulardokument mit Bereichen).
Einheiten: 1/100 mm. Gestaltung: helle Fläche, weiße Karten mit runden Ecken, eine Akzentfarbe.
Bereiche: Jedes Steuerelement heißt <Bereich>_<Name>, z. B. LI_txtSuche. Zweistellige Bereiche (VE) gelten für alle
Unterbereiche (VE1, VE2, VE3). NA (Seitenleiste) ist immer sichtbar. Der Bereichswechsel schaltet EnableVisible
(V8-R1: 0,4 ms je Steuerelement) und die Seitenvorlage B_<Bereich> mit dem Kartenbild (V8-R2)."""
import os, tempfile, uno
from com.sun.star.awt import Point, Size
from com.sun.star.script import ScriptEventDescriptor
from uno_util import pv

FONT = "Liberation Sans"  # V8.8b (Nico 16.10.: Mac-tauglich; vorher Segoe UI)
BG, CARD, TEXT, TEXT2, LINE = 0xF2F2F7, 0xFFFFFF, 0x1C1C1E, 0x6E6E73, 0xD1D1D6
ACCENT, ACCENT_BG = 0x007AFF, 0xE5F1FF
RED, RED_BG = 0xD70015, 0xFFE5E3
ORANGE, ORANGE_BG = 0xC93400, 0xFFF1DB
GREEN, GREEN_BG = 0x248A3D, 0xE3F6E8
GRAY_BG = 0xE5E5EA
PAGE_W, PAGE_H = 32000, 18000

AT_PAGE = uno.Enum("com.sun.star.text.TextContentAnchorType", "AT_PAGE")
FS_SOLID = uno.Enum("com.sun.star.drawing.FillStyle", "SOLID")
VA_MIDDLE = uno.Enum("com.sun.star.style.VerticalAlignment", "MIDDLE")
VA_TOP = uno.Enum("com.sun.star.style.VerticalAlignment", "TOP")
SQLPT = uno.Enum("com.sun.star.form.ListSourceType", "SQLPASSTHROUGH")
SQL = uno.Enum("com.sun.star.form.ListSourceType", "SQL")
BT_URL = uno.Enum("com.sun.star.form.FormButtonType", "URL")
BT_PUSH = uno.Enum("com.sun.star.form.FormButtonType", "PUSH")
NAV_NONE = uno.Enum("com.sun.star.form.NavigationBarMode", "NONE")
H_ZU_LANG = []  # V8.6: Beschriftungen, die neben „H“ zu lang sind
KNOPF_SUBS = set()   # V8.1-F3: Makros an Knöpfen, der Bau setzt die Melden-Sperre davor
HFORMS = set()       # V8.2b-M19: Formulare mit „H"-Knöpfen
HINWEIS = {}         # V8.7 (HIL-01): Standardhinweis je Bereich für die Hinweiszeile
PFLICHT = []         # V8.7: Pflichtfelder „Formular^Element^Beschriftung“ (Beschriftung mit „*“)
UNTEN = []           # V8.7: Elemente an der Unterkante, „W:Name“ wächst / „V:Name“ wandert bei abgeschalteter Zeile
UNTEN_PLUS = 300     # V8.7: so viel tiefer reichen die Karten ohne Hinweiszeile
SCRIPT = "vnd.sun.star.script:Standard.App.{}?language=Basic&location=document"

LABEL_H, FIELD_H, ROW = 400, 700, 1300
CARD_HEAD = 950

# Knopfstile: Textfarbe, Hintergrund, fett, Ausrichtung (0 links, 1 Mitte)
STYLES = {"primary": (0xFFFFFF, ACCENT, True, 1), "secondary": (ACCENT, ACCENT_BG, True, 1),
          "plain": (ACCENT, BG, True, 1), "danger": (RED, RED_BG, True, 1), "card": (ACCENT, CARD, True, 1),
          "nav": (TEXT, CARD, False, 0), "navaktiv": (ACCENT, ACCENT_BG, True, 0), "navrot": (RED, CARD, False, 0), "navsym": (TEXT, CARD, False, 1), "navrotm": (RED, CARD, False, 1),
          "tab": (TEXT2, GRAY_BG, False, 1), "tabaktiv": (0xFFFFFF, ACCENT, True, 1)}


class FormDoc:
    """Ein Writer-Dokument, das zum Base-Formular wird."""

    def __init__(self, office, title):
        self.o = office
        self.doc = office.desktop.loadComponentFromURL("private:factory/swriter", "_blank", 0, (pv("Hidden", True),))
        self.dp = self.doc.DrawPage
        self.forms = self.dp.Forms
        self.title = title
        self.area = "NA"
        self.cards = {}          # Bereich -> [(x, y, w, h, Farbe, Radius, Schatten)]
        self.form_areas = {}     # Formular -> Bereiche seiner Steuerelemente (für den schnellen Wechsel)
        self._seite()

    def bereich(self, code):
        self.area = code
        self.cards.setdefault(code, [])

    def _seite(self):
        st = self.doc.StyleFamilies.getByName("PageStyles").getByName("Standard")
        st.Width, st.Height = PAGE_W, PAGE_H
        st.LeftMargin = st.RightMargin = st.TopMargin = st.BottomMargin = 0
        st.HeaderIsOn = st.FooterIsOn = False
        st.FillStyle = FS_SOLID
        st.FillColor = BG
        st.BackgroundFullSize = True
        para = self.doc.StyleFamilies.getByName("ParagraphStyles").getByName("Standard")
        para.CharHeight = 2
        self.doc.DocumentProperties.Title = self.title
        vs = self.doc.CurrentController.ViewSettings
        for k, v in (("ShowRulers", False), ("ShowHoriRuler", False), ("ShowVertRuler", False),
                     ("ShowParaBreaks", False), ("ShowTextBoundaries", False), ("ZoomType", 2)):
            try:
                vs.setPropertyValue(k, v)
            except Exception:
                pass

    # ------------------------------------------------------------ Formulare und Ereignisse
    def form(self, name, command=None, ctype=0, parent=None, master=None, detail=None, order=None,
             readonly=False, nav=True, filter=None):
        f = self.doc.createInstance("com.sun.star.form.component.Form")
        f.Name = name
        if command is not None:
            f.Command, f.CommandType = command, ctype
        if master:
            f.MasterFields, f.DetailFields = tuple(master), tuple(detail)
        if order:
            f.Order = order
        if filter:
            f.Filter, f.ApplyFilter = filter, True
        if readonly:
            f.AllowInserts = f.AllowUpdates = f.AllowDeletes = False
        if not nav:
            f.NavigationBarMode = NAV_NONE
        (parent if parent is not None else self.forms).insertByName(name, f)
        return f

    def on_form(self, form, listener, method, sub, param=""):
        cont = form.Parent
        idx = [cont.getByIndex(i).Name for i in range(cont.getCount())].index(form.Name)
        ev = ScriptEventDescriptor()
        ev.ListenerType, ev.EventMethod, ev.AddListenerParam = listener, method, param
        ev.ScriptType, ev.ScriptCode = "Script", SCRIPT.format(sub)
        cont.registerScriptEvent(idx, ev)
    def on_ctl(self, form, model, listener, method, sub):
        idx = [form.getByIndex(i) for i in range(form.getCount())].index(model)
        ev = ScriptEventDescriptor()
        ev.ListenerType, ev.EventMethod, ev.AddListenerParam = listener, method, ""
        ev.ScriptType, ev.ScriptCode = "Script", SCRIPT.format(sub)
        form.registerScriptEvent(idx, ev)

    def on_doc(self, event, sub):
        props = uno.Any("[]com.sun.star.beans.PropertyValue",
                        (pv("EventType", "Script"), pv("Script", SCRIPT.format(sub))))
        uno.invoke(self.doc.Events, "replaceByName", (event, props))

    # ------------------------------------------------------------ Zeichnen
    def card(self, x, y, w, h, color=CARD, radius=380, shadow=True):
        """Karten werden Teil des Seitenhintergrunds (Bild je Bereich). Zeichenobjekte wären anklickbar."""
        self.cards.setdefault(self.area, []).append((x, y, w, h, color, radius, shadow))

    def _bild(self, cards, nr):
        from PIL import Image, ImageDraw, ImageFilter
        ss = 2
        k = 0.08 * ss
        W, H = int(PAGE_W * k), int(PAGE_H * k)
        rgb = lambda c: ((c >> 16) & 255, (c >> 8) & 255, c & 255)
        img = Image.new("RGB", (W, H), rgb(BG))
        sh = Image.new("L", (W, H), 0)
        d = ImageDraw.Draw(sh)
        for (x, y, w, h, color, radius, shadow) in cards:
            if shadow:
                d.rounded_rectangle([x * k, (y + 35) * k, (x + w) * k, (y + h + 35) * k], radius=radius * k, fill=70)
        sh = sh.filter(ImageFilter.GaussianBlur(120 * k / 2))
        img.paste(Image.new("RGB", (W, H), (199, 199, 204)), (0, 0), sh)
        d = ImageDraw.Draw(img)
        for (x, y, w, h, color, radius, shadow) in cards:
            d.rounded_rectangle([x * k, y * k, (x + w) * k, (y + h) * k], radius=radius * k, fill=rgb(color))
        img = img.resize((W // ss, H // ss), Image.LANCZOS)
        # V8: Palettenbild hält die .odb klein (13 Bilder); jedes Speichern schreibt die ganze .odb
        img = img.convert("P", palette=Image.ADAPTIVE, colors=64)
        png = os.path.join(tempfile.gettempdir(), f"vr_bg_{os.getpid()}_{nr}.png")
        img.save(png, optimize=True)
        gp = self.o.create("com.sun.star.graphic.GraphicProvider")
        return gp.queryGraphic((pv("URL", uno.systemPathToFileUrl(png)),))

    def anzeigebereiche(self):
        codes = [c for c in self.cards if c != "NA"]
        eltern = {c[:2] for c in codes if len(c) == 3}
        return [c for c in codes if c not in eltern]

    def hintergruende(self):
        """Je anzeigbarem Bereich eine Seitenvorlage B_<Bereich> mit Kartenbild (Seitenleiste + Eltern + Bereich)."""
        styles = self.doc.StyleFamilies.getByName("PageStyles")
        std = styles.getByName("Standard")
        unten = getattr(self, "unten", None)
        for nr, code in enumerate(self.anzeigebereiche()):
            cards = self.cards.get("NA", []) + (self.cards.get(code[:2], []) if len(code) == 3 else []) + self.cards[code]
            # V8.7: zweites Bild B_<Bereich>_voll für abgeschaltete Hinweiszeile – Karten an der Unterkante reichen tiefer
            voll = [(x, y, w, h + UNTEN_PLUS if unten and abs(y + h - unten) <= 5 else h, c, r, s)
                    for (x, y, w, h, c, r, s) in cards]
            for k_, (suffix, kk) in enumerate((("", cards), ("_voll", voll))):
                st = self.doc.createInstance("com.sun.star.style.PageStyle")
                styles.insertByName("B_" + code + suffix, st)
                for k in ("Width", "Height", "LeftMargin", "RightMargin", "TopMargin", "BottomMargin"):
                    setattr(st, k, getattr(std, k))
                st.HeaderIsOn = st.FooterIsOn = False
                st.FillStyle = uno.Enum("com.sun.star.drawing.FillStyle", "BITMAP")
                st.FillBitmap = self._bild(kk, nr * 2 + k_)
                st.FillBitmapMode = uno.Enum("com.sun.star.drawing.BitmapMode", "STRETCH")
                st.BackgroundFullSize = True

    def _place(self, form, model, x, y, w, h):
        model.Name = f"{self.area}_{model.Name}"
        form.insertByName(model.Name, model)
        self.form_areas.setdefault(form.Name, set()).add(self.area)
        sh = self.doc.createInstance("com.sun.star.drawing.ControlShape")
        sh.AnchorType = AT_PAGE
        sh.Control = model
        self.dp.add(sh)
        sh.Size, sh.Position = Size(w, h), Point(x, y)
        return model

    def _font(self, m, size, bold=False, color=TEXT):
        m.FontName, m.FontHeight = FONT, size
        m.FontWeight = 150.0 if bold else 100.0
        m.TextColor = color

    _n = 0

    def _name(self, prefix):
        FormDoc._n += 1
        return f"{prefix}{FormDoc._n}"

    # ------------------------------------------------------------ Steuerelemente
    def text(self, form, label, x, y, w, h=600, size=10, bold=False, color=TEXT2, bg=CARD, align=0, name=None,
             top=False, multiline=False):
        m = self.doc.createInstance("com.sun.star.form.component.FixedText")
        m.Name = name or self._name("lbl")
        m.Label = label
        self._font(m, size, bold, color)
        m.BackgroundColor = bg
        m.Border = 0
        m.Align = align
        m.MultiLine = multiline
        try:
            m.VerticalAlign = VA_TOP if top else VA_MIDDLE
        except Exception:
            pass
        return self._place(form, m, x, y, w, h)

    def section(self, form, label, x, y, w, bg=CARD, name=None):
        return self.text(form, label.upper(), x, y, w, 500, 8.5, True, TEXT2, bg, name=name)

    def _field_common(self, m, size=10.5, readonly=False, bg=CARD):
        self._font(m, size, False, TEXT)
        if readonly:
            m.ReadOnly = True
            m.Border = 0
            m.BackgroundColor = bg
            m.Tabstop = False
        else:
            m.Border = 2
            m.BorderColor = LINE
            m.BackgroundColor = 0xFFFFFF

    def field(self, form, kind, data, label, x, y, w, readonly=False, size=10.5, bold=False, color=TEXT, bg=CARD,
              h=FIELD_H, help=None, name=None, **props):
        """Beschriftung über dem Feld. kind: TextField, DateField, TimeField, NumericField, CurrencyField, ListBox."""
        # V8.1-P1 (B-L4): Beträge als Zahlenfeld mit 2 Nachkommastellen. Ein Währungsfeld setzt das Symbol des
        # Gebietsschemas ein (Windows: „€ 140,00", leeres Symbol: Landeswährung); die Beschriftung trägt „(€)".
        typ = "NumericField" if kind == "CurrencyField" else kind
        m = self.doc.createInstance(f"com.sun.star.form.component.{typ}")
        m.Name = name or self._name(kind[:3].lower())
        if data:
            m.DataField = data
        self._field_common(m, size, readonly, bg)
        m.FontWeight = 150.0 if bold else 100.0
        m.TextColor = color
        if kind == "DateField":
            m.Dropdown, m.Spin, m.StrictFormat, m.DateFormat = (not readonly), False, True, 2
        elif kind == "TimeField":
            m.Spin, m.StrictFormat, m.TimeFormat = False, True, 0
        elif kind == "NumericField":
            m.DecimalAccuracy, m.Spin, m.ShowThousandsSeparator, m.ValueMin = 0, False, False, 0
            m.StrictFormat = True
        elif kind == "CurrencyField":
            m.DecimalAccuracy, m.Spin, m.ShowThousandsSeparator = 2, False, True
            m.StrictFormat = True
        elif kind == "ListBox":
            m.Dropdown = True
            m.LineCount = 14
        elif kind == "ComboBox":
            # V8.2b-M20 (E20): Vorschlagsliste mit Freitext; ListSource ist bei ComboBox ein Text
            m.Dropdown = True
            m.LineCount = 10
            m.Autocomplete = True
        if help:
            m.HelpText = help
        for k, v in props.items():
            setattr(m, k, v)
        # V8.2b-M19 / V8.4-P02: „H“ in der Beschriftungszeile rechts (unter Windows übermalte ein Feld beim Darüberfahren
        # einen überlappenden Knopf). Passt die Beschriftung daneben, wird sie gekürzt; sonst liegt „H“ über ihrem
        # Ende und wird vorher angelegt (zuerst angelegt = oben). Eine Beschriftung zeichnet beim Darüberfahren nicht neu.
        mit_h = kind == "DateField" and not readonly and h == FIELD_H
        hb = None
        yf = y + (LABEL_H if label else 0)
        if label:
            ln = self._name("lbl")
            lw_ = w
            if mit_h:
                # V8.6: „H“ liegt immer rechts neben der Beschriftung, nie über ihrem Text (Nico 16.10. 00:11).
                # Zu lange Beschriftungen meldet der Bau; test_v86_layout misst den Text in Pixeln.
                lw_ = w - 650
                if len(label) * 200 + 250 > lw_:
                    H_ZU_LANG.append(f"{self.area}: {label} ({len(label)} Zeichen, Platz {lw_})")
            # V8.2a: benannte Felder bekommen eine benannte Beschriftung (<Name>L) für das rote „!" (E14)
            self.text(form, label, x, y, lw_, LABEL_H, 8.5, False, TEXT2, bg, name=(name + "L") if name else ln)
        if mit_h and hb is None:
            hb = self._heute(form, m, x, yf, w)
        self._place(form, m, x, yf, w, h)
        if kind in ("DateField", "NumericField", "CurrencyField") and not readonly:
            # V8.8 (EIN-02, EIN-04): ungültige Eingaben melden statt still ersetzen; Text geändert ruft auch „H“ nach
            self.on_ctl(form, m, "XTextListener", "textChanged", "EingabeText")
            self.on_ctl(form, m, "XFocusListener", "focusGained", "EingabeMerken")
            self.on_ctl(form, m, "XFocusListener", "focusLost", "EingabePruefen")
        elif hb is not None:
            self.on_ctl(form, m, "XTextListener", "textChanged", "HText")
        if label and "*" in label:
            PFLICHT.append(f"{form.Name}^{m.Name}^{' '.join(label.replace('*', '').split())}")
        return m

    def _heute(self, form, feld, x, y, w):
        """V8.2b-M19 (E19): Knopf „H" liegt über dem rechten Teil eines leeren Datumsfelds, vor dem Pfeil.
        Name <Bereich>h_<Feld>: Der Bereichswechsel (Zweig) kennt das Präfix nicht und lässt ihn liegen;
        HAktualisieren blendet ihn ein, solange das Feld leer ist. Kein anderes Feld verschiebt sich."""
        b = self.doc.createInstance("com.sun.star.form.component.CommandButton")
        b.Name = f"{self.area}h_{feld.Name}"
        b.Label = "H"
        self._font(b, 8, True, ACCENT)
        b.BackgroundColor = ACCENT_BG
        b.Tabstop = False
        b.FocusOnClick = False
        b.HelpText = "Heute eintragen"
        b.Tag = f"{self.area}_{feld.Name}"
        b.ButtonType = BT_PUSH
        b.EnableVisible = False
        form.insertByName(b.Name, b)
        sh = self.doc.createInstance("com.sun.star.drawing.ControlShape")
        sh.AnchorType = AT_PAGE
        sh.Control = b
        self.dp.add(sh)
        # V8.4-P02: „H“ in der Beschriftungszeile rechts über dem Pfeil. Unter Windows übermalte das Feld beim
        # Darüberfahren einen überlappenden Knopf; hier überlappt nichts.
        bw, bh = 650, LABEL_H  # V8.8 (LES-01): etwas größer (600×380 → 650×400)
        sh.Size, sh.Position = Size(bw, bh), Point(x + w - bw, y - LABEL_H + 10)
        self.on_ctl(form, b, "XActionListener", "actionPerformed", "HeuteSetzen")
        KNOPF_SUBS.add("HeuteSetzen")
        HFORMS.add(form.Name)
        return b

    def checkbox(self, form, data, label, x, y, w, bg=CARD, name=None, h=None, multiline=False, size=10.5):
        m = self.doc.createInstance("com.sun.star.form.component.CheckBox")
        m.Name = name or self._name("chk")
        m.DataField = data
        m.Label = label
        self._font(m, size, False, TEXT)
        m.BackgroundColor = bg
        m.TriState = False
        try:
            m.VisualEffect = 2
            m.VerticalAlign = VA_TOP if multiline else VA_MIDDLE
            m.MultiLine = multiline
        except Exception:
            pass
        if h is None:
            # B1-R3: mehr Höhe, damit Unterlängen der Beschriftung unter Windows sichtbar bleiben (W3)
            return self._place(form, m, x, y + LABEL_H - 60, w, FIELD_H + 120)
        return self._place(form, m, x, y, w, h)

    def button(self, form, label, x, y, w, h=780, style="primary", url=None, sub=None, name=None, size=10.5, help=None):
        m = self.doc.createInstance("com.sun.star.form.component.CommandButton")
        m.Name = name or self._name("btn")
        m.Label = label
        fg, bg, bold, align = STYLES[style]
        self._font(m, size, bold, fg)
        m.BackgroundColor = bg
        m.Tabstop = False
        m.FocusOnClick = False
        try:
            m.Align = align
        except Exception:
            pass
        if help:
            m.HelpText = help
        if url:
            m.ButtonType, m.TargetURL = BT_URL, url
        else:
            m.ButtonType = BT_PUSH
        self._place(form, m, x, y, w, h)
        if sub:
            self.on_ctl(form, m, "XActionListener", "actionPerformed", sub)
            KNOPF_SUBS.add(sub)
        return m

    def grid(self, form, cols, x, y, w, h, name=None, readonly=False, sub_dblclick=None, rowh=75):
        """cols: (Art, Datenfeld, Kopf, Breite in 1/10 mm, Ausrichtung[, Zusatzeigenschaften]). rowh in 1/10 mm."""
        g = self.doc.createInstance("com.sun.star.form.component.GridControl")
        g.Name = name or self._name("grid")
        self._font(g, 10.5, False, TEXT)
        g.BackgroundColor = 0xFFFFFF
        # B1.1-R3: flacher Rand in Hellgrau; Windows zeichnete sonst links eine dunkle Kante
        # V8.3-N18: Windows zeichnete trotz flachem Rand links eine dunkle Kante → kein Rand; die Karte rahmt
        g.Border = 0
        g.HasNavigationBar = False
        # V8.5-N18 (Nico 15.10. 20:10, Variante „links“): Markierungsspalte in allen Rastern. Ohne sie zeichnete
        # Windows links unter den Zeilen eine dunkle Kante; mit ihr ist der linke Rand überall gleich.
        g.HasRecordMarker = True
        g.RowHeight = rowh
        try:
            g.HeaderBackgroundColor = CARD
            g.HeaderTextColor = TEXT2
            g.GridLineColor = 0xE5E5EA
        except Exception:
            pass
        for i, col in enumerate(cols):
            kind, data, head, width, align = col[:5]
            extra = col[5] if len(col) > 5 else {}
            c = g.createColumn("NumericField" if kind == "CurrencyField" else kind)  # V8.1-P1 (B-L4)
            c.DataField, c.Label, c.Width = data, head, width
            try:
                c.Align = align
            except Exception:
                pass
            if kind == "DateField":
                c.DateFormat = 2
                c.Dropdown = not readonly
                c.StrictFormat = True
            if kind == "CurrencyField":
                c.DecimalAccuracy, c.ShowThousandsSeparator = 2, True
            if kind == "CheckBox":
                c.TriState = False
            for k, v in extra.items():
                setattr(c, k, v)
            if readonly:
                try:
                    c.ReadOnly = True
                except Exception:
                    pass
            g.insertByIndex(i, c)
        self._place(form, g, x, y, w, h)
        if sub_dblclick:
            self.on_ctl(form, g, "XMouseListener", "mousePressed", sub_dblclick)
        return g

    # ------------------------------------------------------------ Abschluss
    def alle_modelle(self, cont=None):
        cont = cont if cont is not None else self.forms
        for i in range(cont.getCount()):
            m = cont.getByIndex(i)
            if m.supportsService("com.sun.star.form.component.Form"):
                yield from self.alle_modelle(m)
            else:
                yield m

    def startbereich(self, code):
        """Nur Seitenleiste und Startbereich sind beim Laden sichtbar (auch ohne Makros, V8-R1b)."""
        for m in self.alle_modelle():
            p = m.Name.split("_", 1)[0]
            m.EnableVisible = p in ("NA", code, code[:2])
        cur = self.doc.Text.createTextCursor()
        cur.PageDescName = "B_" + code

    def formbereiche(self):
        """Konstante für das Makro: Formular:Bereich,Bereich;… (nur Formulare mit Steuerelementen)."""
        return ";".join(f"{f}:{','.join(sorted(a))}" for f, a in self.form_areas.items())

    def save_odt(self, path, start="ST"):
        self.hintergruende()
        self.startbereich(start)
        self.doc.storeToURL(uno.systemPathToFileUrl(path), (pv("FilterName", "writer8"),))
        self.doc.close(True)


class Grid:
    """Raster für Karten mit Beschriftung über dem Feld."""

    def __init__(self, x, y, w, gap=500):
        self.x, self.y, self.w, self.gap = x, y, w, gap

    def half(self, i):
        hw = (self.w - self.gap) // 2
        return self.x + i * (hw + self.gap), hw


def card_height(rows, extra=0):
    return CARD_HEAD + rows * ROW + extra + 250


def lsql(typ):
    return f'SELECT "Wert" FROM "Liste" WHERE "Typ" = \'{typ}\' ORDER BY "Sort"'
