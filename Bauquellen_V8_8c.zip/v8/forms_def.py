"""V8 · Ein Formular „Vertragsregister" mit allen Bereichen (Ein-Fenster-Anwendung).
Bereiche: NA Seitenleiste · ST Übersicht · LI Verträge · VE Vertrag (VE1 Vertrag, VE2 Leistungen & Protokoll,
VE3 Dokumente & Verlauf) · LE Leistungen · PR Rechnungsverlauf · PA Partner · VT Vertretung (VT1, VT2) ·
AE Änderungen · AB Ablage prüfen · EI Einstellungen · HI Hilfe."""
from formkit import (FormDoc, Grid, card_height, lsql, PAGE_W, PAGE_H, BG, CARD, TEXT, TEXT2, RED, ORANGE,
                     GRAY_BG, ROW, LABEL_H, FIELD_H, CARD_HEAD, SQLPT, ACCENT)
import anleitung
import formkit
import uno

FORM_NAME = "Vertragsregister"
X0, XR = 5900, 31700
CW = XR - X0
GAP = 500
TOP2 = 2550            # Inhalt unter Titel und Untertitel
BOTTOM = 17450         # Unterkante der Karten (V8.6e: 17100 → 17450, Nico 16.10. „Außenkanten nach außen“)
PAD = 550


def ls(sql, bound=0):
    return dict(ListSourceType=SQLPT, ListSource=(sql,), BoundColumn=bound)


def vorschlag(spalte):
    """V8.2b-M20: bisher benutzte Werte einer Protokollspalte, zuletzt benutzte zuerst."""
    return (f'SELECT "{spalte}" FROM "Ereignis" WHERE "{spalte}" > \'\' GROUP BY "{spalte}" '
            'ORDER BY MAX("ID") DESC')


def kopf(fd, f, titel, unter=None):
    # V8.5: Titel nur so breit wie nötig – eine breite Beschriftung lag über „Exportieren“ (Vertretung) und schluckte den Klick
    fd.text(f, titel, X0, 450, min(14000, 620 * len(titel) + 600), 1100, 22, True, TEXT, BG, name="lblTitel")
    if unter:
        fd.text(f, unter, X0, 1500, 16000, 550, 10.5, False, TEXT2, BG, name="lblUnter")


def rechts(fd, f, items, y=600, h=800):
    """Knöpfe rechtsbündig: (Beschriftung, Breite, Stil, Makro, Name, Hilfe)."""
    x = XR
    for label, w, style, sub, name, *hilfe in items:
        x -= w
        fd.button(f, label, x, y, w, h, style=style, sub=sub, name=name, size=10.5, help=(hilfe[0] if hilfe else None))
        x -= 300


def chips(fd, f, x, y, items, prefix):
    """Filterknöpfe: (Beschriftung, Makro, Name)."""
    for label, sub, name in items:
        w = 900 + 200 * len(label)
        fd.button(f, label, x, y, w, 700, style="card", sub=sub, name=name, size=10)
        x += w + 250
    return x


def suche(fd, f, x, y, w, sub, help):
    m = fd.field(f, "TextField", None, None, x, y, w, size=11.5, h=800, name="txtSuche", help=help)
    fd.on_ctl(f, m, "XTextListener", "textChanged", sub)
    fd.text(f, "⌕", x + w + 100, y, 600, 800, 14, False, TEXT2, BG, name="lblLupe")
    return m


def hinweis(fd, f, text):
    # V8.7 (HIL-01): kein eigenes Label je Ansicht mehr; der Text ist der Standardhinweis der gemeinsamen Zeile NA_lblHinweis
    formkit.HINWEIS[fd.area] = text


# V8.7: Standardhinweise für Ansichten ohne hinweis()-Aufruf (Entwurf, Abnahme durch Nico)
STANDARD_HINWEIS = {
    "ST": "Oben die Kennzahlen, darunter was offen ist und die nächsten Termine. Doppelklick auf eine Zeile öffnet den Vertrag.",
    "VE1": "Felder ändern, dann „Sichern“. Pflichtfelder tragen *. „H“ trägt das heutige Datum ein.",
    "VE2": "Leistungen dieses Vertrags und ihr Protokoll. Zeile anklicken zeigt die Einzelheiten.",
    "VE3": "Dokumente und Änderungsverlauf dieses Vertrags. Doppelklick auf ein Dokument öffnet es.",
    "VE4": "Angaben zum Dienstvertrag. Ändern, dann „Sichern“.",
    "PA": "Partner links wählen, Angaben rechts ändern und „Sichern“. Darunter stehen die Verträge des Partners.",
    "VT1": "Wer wen vertritt: Eintrag links wählen, Zeitraum und Person rechts eintragen, dann „Sichern“.",
    "VT2": "Was sich während einer Vertretung geändert hat. Doppelklick öffnet den Vertrag.",
    "AE": "Alle Änderungen mit Name und Zeit. Doppelklick auf eine Zeile öffnet den Vertrag.",
    "EI": "Einstellungen gelten nach „Sichern“. Hinweiszeile, Farben und Tooltip: Karte „Beispieldaten und Anzeige“.",
    "HI": "Anleitung zum Register. „Alles durchsuchen“ links findet auch Stellen in der Hilfe.",
}  # V8.6e: 17300 → 17500


def fehler(fd, f):
    fd.on_form(f, "com.sun.star.sdb.XSQLErrorListener", "errorOccured", "DbFehler")


# ================================================================ NA Seitenleiste
NAV = [("ST", "Übersicht"), ("LI", "Verträge"), ("LE", "Leistungen"), ("PR", "Rechnungsverlauf"),
       ("PA", "Partner"), ("VT", "Vertretung"), ("AE", "Änderungen"), ("AB", "Ablage prüfen"),
       ("PK", "Papierkorb & Sicherung"), ("EI", "Einstellungen"), ("HI", "Hilfe")]
NAV_SUB = {"ST": "NavStart", "LI": "NavListe", "LE": "NavLeistung", "PR": "NavProtokoll", "PA": "NavPartner",
           "VT": "NavVertretung", "AE": "NavAenderung", "AB": "NavAbgleich", "PK": "NavPapierkorb", "EI": "NavEinstellung", "HI": "NavHilfe"}


def seitenleiste(fd, nav):
    fd.bereich("NA")
    fd.card(250, 250, 5300, 17500)
    m = fd.text(nav, "Vertragsregister", 700, 600, 4500, 800, 15, True, TEXT, CARD, name="lblApp")
    m.Tag = "ST"           # aktueller Bereich (Zustand im Tag, B1-R15)
    fd.field(nav, "TextField", "Heute", None, 700, 1350, 4500, readonly=True, size=9.5, color=TEXT2, h=550,
             name="txtHeute")
    y = 2300
    for code, label in NAV:
        if code == "EI":
            continue   # V8.2b-M04: Einstellungen als Zahnrad unten rechts
        fd.button(nav, "   " + label, 500, y, 4800, 820, style="navaktiv" if code == "ST" else "nav",
                  sub=NAV_SUB[code], name="nav" + code, size=10.5)
        y += 950
    # V8.5-E23: Gesamtsuche unter den Ansichten; Enter oder ⌕ sucht überall
    fd.text(nav, "ALLES DURCHSUCHEN", 700, 11950, 4500, 450, 8.5, True, TEXT2, CARD, name="lblGesamt")
    g = fd.field(nav, "TextField", None, None, 500, 12400, 4000, size=10.5, h=750, name="txtGesamt",
                 help="Suchbegriff eingeben und Enter drücken: sucht in Verträgen, Leistungen, Protokoll, Partnern, Dokumenten und Hilfe.")
    fd.on_ctl(nav, g, "XKeyListener", "keyPressed", "SucheTaste")
    fd.button(nav, "\U0001F50D", 4550, 12400, 750, 750, style="secondary", sub="SucheKnopf", name="btnGesamt", size=11,
              help="Überall suchen")
    # V8.8c (M5): Schalter direkt unter der Suche, Vorgabe an
    ca = fd.checkbox(nav, "", "Ähnliche Schreibweisen", 500, 13250, 4800, name="chkAehnlich", h=550, size=9)
    ca.State = 1
    ca.HelpText = "An: findet auch ä/ae, ß/ss, c/k/č, doppelte Buchstaben. Groß/klein und Leerzeichen sind immer egal."
    # V8.7 (ORI-01): Statuszeile nur noch bei abgeschalteter Hinweiszeile; zweizeilig, damit nichts abgeschnitten wird
    fd.text(nav, "", 700, 14850, 4500, 950, 8.5, False, TEXT2, CARD, name="lblStatus", multiline=True, top=True)
    # V8.7 (HIL-01): gemeinsame Hinweiszeile unter den Karten, in jeder Ansicht (Bereich NA, Text setzt das Makro)
    fd.text(nav, "", X0, 17500, CW, 450, 9.5, False, TEXT2, BG, name="lblHinweis")
    fd.text(nav, "", 700, 15850, 4500, 500, 8.5, False, TEXT2, CARD, name="lblBenutzer")
    # V8.2b-M04: Fußzeile – „Beenden" so breit wie die Schrift, rechts daneben Käfer (Melden) und Zahnrad (Einstellungen)
    # V8.6e: Fußzeile 450 tiefer (16200 → 16650), näher an die Unterkante der Karte
    fd.button(nav, "Beenden", 500, 16650, 1900, 820, style="navrotm", sub="AppBeenden", name="btnBeenden",
              help="Speichert und schließt das Vertragsregister.")
    # V8.1-P6: Fehler/Wunsch melden (danach angeklicktes Element wird erfasst)
    fd.button(nav, "\U0001F41E", 3500, 16650, 820, 820, style="navsym", sub="MeldenStart", name="btnMelden", size=14,
              help="Fehler oder Wunsch melden: hier klicken, dann auf das Element, um das es geht. Danach Kommentar schreiben.")
    fd.button(nav, "\u2699", 4480, 16650, 820, 820, style="navsym", sub=NAV_SUB["EI"], name="navEI", size=16,
              help="Einstellungen")


# ================================================================ ST Übersicht
def uebersicht(fd, nav):
    fd.bereich("ST")
    kopf(fd, nav, "Übersicht")
    fd.field(nav, "TextField", "BeispielHinweis", None, X0, 1500, 16000, readonly=True, size=10, color=ORANGE, bg=BG,
             h=550, name="txtBeispiel")
    # V8.5-Q8 (Nico 15.10. 15:11): kein „Neuer Vertrag“ in der Übersicht; Notes-Knopf schließt rechts ab
    rechts(fd, nav, [("Termine (nach Notes) exportieren", 7200, "secondary", "NotesExport", "btnNotes",
                      "Schreibt alle Fristen als Kalenderdatei (.ics) für HCL Notes."),
                     ("Statistik", 3000, "secondary", "StatistikErzeugen", "btnStatistik",
                      "Erstellt eine Calc-Datei mit Pivot-Tabelle und Diagramm (Kosten je Vertragsart; Gliederung in Calc frei wählbar)."),
                     ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport",
                      "Öffnet die Aufgaben und Termine als Tabelle.")])
    y, h = TOP2, 2800
    w = (CW - 4 * GAP) // 5
    kpis = [("NumericField", "Rot", "Verträge mit dringendem Handlungsbedarf  ›", RED, "kpiRot", "KpiRot"),
            ("NumericField", "Gelb", "To-do  ›", ORANGE, "kpiGelb", "KpiGelb"),
            ("NumericField", "LRot", "Leistungen & Rechnungen prüfen  ›", RED, "kpiLeistung", "KpiLeistung"),
            ("NumericField", "Aktiv", "Aktive Verträge  ›", TEXT, "kpiAktiv", "KpiAktiv"),
            ("TextField", "JahreskostenText", "Kosten dieses Jahr (Prognose)  ›", TEXT, "kpiKosten", "KpiAktiv")]
    for i, (kind, data, cap, col, name, sub) in enumerate(kpis):
        cx = X0 + i * (w + GAP)
        fd.card(cx, y, w, h)
        # V8.1-P1 (B-L3): Zahl höher, Beschriftung mit Platz für zwei Zeilen in Segoe UI (Windows)
        m = fd.field(nav, kind, data, None, cx + 450, y + 250, w - 900, readonly=True, size=26, bold=True, color=col,
                     h=1200, name=name)
        fd.on_ctl(nav, m, "XMouseListener", "mousePressed", sub)
        c = fd.text(nav, cap, cx + 450, y + 1480, w - 900, 1200, 10, False, TEXT2, name="cap" + name, top=True,
                    multiline=True)
        fd.on_ctl(nav, c, "XMouseListener", "mousePressed", sub)
    y2 = y + h + GAP
    h2 = BOTTOM - y2
    lw = 14300
    rw = CW - GAP - lw
    fd.card(X0, y2, lw, h2)
    # V8.2a (M03): „Offen" statt „Heute zu tun"; (M01) Stufe im Klartext; (E25) Sortierknopf im Kartenkopf
    fd.section(nav, "Offen", X0 + PAD, y2 + 350, 6000)
    fh = fd.form("Heute", "V_HeuteListe", 0, order='"Prio", "Bezug"', readonly=True, nav=False)
    fd.button(nav, "Sortiert: Dringlichkeit ▾", X0 + lw - PAD - 5200, y2 + 230, 5200, 650, style="plain",
              sub="SortHeute", name="btnSortHeute", size=10,
              help="Klick wechselt die Sortierung: Dringlichkeit, Datum, Vertrag, Aufgabe.")
    fd.grid(fh, [("TextField", "Symbol", "Stufe", 240, 0), ("TextField", "DatumText", "Datum", 200, 0),
                 ("TextField", "Aufgabe", "Aufgabe", 450, 0), ("TextField", "Gegenstand", "Vertrag", 470, 0)],
            X0 + 300, y2 + 950, lw - 600, h2 - 1250, name="gridHeute", readonly=True,
            sub_dblclick="StartDoppelklick")
    rx = X0 + lw + GAP
    fd.card(rx, y2, rw, h2)
    fd.section(nav, "Nächste Termine (12 Monate)", rx + PAD, y2 + 350, rw - 2 * PAD - 4600)
    ff = fd.form("Fristen", "V_FristenListe", 0, order='"Datum", "ID"', readonly=True, nav=False)
    fd.button(nav, "Sortiert: Datum ▾", rx + rw - PAD - 4300, y2 + 230, 4300, 650, style="plain",
              sub="SortFristen", name="btnSortFristen", size=10,
              help="Klick wechselt die Sortierung: Datum, Vertrag, Termin.")
    fd.grid(ff, [("TextField", "DatumText", "Datum", 220, 0), ("TextField", "Art", "Termin", 330, 0),
                 ("TextField", "Gegenstand", "Vertrag", 470, 0)],
            rx + 300, y2 + 950, rw - 600, h2 - 1250, name="gridFristen", readonly=True,
            sub_dblclick="StartDoppelklick")
    # V8.4-P05: Hinweis unten entfällt (Erklärung im Tooltip der Liste)


# ================================================================ LI Verträge
def vertraege(fd):
    f = fd.form("Liste", 'SELECT * FROM "V_Liste"', 2, order='"Prio", "Bezug"', readonly=True, nav=False)
    fd.bereich("LI")
    kopf(fd, f, "Verträge", "Alle Verträge mit Stand und Jahreskosten")
    rechts(fd, f, [("Neuer Vertrag", 3800, "primary", "NeuerVertrag", "btnNeu"),
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport",
                    "Öffnet die gezeigten Verträge als Tabelle.")])
    suche(fd, f, X0, TOP2, 7000, "ListeSuchen", "Suche nach Gegenstand, Partner, Nummer, Art oder Kostenstelle")
    chips(fd, f, X0 + 8000, TOP2 + 50, [("Alle", "LiChipAlle", "chipAlle"),
                                        ("Dringender Handlungsbedarf!", "LiChipRot", "chipRot"),
                                        ("To-do", "LiChipGelb", "chipGelb"), ("Aktiv", "LiChipAktiv", "chipAktiv"),
                                        ("Beendet", "LiChipBeendet", "chipBeendet")], "chip")
    y2 = TOP2 + 1250
    fd.card(X0, y2, CW, BOTTOM - y2)
    fd.grid(f, [("TextField", "Nr", "Nr.", 270, 0), ("TextField", "Gegenstand", "Gegenstand", 600, 0),
                ("TextField", "Partner", "Partner", 430, 0), ("TextField", "Art", "Art", 230, 0),
                ("TextField", "Anzeige", "Stand", 660, 0), ("TextField", "JahreskostenText", "Jahreskosten", 280, 2)],
            X0 + 300, y2 + 300, CW - 600, BOTTOM - y2 - 600, name="gridListe", readonly=True,
            sub_dblclick="ListeDoppelklick", rowh=80)
    hinweis(fd, f, "Doppelklick auf eine Zeile öffnet den Vertrag.")


# ================================================================ VE Vertrag
def vertrag(fd):
    f = fd.form("Vertrag", "Vertrag", 0, order='"ID"')
    fd.on_form(f, "XRowSetApproveListener", "approveRowChange", "VertragPruefen")
    fd.on_form(f, "XRowSetListener", "rowChanged", "VertragGespeichert")
    fehler(fd, f)
    info = fd.form("Info", "V_Vertrag", 0, parent=f, master=["ID"], detail=["ID"], readonly=True, nav=False)
    for ev in ("loaded", "reloaded"):
        fd.on_form(info, "XLoadListener", ev, "InfoFaerben")
    fd.on_form(info, "XRowSetListener", "cursorMoved", "InfoFaerben")
    ent = fd.form("Entscheidung", "Entscheidung", 0, parent=f, master=["ID"], detail=["VertragID"],
                  order='"Datum" DESC, "ID" DESC')
    fd.on_form(ent, "XRowSetApproveListener", "approveRowChange", "EntscheidungPruefen")
    fd.on_form(ent, "XRowSetListener", "rowChanged", "EntscheidungGespeichert")
    fehler(fd, ent)
    dok = fd.form("Dokumente", "Dokument", 0, parent=f, master=["ID"], detail=["VertragID"],
                  order='"Datum" DESC, "ID" DESC')
    fd.on_form(dok, "XRowSetApproveListener", "approveRowChange", "DokumentPruefen")
    fd.on_form(dok, "XRowSetListener", "rowChanged", "NachDatensatz")
    fehler(fd, dok)
    lei = fd.form("Leistung", "Leistung", 0, parent=f, master=["ID"], detail=["VertragID"], order='"ID"')
    fd.on_form(lei, "XRowSetApproveListener", "approveRowChange", "LeistungPruefen")
    fd.on_form(lei, "XRowSetListener", "rowChanged", "LeistungGespeichert")
    fehler(fd, lei)
    linfo = fd.form("LeistungInfo", "V_Leistung", 0, parent=lei, master=["ID"], detail=["ID"], readonly=True, nav=False)
    for ev in ("loaded", "reloaded"):
        fd.on_form(linfo, "XLoadListener", ev, "LeistungInfoFaerben")
    fd.on_form(linfo, "XRowSetListener", "cursorMoved", "LeistungInfoFaerben")
    lprot = fd.form("LeistungProt", "V_Ereignis", 0, parent=lei, master=["ID"], detail=["LeistungID"],
                    order='"Datum" DESC, "ID" DESC', readonly=True, nav=False)
    verl = fd.form("Verlauf", "V_AenderungListe", 0, parent=f, master=["ID"], detail=["VertragID"],
                   order='"Zeit" DESC, "ID" DESC', readonly=True, nav=False)

    # ---------------- Kopf (alle Unterbereiche)
    fd.bereich("VE")
    b = fd.button(f, "‹  Übersicht", X0 - 200, 450, 4000, 750, style="plain", sub="VertragZurueck", name="btnZurueck")
    b.Tag = "ST"
    # V8.1-P2: Platz für lange Vertragsnummern (12_132_01_2026)
    fd.field(info, "TextField", "Nr", None, X0 + 3900, 560, 3000, readonly=True, size=10, color=TEXT2, bg=BG, h=550,
             name="txtNr")
    fd.button(f, "‹", X0 + 7000, 450, 900, 750, style="secondary", sub="PfeilZurueck", name="btnPfeilZurueck", size=13,
              help="Vorheriger Vertrag der Liste")
    fd.button(f, "›", X0 + 8050, 450, 900, 750, style="secondary", sub="PfeilVor", name="btnPfeilVor", size=13,
              help="Nächster Vertrag der Liste")
    fd.text(f, "", X0 + 9150, 450, 3000, 750, 10, False, TEXT2, BG, name="lblPosition")
    rechts(fd, f, [("Sichern", 2800, "primary", "AlleSichern", "btnSichern", "Speichert alle Änderungen."),
                   ("Neuer Vertrag", 3400, "secondary", "NeuerVertrag", "btnNeu"),
                   ("Vertrag löschen", 3500, "danger", "VertragLoeschen", "btnLoeschen",  # V8.2b-M14
                    "Löscht den Vertrag mit Leistungen, Protokoll und Dokumenten (mit Rückfrage)."),
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")], y=450, h=780)
    # V8.8 (EIN-03): sichtbare Beschriftung mit Pflichtstern; Feld dafür 400 tiefer und etwas flacher (1400/1000 → 1630/950)
    fd.field(f, "TextField", "Gegenstand", "Gegenstand *", X0, 1230, 15500, size=18, bold=True, h=950, bg=BG,
             name="txtGegenstand", help="Pflichtfeld: was der Vertrag betrifft, z. B. Kaffeemaschine Küche 2. OG",
             MaxTextLen=120)
    fd.field(info, "TextField", "Anzeige", None, X0 + 16000, 1720, CW - 16000, readonly=True, size=11, bold=True,
             bg=GRAY_BG, h=760, name="txtAnzeige", Align=1)
    x = X0
    for code, label, w, sub in (("1", "Vertrag", 3000, "TabVertrag"), ("2", "Leistungen & Protokoll", 5200, "TabLeistungen"),
                                ("3", "Dokumente & Verlauf", 4800, "TabDokumente")):
        fd.button(f, label, x, 2700, w, 750, style="tabaktiv" if code == "1" else "tab", sub=sub, name="tab" + code,
                  size=10.5)
        x += w + 150
    # V8.3-LEC: Reiter „Dienstvertrag“ nur bei Vertragsart „Dienstvertrag (LEC)“. Präfix VEt: Zweig lässt ihn liegen,
    # DienstReiterZeigen blendet ihn ein.
    alt, fd.area = fd.area, "VEt"
    fd.button(f, "Dienstvertrag", x, 2700, 3600, 750, style="tab", sub="TabDienst", name="tab4", size=10.5,
              help="Angaben zum Dienstvertrag: Angestellte/r, Dienstort, Sollstunden, Stundenlohn, Bereitschaft.")
    fd.area = alt
    top = 3800

    # ---------------- VE1 Vertrag
    fd.bereich("VE1")
    cw = (CW - 2 * GAP) // 3
    cx = [X0 + i * (cw + GAP) for i in range(3)]

    def card(col, y, rows, title, extra=0):
        h = card_height(rows, extra)
        fd.card(cx[col], y, cw, h)
        fd.section(f, title, cx[col] + PAD, y + 330, cw - 2 * PAD)
        return y + CARD_HEAD, h, Grid(cx[col] + PAD, 0, cw - 2 * PAD)

    def row(y0, r):
        return y0 + r * ROW

    y = top
    # V8.1-P2: Karte „Vertrag" mit Vertragsnummer (4 Zeilen); Kosten und Wertsicherung teilen sich eine Karte
    y0, h, g = card(0, y, 4, "Vertrag")
    x0, hw = g.half(0); x1, _ = g.half(1)
    fd.field(f, "TextField", "Vertragsnummer", "Vertragsnummer", x0, row(y0, 0), hw, name="txtVertragsnummer",
             MaxTextLen=40, help="Eure Nummer, z. B. 12_132_01_2026. Leer: vorläufig „unbenannt 7“.")
    fd.field(f, "ListBox", "Status", "Status", x1, row(y0, 0), hw, name="lbStatus", DefaultSelection=(0,),
             **ls(lsql("Status")))
    fd.field(f, "ListBox", "PartnerID", "Vertragspartner *", g.x, row(y0, 1), g.w - 2300, name="lbPartner",
             help="Pflichtfeld. Fehlt der Partner in der Liste, klick auf „Neu“.",
             **ls('SELECT "Name", "ID" FROM "Partner" ORDER BY "Name"', 1))
    fd.button(f, "Neu", g.x + g.w - 2000, row(y0, 1) + LABEL_H, 2000, FIELD_H, style="secondary",
              sub="PartnerNeu", name="btnPartnerNeu", help="Neuen Partner anlegen")
    m_art = fd.field(f, "ListBox", "Art", "Vertragsart", x0, row(y0, 2), hw, name="lbArt", **ls(lsql("Vertragsart")))
    fd.on_ctl(f, m_art, "XItemListener", "itemStateChanged", "ArtGeaendert")  # V8.3-LEC
    fd.field(f, "TextField", "PartnerVertragsnr", "Nr. beim Partner", x1, row(y0, 2), hw, MaxTextLen=40)
    # V8.3-E30: Der neue Vertrag nennt den alten (Vorgänger). „›“ springt zum alten, rechts der Link zum Nachfolger.
    fd.field(f, "ListBox", "ErsetztVertrag", "Ersetzt Vertrag", x0, row(y0, 3), hw - 800, name="lbErsetzt",
             help="Der alte Vertrag, den dieser hier ablöst. „›“ öffnet ihn.",
             **ls('SELECT \'(keiner)\', NULL FROM RDB$DATABASE UNION ALL '
                  'SELECT "Nr" || \' \' || "Gegenstand", "ID" FROM "V_Liste"', 1))
    fd.button(f, "›", x0 + hw - 700, row(y0, 3) + LABEL_H, 700, FIELD_H, style="secondary", sub="ZumVorgaenger",
              name="btnVorgaenger", size=13, help="Öffnet den alten Vertrag, den dieser ersetzt.")
    fd.text(f, "Wird ersetzt durch", x1, row(y0, 3), hw, LABEL_H, 8.5, False, TEXT2, CARD, name="lblNachfolgerL")
    lk = fd.text(f, "", x1, row(y0, 3) + LABEL_H, hw, FIELD_H, 10.5, False, ACCENT, CARD, name="lblNachfolger")
    lk.FontUnderline = 1
    lk.HelpText = "Öffnet den neuen Vertrag, der diesen ersetzt."
    fd.on_ctl(f, lk, "XMouseListener", "mousePressed", "ZumNachfolger")
    y += h + 300
    y0, h, g = card(0, y, 4, "Kosten und Wertsicherung")
    fd.field(f, "CurrencyField", "Kosten", "Betrag je Zahlung (€)", x0, row(y0, 0), hw, ValueMin=0, ValueMax=9999999)
    fd.field(f, "ListBox", "Intervall", "Zahlungsintervall", x1, row(y0, 0), hw, **ls(lsql("Zahlungsintervall")))
    fd.field(f, "TextField", "Kostenstelle", "Kostenstelle", x0, row(y0, 1), hw, MaxTextLen=40)
    fd.field(info, "TextField", "JahreskostenText", "Jahreskosten", x1, row(y0, 1), hw, readonly=True, bold=True,
             name="txtJahreskosten")
    fd.checkbox(f, "Wertsicherung", "Wertgesichert", x0, row(y0, 2), hw)
    fd.field(f, "DateField", "NaechsteAnpassung", "Anpassung am", x1, row(y0, 2), hw, name="txtIndex")
    fd.field(f, "TextField", "IndexBasis", "Index und Basis", g.x, row(y0, 3), g.w,
             help="z. B. VPI 2020, Basis März 2024, Schwelle 3 %", MaxTextLen=80)

    y = top
    y0, h, g = card(1, y, 3, "Laufzeit und Kündigung")
    x0, hw = g.half(0); x1, _ = g.half(1)
    fd.field(f, "DateField", "Beginn", "Beginn", x0, row(y0, 0), hw)
    fd.field(f, "DateField", "ErstesEnde", "Erstes Ende", x1, row(y0, 0), hw,
             help="Ende der ersten Laufzeit. Leer lassen bei unbefristeten Verträgen.")
    fd.checkbox(f, "AutoVerl", "Verlängert sich", x0, row(y0, 1), hw)
    fd.field(f, "NumericField", "VerlMonate", "Verlängerung (Monate)", x1, row(y0, 1), hw, ValueMin=1, ValueMax=120,
             help="Pflicht, wenn der Vertrag sich automatisch verlängert.")
    fd.field(f, "NumericField", "FristMonate", "Kündigungsfrist (Mon.)", x0, row(y0, 2), hw, ValueMin=0, ValueMax=120,
             help="Kündigungsfrist in Monaten", name="txtFrist")
    fd.field(f, "ListBox", "KTermin", "Kündbar zum", x1, row(y0, 2), hw, **ls(lsql("Kuendigungstermin")))
    y += h + 300
    y0, h, g = card(1, y, 2, "Berechnet")
    fd.field(info, "DateField", "Ende", "Aktuelles Laufzeitende", x0, row(y0, 0), hw, readonly=True, bold=True,
             name="txtEnde")
    fd.field(info, "DateField", "Stichtag", "Kündigungsstichtag", x1, row(y0, 0), hw, readonly=True, bold=True,
             name="txtStichtag", help="Bis zu diesem Tag muss die Kündigung beim Partner eingelangt sein.")
    fd.field(info, "DateField", "Frueh", "Frühestes Ende", x0, row(y0, 1), hw, readonly=True,
             bold=True, name="txtFrueh")
    fd.field(info, "DateField", "NaechstePruefung", "Nächste Prüfung", x1, row(y0, 1), hw, readonly=True, bold=True,
             name="txtNPruef")
    y += h + 300
    y0, h, g = card(1, y, 2, "Ablage und Prüfung")
    fd.field(f, "TextField", "Ordner", "Ordner im Ablagepfad", g.x, row(y0, 0), g.w - 2300, name="txtOrdner",
             help="Name des Vertragsordners: Vertragsnummer_Gegenstand_Partner, z. B. 12_132_01_2026_Kaffeemaschine_Partner", MaxTextLen=160)
    fd.button(f, "Öffnen", g.x + g.w - 2000, row(y0, 0) + LABEL_H, 2000, FIELD_H, style="secondary",
              sub="OrdnerOeffnen", name="btnOrdner", help="Öffnet den Vertragsordner im Explorer.")
    fd.field(f, "DateField", "ZuletztGeprueft", "Zuletzt geprüft", x0, row(y0, 1), hw, name="txtGeprueft")
    fd.button(f, "Heute geprüft", x1, row(y0, 1) + LABEL_H, hw, FIELD_H, style="secondary", sub="HeuteGeprueft",
              name="btnGeprueft")

    y = top
    h = CARD_HEAD + 1000 + 4 * ROW + 250 + 950  # V8.5-Q1: Zeile für Sichern/Verwerfen
    fd.card(cx[2], y, cw, h)
    fd.section(f, "Entscheidung zum Stichtag", cx[2] + PAD, y + 330, cw - 2 * PAD)
    g = Grid(cx[2] + PAD, 0, cw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    by = y + CARD_HEAD
    # V8.2c-N09: „+ Andere" entfällt; andere Entscheidungen (neu verhandeln) direkt unten in der Liste wählen
    bw = (g.w - 300) // 2
    fd.button(ent, "Verlängern", g.x, by, bw, 750, style="secondary", sub="EntscheidungVerlaengern", name="btnVerl",
              help="Trägt „verlängern“ mit heutigem Datum und deinem Namen ein. Der Vertrag läuft nach dem Stichtag weiter.")
    fd.button(ent, "Kündigen", g.x + bw + 300, by, bw, 750, style="danger", sub="EntscheidungKuendigen", name="btnKuend",
              help="Trägt „kündigen“ ein. Danach „Kündigung versandt am“ und später „Bestätigung erhalten am“ ausfüllen.")
    y0 = by + 1000
    fd.field(ent, "ListBox", "Art", "Entscheidung", x0, row(y0, 0), hw, name="lbEntArt", **ls(lsql("Entscheidung")),
             help="Hier auch „neu verhandeln“ wählen. Datum und Name füllen sich beim Sichern selbst.")
    fd.field(ent, "DateField", "Datum", "Entschieden am", x1, row(y0, 0), hw, name="txtEntDatum")
    fd.field(ent, "TextField", "Verantwortlich", "Verantwortlich", x0, row(y0, 1), hw, MaxTextLen=60)
    fd.field(ent, "ListBox", "Versandart", "Versandart", x1, row(y0, 1), hw, **ls(lsql("Versandart")))
    fd.field(ent, "DateField", "Versandt", "Versandt am", x0, row(y0, 2), hw, name="txtVersandt")
    fd.field(ent, "DateField", "Bestaetigt", "Bestätigt am", x1, row(y0, 2), hw, name="txtBestaetigt")
    fd.field(ent, "TextField", "Beleg", "Beleg (Ordner _korrespondenz)", g.x, row(y0, 3), g.w, MaxTextLen=200)
    # V8.5-Q1 (Nico 15.10. 14:51): eigene Knöpfe für Entscheidung und Korrespondenz
    fd.button(ent, "Verwerfen", g.x, row(y0, 4) + 150, bw, 650, style="danger", sub="EntscheidungVerwerfen",
              name="btnEntVerwerfen", size=10,
              help="Nimmt ungesicherte Eingaben in dieser Karte zurück (Entscheidung, Versand, Bestätigung, Beleg).")
    fd.button(ent, "Sichern", g.x + bw + 300, row(y0, 4) + 150, bw, 650, style="secondary", sub="AlleSichern",  # V8.8 KOH-01
              name="btnEntSichern", size=10, help="Speichert alle Änderungen.")
    y += h + 300
    h = BOTTOM - 600 - y
    fd.card(cx[2], y, cw, h)
    fd.section(f, "Bemerkung", cx[2] + PAD, y + 330, cw - 2 * PAD)
    fd.field(f, "TextField", "Bemerkung", None, cx[2] + PAD, y + CARD_HEAD, cw - 2 * PAD, h=h - CARD_HEAD - 400,
             MultiLine=True, VScroll=True, name="txtBemerkung", MaxTextLen=2000)

    # ---------------- VE2 Leistungen & Protokoll
    fd.bereich("VE2")
    lw = 12000  # V8.1-P1 (B-L5), V8.2b-B1: breitere Leistungsliste (Windows schnitt Spalten ab)
    ya, ha = top, 7700
    fd.card(X0, ya, lw, ha)
    fd.section(f, "Vertragsleistungen", X0 + PAD, ya + 330, 5000)
    fd.button(lei, "+ Neu", X0 + lw - PAD - 4300, ya + 230, 2200, 650, style="secondary", sub="LeistungNeu",
              name="btnLeiNeu", size=10, help="Neue Vertragsleistung erfassen")
    fd.button(lei, "Löschen", X0 + lw - PAD - 1900, ya + 230, 1900, 650, style="danger", sub="LeistungLoeschen",
              name="btnLeiLoeschen", size=10)
    # V8.2a (M08, M22): Spalte „!" (!! dringend, ! offen) und Abdeckung; Marke wird beim Öffnen des Vertrags berechnet
    fd.grid(lei, [("TextField", "Marke", "!", 50, 1, dict(HelpText="!! = dringend, ! = offen. Was zu tun ist: unten bei „Stand“.")),
                  ("TextField", "Bezeichnung", "Leistung", 430, 0), ("TextField", "Objekt", "Objekt", 330, 0),
                  ("TextField", "Abdeckung", "Abdeckung", 270, 0)],
            X0 + 300, ya + CARD_HEAD, lw - 600, ha - CARD_HEAD - 300, name="gridLeistung", readonly=True)
    dx, dw = X0 + lw + GAP, CW - lw - GAP
    fd.card(dx, ya, dw, ha)
    fd.section(f, "Detail zur Leistung", dx + PAD, ya + 330, dw - 2 * PAD - 2700, name="lblLeiDetail")
    fd.button(lei, "Sichern", dx + dw - PAD - 2400, ya + 230, 2400, 650, style="secondary", sub="AlleSichern",  # V8.8 KOH-01
              name="btnLeiSichern", size=10)
    g = Grid(dx + PAD, 0, dw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    y0 = ya + CARD_HEAD
    fd.field(lei, "TextField", "Bezeichnung", "Leistung *", x0, row(y0, 0), hw, name="txtLeistung", MaxTextLen=120,
             help="Was der Partner schuldet, z. B. Entkalkung")
    fd.field(lei, "TextField", "Objekt", "Objekt", x1, row(y0, 0), hw, MaxTextLen=120, help="Gerät oder Ort")
    fd.field(lei, "TextField", "Umfang", "Umfang / Bedingung", x0, row(y0, 1), hw, MaxTextLen=200,
             help="z. B. 2× jährlich, Mo–Fr, inkl. Anfahrt")
    fd.field(lei, "TextField", "Quelle", "Quelle (Dokument, Punkt)", x1, row(y0, 1), hw, MaxTextLen=120)
    fd.field(lei, "ListBox", "Abdeckung", "Abdeckung *", x0, row(y0, 2), hw, name="lbAbdeckung",
             help="inklusive = im Preis · kostenpflichtig = extra verrechnet · ausgeschlossen = nicht Teil des Vertrags",
             **ls(lsql("Abdeckung")))
    fd.field(lei, "CurrencyField", "GrenzeJahr", "Kostengrenze (€ je Kalenderjahr)", x1, row(y0, 2), hw, ValueMin=0,
             ValueMax=9999999, help="Nur bei inklusive: bis zu diesem Betrag je Jahr frei. Leer = ohne Grenze.")
    fd.field(lei, "NumericField", "SollStunden", "Erledigungszeit Soll (Stunden)", x0, row(y0, 3), hw, ValueMin=0,
             ValueMax=9999)
    fd.field(lei, "NumericField", "IntervallMonate", "Intervall (Monate)", x1, row(y0, 3), hw, ValueMin=1, ValueMax=120,
             help="Nur bei wiederkehrenden Leistungen, z. B. 6 für halbjährlich.")
    fd.field(lei, "TextField", "Bemerkung", "Bemerkung", g.x, row(y0, 4), g.w, MaxTextLen=1000)
    yb, hb = ya + ha + 300, BOTTOM - (ya + ha + 300)
    fd.card(X0, yb, lw, hb)
    fd.section(f, "Stand", X0 + PAD, yb + 330, lw - 2 * PAD, name="lblLeiStand")
    g = Grid(X0 + PAD, 0, lw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    y0 = yb + CARD_HEAD
    fd.field(linfo, "TextField", "ZuletztText", "Zuletzt erbracht", x0, row(y0, 0), hw, readonly=True, bold=True,
             name="txtZuletzt")
    fd.field(linfo, "TextField", "NaechsteText", "Nächste Fälligkeit", x1, row(y0, 0), hw, readonly=True, bold=True,
             name="txtNaechste")
    fd.field(linfo, "CurrencyField", "RechnungenJahr", "Rechnungen lfd. Jahr (€)", x0, row(y0, 1), hw, readonly=True,
             name="txtRechJahr")
    fd.field(linfo, "CurrencyField", "NVJahr", "nicht verrechenbar (€)", x1, row(y0, 1), hw, readonly=True,
             name="txtNVJahr")
    fd.field(linfo, "TextField", "Anzeige", None, g.x, row(y0, 2) + 200, g.w - 5400, readonly=True, bold=True, bg=GRAY_BG,
             h=760, name="txtLAnzeige", Align=1)
    # V8.2a (M15): führt direkt zum offenen Eintrag (Rechnung prüfen, Leistungsanfall ohne Erledigung); sonst unsichtbar
    fd.button(lei, "Offenen Eintrag öffnen ›", g.x + g.w - 5100, row(y0, 2) + 200, 5100, 760, style="danger",  # V8.2b-B1
              sub="OffenenEintragOeffnen", name="btnOffenes", size=10,
              help="Öffnet den ältesten offenen Eintrag dieser Leistung in „Rechnungsverlauf“.")
    fd.card(dx, yb, dw, hb)
    # V8.2b-B1: schmalere rechte Karte → kürzere Knöpfe, mehr Platz für den Titel
    fd.section(f, "Protokoll", dx + PAD, yb + 330, dw - 2 * PAD - 6400, name="lblLeiProt")
    fd.button(lei, "Heute erbracht", dx + dw - PAD - 6200, yb + 230, 3300, 650, style="secondary", sub="LeistungErbracht",
              name="btnErbracht", size=10, help="Trägt „Leistung erbracht“ mit dem heutigen Datum ein.")
    fd.button(lei, "+ Eintrag", dx + dw - PAD - 2600, yb + 230, 2600, 650, style="primary", sub="EintragNeuFuerLeistung",
              name="btnEintragNeu", size=10, help="Leistungsanfall, Rechnung, Reklamation oder Leistung erfassen")
    fd.grid(lprot, [("TextField", "DatumText", "Datum", 190, 0), ("TextField", "Art", "Ereignis", 210, 0),
                    ("TextField", "Beschreibung", "Beschreibung", 340, 0),
                    ("CurrencyField", "Betrag", "Betrag (€)", 170, 2), ("TextField", "Stand", "Stand", 330, 0)],
            dx + 300, yb + CARD_HEAD, dw - 600, hb - CARD_HEAD - 300, name="gridProt", readonly=True,
            sub_dblclick="LeistungProtDoppelklick")

    # ---------------- VE4 Dienstvertrag (LEC)  V8.3-LEC
    fd.bereich("VE4")
    cw4 = (CW - GAP) // 2
    h4 = card_height(4)
    fd.card(X0, top, cw4, h4)
    fd.section(f, "Dienstvertrag (LEC)", X0 + PAD, top + 330, cw4 - 2 * PAD)
    g4 = Grid(X0 + PAD, 0, cw4 - 2 * PAD)
    a0, hw4 = g4.half(0); a1, _ = g4.half(1)
    y4 = top + CARD_HEAD
    fd.field(f, "TextField", "Angestellte", "Angestellte/r", g4.x, y4, g4.w, MaxTextLen=100, name="txtAngestellte",
             help="Name der/des Angestellten, z. B. Amra Hodžić. Vertragspartner im Register ist der Platzhalter „LEC (HRMO)“.")
    fd.field(f, "TextField", "Dienstort", "Dienstort", a0, y4 + ROW, hw4, MaxTextLen=100,
             help="Wo die Arbeit geleistet wird, z. B. Camp Butmir, Sarajevo.")
    fd.field(f, "CurrencyField", "SollStundenMonat", "Sollstunden je Monat", a1, y4 + ROW, hw4, ValueMin=0, ValueMax=744,
             help="Vereinbarte Arbeitsstunden je Monat, z. B. 173,33.")
    fd.field(f, "CurrencyField", "Stundenlohn", "Stundenlohn", a0, y4 + 2 * ROW, hw4, ValueMin=0, ValueMax=99999,
             help="Lohn je Stunde laut Vertrag, z. B. 9,50.")
    fd.checkbox(f, "Bereitschaft", "Bereitschaft vereinbart", a1, y4 + 2 * ROW, hw4, name="chkBereitschaft")
    fd.field(f, "CurrencyField", "BereitschaftStunden", "Bereitschaftsstunden je Monat", a0, y4 + 3 * ROW, hw4,
             ValueMin=0, ValueMax=744, name="numBereitschaft",
             help="Nur bei Bereitschaft: vereinbarte Bereitschaftsstunden je Monat, z. B. 40.")
    fd.text(f, "Kosten und Laufzeit stehen im Reiter „Vertrag“. Der Partner ist dort „LEC (HRMO)“.",
            X0 + PAD, top + h4 + 200, CW - 2 * PAD, 600, 9, False, TEXT2, BG, name="lblDienstHinweis")

    # ---------------- VE3 Dokumente & Verlauf
    fd.bereich("VE3")
    hw2 = (CW - GAP) // 2
    fd.card(X0, top, hw2, BOTTOM - top)
    fd.section(f, "Dokumente", X0 + PAD, top + 330, 4000)
    fd.button(dok, "Datei öffnen", X0 + hw2 - PAD - 3400, top + 230, 3400, 650, style="secondary", sub="DokumentOeffnen",
              name="btnDokOeffnen", size=10, help="Öffnet die markierte Datei aus dem Vertragsordner.")
    # V8.2c-N13: Tooltips mit Beispielen in allen Spaltenköpfen
    fd.grid(dok, [("DateField", "Datum", "Datum", 220, 0, dict(HelpText="Datum des Dokuments, z. B. Tag der Unterschrift: 15.03.2024")),
                  ("TextField", "Bezeichnung", "Bezeichnung", 400, 0,
                   dict(HelpText="Was das Dokument ist, z. B. Grundvertrag, Nachtrag 1, Preisblatt 2025, AGB")),
                  ("TextField", "Datei", "Datei", 400, 0,
                   dict(HelpText="Dateiname im Vertragsordner, z. B. 2024-03-15_Grundvertrag.pdf. „Datei öffnen“ öffnet sie.")),
                  ("CheckBox", "Gilt", "Gilt", 80, 1,
                   dict(HelpText="Haken = gültige Fassung. Ältere Fassungen ohne Haken bleiben zur Nachvollziehbarkeit stehen."))],
            X0 + 300, top + CARD_HEAD, hw2 - 600, BOTTOM - top - CARD_HEAD - 1000, name="gridDok")
    fd.text(f, "Neues Dokument: unterste leere Zeile. „Gilt“ = gültige Fassung.",
            X0 + PAD, BOTTOM - 900, hw2 - 2 * PAD, 600, 9, False, TEXT2, name="lblDokHinweis")
    rx = X0 + hw2 + GAP
    fd.card(rx, top, hw2, BOTTOM - top)
    fd.section(f, "Änderungsverlauf dieses Vertrags", rx + PAD, top + 330, 9000)
    fd.grid(verl, [("TextField", "ZeitText", "Zeit", 330, 0), ("TextField", "Benutzer", "Wer", 220, 0),
                   ("TextField", "Was", "Was", 260, 0), ("TextField", "Alt", "Vorher", 170, 0),
                   ("TextField", "Neu", "Nachher", 170, 0)],
            rx + 300, top + CARD_HEAD, hw2 - 600, BOTTOM - top - CARD_HEAD - 300, name="gridVerlauf", readonly=True)


# ================================================================ LE Leistungen
def leistungen(fd):
    f = fd.form("Leistungen", 'SELECT * FROM "V_Leistung"', 2, order='"Prio", "Naechste", "Nr"', readonly=True, nav=False)
    fd.bereich("LE")
    kopf(fd, f, "Leistungen", "Alle vereinbarten Leistungen mit Fälligkeit und Stand")
    # V8.5-Q7 (Nico 15.10. 15:10): „Neue Leistung“ ganz rechts, Vertrag im Dialog wählen
    rechts(fd, f, [("Neue Leistung", 3800, "primary", "LeistungNeuAusListe", "btnNeu",
                    "Neue Leistung erfassen. Zuerst wählst du den Vertrag."),
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    suche(fd, f, X0, TOP2, 7000, "LeistungenSuchen", "Suche nach Vertrag, Leistung, Objekt oder Abdeckung")
    chips(fd, f, X0 + 8000, TOP2 + 50, [("Alle", "LeChipAlle", "chipAlle"),
                                        ("Dringender Handlungsbedarf!", "LeChipRot", "chipRot"),
                                        ("To-do", "LeChipGelb", "chipGelb")], "chip")
    y2 = TOP2 + 1250
    fd.card(X0, y2, CW, BOTTOM - y2)
    # V8.2a (M08, M22): Spalte „!" und Abdeckung mit „✕ ausgeschlossen"
    fd.grid(f, [("TextField", "Marke", "!", 70, 1, dict(HelpText="!! = dringend, ! = offen. Was zu tun ist: Spalte „Stand“.")),
                ("TextField", "Nr", "Nr.", 260, 0), ("TextField", "Gegenstand", "Vertrag", 420, 0),
                ("TextField", "Bezeichnung", "Leistung", 420, 0), ("TextField", "Objekt", "Objekt", 330, 0),
                ("TextField", "AbdeckungText", "Abdeckung", 260, 0), ("TextField", "NaechsteText", "Nächste", 200, 0),
                ("TextField", "Anzeige", "Stand", 520, 0)],
            X0 + 300, y2 + 300, CW - 600, BOTTOM - y2 - 600, name="gridLeistungen", readonly=True,
            sub_dblclick="LeistungenDoppelklick", rowh=80)
    hinweis(fd, f, "Doppelklick öffnet den Vertrag bei dieser Leistung. Dort erfasst du auch, wann eine Leistung erbracht wurde.")


# ================================================================ PR Rechnungsverlauf
def protokoll(fd):
    lst = fd.form("Protokoll", 'SELECT * FROM "V_Ereignis"', 2, order='"Datum" DESC, "ID" DESC', readonly=True, nav=False)
    fd.on_form(lst, "XRowSetListener", "cursorMoved", "ProtokollAuswahl")
    e = fd.form("Ereignis", "Ereignis", 0, filter='"ID" = -1')
    fd.on_form(e, "XRowSetApproveListener", "approveRowChange", "EreignisPruefen")
    fd.on_form(e, "XRowSetListener", "rowChanged", "EreignisGespeichert")
    fehler(fd, e)
    einfo = fd.form("EreignisInfo", "V_Ereignis", 0, parent=e, master=["ID"], detail=["ID"], readonly=True, nav=False)
    for ev in ("loaded", "reloaded"):
        fd.on_form(einfo, "XLoadListener", ev, "EreignisInfoFaerben")
    fd.on_form(einfo, "XRowSetListener", "cursorMoved", "EreignisInfoFaerben")
    fd.bereich("PR")
    kopf(fd, lst, "Rechnungsverlauf", "Leistungen, Leistungsanfälle, Reklamationen und Rechnungen mit Stand")
    rechts(fd, lst, [("Neuer Eintrag", 3800, "primary", "EintragNeu", "btnNeu",
                      "Leistungsanfall, Rechnung, Reklamation oder erbrachte Leistung erfassen"),
                     ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    lw = 12300
    suche(fd, lst, X0, TOP2, lw - 800, "ProtokollSuchen", "Suche nach Vertrag, Leistung, Rechnungsnummer oder Text")
    chips(fd, lst, X0, TOP2 + 1000, [("Offen", "PrChipOffen", "chipOffen"), ("Rechnungen", "PrChipRechnung", "chipRechnung"),
                                     ("Leistungsanfälle", "PrChipStoerung", "chipStoerung"), ("Alle", "PrChipAlle", "chipAlle")],
          "chip")
    y2 = TOP2 + 1950
    fd.card(X0, y2, lw, BOTTOM - y2)
    # V8.4-P01: Spalte „!“ wie bei den Leistungen
    fd.grid(lst, [("TextField", "Symbol", "!", 50, 1, dict(HelpText="!! = dringend (lange offen), ! = offen. Was zu tun ist: rechts „Offen“.")),
                  ("TextField", "DatumText", "Datum", 190, 0), ("TextField", "Nr", "Nr.", 250, 0),
                  ("TextField", "Leistung", "Leistung", 260, 0), ("TextField", "Art", "Ereignis", 180, 0),
                  ("TextField", "Stand", "Stand", 240, 0)],
            X0 + 300, y2 + 300, lw - 600, BOTTOM - y2 - 1300, name="gridProtokoll", readonly=True, rowh=80)
    # V8.4-E21: Schalter für stornierte Einträge (nicht gebunden, steuert den Filter)
    sw = fd.checkbox(lst, "", "Stornierte Einträge zeigen (✕)", X0 + 300, BOTTOM - 900, lw - 600, name="chkStorno", h=600)
    sw.State = 1
    sw.HelpText = "Haken weg = stornierte Einträge ausblenden. Sie zählen ohnehin nicht."
    fd.on_ctl(lst, sw, "XItemListener", "itemStateChanged", "StornoSchalter")
    dx, dw = X0 + lw + GAP, CW - lw - GAP
    fd.card(dx, TOP2, dw, BOTTOM - TOP2)
    fd.section(lst, "Eintrag", dx + PAD, TOP2 + 330, 2200)
    bx = dx + dw - PAD
    # V8.5-Q6: vier Plätze – Verwerfen | Sichern | Korrigieren | Zum Vertrag. Präfix PRv: Zweig lässt die beiden
    # Zustandsknöpfe liegen, SichernFarbe blendet sie ein.
    for label, w, style, sub, name in (("Zum Vertrag ›", 2700, "secondary", "EintragZumVertrag", "btnZumVertrag"),
                                       ("Korrigieren", 2300, "secondary", "EintragKorrigieren", "btnKorrigieren"),
                                       ("Sichern", 1900, "primary", "AlleSichern", "btnSichern"),
                                       ("Verwerfen", 2100, "danger", "EintragVerwerfen", "btnVerwerfen")):
        bx -= w
        if name == "btnVerwerfen":
            alt, fd.area = fd.area, "PRv"
            fd.button(e, label, bx, TOP2 + 230, w, 650, style=style, sub=sub, name=name, size=10,
                      help="Verwirft die ungesicherten Eingaben in diesem Eintrag.")
            fd.area = alt
        elif name == "btnKorrigieren":
            alt, fd.area = fd.area, "PRv"
            fd.button(e, label, bx, TOP2 + 230, w, 650, style=style, sub=sub, name=name, size=10,
                      help="Falscher Wert? Ändere ihn hier und klick auf „Korrigieren“. Das Register sichert die neuen Werte, "
                           "hält den bisherigen Stand als stornierte Zeile (✕) fest und verknüpft beide. "
                           "Neu ausgestellte Rechnung: neue Nummer und Betrag hier eintragen, dann „Korrigieren“ – keine neue Zeile.")
            fd.area = alt
        else:
            fd.button(e, label, bx, TOP2 + 230, w, 650, style=style, sub=sub, name=name, size=10)
        bx -= 200
    g = Grid(dx + PAD, 0, dw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    y0 = TOP2 + CARD_HEAD
    r = lambda i: y0 + i * ROW
    fd.field(e, "ListBox", "LeistungID", "Leistung *", g.x, r(0), g.w, name="lbLeistung",
             help="Zu welcher vereinbarten Leistung gehört der Eintrag?",
             **ls('SELECT "Auswahl", "ID" FROM "V_Leistung" ORDER BY "Nr", "Bezeichnung"', 1))
    fd.field(e, "DateField", "Datum", "Datum * / Rechnungsdatum", x0, r(1), hw, name="txtDatum")
    fd.field(e, "ListBox", "Art", "Ereignis *", x1, r(1), hw, name="lbArt", **ls(lsql("Ereignis")))
    fd.field(e, "TextField", "Beschreibung", "Beschreibung", g.x, r(2), g.w, MaxTextLen=500, name="txtBeschreibung")
    dwid = (hw - 300) * 6 // 10
    twid = hw - 300 - dwid
    fd.field(e, "DateField", "GemeldetAm", "Gemeldet am", x0, r(3), dwid, name="txtGemAm")
    fd.field(e, "TimeField", "GemeldetUm", "um", x0 + dwid + 300, r(3), twid, name="txtGemUm",
             help="Uhrzeit als SS:MM, z. B. 08:30")
    fd.field(e, "DateField", "ReagiertAm", "Erledigt am", x1, r(3), dwid, name="txtReaAm")
    fd.field(e, "TimeField", "ReagiertUm", "um", x1 + dwid + 300, r(3), twid, name="txtReaUm")
    fd.field(e, "TextField", "Rechnungsnr", "Rechnungsnr.", x0, r(4), hw, MaxTextLen=40)
    fd.field(e, "CurrencyField", "Betrag", "Rechnungsbetrag (€)", x1, r(4), hw, ValueMin=0, ValueMax=9999999,
             name="txtBetrag")
    fd.field(e, "DateField", "FreigabeDatum", "Freigegeben am", x0, r(5), hw, name="txtFreiDatum")
    fd.field(e, "CurrencyField", "FreigabeBetrag", "Freigegebener Betrag (€)", x1, r(5), hw, ValueMin=0,
             ValueMax=9999999, name="txtFreiBetrag", help="Höchstens Betrag minus nicht verrechenbar. Rechnung zurückgewiesen: 0 eintragen.")
    # V8.2b-M20 (E20): Vorschläge = bisher benutzte Werte, zuletzt benutzte zuerst
    fd.field(e, "ComboBox", "FreigabeVon", "Freigegeben von", x0, r(6), hw, MaxTextLen=60, name="cbFreiVon",
             help="Auswählen oder neu schreiben. Leer lassen = dein Name (wenn ein Freigabedatum eingetragen ist).",
             ListSourceType=SQLPT, ListSource=vorschlag("FreigabeVon"))
    # V8.8c (M10): nur über den Knopf „Stornieren“ setzbar
    cs = fd.checkbox(e, "Storniert", "Storniert", x1, r(6), hw, name="chkStorniert")
    cs.Enabled = False
    fd.field(e, "ComboBox", "Beleg", "Beleg / Ablageort", x0, r(7), hw, MaxTextLen=200, name="cbBeleg",
             help="Auswählen oder neu schreiben. Die Liste zeigt bisher benutzte Ablageorte.",
             ListSourceType=SQLPT, ListSource=vorschlag("Beleg"))
    fd.field(e, "TextField", "Bemerkung", "Bemerkung", x1, r(7), hw, MaxTextLen=1000)
    fd.field(e, "TextField", "Bearbeiter", "Bearbeiter (füllt sich selbst)", x0, r(8), hw, MaxTextLen=60)
    fd.field(einfo, "CurrencyField", "MaxFreigabe", "Höchstens freigeben (€)", x1, r(8), hw, readonly=True, bold=True,
             name="txtMaxFrei")
    fd.field(einfo, "TextField", "Pruefergebnis", "Stand", x0, r(9), hw, readonly=True, bold=True, bg=GRAY_BG,
             name="txtPruef")
    fd.field(einfo, "TextField", "Offen", "Offen", x1, r(9), hw, readonly=True, bold=True, color=RED, name="txtOffen")
    # V8.8c (M10): Stornieren unten links – wirkt rückwirkend wie Korrigieren, aber ohne Nachfolgeeintrag
    fd.button(e, "Stornieren", dx + PAD, BOTTOM - 1000, 2600, 650, style="danger", sub="EintragStornieren",
              name="btnStornieren", size=10,
              help="Setzt den Eintrag auf „Storniert“: Er bleibt im Verlauf (✕), zählt aber nicht mehr und ist nicht mehr offen. "
                   "Wie Korrigieren, nur ohne neuen Stand.")
    hinweis(fd, lst, "Zeile links anklicken zeigt den Eintrag. Falsch erfasst? Wert ändern, dann „Korrigieren“ (alter Stand bleibt ✕).")


# ================================================================ PA Partner
def partner(fd):
    f = fd.form("Partner", "Partner", 0, order='"Name"')
    fd.on_form(f, "XRowSetApproveListener", "approveRowChange", "PartnerPruefen")
    fd.on_form(f, "XRowSetListener", "rowChanged", "PartnerGespeichert")
    fd.on_form(f, "XRowSetListener", "cursorMoved", "PartnerStandSpaeter")  # V8.4-P03
    fehler(fd, f)
    pv_ = fd.form("PartnerVertraege", 'SELECT * FROM "V_Liste"', 2, parent=f, master=["ID"], detail=["PartnerID"],
                  order='"Nr"', readonly=True, nav=False)
    fd.bereich("PA")
    kopf(fd, f, "Partner", "Vertragspartner mit Kontakt und Hotline")
    rechts(fd, f, [("Neuer Partner", 3800, "primary", "PartnerNeuKlick", "btnNeu"),
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    lw = 8000
    # V8.3-E29: zwei Listen (eigene Leseformulare); ein Klick stellt das Partnerformular auf den gewählten Partner
    pa = fd.form("PartnerAktiv", 'SELECT "ID", "Name" FROM "V_PartnerStand" WHERE "Stand" = \'aktiv\'', 2,
                 order='"Name"', readonly=True, nav=False)
    pi = fd.form("PartnerInaktiv", 'SELECT "ID", "Name", "Name" || \' (\' || "Stand" || \')\' AS "Anzeige" '
                 'FROM "V_PartnerStand" WHERE "Stand" <> \'aktiv\'', 2, order='"Name"', readonly=True, nav=False)
    fd.on_form(pa, "XRowSetListener", "cursorMoved", "PartnerListeGewaehlt")
    fd.on_form(pi, "XRowSetListener", "cursorMoved", "PartnerListeGewaehlt")
    hi = 3700
    ha = BOTTOM - TOP2 - hi - 300
    fd.card(X0, TOP2, lw, ha)
    # V8.8c (M4): Spaltenkopf sagt, was die Liste enthält; die Überschrift darüber entfällt (mehr Zeilen sichtbar)
    fd.grid(pa, [("TextField", "Name", "Mit laufendem Vertrag", 720, 0)], X0 + 300, TOP2 + 300, lw - 600, ha - 600,
            name="gridPartner", readonly=True, rowh=80, sub_dblclick="PartnerGridKlick")
    yi = TOP2 + ha + 300
    fd.card(X0, yi, lw, hi)
    gi = fd.grid(pi, [("TextField", "Anzeige", "Ohne laufenden Vertrag", 720, 0, dict(CharColor=TEXT2))], X0 + 300, yi + 300,
                 lw - 600, hi - 600, name="gridPartnerInaktiv", readonly=True, rowh=80,
                 sub_dblclick="PartnerGridKlick")  # Klick auf die schon aktuelle Zeile löst kein cursorMoved aus
    gi.TextColor = TEXT2
    rx, rw = X0 + lw + GAP, CW - lw - GAP
    hc = card_height(5, 700)
    fd.card(rx, TOP2, rw, hc)
    fd.section(f, "Angaben", rx + PAD, TOP2 + 330, 4000)
    bx = rx + rw - PAD
    for label, w, style, sub, name in (("Löschen", 2000, "danger", "PartnerLoeschen", "btnLoeschen"),
                                       ("Sichern", 2200, "primary", "AlleSichern", "btnSichern")):
        bx -= w
        fd.button(f, label, bx, TOP2 + 230, w, 650, style=style, sub=sub, name=name, size=10)
        bx -= 250
    g = Grid(rx + PAD, 0, rw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    y0 = TOP2 + CARD_HEAD
    fd.field(f, "TextField", "Name", "Name *", g.x, y0, g.w, size=12, bold=True, name="txtName", MaxTextLen=120)
    # V8.4-P03: benannte Felder; die Beschriftung zeigt „(Stand: Datum)“ der letzten Änderung (PartnerStand)
    fd.field(f, "TextField", "Ansprechperson", "Ansprechperson", x0, y0 + ROW, hw, MaxTextLen=80, name="txtAnsprech")
    fd.field(f, "TextField", "Telefon", "Telefon", x1, y0 + ROW, hw, MaxTextLen=40, name="txtTelefon")
    fd.field(f, "TextField", "Email", "E-Mail", x0, y0 + 2 * ROW, hw, MaxTextLen=100, name="txtEmail")
    fd.field(f, "TextField", "Hotline", "Hotline bei Störung", x1, y0 + 2 * ROW, hw, MaxTextLen=60, name="txtHotline")
    fd.field(f, "TextField", "Kundennr", "Unsere Kundennummer", x0, y0 + 3 * ROW, hw, MaxTextLen=40, name="txtKundennr")
    fd.field(f, "TextField", "Bemerkung", "Bemerkung", g.x, y0 + 4 * ROW, g.w, h=FIELD_H + 700, MultiLine=True,
             MaxTextLen=1000)
    yv = TOP2 + hc + 300
    fd.card(rx, yv, rw, BOTTOM - yv)
    fd.section(f, "Verträge mit diesem Partner", rx + PAD, yv + 330, 8000)
    fd.grid(pv_, [("TextField", "Nr", "Nr.", 270, 0), ("TextField", "Gegenstand", "Gegenstand", 650, 0),
                  ("TextField", "Anzeige", "Stand", 640, 0)],
            rx + 300, yv + CARD_HEAD, rw - 600, BOTTOM - yv - CARD_HEAD - 300, name="gridPVertraege", readonly=True,
            sub_dblclick="PartnerVertragDoppelklick")


# ================================================================ VT Vertretung
CHECKLISTE = [
    "1. Die Vertretung öffnet das Vertragsregister an ihrem PC. Der Ordner der Datei ist dort als vertrauenswürdig eingetragen (Hilfe › Einrichtung).",
    "2. Der Name der Vertretung steht in LibreOffice: Extras › Optionen › LibreOffice › Benutzerdaten. Er erscheint in der Änderungsspur.",
    "3. Die Vertretung erreicht den Ablagepfad. Der Knopf „Öffnen“ bei einem Vertrag zeigt den Ordner.",
    "4. Eine Sicherung ist erstellt: Papierkorb & Sicherung › Jetzt sichern.",
    "5. Die Übersicht ist gemeinsam durchgesehen. Die offenen Punkte stehen im zweiten Reiter.",
    "6. Die Termine sind nach Notes exportiert und im Kalender der Vertretung.",
]


def vertretung(fd):
    f = fd.form("Vertretung", "Vertretung", 0, order='"Ab" DESC, "ID" DESC')
    fd.on_form(f, "XRowSetApproveListener", "approveRowChange", "VertretungPruefen")
    fd.on_form(f, "XRowSetListener", "rowChanged", "VertretungGespeichert")
    fd.on_form(f, "XRowSetListener", "cursorMoved", "HNachWechsel")  # V8.2b-M19
    fehler(fd, f)
    pk = fd.form("Punkte", "VertretungPunkt", 0, parent=f, master=["ID"], detail=["VertretungID"],
                 order='"ErledigtAm", "BisWann", "ID"')
    fd.on_form(pk, "XRowSetApproveListener", "approveRowChange", "PunktPruefen")
    fd.on_form(pk, "XRowSetListener", "rowChanged", "NachDatensatz")
    fehler(fd, pk)
    va = fd.form("VtAenderung", "V_AenderungVertretung", 0, parent=f, master=["ID"], detail=["VertretungID"],
                 order='"Zeit" DESC', readonly=True, nav=False)
    fd.bereich("VT")
    kopf(fd, f, "Vertretung", "Übergabe, Checkliste, offene Punkte und alle Änderungen während der Vertretung")
    rechts(fd, f, [("Neue Vertretung", 4000, "primary", "VertretungNeu", "btnNeu"),
                   ("Termine (nach Notes) exportieren", 7200, "secondary", "NotesExport", "btnNotes"),  # V8.5-Q8
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    lw = 7000
    fd.card(X0, TOP2, lw, BOTTOM - TOP2)
    fd.section(f, "Vertretungen", X0 + PAD, TOP2 + 330, 4000)
    fd.grid(f, [("DateField", "Ab", "Ab", 200, 0), ("DateField", "Bis", "Bis", 200, 0),
                ("TextField", "Vertreter", "Vertretung", 230, 0)],
            X0 + 300, TOP2 + CARD_HEAD, lw - 600, BOTTOM - TOP2 - CARD_HEAD - 300, name="gridVertretung", readonly=True)
    rx, rw = X0 + lw + GAP, CW - lw - GAP
    rechts_x = rx
    for code, label, w, sub in (("1", "Übergabe & Checkliste", 5200, "TabUebergabe"),
                                ("2", "Offene Punkte & Änderungen", 6000, "TabPunkte")):
        fd.button(f, label, rechts_x, TOP2, w, 750, style="tabaktiv" if code == "1" else "tab", sub=sub, name="tab" + code)
        rechts_x += w + 150
    bx = XR
    for label, w, style, sub, name in (("Löschen", 2000, "danger", "VertretungLoeschen", "btnLoeschen"),
                                       ("Sichern", 2200, "primary", "AlleSichern", "btnSichern")):
        bx -= w
        fd.button(f, label, bx, TOP2, w, 750, style=style, sub=sub, name=name, size=10)
        bx -= 250
    top = TOP2 + 1050

    fd.bereich("VT1")
    hw2 = (rw - GAP) // 2
    hu = card_height(3)
    fd.card(rx, top, hw2, hu)
    fd.section(f, "Übergabe", rx + PAD, top + 330, 4000)
    g = Grid(rx + PAD, 0, hw2 - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    y0 = top + CARD_HEAD
    fd.field(f, "TextField", "Vertreter", "Vertretung durch *", g.x, y0, g.w, name="txtVertreter", MaxTextLen=80)
    fd.field(f, "DateField", "Ab", "Ab *", x0, y0 + ROW, hw, name="txtAb")
    fd.field(f, "DateField", "Bis", "Bis", x1, y0 + ROW, hw)
    fd.field(f, "TextField", "UebergebenVon", "Übergeben von", x0, y0 + 2 * ROW, hw, MaxTextLen=80)
    fd.field(f, "DateField", "UebergabeAm", "Übergabe am", x1, y0 + 2 * ROW, hw)
    yr = top + hu + 300
    hr = BOTTOM - yr
    fd.card(rx, yr, hw2, hr)
    fd.section(f, "Rückgabe", rx + PAD, yr + 330, 4000)
    y0 = yr + CARD_HEAD
    fd.field(f, "DateField", "RueckgabeAm", "Rückgabe am", x0, y0, hw)
    fd.field(f, "DateField", "DurchgesehenAm", "Durchgesehen am", x1, y0, hw,
             help="Die Änderungen stehen im zweiten Reiter.")
    fd.field(f, "TextField", "Bemerkung", "Bemerkung", g.x, y0 + ROW, g.w, h=hr - CARD_HEAD - ROW - LABEL_H - 400,
             MultiLine=True, MaxTextLen=1000)
    cx = rx + hw2 + GAP
    fd.card(cx, top, hw2, BOTTOM - top)
    fd.section(f, "Checkliste vor der Übergabe", cx + PAD, top + 330, 8000)
    yc = top + CARD_HEAD
    hc = (BOTTOM - top - CARD_HEAD - 300) // 6
    for i, t in enumerate(CHECKLISTE, start=1):
        fd.checkbox(f, f"C{i}", t, cx + PAD, yc + (i - 1) * hc, hw2 - 2 * PAD, h=hc - 150, multiline=True, size=10,
                    name=f"chkC{i}")

    fd.bereich("VT2")
    hp = 6200
    fd.card(rx, top, rw, hp)
    fd.section(f, "Offene Punkte bei Übergabe", rx + PAD, top + 330, 8000)
    fd.grid(pk, [("TextField", "Was", "Was ist zu tun", 620, 0),
                 ("ListBox", "VertragID", "Vertrag", 450, 0,
                  dict(ListSourceType=SQLPT, ListSource=('SELECT "Nr" || \' \' || "Gegenstand", "ID" FROM "V_Liste" ORDER BY "Nr"',),
                       BoundColumn=1)),
                 ("DateField", "BisWann", "Bis wann", 220, 0), ("DateField", "ErledigtAm", "Erledigt am", 220, 0)],
            rx + 300, top + CARD_HEAD, rw - 600, hp - CARD_HEAD - 300, name="gridPunkte")
    ya = top + hp + 300
    fd.card(rx, ya, rw, BOTTOM - ya)
    fd.section(f, "Änderungen während der Vertretung (ab Beginn bis Rückgabe)", rx + PAD, ya + 330, 14000)
    fd.grid(va, [("TextField", "ZeitText", "Zeit", 330, 0), ("TextField", "Benutzer", "Wer", 230, 0),
                 ("TextField", "Bereich", "Bereich", 200, 0), ("TextField", "Nr", "Nr.", 260, 0),
                 ("TextField", "Was", "Was", 260, 0), ("TextField", "Alt", "Vorher", 230, 0),
                 ("TextField", "Neu", "Nachher", 230, 0)],
            rx + 300, ya + CARD_HEAD, rw - 600, BOTTOM - ya - CARD_HEAD - 300, name="gridVtAenderung", readonly=True)


# ================================================================ AE Änderungen
def aenderungen(fd):
    f = fd.form("Aenderungen", 'SELECT * FROM "V_AenderungListe"', 2, order='"Zeit" DESC, "ID" DESC', readonly=True,
                nav=False)
    fd.bereich("AE")
    kopf(fd, f, "Änderungen", "Wer hat wann was geändert. LibreOffice zeichnet jede Änderung automatisch auf.")
    rechts(fd, f, [("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    suche(fd, f, X0, TOP2, 7000, "AenderungSuchen", "Suche nach Person, Vertrag, Feld oder Wert")
    chips(fd, f, X0 + 8000, TOP2 + 50, [("Alle", "AeChipAlle", "chipAlle"), ("Letzte 7 Tage", "AeChip7", "chip7"),
                                        ("Letzte 30 Tage", "AeChip30", "chip30")], "chip")
    y2 = TOP2 + 1250
    fd.card(X0, y2, CW, BOTTOM - y2)
    fd.grid(f, [("TextField", "ZeitText", "Zeit", 330, 0), ("TextField", "Benutzer", "Wer", 260, 0),
                ("TextField", "Bereich", "Bereich", 230, 0), ("TextField", "Nr", "Nr.", 270, 0),
                ("TextField", "Gegenstand", "Vertrag", 380, 0), ("TextField", "Was", "Was", 300, 0),
                ("TextField", "Alt", "Vorher", 345, 0), ("TextField", "Neu", "Nachher", 335, 0)],
            X0 + 300, y2 + 300, CW - 600, BOTTOM - y2 - 600, name="gridAenderung", readonly=True, rowh=80)


# ================================================================ AB Ablage prüfen
def abgleich(fd):
    f = fd.form("Abgleich", "AbgleichBefund", 0, order='"Nr", "ID"', readonly=True, nav=False)
    fd.bereich("AB")
    kopf(fd, f, "Ablage prüfen", "Vergleicht die Ordner im Ablagepfad mit dem Register. Interne Vorschläge setzt du per Link um.")
    rechts(fd, f, [("Jetzt prüfen", 3600, "primary", "AbgleichStarten", "btnPruefen"),
                   ("Exportieren", 3300, "secondary", "ExportAnsicht", "btnExport")])
    fd.text(f, "", X0, TOP2, CW, 600, 10.5, False, TEXT, BG, name="lblPfad")
    y2 = TOP2 + 900
    fd.card(X0, y2, CW, BOTTOM - y2)
    # V8.1-P1 (B-L6): Befund und Ort breiter; Ort ist jetzt relativ zum Vertragsordner
    # V8.6-N14: Spalte „Wo“ (intern/extern); Vorschlag der gewählten Zeile als Link unter der Liste
    fd.grid(f, [("TextField", "Nr", "Nr.", 270, 0), ("TextField", "Wo", "Ändern in", 160, 0), ("TextField", "Befund", "Befund", 650, 0),
                ("TextField", "WasTun", "Was tun", 720, 0), ("TextField", "Ort", "Ort", 500, 0),
                ("DateField", "Geaendert", "Geändert", 200, 0)],
            X0 + 300, y2 + 300, CW - 600, BOTTOM - y2 - 1500, name="gridAbgleich", readonly=True,
            sub_dblclick="AbgleichDoppelklick", rowh=80)
    lk = fd.text(f, "", X0 + 300, BOTTOM - 1050, CW - 600, 650, 10.5, False, ACCENT, CARD, name="lnkAktion")
    lk.FontUnderline = 1
    lk.HelpText = "Intern: setzt den Vorschlag nach Rückfrage im Register um. Extern: öffnet den Ordner; Dateien änderst du selbst."
    fd.on_ctl(f, lk, "XMouseListener", "mousePressed", "AbgleichAktion")
    fd.on_form(f, "XRowSetListener", "cursorMoved", "AbgleichAuswahl")
    for ev in ("loaded", "reloaded"):
        fd.on_form(f, "XLoadListener", ev, "AbgleichAuswahl")
    hinweis(fd, f, "Zeile wählen: unten steht der Vorschlag als Link. Doppelklick öffnet den Ordner oder die Datei. Ablageregel: Hilfe › Ablage.")


# ================================================================ PK Papierkorb & Sicherung (V8.1-P4, P5)
PK_H = 6000    # Höhe der Karte Papierkorb; darunter „Stand von Tag … zurückholen" (P5)


def papierkorb(fd):
    f = fd.form("Papierkorb", "V_Papierkorb", 0, order='"Zeit" DESC, "Vorgang" DESC', readonly=True, nav=False)
    fd.bereich("PK")
    kopf(fd, f, "Papierkorb & Sicherung",
         "Gelöschtes bleibt 90 Tage im Papierkorb. Danach löscht das Register es endgültig.")
    y = TOP2
    fd.card(X0, y, CW, PK_H)
    fd.section(f, "Papierkorb", X0 + PAD, y + 330, 5000)
    fd.button(f, "Endgültig löschen", X0 + CW - PAD - 7900, y + 230, 3900, 650, style="danger",
              sub="PapierkorbEndgueltig", name="btnEndgueltig", size=10,
              help="Löscht den markierten Eintrag sofort und für immer (mit Rückfrage).")
    fd.button(f, "Zurückholen", X0 + CW - PAD - 3800, y + 230, 3800, 650, style="primary",
              sub="PapierkorbZurueck", name="btnZurueck", size=10,
              help="Stellt den markierten Eintrag samt allem, was mit ihm gelöscht wurde, wieder her.")
    fd.grid(f, [("TextField", "ZeitText", "Gelöscht am", 300, 0), ("TextField", "Von", "Von", 300, 0),
                ("TextField", "Art", "Was", 260, 0), ("TextField", "Was", "Bezeichnung", 890, 0),
                ("TextField", "Dazu", "Dazu", 460, 0),
                ("NumericField", "TageUebrig", "Tage übrig", 200, 2, {"DecimalAccuracy": 0})],
            X0 + 300, y + CARD_HEAD, CW - 600, PK_H - CARD_HEAD - 300, name="gridPapierkorb", readonly=True,
            rowh=80)
    # ---- V8.1-P5 Stand von Tag … zurückholen
    v = fd.form("Vergleich", "R_Vergleich", 0, order='"Rang", "Tabelle", "DatensatzID"', nav=False)
    v.AllowInserts = False
    v.AllowDeletes = False
    y2 = y + PK_H + 300
    h2 = BOTTOM - y2
    fd.card(X0, y2, CW, h2)
    fd.section(v, "Stand von Tag … zurückholen", X0 + PAD, y2 + 330, 9000)
    fd.button(v, "Sicherungsordner öffnen", X0 + CW - PAD - 8600, y2 + 230, 5000, 650, style="secondary",
              sub="SicherungOrdnerOeffnen", name="btnSichOrdner", size=10)
    fd.button(v, "Jetzt sichern", X0 + CW - PAD - 3400, y2 + 230, 3400, 650, style="secondary", sub="SicherungJetzt",
              name="btnSichJetzt", size=10, help="Schreibt sofort Spiegel und Textsicherung.")
    yr = y2 + 950
    fd.field(v, "ListBox", None, "Stand vom", X0 + PAD, yr, 6500, name="lbStand",
             help="Tagesstand: Stand am Ende dieses Tages. Vollstand: vollständige Sicherung (alle 30 Tage).")
    fd.button(v, "Vergleichen", X0 + PAD + 6700, yr + LABEL_H, 3300, FIELD_H, style="secondary", sub="StandVergleichen",
              name="btnVergleichen", size=10, help="Zeigt, was heute fehlt oder anders ist als an diesem Tag.")
    fd.button(v, "Ausgewählte zurückholen", X0 + CW - PAD - 11300, yr + LABEL_H, 5300, FIELD_H, style="secondary",
              sub="StandAusgewaehlte", name="btnAusgewaehlte", size=10)
    fd.button(v, "Alle fehlenden zurückholen", X0 + CW - PAD - 5800, yr + LABEL_H, 5800, FIELD_H, style="primary",
              sub="StandAlleFehlenden", name="btnAlleFehlenden", size=10,
              help="Holt alles zurück, was es an diesem Tag gab und heute fehlt. Ändert nichts Bestehendes.")
    fd.text(v, "", X0 + PAD, yr + 1250, CW - 2 * PAD, 450, 9, False, TEXT2, CARD, name="lblSichInfo")
    fd.text(v, "Wähle einen Tag und klick auf „Vergleichen“.", X0 + PAD, yr + 1700, CW - 2 * PAD, 450, 10, True, TEXT,
            CARD, name="lblVergleich")
    gy = yr + 2250
    fd.grid(v, [("CheckBox", "Zurueck", "Zurück", 160, 1),
                ("TextField", "Art", "Was", 300, 0, {"ReadOnly": True}),
                ("TextField", "Was", "Bezeichnung", 1300, 0, {"ReadOnly": True}),
                ("TextField", "Unterschied", "Unterschied", 400, 0, {"ReadOnly": True})],
            X0 + 300, gy, CW - 600, y2 + h2 - 300 - gy, name="gridVergleich", rowh=75)
    hinweis(fd, f, "Zurückholen stellt Einträge mit ihrer alten Nummer wieder her. „im Papierkorb“: dort zurückholen.")


# ================================================================ EI Einstellungen
def einstellungen(fd):
    f = fd.form("Einstellung", "Einstellung", 0, filter='"ID" = 1')
    f.AllowInserts = False
    f.AllowDeletes = False
    fd.on_form(f, "XRowSetApproveListener", "approveRowChange", "EinstellungPruefen")
    fd.on_form(f, "XRowSetListener", "rowChanged", "EinstellungGespeichert")
    fehler(fd, f)
    li = fd.form("Listen", "Liste", 0, order='"Typ", "Sort", "Wert"')
    fd.on_form(li, "XRowSetApproveListener", "approveRowChange", "ListePruefen")
    fd.on_form(li, "XRowSetListener", "rowChanged", "NachDatensatz")
    fehler(fd, li)
    fd.bereich("EI")
    kopf(fd, f, "Einstellungen")
    rechts(fd, f, [("Sichern", 2800, "primary", "AlleSichern", "btnSichern")])
    cw = (CW - GAP) // 2
    g = Grid(X0 + PAD, 0, cw - 2 * PAD)
    x0, hw = g.half(0); x1, _ = g.half(1)
    h1 = card_height(4)
    fd.card(X0, TOP2, cw, h1)
    fd.section(f, "Fristen und Warnungen", X0 + PAD, TOP2 + 330, 8000)
    y0 = TOP2 + CARD_HEAD
    num = dict(ValueMin=0, ValueMax=1095)
    # V8.2a (E13, E15, E16): Schwellen der Ampel; kurze Beschriftung, Erklärung im Tooltip
    fd.field(f, "NumericField", "WarnTage", "Kündigung/Ende: rot ab … Tagen", x0, y0, hw, name="numWarn",
             help="Kündigungsstichtag oder Vertragsende in so vielen Tagen oder weniger: rot (Standard 30).", **num)
    fd.field(f, "NumericField", "VorwarnTage", "Kündigung/Ende: gelb ab … Tagen", x1, y0, hw, name="numVorwarn",
             help="Kündigungsstichtag oder Vertragsende in so vielen Tagen oder weniger: gelb (Standard 180).", **num)
    fd.field(f, "NumericField", "RotTage", "Andere Termine: rot ab … Tagen", x0, y0 + ROW, hw, name="numRot",
             help="Leistungen, Indexanpassungen: in so vielen Tagen fällig oder überfällig = rot (Standard 7).", **num)
    fd.field(f, "NumericField", "OffenTage", "Ohne Termin: rot nach … Tagen", x1, y0 + ROW, hw, name="numOffen",
             help="Rechnung prüfen, Leistungsanfall ohne Erledigung, Bestätigung fehlt: rot, wenn so viele Tage offen (Standard 14).",
             **num)
    fd.field(f, "NumericField", "LeistungTage", "Leistung: gelb ab … Tagen", x0, y0 + 2 * ROW, hw, name="numLeistung",
             help="Leistung in so vielen Tagen fällig: gelb (Standard 30).", **num)
    fd.field(f, "NumericField", "IndexTage", "Indexanpassung: gelb ab … Tagen", x1, y0 + 2 * ROW, hw, name="numIndex",
             help="Indexanpassung in so vielen Tagen: gelb (Standard 30).", **num)
    fd.field(f, "NumericField", "PruefMonate", "Verträge prüfen alle … Monate", x0, y0 + 3 * ROW, hw, ValueMin=1,
             ValueMax=120)
    # V8.4-E18: Datumsanzeige (LibreOffice-DateFormat 2 / 1 / 11)
    fd.field(f, "ListBox", "DatumFormat", "Datumsanzeige", x1, y0 + 3 * ROW, hw, name="lbDatumFormat",
             help="Wie Datumsfelder angezeigt werden. Gilt nach dem Sichern sofort.",
             ListSourceType=uno.Enum("com.sun.star.form.ListSourceType", "VALUELIST"), ListSource=("2", "1", "11"),
             StringItemList=("TT.MM.JJJJ (Windows-Einstellung)", "TT.MM.JJ (kurz)", "JJJJ-MM-TT"))
    y2 = TOP2 + h1 + 300
    h2 = card_height(2, 950)
    fd.card(X0, y2, cw, h2)
    fd.section(f, "Ablage und Sicherung", X0 + PAD, y2 + 330, 8000)
    y0 = y2 + CARD_HEAD
    fd.field(f, "TextField", "Ablagepfad", "Ablagepfad (Ordner mit den Vertragsordnern)", g.x, y0, g.w, MaxTextLen=200,
             name="txtAblage", help="z. B. Z:\\Verträge\\")
    fd.field(f, "TextField", "SicherungOrdner", "Sicherungsordner (leer = Ordner „Sicherung“ neben dieser Datei)", g.x,
             y0 + ROW, g.w, MaxTextLen=200, name="txtSichOrdner",
             help="Hier liegen Spiegel und Textsicherung. Am besten ein anderes Laufwerk als das Register.")
    # V8.2a: Hinweis als Tooltip der Knöpfe (Platz für die Schwellen; F5 abgeschnittener Text)
    sich_tipp = "Spiegel und Textsicherung laufen von selbst. Stand und Zurückholen: „Papierkorb & Sicherung“."
    bw = (g.w - 2 * 300) // 3
    for i, (label, sub, name) in enumerate((("Jetzt sichern", "SicherungJetzt", "btnSichern2"),
                                            ("Sicherungen zeigen", "SicherungOrdnerOeffnen", "btnSichOrdner"),
                                            ("Exporte zeigen", "ExportOrdnerOeffnen", "btnExpOrdner"))):
        fd.button(f, label, g.x + i * (bw + 300), y0 + 2 * ROW + 200, bw, 750, style="secondary", sub=sub, name=name,
                  size=10, help=sich_tipp)
    y3 = y2 + h2 + 300
    fd.card(X0, y3, cw, BOTTOM - y3)
    fd.section(f, "Beispieldaten und Anzeige", X0 + PAD, y3 + 330, 9000)
    fd.text(f, "Löscht alle Beispiele. Eigene Einträge bleiben.",
            g.x, y3 + CARD_HEAD - 100, g.w - 5800, 700, 10, False, TEXT2, multiline=True, top=False, name="lblBsp")
    fd.button(f, "Beispieldaten entfernen", g.x + g.w - 5400, y3 + CARD_HEAD - 100, 5400, 700, style="danger",
              sub="BeispieleEntfernen", name="btnBeispiele", size=10)
    # V8.8c (W1, W2, M8): Anzeige – Hinweiszeile in drei Stufen, Farben, Tooltip-Verzögerung (Dokumenteigenschaften der .odb)
    ya = y3 + CARD_HEAD + 750
    w1 = g.w * 45 // 100
    w2 = (g.w - w1 - 600) // 2
    lb = fd.field(f, "ListBox", None, "Hinweiszeile unten", g.x, ya, w1, name="lbHinweis",
                  help="Aus: mehr Platz. Nur Status und To Do: Ergebnisse und was zu tun ist. Mit Bedienhinweisen: "
                       "zeigt zusätzlich, wozu das Element unter der Maus dient (dann ohne Tooltip).",
                  StringItemList=("Aus", "Nur Status und To Do", "Mit Bedienhinweisen"), Dropdown=True)
    fd.on_ctl(f, lb, "XItemListener", "itemStateChanged", "HinweisStufeGewaehlt")
    cf = fd.checkbox(f, "", "Farben", g.x + w1 + 300, ya, w2, name="chkFarben")
    cf.HelpText = "Grün/Rot für Ergebnisse in der Hinweiszeile. Aus: alles grau, ✓ und ! bleiben."
    fd.on_ctl(f, cf, "XItemListener", "itemStateChanged", "HinweisFarbenUmschalten")
    nt = fd.field(f, "NumericField", None, "Tooltip nach (Sek.)", g.x + w1 + w2 + 600, ya, w2, name="numTipp",
                  help="So lange ruht die Maus, bis der Tooltip erscheint, z. B. 0,3 oder 1,5. Gilt sofort.",
                  DecimalAccuracy=1, ValueMin=0, ValueMax=10, ValueStep=0.1, Spin=True)
    fd.on_ctl(f, nt, "XFocusListener", "focusLost", "TippVerzoegerungMerken")
    rx = X0 + cw + GAP
    ha = 7000  # V8.4-E18: Platz für die Karte „Termine nach Notes“
    fd.card(rx, TOP2, cw, ha)
    fd.section(f, "Auswahllisten", rx + PAD, TOP2 + 330, 8000)
    # V8.5-E22 (M11, M12): Knopfleiste statt Eingabe in der untersten Zeile; Spalte „Reihe“ entfällt
    gh = ha - CARD_HEAD - 2700
    fd.grid(li, [("TextField", "Typ", "Liste", 330, 0), ("TextField", "Wert", "Wert", 600, 0)],
            rx + 300, TOP2 + CARD_HEAD, cw - 600, gh, name="gridListen")
    ky = TOP2 + CARD_HEAD + gh + 200
    kx = rx + 300
    for label, w, style, sub, name, hilfe in (
            ("+ Neu", 2000, "secondary", "ListeNeu", "btnListeNeu", "Neuer Wert in der Liste der markierten Zeile."),
            ("Entfernen", 2300, "danger", "ListeEntfernen", "btnListeWeg", "Entfernt den markierten Wert (mit Rückfrage)."),
            ("▲", 900, "secondary", "ListeHoch", "btnListeHoch", "Schiebt den markierten Wert in der Auswahl nach oben."),
            ("▼", 900, "secondary", "ListeRunter", "btnListeRunter", "Schiebt den markierten Wert in der Auswahl nach unten.")):
        fd.button(li, label, kx, ky, w, 650, style=style, sub=sub, name=name, size=10, help=hilfe)
        kx += w + 200
    fd.text(f, "Werte von Status, Zahlungsintervall, Ereignis, Abdeckung und Entscheidung steuern Berechnungen: "
               "nicht umbenennen oder entfernen.",
            rx + PAD, ky + 800, cw - 2 * PAD, 1100, 9, False, TEXT2, multiline=True, top=True, name="lblListen")
    # V8.4-E18: Termine nach Notes
    yn = TOP2 + ha + 300
    hn = card_height(2)
    fd.card(rx, yn, cw, hn)
    fd.section(f, "Termine nach Notes", rx + PAD, yn + 330, 8000)
    gr = Grid(rx + PAD, 0, cw - 2 * PAD)
    rx0, rhw = gr.half(0); rx1, _ = gr.half(1)
    y0 = yn + CARD_HEAD
    fd.field(f, "NumericField", "NotesVorwarnTage", "Vorwarnung (Tage vorher)", rx0, y0, rhw, name="numNotesVor",
             help="So viele Tage vor einem Kündigungsstichtag oder Vertragsende steht ein Vorwarntermin im Kalender (Standard 90).",
             ValueMin=0, ValueMax=365)
    fd.checkbox(f, "NotesErinnerung", "Erinnerung im Kalender", rx1, y0, rhw, name="chkNotesErinn")
    fd.checkbox(f, "NotesGanztaegig", "Termine ganztägig", rx0, y0 + ROW, rhw, name="chkNotesGanz")
    fd.field(f, "NumericField", "NotesUhrzeit", "Uhrzeit (Stunde, 0–23)", rx1, y0 + ROW, rhw, name="numNotesUhr",
             help="Ganztägig: Erinnerung um diese Uhrzeit am Tag. Sonst: Termin beginnt zu dieser Stunde, Erinnerung 15 Minuten vorher.",
             ValueMin=0, ValueMax=23)
    yb = yn + hn + 300
    fd.card(rx, yb, cw, BOTTOM - yb)
    fd.section(f, "Dein Name in der Änderungsspur", rx + PAD, yb + 330, 8000)
    fd.text(f, "", rx + PAD, yb + CARD_HEAD - 50, cw - 2 * PAD, 700, 13, True, TEXT, name="lblName")
    # V8.2b-F5: Platz für zwei Zeilen unter Windows
    fd.text(f, "Den Namen ändern: Extras › Optionen › LibreOffice › Benutzerdaten. Danach das Vertragsregister neu öffnen.",
            rx + PAD, yb + CARD_HEAD + 700, cw - 2 * PAD, 1300, 10, False, TEXT2, multiline=True, top=True,
            name="lblNameHinweis")


# ================================================================ HI Hilfe
def hilfe(fd, nav):
    fd.bereich("HI")
    kopf(fd, nav, "Hilfe", "Anleitung zum Vertragsregister")
    lw = 16800
    fd.card(X0, TOP2, lw, BOTTOM - TOP2)
    fd.field(nav, "TextField", None, None, X0 + PAD, TOP2 + 400, lw - 2 * PAD, h=BOTTOM - TOP2 - 800, readonly=True,
             size=10.5, name="txtAnleitung", MultiLine=True, VScroll=True, DefaultText=anleitung.TEXT)
    rx, rw = X0 + lw + GAP, CW - lw - GAP
    fd.card(rx, TOP2, rw, BOTTOM - TOP2)
    fd.text(nav, "SO FÄNGST DU AN", rx + PAD, TOP2 + 330, rw - 2 * PAD, 500, 8.5, True, TEXT2, name="lblStartTitel")
    fd.text(nav, anleitung.ERSTE_SCHRITTE, rx + PAD, TOP2 + 950, rw - 2 * PAD, BOTTOM - TOP2 - 1300, 10.5, False, TEXT,
            name="lblErsteSchritte", multiline=True, top=True)


# ================================================================ GS Gesamtsuche (V8.5-E23/E24)
def vorschau_feld(fd, f, x, y, w, h):
    """Mehrzeiliges Feld mit Formatierung (RichText): Ausschnitt in Anführungszeichen, Trefferwort fett."""
    fd.field(f, "TextField", None, None, x, y, w, h=h, readonly=True, size=11.5, name="txtVorschau",
             MultiLine=True, VScroll=True, RichText=True,
             help="Ausschnitt um das Trefferwort. Doppelklick in der Liste oder „Öffnen ›“ springt zur Fundstelle.")


def gesamtsuche(fd):
    t = fd.form("Treffer", "Treffer", 0, order='"Rang", "Herkunft", "Titel", "ID"', readonly=True, nav=False)
    fd.on_form(t, "XRowSetListener", "cursorMoved", "TrefferVorschau")
    for ev in ("loaded", "reloaded"):
        fd.on_form(t, "XLoadListener", ev, "TrefferVorschau")
    fd.bereich("GS")
    kopf(fd, t, "Alles durchsuchen", "Verträge, Entscheidungen, Leistungen, Protokoll, Partner, Dokumente und Hilfe")
    rechts(fd, t, [("Öffnen ›", 3300, "primary", "TrefferOeffnen", "btnOeffnen", "Öffnet die Fundstelle des markierten Treffers.")])
    lw = 15300
    m = fd.field(t, "TextField", None, None, X0, TOP2, lw - 800, size=11.5, h=800, name="txtSuche",
                 help="Suchbegriff ändern und Enter drücken.")
    fd.on_ctl(t, m, "XKeyListener", "keyPressed", "SucheTaste")
    fd.text(t, "", X0, TOP2 + 950, lw, 500, 10, False, TEXT2, BG, name="lblAnzahl")
    y2 = TOP2 + 1600
    fd.card(X0, y2, lw, BOTTOM - y2)
    fd.grid(t, [("TextField", "Herkunft", "Herkunft", 170, 0), ("TextField", "Titel", "Fundort", 420, 0),
                ("TextField", "Ausschnitt", "Ausschnitt", 820, 0)],
            X0 + 300, y2 + 300, lw - 600, BOTTOM - y2 - 600, name="gridTreffer", readonly=True,
            sub_dblclick="TrefferDoppelklick", rowh=80)
    rx, rw = X0 + lw + GAP, CW - lw - GAP
    fd.card(rx, TOP2, rw, BOTTOM - TOP2)
    fd.section(t, "Vorschau", rx + PAD, TOP2 + 330, rw - 2 * PAD)
    fd.text(t, "", rx + PAD, TOP2 + 900, rw - 2 * PAD, 500, 9.5, True, TEXT2, CARD, name="lblVorHerkunft")
    fd.text(t, "", rx + PAD, TOP2 + 1400, rw - 2 * PAD, 1100, 12, True, TEXT, CARD, name="lblVorTitel", multiline=True, top=True)
    vorschau_feld(fd, t, rx + PAD, TOP2 + 2700, rw - 2 * PAD, BOTTOM - TOP2 - 3200)
    hinweis(fd, t, "Doppelklick auf einen Treffer öffnet die Fundstelle. Die Suche je Ansicht bleibt daneben bestehen.")


def build_app(o, path, start="ST"):
    fd = FormDoc(o, FORM_NAME)
    nav = fd.form("Nav", "V_Kennzahlen", 0, readonly=True, nav=False)
    for ev in ("loaded", "reloaded"):
        fd.on_form(nav, "XLoadListener", ev, "StartGeladen")
    seitenleiste(fd, nav)
    uebersicht(fd, nav)
    vertraege(fd)
    vertrag(fd)
    leistungen(fd)
    protokoll(fd)
    partner(fd)
    vertretung(fd)
    aenderungen(fd)
    abgleich(fd)
    papierkorb(fd)
    einstellungen(fd)
    hilfe(fd, nav)
    gesamtsuche(fd)
    # V8.8c (W1): eigener Tooltip – zuletzt angelegt, damit er über allen Elementen liegt
    fd.bereich("NA")
    tl = fd.text(nav, "", 0, 0, 3000, 500, 9.5, False, TEXT, 0xFFFBDC, name="lblTipp", multiline=True, top=True)
    tl.Border = 2
    tl.BorderColor = 0xC7C7CC
    tl.EnableVisible = False
    fd.on_doc("OnLoad", "FormAnsicht")
    fd.on_doc("OnUnload", "FormZu")
    import tooltips   # V8.2c-N17
    fehlt = tooltips.anwenden(fd)
    print("Ohne Tooltip:", len(fehlt), fehlt)
    # V8.8 (Nico 16.10.): Tastenkürzel im Hilfetext der Knöpfe nennen (H7.2)
    kurz = {"NA_navST": "Strg+1", "NA_navLI": "Strg+2", "NA_navLE": "Strg+3", "NA_navPR": "Strg+4", "NA_navPA": "Strg+5",
            "NA_navVT": "Strg+6", "NA_navAE": "Strg+7", "NA_navAB": "Strg+8", "NA_navPK": "Strg+9", "NA_navHI": "F1 oder Strg+0",
            "NA_navEI": "Strg+,", "NA_txtGesamt": "Strg+Umschalt+F", "VE_btnSichern": "Strg+S", "PRv_btnSichern": "Strg+S",
            "EI_btnSichern": "Strg+S", "LI_btnNeu": "Strg+N", "VE_btnNeu": "Strg+N", "LE_btnNeu": "Strg+N",
            "PR_btnNeu": "Strg+N", "PA_btnNeu": "Strg+N", "VT_btnNeu": "Strg+N", "LI_txtSuche": "Strg+F",
            "LE_txtSuche": "Strg+F", "PR_txtSuche": "Strg+F", "AE_txtSuche": "Strg+F", "VE_btnPfeilVor": "Strg+Bild↓",
            "VE_btnPfeilZurueck": "Strg+Bild↑", "VE_btnZurueck": "Alt+←"}
    for m in fd.alle_modelle():
        if m.Name in kurz:
            m.HelpText = (m.HelpText + " " if m.HelpText else "") + "(" + kurz[m.Name] + ")"
    n = sum(1 for _ in fd.alle_modelle())
    fb = fd.formbereiche()
    # V8.7 (HIL-01): Standardhinweise ergänzen, Länge prüfen; Elemente an der Unterkante für die abgeschaltete Zeile
    for k, v in STANDARD_HINWEIS.items():
        formkit.HINWEIS.setdefault(k, v)
    print("Hinweistexte über 140 Zeichen:", [k for k, v in formkit.HINWEIS.items() if len(v) > 140])
    for i in range(fd.dp.Count):
        sh = fd.dp.getByIndex(i)
        try:
            nm = sh.Control.Name
        except Exception:
            continue
        if nm.split("_")[0] == "NA":
            continue
        unten = sh.Position.Y + sh.Size.Height
        if BOTTOM - 1100 < unten <= BOTTOM + 10:
            formkit.UNTEN.append(("W:" if sh.Size.Height >= 1500 else "V:") + nm)
    print("Unterkante wächst/wandert:", len(formkit.UNTEN), formkit.UNTEN)
    print("Pflichtfelder:", formkit.PFLICHT)
    fd.unten = BOTTOM
    fd.save_odt(path, start=start)
    return n, fb


FORMS = [(FORM_NAME, build_app)]
