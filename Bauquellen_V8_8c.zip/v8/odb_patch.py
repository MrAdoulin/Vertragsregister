"""Nachbearbeitung einer .odb (zip): Inhalte einzelner Einträge per Funktion ändern."""
import zipfile, shutil

def patch_zip(path, fn):
    """fn(name, text) -> text oder None (unverändert). mimetype bleibt erster, unkomprimierter Eintrag."""
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zi, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zo:
        for it in zi.infolist():
            data = zi.read(it.filename)
            if it.filename.endswith(".xml"):
                new = fn(it.filename, data.decode("utf8"))
                if new is not None:
                    data = new.encode("utf8")
            zo.writestr(it, data)
    shutil.move(tmp, path)
