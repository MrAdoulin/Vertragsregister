# V8.8c · Zeitgeber für das Basic-Makro (Basic hat keinen): ruft nach ms Millisekunden Standard.App.<makro>(arg)
# im Hauptthread auf (AsyncCallback). Genutzt für die Tooltip-Verzögerung (Einstellungen › Anzeige).
import threading
import unohelper
from com.sun.star.awt import XCallback


class _Rueckruf(unohelper.Base, XCallback):
    def __init__(self, doc, makro, arg):
        self.doc, self.makro, self.arg = doc, makro, arg

    def notify(self, data):
        try:
            sp = self.doc.getScriptProvider()
            sp.getScript("vnd.sun.star.script:Standard.App.%s?language=Basic&location=document" % self.makro).invoke(
                (self.arg,), (), ())
        except Exception:
            pass


def spaeter(ms, makro, arg):
    doc = XSCRIPTCONTEXT.getDocument()
    ctx = XSCRIPTCONTEXT.getComponentContext()

    def feuer():
        ac = ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.AsyncCallback", ctx)
        ac.addCallback(_Rueckruf(doc, makro, arg), None)

    t = threading.Timer(max(0, float(ms)) / 1000.0, feuer)
    t.daemon = True
    t.start()
    return True


g_exportedScripts = (spaeter,)
