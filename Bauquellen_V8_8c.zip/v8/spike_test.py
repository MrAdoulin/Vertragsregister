import sys, time, os
from xui import Sitzung
open("/tmp/spike_log.txt", "w").close()
s = Sitzung("spike.odb", warte=5)
P = lambda x, y: (int(19 + x * 0.0429), int(y * 0.0429))
btn = {"AV": 1200, "BV": 2200, "AE": 3200, "BE": 4200, "NEU": 5200}
def k(n):
    s.klick(*P(2300, btn[n] + 390)); time.sleep(1.2)
try:
    k("BE"); s.foto("exp/sp_BE.png")
    k("AE"); s.foto("exp/sp_AE.png")
    k("BE"); k("AE"); k("BE"); k("AE")
    k("BV"); s.foto("exp/sp_BV.png")
    k("AV"); s.foto("exp/sp_AV.png")
    k("NEU")
    print("vor X", s.fenster())
    s.schliessen_x(None); time.sleep(3)
    try:
        print("nach X", s.fenster())
    except Exception as e:
        print("nach X: Fehler", e)
    print("soffice läuft:", s.p.poll() is None)
finally:
    s.ende()
print(open("/tmp/spike_log.txt").read())
