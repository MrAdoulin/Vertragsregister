import os, uno
from uno_util import Office, pv, url, pva
o = Office(2023)
try:
    ctx = o.ctx
    smgr = ctx.ServiceManager
    ziel = os.path.abspath("_spike/test.zip")
    os.makedirs("_spike", exist_ok=True)
    if os.path.exists(ziel): os.remove(ziel)
    fac = smgr.createInstanceWithContext("com.sun.star.embed.StorageFactory", ctx)
    WRITE = 4 | 1  # READWRITE
    st = uno.invoke(fac, "createInstanceWithArguments", ((url(ziel), WRITE | 8, pva(("StorageFormat", "ZipFormat"))),))
    s = st.openStreamElement("Vertrag.csv", 4 | 8)
    out = smgr.createInstanceWithContext("com.sun.star.io.TextOutputStream", ctx)
    out.setOutputStream(s.getOutputStream())
    out.setEncoding("UTF-8")
    out.writeString('"ID";"Gegenstand"\n1;"Kaffee ü ""x"""\n')
    out.closeOutput()
    st.commit()
    st.dispose()
    print("zip size", os.path.getsize(ziel))
    import zipfile
    z = zipfile.ZipFile(ziel); print(z.namelist()); print(z.read("Vertrag.csv").decode())
    zf = smgr.createInstanceWithContext("com.sun.star.packages.zip.ZipFileAccess", ctx)
    zf.initialize((url(ziel),))
    print("Namen:", zf.getElementNames())
    inp = smgr.createInstanceWithContext("com.sun.star.io.TextInputStream", ctx)
    inp.setInputStream(zf.getByName("Vertrag.csv")); inp.setEncoding("UTF-8")
    while not inp.isEOF(): print("Zeile:", inp.readLine())
finally:
    o.close()
