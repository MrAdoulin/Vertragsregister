"""V8 · Datenbank ohne Formulare bauen und Sichten prüfen (headless)."""
import sys, os
from uno_util import Office
import db_build
from db_build import query, run, kontext
o = Office(2022)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v8.odb"), samples=True)
    def zeig(sql, cols=None):
        for r in query(con, sql):
            print("  ", {k: v for k, v in r.items() if cols is None or k in cols})
    print("Ereignisse:")
    zeig('SELECT "ID","LeistungID","Art","Betrag","Vorher","NV","MaxFreigabe","Reaktionszeit","Pruefergebnis","Offen" FROM "V_Ereignis" ORDER BY "ID"')
    print("Leistungen:")
    zeig('SELECT "ID","Nr","Bezeichnung","Zuletzt","Naechste","Tage","RechnungenJahr","NVJahr","OffeneRechnungen","OffeneStoerungen","SollVerfehlt12","Hinweis","Anzeige","Ampel" FROM "V_Leistung" ORDER BY "ID"')
    print("Kennzahlen:"); zeig('SELECT * FROM "V_Kennzahlen"')
    print("Heute:"); zeig('SELECT * FROM "V_HeuteListe" ORDER BY "Prio", "Bezug"')
    print("Fristen:"); zeig('SELECT * FROM "V_FristenListe" ORDER BY "Datum"')
    print("Notes:"); zeig('SELECT "Uid","Tag","Titel" FROM "V_NotesTermine" ORDER BY "Tag"')
    print("Spur (Beispiel):"); zeig('SELECT "ZeitText","Benutzer","Bereich","Nr","Was","Alt","Neu" FROM "V_AenderungListe"')
    print("Vertretung:"); zeig('SELECT * FROM "V_Vertretung"'); zeig('SELECT "VertretungID","ZeitText","Was" FROM "V_AenderungVertretung"')
    # Spur-Trigger
    kontext(con, "BENUTZER", "Test Person")
    run(con, 'UPDATE "Vertrag" SET "Kosten" = 495, "AutoVerl" = FALSE, "PartnerID" = 2, "Beginn" = DATE \'2023-02-01\' WHERE "ID" = 1')
    run(con, 'UPDATE "Ereignis" SET "GemeldetUm" = TIME \'08:45:00\' WHERE "ID" = 2')
    run(con, 'INSERT INTO "Ereignis" ("LeistungID","Datum","Art") VALUES (1, CURRENT_DATE, \'Leistung erbracht\')')
    run(con, 'UPDATE "Einstellung" SET "WarnTage" = 60 WHERE "ID" = 1')
    print("Spur nach Änderung:"); zeig('SELECT "Benutzer","Bereich","Nr","Aktion","Was","Alt","Neu" FROM "V_AenderungListe" WHERE "Benutzer" = \'Test Person\'')
    zeig('SELECT "ID","Bearbeiter","Angelegt" FROM "Ereignis" WHERE "ID" = 13')
    # Prüfregel
    try:
        run(con, 'UPDATE "Einstellung" SET "VorwarnTage" = 10 WHERE "ID" = 1'); print("CHECK FEHLT")
    except Exception as e:
        print("CHECK greift:", str(e).split("\n")[0][:120])
    con.close(); doc.close(True)
finally:
    o.close()
