"""V8.1 · Datenbankprüfungen ohne Formular (P2 Vertragsnummer; später P4/P5)."""
import os
from uno_util import Office
import db_build
from db_build import query, run, kontext
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
o = Office(2022)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v81.odb"), samples=True)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    nr = q('SELECT "ID", "Nr", "Vertragsnummer" FROM "Vertrag" ORDER BY "ID"')
    print(nr)
    pruef("P2 Nr aus Vertragsnummer", nr[0][1] == "12_132_01_2023", nr[0])
    pruef("P2 Nr ohne Nummer = unbenannt 4", nr[3][1] == "unbenannt 4", nr[3])
    kontext(con, "BENUTZER", "Test")
    run(con, 'INSERT INTO "Vertrag" ("Gegenstand", "PartnerID") VALUES (\'Neu ohne Nummer\', 1)')
    r = q('SELECT "ID", "Nr" FROM "Vertrag" WHERE "Gegenstand" = \'Neu ohne Nummer\'')
    pruef("P2 neuer Vertrag erhält unbenannt n", r and r[0][1] == "unbenannt %d" % int(r[0][0]), r)
    run(con, 'UPDATE "Vertrag" SET "Vertragsnummer" = \'  \' WHERE "ID" = 4')
    pruef("P2 leere Nummer → unbenannt 4", q('SELECT "Nr", "Vertragsnummer" FROM "Vertrag" WHERE "ID" = 4')[0] == ("unbenannt 4", None))
    try:
        run(con, 'UPDATE "Vertrag" SET "Vertragsnummer" = \'12_132_01_2023\' WHERE "ID" = 4'); pruef("P2 doppelte Nummer abgelehnt (DB)", False)
    except Exception as e:
        pruef("P2 doppelte Nummer abgelehnt (DB)", True, str(e).split("\n")[0][:90])
    for v in ("V_Liste", "V_Leistung", "V_Ereignis", "V_AenderungListe", "V_NotesTermine"):
        r = q(f'SELECT FIRST 3 * FROM "{v}"')
        pruef(f"P2 Sicht {v} lesbar", len(r) > 0)
    print(q('SELECT FIRST 3 "Nr", "Gegenstand" FROM "V_Leistung"'))
    print(q('SELECT FIRST 3 "Uid", "Titel" FROM "V_NotesTermine"'))
    run(con, 'UPDATE "Vertrag" SET "Vertragsnummer" = \'99_999_01_2026\' WHERE "ID" = 4')
    print(q('SELECT "Nr", "Was", "Alt", "Neu" FROM "V_AenderungListe" WHERE "Benutzer" = \'Test\''))
    pruef("P2 Spur kennt Vertragsnummer", any(r[1] == "Vertragsnummer" for r in q('SELECT "Nr", "Was" FROM "V_AenderungListe" WHERE "Benutzer" = \'Test\'')))
    # ---- P4 Papierkorb
    zahl = lambda t, w="": int(q(f'SELECT COUNT(*) FROM "{t}" {w}')[0][0])
    vor = {t: zahl(t) for t in ("Vertrag", "Leistung", "Ereignis", "Dokument", "Entscheidung")}
    run(con, 'DELETE FROM "Vertrag" WHERE "ID" = 1')
    nach = {t: zahl(t) for t in vor}
    print("vor", vor, "nach", nach)
    pk = q('SELECT "Vorgang", "Art", "Was", "Dazu", "TageUebrig", "Von" FROM "V_Papierkorb"')
    print(pk)
    pruef("P4 Papierkorb zeigt einen Vorgang", len(pk) == 1 and pk[0][1] == "Vertrag" and "12_132_01_2023" in pk[0][2], pk)
    pruef("P4 abhängige Zeilen im Papierkorb", zahl("PK_Leistung") == vor["Leistung"] - nach["Leistung"] and zahl("PK_Ereignis") == vor["Ereignis"] - nach["Ereignis"] and zahl("PK_Ereignis") > 0)
    pruef("P4 90 Tage übrig", pk[0][4] == "90", pk[0][4])
    v = pk[0][0]
    run(con, f'EXECUTE PROCEDURE "P_ZURUECK"({v})')
    zur = {t: zahl(t) for t in vor}
    pruef("P4 Zurückholen stellt alles her", zur == vor, f"{vor} / {zur}")
    pruef("P4 Nummer und ID wie vorher", q('SELECT "Nr" FROM "Vertrag" WHERE "ID" = 1') == [("12_132_01_2023",)])
    pruef("P4 Papierkorb danach leer", zahl("PK_Vertrag") == 0 and zahl("PK_Ereignis") == 0)
    sp = q('SELECT "Aktion", COUNT(*) FROM "Aenderung" WHERE "Aktion" = \'zurück\' GROUP BY 1')
    pruef("P4 Spur vermerkt Zurückholen", sp and int(sp[0][1]) > 0, sp)
    # Konflikt: Partner löschen, gleichen Namen neu anlegen, zurückholen scheitert
    run(con, 'INSERT INTO "Partner" ("Name") VALUES (\'Konflikt GmbH\')')
    run(con, 'DELETE FROM "Partner" WHERE "Name" = \'Konflikt GmbH\'')
    run(con, 'INSERT INTO "Partner" ("Name") VALUES (\'Konflikt GmbH\')')
    v2 = q('SELECT "Vorgang" FROM "V_Papierkorb" WHERE "Art" = \'Partner\'')[0][0]
    try:
        run(con, f'EXECUTE PROCEDURE "P_ZURUECK"({v2})'); pruef("P4 Konflikt wird gemeldet", False)
    except Exception as e:
        pruef("P4 Konflikt wird gemeldet", True, str(e).replace("\n", " ")[:160])
    pruef("P4 Konflikt: Papierkorb unverändert", zahl("PK_Partner") == 1)
    run(con, f'EXECUTE PROCEDURE "P_PK_LOESCHEN"({v2})')
    pruef("P4 Endgültig löschen", zahl("PK_Partner") == 0)
    # Aufräumen nach 90 Tagen
    run(con, 'DELETE FROM "Ereignis" WHERE "ID" = 1')
    run(con, 'UPDATE "PK_Ereignis" SET "GeloeschtAm" = DATEADD(-91 DAY TO CURRENT_TIMESTAMP)')
    run(con, 'EXECUTE PROCEDURE "P_PK_AUFRAEUMEN"(90)')
    pruef("P4 nach 90 Tagen endgültig weg", zahl("PK_Ereignis") == 0)
    # ---- P5 Textsicherung: Zeilen, Prüfwert, Vergleich, Zurückholen
    r = q('SELECT FIRST 2 "ID", "Zeile" FROM "VX_Vertrag" ORDER BY "ID"')
    print(r)
    pruef("P5 CSV-Zeile Vertrag", r and r[0][1].startswith('1;"12_132_01_2023";"12_132_01_2023";"Kaffeemaschine'), r[0][1][:80] if r else "")
    for t in ("Einstellung", "Liste", "Partner", "Vertrag", "Entscheidung", "Dokument", "Leistung", "Ereignis", "Vertretung", "VertretungPunkt", "Aenderung"):
        f = q(f'SELECT COUNT(*), SUM("ID"), SUM(CAST("ID" AS BIGINT) * "ID"), SUM(CHAR_LENGTH("Zeile")), SUM(MOD(HASH("Zeile"), 1000000007)) FROM "VX_{t}"')
        print("   ", t, f[0])
    pruef("P5 Prüfwert mit HASH rechenbar", True)
    print(q('SELECT "Tabelle", "Kopf" FROM "VX_Kopf" WHERE "Tabelle" = \'Partner\''))
    # Stand „damals" = heute kopieren, dann heute ändern und löschen
    for t in ("Partner", "Vertrag", "Entscheidung", "Dokument", "Leistung", "Ereignis", "Vertretung", "VertretungPunkt"):
        run(con, f'DELETE FROM "R_{t}"'); run(con, f'INSERT INTO "R_{t}" SELECT * FROM "{t}"')
    run(con, 'UPDATE "Vertrag" SET "Kosten" = 999 WHERE "ID" = 2')
    kontext(con, "KEINE_SPUR", "1")
    run(con, 'DELETE FROM "Leistung" WHERE "ID" = 5')   # ohne Papierkorb (KEINE_SPUR)
    kontext(con, "KEINE_SPUR", None)
    run(con, 'DELETE FROM "Dokument" WHERE "ID" = 6')    # mit Papierkorb
    run(con, 'DELETE FROM "R_Vergleich"')
    run(con, 'INSERT INTO "R_Vergleich" ("Tabelle", "DatensatzID", "Rang", "Art", "Was", "Unterschied") SELECT "Tabelle", "DatensatzID", "Rang", "Art", "Was", "Unterschied" FROM "V_Vergleich"')
    vg = q('SELECT "Tabelle", "DatensatzID", "Unterschied", "Was" FROM "R_Vergleich" ORDER BY "Rang", "DatensatzID"')
    print(vg)
    pruef("P5 Vergleich: geändert", ("Vertrag", "2", "geändert") in [x[:3] for x in vg])
    pruef("P5 Vergleich: fehlt heute", ("Leistung", "5", "fehlt heute") in [x[:3] for x in vg])
    pruef("P5 Vergleich: im Papierkorb", ("Dokument", "6", "im Papierkorb") in [x[:3] for x in vg])
    pruef("P5 Vergleich: Protokoll der Leistung 5 fehlt mit", all(x[0] in ("Vertrag", "Leistung", "Dokument", "Ereignis") for x in vg), str(vg))
    run(con, 'UPDATE "R_Vergleich" SET "Zurueck" = TRUE WHERE "Unterschied" <> \'im Papierkorb\'')
    run(con, 'EXECUTE PROCEDURE "P_TEXT_ZURUECK"')
    pruef("P5 Zurückholen: Kosten wieder alt", float(q('SELECT "Kosten" FROM "Vertrag" WHERE "ID" = 2')[0][0]) == 189, q('SELECT "Kosten" FROM "Vertrag" WHERE "ID" = 2'))
    pruef("P5 Zurückholen: Leistung 5 wieder da", zahl("Leistung", 'WHERE "ID" = 5') == 1)
    pruef("P5 Vergleich danach nur Papierkorb", q('SELECT "Unterschied" FROM "R_Vergleich"') == [("im Papierkorb",)], q('SELECT "Unterschied" FROM "R_Vergleich"'))
    con.close(); doc.close(True)
finally:
    o.close()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
