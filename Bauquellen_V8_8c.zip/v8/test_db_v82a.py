"""V8.2a · Ampelregeln in der Datenbank (E13, E15, E16): Schwellen 30/7/14, eigene Ampel für Prüfung und Index,
Leistungen und Protokolleinträge nach Alter, Marke, Filter auf Ampel."""
import os
from datetime import date, timedelta
from uno_util import Office
import db_build
from db_build import query, run
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
H = date.today()
def d(n):
    return "DATE '" + (H + timedelta(days=n)).isoformat() + "'"
o = Office(2023)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v82a.odb"), samples=False)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    run(con, 'INSERT INTO "Partner" ("Name") VALUES (\'P\')')
    def vertrag(gegenstand, **f):
        spalten = {"Gegenstand": f"'{gegenstand}'", "PartnerID": "1", "Status": "'aktiv'"}
        spalten.update({k: str(v) for k, v in f.items()})
        run(con, f'INSERT INTO "Vertrag" ({", ".join(chr(34) + k + chr(34) for k in spalten)}) VALUES ({", ".join(spalten.values())})')
        return int(q(f'SELECT MAX("ID") FROM "Vertrag"')[0][0])
    def amp(vid):
        return q(f'SELECT "Hinweis", "HAmpel", "PAmpel", "IAmpel", "Ampel", "Prio" FROM "V_Vertrag" WHERE "ID" = {vid}')[0]
    # Ende = heute + n bei Auto-Verlängerung, Frist 1 Monat → Stichtag = Ende − 1 Monat
    def stichtag_in(n):
        return dict(Beginn=d(-400), ErstesEnde=f"DATEADD(1 MONTH TO {d(n)})", AutoVerl="TRUE", VerlMonate=12, FristMonate=1)
    v1 = vertrag("Stichtag 20", **stichtag_in(20))
    v2 = vertrag("Stichtag 60", **stichtag_in(60))
    a1, a2 = amp(v1), amp(v2)
    pruef("E16 Stichtag in 20 Tagen = rot (Schwelle 30)", a1[1] == "rot" and a1[4] == "rot", a1)
    pruef("E16 Stichtag in 60 Tagen = gelb", a2[1] == "gelb" and a2[4] == "gelb", a2)
    # Bestätigung fehlt: Versand vor 20 bzw. 5 Tagen
    for n, erw in ((20, "rot"), (5, "gelb")):
        v = vertrag(f"Versandt vor {n}", **stichtag_in(60))
        run(con, f'INSERT INTO "Entscheidung" ("VertragID", "Art", "Datum", "Versandt") VALUES ({v}, \'kündigen\', {d(-n)}, {d(-n)})')
        a = amp(v)
        pruef(f"E15 Bestätigung fehlt seit {n} Tagen = {erw}", a[0] == "Bestätigung fehlt" and a[1] == erw, a)
    # Index: in 5 Tagen rot (RotTage 7), in 20 Tagen gelb (IndexTage 30); Hinweis bleibt der Stichtag
    for n, erw in ((5, "rot"), (20, "gelb")):
        v = vertrag(f"Index {n}", NaechsteAnpassung=d(n), **stichtag_in(150))
        a = amp(v)
        pruef(f"E13 Index in {n} Tagen: IAmpel {erw}, Gesamt {erw}", a[3] == erw and a[4] == erw, a)
    # Prüfung überfällig bei gelbem Hinweis → Gesamt rot, eigene Zeile in „Offen"
    v = vertrag("Pruefung", ZuletztGeprueft=d(-400), **stichtag_in(60))
    a = amp(v)
    pruef("Prüfung überfällig: PAmpel rot, Gesamt rot, Hinweis gelb", a[2] == "rot" and a[4] == "rot" and a[1] == "gelb", a)
    zeilen = q(f'SELECT "Symbol", "Aufgabe" FROM "V_HeuteListe" WHERE "ID" = {v} ORDER BY "Prio"')
    pruef("Offen: zwei Zeilen (Prüfung dringend, Stichtag offen)",
          ("!! dringend", "Prüfung fällig") in zeilen and ("! offen", "Kündigungsstichtag") in zeilen, zeilen)
    # Leistungen
    vl = vertrag("Leistungen", **stichtag_in(300))
    def leistung(name, **f):
        sp = {"VertragID": str(vl), "Bezeichnung": f"'{name}'", "Abdeckung": "'inklusive'"}
        sp.update({k: str(x) for k, x in f.items()})
        run(con, f'INSERT INTO "Leistung" ({", ".join(chr(34) + k + chr(34) for k in sp)}) VALUES ({", ".join(sp.values())})')
        return int(q('SELECT MAX("ID") FROM "Leistung"')[0][0])
    def lamp(lid):
        return q(f'SELECT "Hinweis", "Ampel", "Marke" FROM "V_Leistung" WHERE "ID" = {lid}')[0]
    for n, erw in ((5, "rot"), (20, "gelb")):
        lid = leistung(f"Faellig {n}", IntervallMonate=6)
        run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art") VALUES ({lid}, DATEADD(-6 MONTH TO {d(n)}), \'Leistung erbracht\')')
        a = lamp(lid)
        pruef(f"E13 Leistung fällig in {n} Tagen = {erw}", a[1] == erw and a[2] == ("!!" if erw == "rot" else "!"), a)
    for n, erw in ((20, "rot"), (3, "gelb")):
        lid = leistung(f"Rechnung {n}")
        run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Betrag") VALUES ({lid}, {d(-n)}, \'Rechnung erhalten\', 100)')
        a = lamp(lid)
        e = q(f'SELECT "Offen", "Ampel", "Symbol" FROM "V_Ereignis" WHERE "LeistungID" = {lid}')[0]
        pruef(f"E15 Rechnung seit {n} Tagen offen: Leistung {erw}, Eintrag {erw}", a[1] == erw and e[1] == erw, f"{a} {e}")
    lid = leistung("Ausgeschlossen", Abdeckung="'ausgeschlossen'")
    pruef("M22 AbdeckungText", q(f'SELECT "AbdeckungText" FROM "V_Leistung" WHERE "ID" = {lid}')[0][0] == "✕ ausgeschlossen")
    # Marke in der Tabelle (M08)
    run(con, 'UPDATE "Leistung" l SET "Marke" = (SELECT NULLIF(v."Marke", \'\') FROM "V_Leistung" v WHERE v."ID" = l."ID") '
             'WHERE "Marke" IS DISTINCT FROM (SELECT NULLIF(v."Marke", \'\') FROM "V_Leistung" v WHERE v."ID" = l."ID")')
    m = q('SELECT "Bezeichnung", "Marke" FROM "Leistung" ORDER BY "ID"')
    pruef("M08 Marke übernommen", ("Faellig 5", "!!") in m and ("Faellig 20", "!") in m, m)
    pruef("M08 Marke ohne Spureintrag", int(q('SELECT COUNT(*) FROM "Aenderung" WHERE "Feld" = \'Marke\'')[0][0]) == 0)
    # Filter auf Ampel (Fehler 226 im Bau)
    r = q('SELECT COUNT(*) FROM "V_Liste" WHERE "Ampel" = \'rot\'')
    pruef("Filter V_Liste nach Ampel", int(r[0][0]) >= 4, r)
    # Schwellen ändern wirkt sofort
    run(con, 'UPDATE "Einstellung" SET "WarnTage" = 10 WHERE "ID" = 1')
    pruef("Schwelle 10: Stichtag in 20 Tagen = gelb", amp(v1)[1] == "gelb", amp(v1))
    doc.close(True)
finally:
    o.close()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
