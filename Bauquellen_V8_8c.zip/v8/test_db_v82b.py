"""V8.2b · Datenbank: „Freigegeben von" füllt sich (M20), Vorschlagslisten (M20), Sortierung nach Datum (B2)."""
import os
from uno_util import Office
import db_build, forms_def
from db_build import query, run
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
o = Office(2023)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v82b.odb"), samples=True)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    q("SELECT RDB$SET_CONTEXT('USER_SESSION', 'BENUTZER', 'Testerin') FROM RDB$DATABASE")
    lid = q('SELECT MIN("ID") FROM "Leistung"')[0][0]
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Betrag", "FreigabeDatum", "FreigabeBetrag") '
             f"VALUES ({lid}, CURRENT_DATE, 'Rechnung erhalten', 50, CURRENT_DATE, 50)")
    e = q('SELECT "FreigabeVon" FROM "Ereignis" WHERE "ID" = (SELECT MAX("ID") FROM "Ereignis")')[0][0]
    pruef("M20 Freigegeben von = angemeldeter Name", e == "Testerin", e)
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Betrag", "FreigabeVon") '
             f"VALUES ({lid}, CURRENT_DATE, 'Rechnung erhalten', 60, 'Chefin')")
    e = q('SELECT "FreigabeVon" FROM "Ereignis" WHERE "ID" = (SELECT MAX("ID") FROM "Ereignis")')[0][0]
    pruef("M20 eigener Wert bleibt", e == "Chefin", e)
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Betrag") VALUES ({lid}, CURRENT_DATE, \'Rechnung erhalten\', 70)')
    e = q('SELECT "FreigabeVon" FROM "Ereignis" WHERE "ID" = (SELECT MAX("ID") FROM "Ereignis")')[0][0]
    pruef("M20 ohne Freigabedatum bleibt leer", e is None, e)
    v = [r[0] for r in q(forms_def.vorschlag("FreigabeVon"))]
    pruef("M20 Vorschläge: zuletzt benutzter zuerst, ohne Doppelte", v[0] == "Chefin" and len(v) == len(set(v)) and "Testerin" in v, v)
    b = [r[0] for r in q(forms_def.vorschlag("Beleg"))]
    pruef("M20 Vorschläge Beleg lesbar", isinstance(b, list), b[:3])
    r = q('SELECT "Datum", "DatumSort" FROM "V_HeuteListe" ORDER BY "DatumSort", "Prio"')
    erst_leer = next((i for i, x in enumerate(r) if x[0] is None), len(r))
    pruef("B2 ohne Datum am Ende", all(x[0] is None for x in r[erst_leer:]) and erst_leer > 0, r)
    doc.close(True)
finally:
    o.close()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
