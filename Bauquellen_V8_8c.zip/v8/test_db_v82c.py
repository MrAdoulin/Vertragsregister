"""V8.2c · Datenbank: Entscheidung füllt Datum/Name (N11), Störung ohne Meldedatum (N19), Spur „aus der Sicherung" (N03),
Reihenfolge der Ereignisarten (N20)."""
import os
from uno_util import Office
import db_build
from db_build import query, run
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
o = Office(2023)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v82c.odb"), samples=True)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    q("SELECT RDB$SET_CONTEXT('USER_SESSION', 'BENUTZER', 'Testerin') FROM RDB$DATABASE")
    vid = q('SELECT MIN("ID") FROM "Vertrag"')[0][0]
    run(con, f'INSERT INTO "Entscheidung" ("VertragID", "Art") VALUES ({vid}, \'neu verhandeln\')')
    r = q('SELECT "Datum", "Verantwortlich" FROM "Entscheidung" WHERE "ID" = (SELECT MAX("ID") FROM "Entscheidung")')[0]
    heute = q("SELECT CURRENT_DATE FROM RDB$DATABASE")[0][0]
    pruef("N11 Entscheidung ohne Datum/Name: heute und angemeldeter Name", r == (heute, "Testerin"), r)
    lid = q('SELECT MIN("ID") FROM "Leistung"')[0][0]
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art") VALUES ({lid}, DATE \'2026-10-01\', \'Leistungsanfall\')')
    g = q('SELECT "GemeldetAm" FROM "Ereignis" WHERE "ID" = (SELECT MAX("ID") FROM "Ereignis")')[0][0]
    pruef("N19 Störung ohne Meldedatum = heute", g == heute, g)
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Betrag") VALUES ({lid}, CURRENT_DATE, \'Rechnung erhalten\', 5)')
    g = q('SELECT "GemeldetAm" FROM "Ereignis" WHERE "ID" = (SELECT MAX("ID") FROM "Ereignis")')[0][0]
    pruef("N19 Rechnung bleibt ohne Meldedatum", g is None, g)
    run(con, "INSERT INTO \"Aenderung\" (\"Zeit\", \"Benutzer\", \"Tabelle\", \"DatensatzID\", \"Aktion\") "
             "VALUES (CURRENT_TIMESTAMP, 'x', 'Ereignis', 1, 'zurückS')")
    w = q('SELECT "Was" FROM "V_AenderungListe" WHERE "Aktion" = \'zurückS\'')
    pruef("N03 Spur: aus der Sicherung zurückgeholt", w and w[0][0] == "aus der Sicherung zurückgeholt", w)
    a = [r[0] for r in q('SELECT "Wert" FROM "Liste" WHERE "Typ" = \'Ereignis\' ORDER BY "Sort"')]
    pruef("N20 Reihenfolge wie es anfällt", a == ["Leistungsanfall", "Leistung erbracht", "Rechnung erhalten", "Reklamation"], a)
    doc.close(True)
finally:
    o.close()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
