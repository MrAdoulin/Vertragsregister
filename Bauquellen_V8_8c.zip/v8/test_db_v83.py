"""V8.3 · Datenbank: Status „zukünftig“ (E28), Kostenprognose Kalenderjahr (E28), Partnerstand (E29),
„Ersetzt Vertrag“ (E30), LEC-Partner und -Felder."""
import os, datetime
from uno_util import Office
import db_build
from db_build import query, run
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
o = Office(2023)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v83.odb"), samples=True)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    heute = datetime.date.fromisoformat(q("SELECT CURRENT_DATE FROM RDB$DATABASE")[0][0])
    j = heute.year
    tage = (datetime.date(j, 12, 31) - datetime.date(j, 1, 1)).days + 1
    lec = q('SELECT "ID" FROM "Partner" WHERE "Name" = \'LEC (HRMO)\'')
    pruef("LEC Platzhalter-Partner vorhanden", len(lec) == 1, lec)
    pid = lec[0][0]
    # Zukünftiger Vertrag ab 1.11. des Jahres, 1200 €/Jahr
    b = datetime.date(j, 11, 1) if heute < datetime.date(j, 11, 1) else datetime.date(j, 12, 15)
    run(con, f'INSERT INTO "Vertrag" ("Gegenstand", "PartnerID", "Art", "Beginn", "Kosten", "Intervall", "AutoVerl", '
             f'"VerlMonate", "ErstesEnde", "FristMonate", "Angestellte", "Dienstort", "SollStundenMonat", "Stundenlohn", '
             f'"Bereitschaft", "BereitschaftStunden") VALUES (\'LEC Test\', {pid}, \'Dienstvertrag (LEC)\', DATE \'{b}\', 1200, '
             f'\'jährlich\', TRUE, 12, DATE \'{j + 1}-10-31\', 1, \'Amra Test\', \'Butmir\', 173.33, 9.5, TRUE, 40)')
    r = q('SELECT "ID", "Status" FROM "Vertrag" WHERE "Gegenstand" = \'LEC Test\'')[0]
    vid = r[0]
    pruef("E28 Beginn in der Zukunft → zukünftig", r[1] == "zukünftig", r)
    k = float(q(f'SELECT "KostenJahr" FROM "V_Vertrag" WHERE "ID" = {vid}')[0][0])
    soll = round(1200 * ((datetime.date(j, 12, 31) - b).days + 1) / tage, 2)
    pruef("E28 Prognose anteilig ab Beginn", abs(k - soll) < 0.02, f"{k} / {soll}")
    st = q(f'SELECT "Stand" FROM "V_PartnerStand" WHERE "ID" = {pid}')[0][0]
    pruef("E29 Partner mit zukünftigem Vertrag = aktiv", st == "aktiv", st)
    run(con, f'UPDATE "Vertrag" SET "Beginn" = DATE \'{heute}\' WHERE "ID" = {vid}')
    pruef("E28 Beginn erreicht → aktiv", q(f'SELECT "Status" FROM "Vertrag" WHERE "ID" = {vid}')[0][0] == "aktiv")
    # Endender Vertrag: Status gekündigt, Ende 30.6. des Jahres
    run(con, f'INSERT INTO "Vertrag" ("Gegenstand", "PartnerID", "Beginn", "ErstesEnde", "Kosten", "Intervall", "Status") '
             f'VALUES (\'Ende Test\', {pid}, DATE \'{j - 2}-01-01\', DATE \'{j}-06-30\', 1000, \'jährlich\', \'gekündigt\')')
    k2 = float(q('SELECT "KostenJahr" FROM "V_Vertrag" WHERE "Gegenstand" = \'Ende Test\'')[0][0])
    soll2 = round(1000 * ((datetime.date(j, 6, 30) - datetime.date(j, 1, 1)).days + 1) / tage, 2)
    pruef("E28 endender Vertrag anteilig bis Ende", abs(k2 - soll2) < 0.02, f"{k2} / {soll2}")
    # Laufender Vertrag ganzjährig
    k3 = q('SELECT "KostenJahr", "Jahreskosten" FROM "V_Vertrag" WHERE "Nr" = \'12_132_01_2023\'')[0]
    pruef("E28 laufender Vertrag mit Verlängerung = volle Jahreskosten", abs(float(k3[0]) - float(k3[1])) < 0.02, k3)
    summe = float(q('SELECT SUM("KostenJahr") FROM "V_Vertrag"')[0][0])
    kpi = float(q('SELECT "Jahreskosten" FROM "V_Kennzahlen"')[0][0])
    pruef("E28 Kennzahl = Summe der Prognosen", abs(summe - kpi) < 0.05, f"{kpi} / {summe}")
    # Partnerstand
    inakt = q('SELECT p."Name", s."Stand" FROM "V_PartnerStand" s JOIN "Partner" p ON p."ID" = s."ID" ORDER BY p."Name"')
    print("  ", inakt)
    pruef("E29 Partner des ersetzten Vertrags = historisch", ("Alt Kaffeetechnik GmbH", "historisch") in inakt
          or any(x[1] == "historisch" for x in inakt), inakt)
    # Ersetzt Vertrag
    e = q('SELECT v."Nr" AS "Neu", a."Nr" AS "Alt" FROM "Vertrag" v JOIN "Vertrag" a ON a."ID" = v."ErsetztVertrag"')
    pruef("E30 neuer Vertrag nennt den alten", e == [("12_132_01_2023", "unbenannt 4")], e)
    # Spur der LEC-Felder
    q("SELECT RDB$SET_CONTEXT('USER_SESSION', 'KEINE_SPUR', NULL) FROM RDB$DATABASE")
    run(con, f'UPDATE "Vertrag" SET "Stundenlohn" = 10 WHERE "ID" = {vid}')
    sp = q(f'SELECT "Feld" FROM "Aenderung" WHERE "Tabelle" = \'Vertrag\' AND "DatensatzID" = {vid} AND "Feld" = \'Stundenlohn\'')
    pruef("LEC Änderung des Stundenlohns in der Spur", len(sp) == 1, sp)
    doc.close(True)
finally:
    o.close()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
