"""V8.5 · Datenbank: SET-NULL-Verweise beim Zurückholen, Spur-VertragID bei kaskadiertem Löschen, Ereignis.Ergaenzen."""
import os
from uno_util import Office
import db_build
from db_build import query, run
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
o = Office(2023)
try:
    doc, con = db_build.create_db(o, os.path.abspath("t_db_v85.odb"), samples=True)
    q = lambda sql: [tuple(r.values()) for r in query(con, sql)]
    pid = q('SELECT MIN("ID") FROM "Partner"')[0][0]
    run(con, f'INSERT INTO "Vertrag" ("Gegenstand", "PartnerID") VALUES (\'Alt V85\', {pid})')
    a = q('SELECT "ID" FROM "Vertrag" WHERE "Gegenstand" = \'Alt V85\'')[0][0]
    run(con, f'INSERT INTO "Vertrag" ("Gegenstand", "PartnerID", "ErsetztVertrag") VALUES (\'Neu V85\', {pid}, {a})')
    b = q('SELECT "ID" FROM "Vertrag" WHERE "Gegenstand" = \'Neu V85\'')[0][0]
    vt = q('SELECT MIN("ID") FROM "Vertretung"')[0][0]
    run(con, f'INSERT INTO "VertretungPunkt" ("VertretungID", "Was", "VertragID") VALUES ({vt}, \'Punkt V85\', {a})')
    run(con, f'INSERT INTO "Leistung" ("VertragID", "Bezeichnung", "Abdeckung") VALUES ({a}, \'Leistung V85\', \'inklusive\')')
    lid = q('SELECT "ID" FROM "Leistung" WHERE "Bezeichnung" = \'Leistung V85\'')[0][0]
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art") VALUES ({lid}, CURRENT_DATE, \'Reklamation\')')
    run(con, f'DELETE FROM "Vertrag" WHERE "ID" = {a}')
    pruef("Löschen setzt Verweis auf NULL", q(f'SELECT "ErsetztVertrag" FROM "Vertrag" WHERE "ID" = {b}')[0][0] in (None, "", "NULL"),
          q(f'SELECT "ErsetztVertrag" FROM "Vertrag" WHERE "ID" = {b}'))
    vw = q('SELECT "Tabelle", "ID", "Ziel" FROM "PK_Verweis" ORDER BY "Tabelle"')
    pruef("Verweise gemerkt", len(vw) == 2, vw)
    sp = q(f'SELECT "VertragID" FROM "Aenderung" WHERE "Tabelle" = \'Ereignis\' AND "Aktion" = \'gelöscht\'')
    pruef("Spur: gelöschtes Protokoll trägt die VertragID", sp and all(str(x[0]) == str(a) for x in sp), sp)
    v = q('SELECT "Vorgang" FROM "V_Papierkorb" WHERE "Art" = \'Vertrag\'')[0][0]
    run(con, f'EXECUTE PROCEDURE "P_ZURUECK"({v})')
    pruef("Zurückholen setzt „Ersetzt Vertrag“ wieder", str(q(f'SELECT "ErsetztVertrag" FROM "Vertrag" WHERE "ID" = {b}')[0][0]) == str(a))
    pruef("Zurückholen setzt Vertrag im offenen Punkt wieder",
          str(q('SELECT "VertragID" FROM "VertretungPunkt" WHERE "Was" = \'Punkt V85\'')[0][0]) == str(a))
    pruef("PK_Verweis danach leer", q('SELECT COUNT(*) FROM "PK_Verweis"')[0][0] in (0, "0"))
    # Ergaenzen: Offen und Leistungsstand
    run(con, f'INSERT INTO "Ereignis" ("LeistungID", "Datum", "Art", "Beschreibung", "Ergaenzen") VALUES ({lid}, CURRENT_DATE, \'Leistung erbracht\', \'x\', TRUE)')
    r = q(f'SELECT "Hinweis", "Marke" FROM "V_Leistung" WHERE "ID" = {lid}')[0]
    pruef("Ergaenzen → Leistung „Angaben ergänzen“ mit !", r[0] == "Angaben ergänzen" and r[1] == "!", r)
    run(con, f'UPDATE "Ereignis" SET "Ergaenzen" = FALSE WHERE "LeistungID" = {lid}')
    r = q(f'SELECT "Hinweis" FROM "V_Leistung" WHERE "ID" = {lid}')[0]
    pruef("Ergänzt → Hinweis weg", r[0] != "Angaben ergänzen", r)
finally:
    try:
        doc.close(True)
    except Exception:
        pass
    o.proc.kill()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
