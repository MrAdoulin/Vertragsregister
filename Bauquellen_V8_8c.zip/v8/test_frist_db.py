"""B1-Rücktest Fristlogik: Die Base-Sichten liefern dieselben Werte wie die Calc-Fassung (Stand AP3).
Vorbereitung: cases.xlsx (AP1-Szenarien) und cases3.xlsx (AP3-Szenarien) heute mit recalc.py neu berechnen.
Aufruf: python3 test_frist_db.py <cases.xlsx> <cases3.xlsx>"""
import sys, os
from datetime import datetime, date
from openpyxl import load_workbook
from uno_util import Office
import db_build

KOPF = {
    "ID": "ID", "Gegenstand / Objekt": "Gegenstand", "Vertragsart": "Art", "Beginn": "Beginn",
    "Erstes Vertragsende": "ErstesEnde", "Auto-Verlängerung": "AutoVerl", "Verlängerung um (Monate)": "VerlMonate",
    "Kündigungsfrist (Monate)": "FristMonate", "Kündigungstermin": "KTermin", "Status": "Status",
    "Kosten (€)": "Kosten", "Zahlungsintervall": "Intervall", "Wertsicherung": "Wertsicherung",
    "Nächste Indexanpassung": "NaechsteAnpassung", "Zuletzt geprüft": "ZuletztGeprueft",
    "Entscheidung": "eArt", "Entschieden am": "eDatum", "Verantwortlich": "eVer", "Kündigung versandt am": "eVersandt",
    "Bestätigung erhalten am": "eBestaetigt",
}
VERGLEICH = {  # Calc-Kopf → Spalte in V_Vertrag, Typ
    "Aktuelles Laufzeitende": ("Ende", "d"), "Frühestes Ende (unbefristet)": ("Frueh", "d"),
    "Kündigungsstichtag": ("Stichtag", "d"), "Tage bis Stichtag": ("TageStichtag", "i"),
    "Tage bis Ende": ("TageEnde", "i"), "Hinweis": ("Hinweis", "s"),
    "Entscheidung aktuell?": ("EntAktuell", "s"), "Jahreskosten (€)": ("Jahreskosten", "n"),
    "Nächste Prüfung": ("NaechstePruefung", "d"),
}

def lese(path, zeilen):
    ws_f = load_workbook(path)["Verträge"]
    ws = load_workbook(path, data_only=True)["Verträge"]
    hdr = {ws.cell(row=4, column=c).value: c for c in range(1, 80) if ws.cell(row=4, column=c).value}
    out = []
    for r in zeilen:
        if not ws.cell(row=r, column=1).value:
            continue
        rec = {"_quelle": f"{os.path.basename(path)}:{r}"}
        for k in list(KOPF) + list(VERGLEICH):
            if k in hdr:
                rec[k] = ws.cell(row=r, column=hdr[k]).value
        out.append(rec)
    return out

def norm(v, t):
    if v in (None, ""):
        return None
    if t == "d":
        if isinstance(v, datetime):
            return v.date().isoformat()
        return str(v)[:10]
    if t == "i":
        return int(float(v))
    if t == "n":
        return round(float(v), 2)
    return str(v)

faelle = lese(sys.argv[1], list(range(5, 11)) + list(range(20, 34))) + lese(sys.argv[2], range(40, 50))
o = Office(2015)
fehler, abw = 0, []
try:
    doc, con = db_build.create_db(o, "test_frist.odb", samples=False, checks=False)
    db_build.run(con, 'INSERT INTO "Partner" ("Name") VALUES (\'Testpartner\')')
    # V8.2a: Die Calc-Fassung rechnet mit Rot 90 / Gelb 180 Tagen; der neue Standard ist 30 (E16). Für den Vergleich
    # der Datums- und Hinweislogik setzt der Test die Calc-Werte.
    db_build.run(con, 'UPDATE "Einstellung" SET "WarnTage" = 90, "VorwarnTage" = 180 WHERE "ID" = 1')
    ids = []
    for f in faelle:
        g = f.get("Gegenstand / Objekt") or f"Test {f['ID']}"
        werte = dict(
            Gegenstand=g, Art=f.get("Vertragsart"), PartnerID=1, Beginn=f.get("Beginn"),
            ErstesEnde=f.get("Erstes Vertragsende"), AutoVerl=(f.get("Auto-Verlängerung") == "ja"),
            VerlMonate=f.get("Verlängerung um (Monate)"), FristMonate=f.get("Kündigungsfrist (Monate)"),
            KTermin=f.get("Kündigungstermin"), Status=f.get("Status") or "aktiv", Kosten=f.get("Kosten (€)"),
            Intervall=f.get("Zahlungsintervall"), Wertsicherung=(f.get("Wertsicherung") == "ja"),
            NaechsteAnpassung=f.get("Nächste Indexanpassung"), ZuletztGeprueft=f.get("Zuletzt geprüft"))
        for k in ("Beginn", "ErstesEnde", "NaechsteAnpassung", "ZuletztGeprueft"):
            if isinstance(werte[k], datetime):
                werte[k] = werte[k].date()
        for k in ("VerlMonate", "FristMonate"):
            if werte[k] is not None:
                werte[k] = int(werte[k])
        if werte["Kosten"] is not None:
            werte["Kosten"] = float(werte["Kosten"])
        cols = ", ".join(f'"{k}"' for k in werte)
        db_build.run(con, f'INSERT INTO "Vertrag" ({cols}) VALUES ({", ".join(["?"] * len(werte))})', tuple(werte.values()))
        vid = int(db_build.query(con, 'SELECT MAX("ID") AS "M" FROM "Vertrag"')[0]["M"])
        ids.append(vid)
        art, am = f.get("Entscheidung"), f.get("Entschieden am")
        if art in ("verlängern", "kündigen", "neu verhandeln") and am:
            d = lambda x: x.date() if isinstance(x, datetime) else x
            db_build.run(con, 'INSERT INTO "Entscheidung" ("VertragID", "Art", "Datum", "Versandt", "Bestaetigt") '
                              'VALUES (?, ?, ?, ?, ?)',
                         (vid, art, d(am), d(f.get("Kündigung versandt am")), d(f.get("Bestätigung erhalten am"))))
    rows = {int(r["ID"]): r for r in db_build.query(con, 'SELECT * FROM "V_Vertrag"')}
    for f, vid in zip(faelle, ids):
        r = rows[vid]
        for kopf, (spalte, t) in VERGLEICH.items():
            if kopf not in f:
                continue
            calc, db = norm(f[kopf], t), norm(r.get(spalte), t)
            if calc == "Datum fehlt" and db is None:
                abw.append(f"{f['_quelle']} {f['ID']}: Entscheidung ohne Datum ist in Base nicht speicherbar (Calc: 'Datum fehlt').")
                continue
            if calc != db:
                fehler += 1
                print(f"FAIL {f['_quelle']} {f['ID']} {kopf}: Calc={calc!r} Base={db!r}")
    print(f"Fälle: {len(faelle)} | Vergleiche je Fall: bis {len(VERGLEICH)} | Abweichungen: {fehler}")
    for a in abw:
        print("Bekannte Abweichung:", a)
    print("ALLE OK" if fehler == 0 else "FEHLER")
    con.close()
    doc.close(True)
finally:
    o.close()
