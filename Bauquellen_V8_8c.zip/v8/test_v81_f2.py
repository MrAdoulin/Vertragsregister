"""V8.1-F2: Beenden ohne UNO-Brücke (wie unter Windows): LibreOffice endet mit Exit-Code 0, Sicherung und Probe laufen."""
import os, subprocess, shutil
shutil.rmtree("xui_test/Sicherung", ignore_errors=True)
r = subprocess.run(["python3", "-u", "exp_pur.py", "20"], capture_output=True, text=True, timeout=200)
print(r.stdout.strip())
ok = "EXIT nach Beenden 0" in r.stdout
prot = open("xui_test/Sicherung/protokoll.txt", encoding="utf-8", errors="replace").read() if os.path.exists("xui_test/Sicherung/protokoll.txt") else ""
ok2 = "Textsicherung" in prot and "Probe" in prot and "FEHLER" not in prot
print(("OK   " if ok else "FEHL ") + "F2 Beenden ohne Absturz (Exit 0)")
print(("OK   " if ok2 else "FEHL ") + "F2 Sicherung und Probe beim Beenden", prot.strip().replace("\n", " | "))
print("ERGEBNIS", int(ok) + int(ok2), "OK /", 2 - int(ok) - int(ok2), "FEHL")
