"""V8.1 · P1: Ablage prüfen mit Testablage 2 (alle Befundarten), Ort relativ, Fotos KPI/VE2/AB."""
import os, sys
from v8ui import V8, NAV, KPI
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
try:
    s.foto("exp/p1_ST.png")
    s.k(*NAV["EI"])
    B("TSetText", "Einstellung", "EI_txtAblage", os.path.abspath("ablage_test2") + "/")
    s.k(30300, 1000, warte=1.0)
    s.k(*NAV["AB"]); s.k(29900, 1000, warte=3)
    d = s.dialog_weg()
    pruef("P1 Ablage prüfen ohne Fehlermeldung", d is None, str(d))
    r = s.sql('SELECT "Nr", "Befund", "Ort" FROM "AbgleichBefund" ORDER BY "Nr", "ID"')
    for x in r: print("   ", x)
    erwartet = {
        ("", "Datei außerhalb eines Vertragsordners"), ("", "Ordner ohne Vertrag im Register"),
        ("V-001", "Datei geändert nach letzter Prüfung"), ("V-001", "Dateiname ohne Datum vorne"),
        ("V-001", "Neue Korrespondenz seit letzter Prüfung"),
        ("V-002", "Datei fehlt unter Dokumente"), ("V-002", "Datei geändert nach letzter Prüfung"),
        ("V-002", "Unterschriebene Fassung fehlt"),
        ("V-003", "Datei geändert nach letzter Prüfung"), ("V-003", "Unbekannter Unterordner"),
        ("V-004", "Ordnername weicht vom Register ab"), ("V-004", "Datei fehlt unter Dokumente")}
    ist = {(a or "", b) for a, b, _ in r}
    pruef("P1 alle Befundarten", erwartet <= ist, f"fehlend: {erwartet - ist}")
    pruef("P1 V-005/V-006 ohne Befund (Beleg mit Umlaut gefunden)", not any(a in ("V-005", "V-006") for a, _, _ in r))
    pruef("P1 Anzahl 16", len(r) == 16, str(len(r)))
    pruef("P1 Ort relativ", all(not o.startswith("V-00") or b.startswith("Ordner") for a, b, o in r if a),
          str([o for a, b, o in r if a][:4]))
    pruef("P1 Infozeile", "16 Befunde" in B("TLabel", "Abgleich", "AB_lblPfad"), B("TLabel", "Abgleich", "AB_lblPfad"))
    s.foto("exp/p1_AB.png")
    # Beleg fehlt: Datei umbenennen
    k = os.path.abspath("ablage_test2/V-006_Telefonanlage_TeleBeispiel/_korrespondenz/2026-09-20_Kündigung-versandt.pdf")
    os.rename(k, k + ".weg")
    s.k(29900, 1000, warte=3)
    s.dialog_weg()
    r = s.sql('SELECT "Nr", "Befund" FROM "AbgleichBefund" WHERE "Nr" = \'V-006\'')
    pruef("P1 Beleg fehlt wird erkannt", ("V-006", "Beleg fehlt in _korrespondenz") in r, str(r))
    os.rename(k + ".weg", k)
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
