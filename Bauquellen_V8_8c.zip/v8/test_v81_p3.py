"""V8.1 · P3: Zoom folgt der Fenstergröße (mind. 75 %), Rückfrage beim Schließen des Datenbankfensters."""
import os, time
from v8ui import V8, NAV
from Xlib import X, protocol
ok, fehler = [], []
def x_namen(sess):
    out = []
    def lauf(w):
        try:
            n = w.get_wm_name()
            if not n:
                pr = w.get_full_property(sess.d.intern_atom("_NET_WM_NAME"), 0)
                n = pr.value.decode("utf8", "replace") if pr else None
        except Exception:
            n = None
        if n:
            out.append((str(n), w))
        for k in w.query_tree().children:
            lauf(k)
    lauf(sess.d.screen().root)
    return out
def x_groesse(sess, cw, w, h):
    """F4: Größe über X11 ändern wie ein Fenstermanager (Hauptthread von LibreOffice), nicht über UNO setPosSize.
    UNO aus einem fremden Thread überschneidet sich mit dem Aufbau der Raster und lässt LibreOffice abstürzen."""
    ps = cw.getPosSize()
    root = sess.d.screen().root
    ziel = None
    for k in root.query_tree().children:
        try:
            if k.get_attributes().map_state != 2: continue
            g = k.get_geometry()
            if abs(g.width - ps.Width) <= 2 and abs(g.height - ps.Height) <= 2:
                ziel = k
        except Exception:
            pass
    ziel.configure(width=w, height=h); sess.d.sync()
def odb_x(sess):
    """Wie Klick auf das X des Datenbankfensters: WM_DELETE_WINDOW an das sichtbare Hauptfenster, das nicht das Formular ist."""
    import threading
    root = sess.d.screen().root
    sicht = [k for k in root.query_tree().children if k.get_attributes().map_state == 2]
    form_xid = None
    try:
        form_xid = sess.form().CurrentController.Frame.ContainerWindow.getWindowHandle(b"", 6)  # SYSTEM_XWINDOW
    except Exception:
        pass
    ziel = [k for k in sicht if form_xid is None or k.id != form_xid]
    print("   sichtbar:", [hex(k.id) for k in sicht], "Formular:", form_xid)
    if not ziel:
        return None
    w = ziel[0]
    ev = protocol.event.ClientMessage(window=w, client_type=sess.d.intern_atom("WM_PROTOCOLS"),
                                      data=(32, [sess.d.intern_atom("WM_DELETE_WINDOW"), X.CurrentTime, 0, 0, 0]))
    w.send_event(ev); sess.d.sync()
    return hex(w.id)

def odb_dispatch(sess):
    """Wie der Befehl, den das X auslöst: .uno:CloseFrame am Rahmen der .odb (läuft durch die Abfangkette)."""
    import threading
    db = [c for c in iter_comp(sess) if c.supportsService("com.sun.star.sdb.OfficeDatabaseDocument")][0]
    fr = db.CurrentController.Frame
    def lauf():
        try:
            h = sess.ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.DispatchHelper", sess.ctx)
            h.executeDispatch(fr, ".uno:CloseFrame", "_self", 0, ())
        except Exception as e:
            print("   dispatch:", type(e).__name__)
    threading.Thread(target=lauf, daemon=True).start()

def iter_comp(sess):
    e = sess.desk.Components.createEnumeration()
    while e.hasMoreElements():
        yield e.nextElement()

def odb_x_name(sess):
    for n, w in x_namen(sess):
        if "Base" in n and "Vertragsregister" not in n and "ormular" not in n:
            ev = protocol.event.ClientMessage(window=w, client_type=sess.d.intern_atom("WM_PROTOCOLS"),
                                              data=(32, [sess.d.intern_atom("WM_DELETE_WINDOW"), X.CurrentTime, 0, 0, 0]))
            w.send_event(ev); sess.d.sync()
            return n
    return None
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
try:
    doc = s.form()
    vs = doc.CurrentController.ViewSettings
    win = doc.CurrentController.Frame.ContainerWindow
    z0 = (vs.ZoomType, vs.ZoomValue); print("Start:", z0, win.getPosSize().Width, win.getPosSize().Height)
    pruef("P3 Start ganze Seite", vs.ZoomType == 2, str(z0))
    win.IsMaximized = False; time.sleep(2.0)
    x_groesse(s, win, 1000, 600); time.sleep(2.5)  # V8.1-F4
    z1 = (vs.ZoomType, vs.ZoomValue); print("1000x600:", z1); s.foto("exp/p3_1000.png")
    x_groesse(s, win, 640, 400); time.sleep(2.5)  # V8.1-F4
    z2 = (vs.ZoomType, vs.ZoomValue); print("640x400:", z2); s.foto("exp/p3_640.png")
    pruef("P3 kleines Fenster: Zoom bleibt bei 75 %", z2 == (3, 75), str(z2))
    x_groesse(s, win, 1400, 800); time.sleep(2.5)  # V8.1-F4
    z3 = (vs.ZoomType, vs.ZoomValue); print("1400x800:", z3)
    pruef("P3 großes Fenster: wieder ganze Seite", z3[0] == 2 and z3[1] >= 75, str(z3))
    pruef("P3 mittleres Fenster: ganze Seite oder 75 %", z1[0] == 2 or z1 == (3, 75), str(z1))
    win.IsMaximized = True; time.sleep(1.5)
    print("Fenster:", s.fenster())
    # Datenbankfenster schließen → Rückfrage → Nein
    odb_dispatch(s); time.sleep(1.5)
    d = s.dialog_weg(("No", "Nein"))
    pruef("P3 Rückfrage beim Schließen der .odb", d is not None and "ganz" in d, str(d))
    time.sleep(1.5)
    pruef("P3 Nein: Register bleibt offen", s.form() is not None and len(s.fenster()) >= 2, str(s.fenster()))
    db = [c for c in iter_comp(s) if c.supportsService("com.sun.star.sdb.OfficeDatabaseDocument")][0]
    pruef("P3 Datenbankfenster minimiert", db.CurrentController.Frame.ContainerWindow.IsMinimized)
    odb_dispatch(s); time.sleep(1.5)
    d = s.dialog_weg(("Yes", "Ja"))
    pruef("P3 zweite Rückfrage", d is not None, str(d))
    time.sleep(5)
    laeuft = bool(os.popen("pgrep -f 'soffice\\.bin'").read().strip())
    pruef("P3 Ja: LibreOffice beendet", not laeuft, str(laeuft))
finally:
    try:
        s.ende()
    except Exception:
        pass
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
