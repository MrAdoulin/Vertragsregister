from Xlib import X
def x_namen(sess):
    out = []
    def lauf(w):
        try:
            n = w.get_wm_name()
            if not n:
                pr = w.get_full_property(sess.d.intern_atom("_NET_WM_NAME"), 0)
                n = pr.value.decode("utf8", "replace") if pr else None
        except Exception:
            n = None
        if n:
            out.append((str(n), w))
        for k in w.query_tree().children:
            lauf(k)
    lauf(sess.d.screen().root)
    return out
