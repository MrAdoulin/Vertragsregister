"""V8.1 · P4 Papierkorb: Vertrag löschen, im Papierkorb sehen, zurückholen, endgültig löschen."""
import time
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
PK_ZURUECK, PK_ENDG = (29250, 3105), (25200, 3105)
s = V8("v8.odb", warte=5)
zahl = lambda t: int(s.sql(f'SELECT COUNT(*) FROM "{t}"')[0][0])
try:
    v0, l0, e0 = zahl("Vertrag"), zahl("Leistung"), zahl("Ereignis")
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    nr = s.fm("Info").getString(s.fm("Info").findColumn("Nr"))
    s.k(*VE["loeschen"], warte=0.8)
    d = s.dialog_weg(("Yes", "Ja"))
    pruef("P4 Löschen fragt nach und nennt Papierkorb", d is not None and "Papierkorb" in d, str(d)[:120])
    time.sleep(1)
    pruef("P4 Vertrag gelöscht", zahl("Vertrag") == v0 - 1, f"{v0}→{zahl('Vertrag')}")
    s.k(*NAV["PK"], warte=1.0)
    pk = s.fm("Papierkorb")
    pruef("P4 Bereich Papierkorb", s.bereich() == "PK" and pk.RowCount == 1, f"{s.bereich()} {pk.RowCount}")
    was = pk.getString(pk.findColumn("Was")) if pk.RowCount else ""
    pruef("P4 Eintrag nennt den Vertrag", nr in was, was)
    s.foto("exp/v81_PK.png")
    s.k(*PK_ZURUECK, warte=1.5)
    d = s.dialog_weg()
    pruef("P4 Zurückholen meldet Erfolg", d is not None and "Zurückgeholt" in d, str(d)[:120])
    pruef("P4 alles wieder da", (zahl("Vertrag"), zahl("Leistung"), zahl("Ereignis")) == (v0, l0, e0))
    pruef("P4 Papierkorb leer", s.fm("Papierkorb").RowCount == 0, str(s.fm("Papierkorb").RowCount))
    # noch einmal löschen und endgültig entfernen
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    s.k(*VE["loeschen"], warte=0.8); s.dialog_weg(("Yes", "Ja")); time.sleep(1)
    s.k(*NAV["PK"], warte=1.0)
    s.k(*PK_ENDG, warte=0.8)
    d = s.dialog_weg(("Yes", "Ja"))
    pruef("P4 Endgültig fragt nach", d is not None and "endgültig" in d, str(d)[:120])
    time.sleep(1)
    pruef("P4 Papierkorb nach endgültig leer", int(s.sql('SELECT COUNT(*) FROM "PK_Vertrag"')[0][0]) == 0 and s.fm("Papierkorb").RowCount == 0)
    pruef("P4 Vertrag bleibt weg", zahl("Vertrag") == v0 - 1)
    s.k(*PK_ENDG, warte=0.8)
    d = s.dialog_weg()
    pruef("P4 leerer Papierkorb: Hinweis", d is not None and "leer" in d, str(d))
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
