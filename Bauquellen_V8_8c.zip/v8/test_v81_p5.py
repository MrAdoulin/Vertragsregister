"""V8.1 · P5 Sicherung: Spiegel nach dem Speichern, Jetzt sichern (Vollstand, Tagesstand), Stand vergleichen und
zurückholen, Schließen mit Textsicherung und Probe."""
import os, time, glob, zipfile, shutil
import faulthandler; faulthandler.dump_traceback_later(330, exit=True)
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
base = os.path.abspath("xui_test")
shutil.rmtree(os.path.join(base, "Sicherung"), ignore_errors=True)
SJ, VG, ALLE, AUSW = (29450, 9405), (14800, 10550), (28250, 10550), (22500, 10550)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
sich = os.path.join(base, "Sicherung"); text = os.path.join(sich, "Text")
def offen():
    """V8.1-F1: Dateigriffe von soffice auf Dateien der Textsicherung (Windows sperrt solche Dateien)."""
    r = []
    for pid in os.popen("pgrep -f 'soffice[.]bin'").read().split():
        try:
            for fd in os.listdir(f"/proc/{pid}/fd"):
                try:
                    z = os.readlink(f"/proc/{pid}/fd/{fd}")
                except OSError:
                    continue
                if "/Sicherung/Text" in z:
                    r.append(z)
        except OSError:
            pass
    return r
def upd(q):
    s.form().DrawPage.Forms.getByName("Nav").ActiveConnection.createStatement().executeUpdate(q)
try:
    # 1 Spiegel nach dem ersten Speichern
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    vid = s.fm("Vertrag").getLong(s.fm("Vertrag").findColumn("ID"))
    B("TSetText", "Vertrag", "VE_txtGegenstand", "Probe Sicherung")
    s.k(*VE["sichern"], warte=2.0); s.dialog_weg()
    sp = glob.glob(os.path.join(sich, "*_Spiegel_*.odb"))
    pruef("P5 Spiegel nach dem Speichern", len(sp) == 1, str(sp))
    # 2 Jetzt sichern → Vollstand + zweiter Spiegel
    s.k(*NAV["PK"], warte=1.0)
    s.k(*SJ, warte=4.0)
    d = s.dialog_weg()
    pruef("P5 Jetzt sichern meldet Erfolg", d is not None and "Gesichert" in d, str(d)[:200])
    basis = glob.glob(os.path.join(text, "Basis_*.zip"))
    pruef("P5 Vollstand geschrieben", len(basis) == 1, str(basis))
    pruef("F1 keine offene ZIP nach Jetzt sichern", offen() == [], str(offen()))
    pruef("F1 keine .tmp im Textordner", glob.glob(os.path.join(text, "*.tmp")) == [], str(glob.glob(os.path.join(text, "*.tmp"))))
    pruef("P5 zwei Spiegel", len(glob.glob(os.path.join(sich, "*_Spiegel_*.odb"))) == 2)
    if basis:
        z = zipfile.ZipFile(basis[0]); namen = z.namelist()
        pruef("P5 ZIP enthält CSV je Tabelle", "Vertrag.csv" in namen and "Pruefung.csv" in namen and "Aenderung.csv" in namen, str(namen))
        n = int(s.sql('SELECT COUNT(*) FROM "Vertrag"')[0][0])
        zeilen = z.read("Vertrag.csv").decode("utf-8").strip().split("\n")
        pruef("P5 Vertrag.csv: Kopf + eine Zeile je Vertrag", len(zeilen) == n + 1, f"{len(zeilen)} / {n}")
        print("   ", zeilen[0][:80]); print("   ", zeilen[1][:120])
    # 3 Vertrag löschen und endgültig entfernen (Verlust), Kosten ändern, Jetzt sichern → Tagesstand
    v0 = int(s.sql('SELECT COUNT(*) FROM "Vertrag"')[0][0]); l0 = int(s.sql('SELECT COUNT(*) FROM "Leistung"')[0][0])
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    vid = s.fm("Vertrag").getLong(s.fm("Vertrag").findColumn("ID"))
    nr = s.sql(f'SELECT "Nr" FROM "Vertrag" WHERE "ID" = {vid}')[0][0]
    kid = 3 if vid == 2 else 2
    s.k(*VE["loeschen"], warte=0.8); s.dialog_weg(("Yes", "Ja")); time.sleep(1)
    s.k(*NAV["PK"], warte=1.0); s.k(25200, 3105, warte=0.8); s.dialog_weg(("Yes", "Ja")); time.sleep(1)
    pruef("P5 Vertrag endgültig weg", int(s.sql('SELECT COUNT(*) FROM "Vertrag"')[0][0]) == v0 - 1)
    upd('UPDATE "Vertrag" SET "Kosten" = 111 WHERE "ID" = ' + str(kid))
    s.k(*SJ, warte=4.0); d = s.dialog_weg()
    tag = glob.glob(os.path.join(text, "Tag_*.zip"))
    pruef("P5 Tagesstand geschrieben", len(tag) == 1 and d is not None and "Gesichert" in d, f"{tag} {str(d)[:120]}")
    if tag:
        z = zipfile.ZipFile(tag[0])
        gel = z.read("Geloescht.csv").decode()
        pruef("P5 Tagesstand: Löschvermerk", f"Vertrag;{vid}" in gel, gel[:120])
        zl = z.read("Vertrag.csv").decode().strip().split("\n")
        pruef("P5 Tagesstand: nur Änderungen", 2 <= len(zl) <= 3, str(len(zl)))
    # 4 Vollstand wählen → vergleichen → alle fehlenden zurückholen
    upd('UPDATE "Vertrag" SET "Kosten" = 222 WHERE "ID" = ' + str(kid))
    s.k(*NAV["ST"], warte=0.8); s.k(*NAV["PK"], warte=1.2)
    lb = s.fm("Vergleich").getByName("PK_lbStand")
    print("    Stände:", lb.StringItemList)
    pruef("P5 Liste der Stände", len(lb.StringItemList) == 2 and "Tagesstand" in lb.StringItemList[0] and "Vollstand" in lb.StringItemList[1], str(lb.StringItemList))
    lb.SelectedItems = (1,)
    s.k(*VG, warte=6.0); d = s.dialog_weg()
    pruef("F1 keine offene ZIP nach Vergleichen", offen() == [], str(offen()))
    r = s.sql('SELECT "Art", "Was", "Unterschied" FROM "R_Vergleich" ORDER BY "Rang"')
    print("    Vergleich Vollstand:", r[:6], len(r))
    pruef("P5 Vergleich: Vertrag fehlt heute", any(a == "Vertrag" and u == "fehlt heute" and nr in w for a, w, u in r), str(r[:3]))
    pruef("P5 Vergleich: Kosten geändert", any(u == "geändert" for a, w, u in r))
    s.foto("exp/v81_PK_vergleich.png")
    s.k(*ALLE, warte=4.0); d = s.dialog_weg()
    pruef("P5 Alle fehlenden zurückgeholt", d is not None and "zurückgeholt" in d, str(d)[:120])
    pruef("P5 Vertrag und Leistungen wieder da", int(s.sql('SELECT COUNT(*) FROM "Vertrag"')[0][0]) == v0 and int(s.sql('SELECT COUNT(*) FROM "Leistung"')[0][0]) == l0)
    pruef("P5 Geändertes blieb unverändert", s.sql('SELECT CAST("Kosten" AS INTEGER) FROM "Vertrag" WHERE "ID" = ' + str(kid))[0][0] == "222")
    # 5 Tagesstand wählen → geändert → ausgewählte zurückholen → Kosten 111
    lb.SelectedItems = (0,)
    s.k(*VG, warte=6.0); s.dialog_weg()
    r = s.sql('SELECT "ID", "Art", "Unterschied" FROM "R_Vergleich"')
    print("    Vergleich Tagesstand:", r)
    # wie der Nutzer: Haken in der ersten Zeile setzen, dann „Ausgewählte zurückholen"
    s.k(7700, 12925, warte=0.8)  # V8.5-N18: Markierungsspalte schiebt die Haken-Spalte nach rechts
    k1 = s.fm("Vergleich").IsModified
    if not k1:
        s.k(7700, 12925, warte=0.8)  # V8.5-N18: Markierungsspalte schiebt die Haken-Spalte nach rechts
    s.foto("exp/p5_haken.png")
    print("    Haken nach 1. Klick:", k1, "nach 2. Klick:", s.fm("Vergleich").IsModified)
    import threading
    threading.Timer(25, lambda: s.foto("exp/p5_haengt.png")).start()
    s.k(*AUSW, warte=3.0); s.foto("exp/p5_ausw.png"); d = s.dialog_weg()
    pruef("P5 Ausgewählte zurückgeholt", d is not None and "zurückgeholt" in d, str(d)[:120])
    pruef("P5 Kosten wie im Tagesstand", s.sql('SELECT CAST("Kosten" AS INTEGER) FROM "Vertrag" WHERE "ID" = ' + str(kid))[0][0] == "111")
    pruef("P5 Spur: aus der Sicherung zurückgeholt (V8.2c-N03)", int(s.sql('SELECT COUNT(*) FROM "Aenderung" WHERE "Aktion" = \'zurückS\'')[0][0]) > 0)
    # 6 Schließen per X: Textsicherung, Spiegel, Probe
    vor = {os.path.basename(f): os.path.getmtime(f) for f in glob.glob(os.path.join(sich, "*_Spiegel_*.odb"))}
    print("    Fenster vor X:", s.fenster())
    s.foto("exp/p5_vorX.png")
    s.schliessen_x(None); time.sleep(3); s.foto("exp/p5_nachX.png"); time.sleep(10)
    print("    Dateien:", sorted(os.listdir(sich)), sorted(os.listdir(text)))
    nach = {os.path.basename(f): os.path.getmtime(f) for f in glob.glob(os.path.join(sich, "*_Spiegel_*.odb"))}
    pruef("P5 Spiegel beim Schließen erneuert", any(nach[k] > vor.get(k, 0) for k in nach), str(nach))
    pr = open(os.path.join(sich, "pruefung.txt"), encoding="utf-8").read() if os.path.exists(os.path.join(sich, "pruefung.txt")) else ""
    pruef("P5 Probe beim Schließen: OK", ";OK;" in pr, pr)
    print("    protokoll:", open(os.path.join(sich, "protokoll.txt"), encoding="latin-1").read()[-600:])
    pruef("P5 LibreOffice beendet", not os.popen("pgrep -f 'soffice\\.bin'").read().strip())
finally:
    try:
        s.ende()
    except Exception:
        pass
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
