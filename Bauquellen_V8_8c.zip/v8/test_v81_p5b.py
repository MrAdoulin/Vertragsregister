"""V8.1 · P5: Warnung nach fehlgeschlagener Probe; Spiegeldatei als Register übernehmen (Notfall)."""
import os, time, shutil, glob
import faulthandler; faulthandler.dump_traceback_later(300, exit=True)
from v8ui import V8
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
base = os.path.abspath("xui_test")
sich = os.path.join(base, "Sicherung")
os.makedirs(sich, exist_ok=True)
open(os.path.join(sich, "pruefung.txt"), "w").write("2026-10-14;FEHLER: Spiegel nicht lesbar (Test);v8_Spiegel_A.odb")
s = V8("v8.odb", warte=6)
try:
    d = s.dialog_weg()
    pruef("P5 Warnung nach fehlgeschlagener Probe", d is not None and "Probe" in d, str(d)[:160])
finally:
    s.ende()
os.remove(os.path.join(sich, "pruefung.txt"))
# Notfall: Spiegel öffnen. Herkunft zeigt auf eine Testdatei (die „kaputte" Datei)
for _f in glob.glob(os.path.join(base, "Register_kaputt*")): os.remove(_f)
ziel = os.path.join(base, "Register_kaputt.odb")
open(ziel, "wb").write(b"kaputt")
spiegel = os.path.join(base, "v8_Spiegel_A.odb")
shutil.copy("v8.odb", "v8_Spiegel_A.odb")
open(os.path.join(base, "Spiegel_Herkunft.txt"), "w").write("file://" + ziel)
s = V8("v8_Spiegel_A.odb", warte=6)
try:
    d = s.dialog_weg(("No", "Nein"))
    pruef("P5 Spiegel fragt nach Übernahme", d is not None and "Sicherungskopie" in d and "übernehmen" in d, str(d)[:200])
    d = s.dialog_weg()
    pruef("P5 Nein: nur zum Ansehen", d is not None and "Ansehen" in d, str(d)[:120])
finally:
    s.ende()
s = V8("v8_Spiegel_A.odb", warte=6)
try:
    d = s.dialog_weg(("Yes", "Ja")); time.sleep(1)
    d = s.dialog_weg()
    pruef("P5 Ja: Erledigt-Meldung", d is not None and "Erledigt" in d, str(d)[:160])
    time.sleep(5)
finally:
    try: s.ende()
    except Exception: pass
defekt = glob.glob(os.path.join(base, "Register_kaputt_defekt_*.odb"))
pruef("P5 kaputte Datei umbenannt", len(defekt) == 1, str(defekt))
pruef("P5 Register ersetzt", os.path.exists(ziel) and os.path.getsize(ziel) > 100000, str(os.path.getsize(ziel) if os.path.exists(ziel) else 0))
pruef("P5 Spiegel schreibt keine eigene Sicherung", not glob.glob(os.path.join(base, "Sicherung", "v8_Spiegel_A_Spiegel_*")))
os.remove("v8_Spiegel_A.odb")
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
