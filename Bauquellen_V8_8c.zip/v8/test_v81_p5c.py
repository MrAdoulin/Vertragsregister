"""V8.1 · P5: 30-Tage-Schwelle für den Basisstand und Aufbewahrung (Tagesdateien 30 Tage, 12 Basisstände + erster je Jahr)."""
import os, time, shutil, glob
import faulthandler; faulthandler.dump_traceback_later(250, exit=True)
from v8ui import V8, NAV
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
base = os.path.abspath("xui_test"); sich = os.path.join(base, "Sicherung"); text = os.path.join(sich, "Text")
shutil.rmtree(sich, ignore_errors=True); os.makedirs(text)
alt = [f"Basis_2025-{m:02d}-05_1000.zip" for m in range(1, 13)] + [f"Basis_2026-{m:02d}-05_1000.zip" for m in (1, 2, 3)] + ["Basis_2026-09-01_1000.zip"]
for n in alt + ["Tag_2026-08-01.zip", "Tag_2026-10-01.zip"]:
    open(os.path.join(text, n), "w").write("x")
open(os.path.join(text, "basis.txt"), "w").write("2026-09-01 10:00:00;Basis_2026-09-01_1000.zip")
open(os.path.join(text, "stand.txt"), "w").write("2026-10-01 10:00:00")
s = V8("v8.odb", warte=5)
try:
    time.sleep(3); s.k(*NAV["PK"], warte=2.5); s.foto("exp/p5c_pk.png"); s.k(29450, 9405, warte=5.0)  # V8.4: Start abwarten (Breite)
    d = s.dialog_weg()
    pruef("P5 Jetzt sichern", d is not None and "Gesichert" in d, str(d)[:150])
finally:
    s.ende()
namen = sorted(os.listdir(text)); print(namen)
neu = [n for n in namen if n.startswith("Basis_" + time.strftime("%Y-%m-%d"))]  # V8.2c: heutiges Datum
pruef("P5 Basisstand nach 30 Tagen neu", len(neu) == 1, str(neu))
pruef("P5 Tagesdatei > 30 Tage gelöscht", "Tag_2026-08-01.zip" not in namen)
pruef("P5 Tagesdatei < 30 Tage bleibt", "Tag_2026-10-01.zip" in namen)
weg = [n for n in alt if n not in namen]
pruef("P5 alte Basisstände: 4 gelöscht", weg == [f"Basis_2025-{m:02d}-05_1000.zip" for m in (2, 3, 4, 5)], str(weg))
pruef("P5 erster Basisstand 2025 bleibt", "Basis_2025-01-05_1000.zip" in namen)
pruef("P5 13 Basisstände übrig", len([n for n in namen if n.startswith("Basis_")]) == 13)
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
