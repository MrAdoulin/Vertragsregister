"""V8.1 · P6: Fehler/Wunsch melden – Element erfassen, Kommentar, meldungen.txt."""
import os, time, shutil
import faulthandler; faulthandler.dump_traceback_later(240, exit=True)
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
base = os.path.abspath("xui_test"); shutil.rmtree(os.path.join(base, "Meldungen"), ignore_errors=True)
from v8ui import MELDEN  # V8.2b-M04
s = V8("v8.odb", warte=5)
try:
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    vid = s.fm("Vertrag").getLong(s.fm("Vertrag").findColumn("ID"))
    s.k(*MELDEN, warte=0.8)
    nav = s.form().DrawPage.Forms.getByName("Nav")
    pruef("P6 Melden wartet auf Klick", nav.getByName("NA_btnMelden").Tag == "warte", nav.getByName("NA_lblStatus").Label)
    s.foto("exp/v81_melden_warte.png")
    s.k(8200, 5500, warte=2.0)
    d = s.dialog()
    pruef("P6 Dialog zeigt erfasstes Element", d is not None and "VE1_txtVertragsnummer" in d, str(d)[:300])
    s.foto("exp/v81_melden_dialog.png")
    s.tippen("Nummer soll sechzehn Stellen haben"); time.sleep(0.5)
    s.dialog_weg(("Speichern",)); time.sleep(1)
    d = s.dialog_weg()
    pruef("P6 Bestätigung mit Dateiort", d is not None and "meldungen.txt" in d, str(d)[:160])
    f = os.path.join(base, "Meldungen", "meldungen.txt")
    t = open(f, encoding="utf-8").read() if os.path.exists(f) else ""
    print(t)
    pruef("P6 Datei: Element, Datenfeld, Datensatz, Kommentar", "VE1_txtVertragsnummer" in t and "Datenfeld:  Vertragsnummer" in t
          and f"ID {vid}" in t and "sechzehn Stellen" in t and "Bereich:    VE1" in t)
    pruef("P6 Knopf wieder normal", nav.getByName("NA_btnMelden").Tag == "")
    # Abbrechen durch zweiten Klick auf Melden
    # V8.4: nach dem Bestätigungsfenster holt der erste Klick unter Xvfb nur das Fenster nach vorn → neutraler Klick
    s.k(20000, 17600, warte=1.0)
    print("   vor dem Abbrechen:", repr(nav.getByName("NA_btnMelden").Tag))
    s.k(*MELDEN, warte=1.5)
    print("   nach Klick 1:", repr(nav.getByName("NA_btnMelden").Tag))
    s.k(*MELDEN, warte=2.0)
    pruef("P6 zweiter Klick bricht ab", nav.getByName("NA_btnMelden").Tag != "warte" and s.dialog(warte=1.0) is None, nav.getByName("NA_btnMelden").Tag)
    # Raster: Element in einem Raster
    s.k(*NAV["LI"], warte=0.8); s.k(*MELDEN, warte=0.6); s.k(15000, LISTE_ZEILE1, warte=2.0)
    d = s.dialog()
    pruef("P6 Raster erfasst", d is not None and "LI_gridListe" in d and "Datensatz" in d, str(d)[:300])
    s.dialog_weg(("Abbrechen", "Cancel"))
    # V8.1-F3: Klick auf einen Knopf im Meldemodus löst dessen Aktion nicht aus
    s.k(*NAV["ST"], warte=1.0)
    b0 = s.bereich()
    s.k(*MELDEN, warte=0.6); s.k(*NAV["PA"], warte=2.0)
    d = s.dialog()
    pruef("F3 Knopf erfasst", d is not None and "NA_navPA" in d, str(d)[:200])
    s.dialog_weg(("Abbrechen", "Cancel")); time.sleep(1.0)
    pruef("F3 Knopfaktion nicht ausgelöst", s.bereich() == b0, f"{b0} -> {s.bereich()}")
    s.k(*NAV["PA"], warte=1.5)
    pruef("F3 Knopf danach wieder bedienbar", s.bereich() != b0, str(s.bereich()))
    import glob
    bilder = glob.glob(os.path.join(base, "Meldungen", "*.png"))
    pruef("P6 Bild der Ansicht", len(bilder) >= 1 and os.path.getsize(bilder[0]) > 10000, str(bilder))
    t = open(os.path.join(base, "Meldungen", "meldungen.txt"), encoding="utf-8").read()
    pruef("P6 Bild in der Meldung vermerkt", "Bild:       meldung_" in t)
    if bilder: shutil.copy(sorted(bilder)[-1], "exp/v81_meldung_bild.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
