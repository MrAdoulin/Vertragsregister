"""V8.1 · Oberflächentest: P1 Ablage prüfen (alle Befundarten), P2 Vertragsnummer."""
import os, time
from v8ui import V8, NAV, KPI, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
info_nr = lambda: s.fm("Info").getString(s.fm("Info").findColumn("Nr"))
try:
    s.foto("exp/v81_ST.png")
    # ---- P1/P2 Ablage prüfen mit Ordnern nach Vertragsnummer
    s.k(*NAV["EI"])
    B("TSetText", "Einstellung", "EI_txtAblage", os.path.abspath("ablage_test3") + "/")
    s.k(30300, 1000, warte=1.0)
    s.k(*NAV["AB"]); s.k(29900, 1000, warte=3)
    d = s.dialog_weg()
    pruef("P1 Ablage prüfen ohne Fehlermeldung", d is None, str(d))
    r = s.sql('SELECT "Nr", "Befund", "Ort" FROM "AbgleichBefund" ORDER BY "Nr", "ID"')
    for x in r: print("   ", x)
    A, Bn, C, D = "12_132_01_2023", "14_210_03_2024", "11_305_02_2022", "unbenannt 4"
    erwartet = {("", "Datei außerhalb eines Vertragsordners"), ("", "Ordner ohne Vertrag im Register"),
                (A, "Datei geändert nach letzter Prüfung"), (A, "Dateiname ohne Datum vorne"),
                (A, "Neue Korrespondenz seit letzter Prüfung"), (Bn, "Datei fehlt unter Dokumente"),
                (Bn, "Datei geändert nach letzter Prüfung"), (Bn, "Unterschriebene Fassung fehlt"),
                (C, "Datei geändert nach letzter Prüfung"), (C, "Unbekannter Unterordner"),
                (D, "Ordnername weicht vom Register ab"), (D, "Datei fehlt unter Dokumente")}
    ist = {(a or "", b) for a, b, _ in r}
    pruef("P1 alle Befundarten", erwartet <= ist, f"fehlend: {erwartet - ist}; zuviel: {ist - erwartet}")
    pruef("P1 13_118 und 12_132_04 ohne Befund (Beleg mit Umlaut)", not any(a in ("13_118_01_2024", "12_132_04_2022") for a, _, _ in r))
    pruef("P1 Anzahl 16", len(r) == 16, str(len(r)))
    s.foto("exp/v81_AB.png")
    k = os.path.abspath("ablage_test3/12_132_04_2022_Telefonanlage_TeleBeispiel/_korrespondenz/2026-09-20_Kündigung-versandt.pdf")
    os.rename(k, k + ".weg")
    s.k(29900, 1000, warte=3); s.dialog_weg()
    r = s.sql('SELECT "Nr", "Befund" FROM "AbgleichBefund" WHERE "Nr" = \'12_132_04_2022\'')
    pruef("P1 Beleg fehlt wird erkannt", ("12_132_04_2022", "Beleg fehlt in _korrespondenz") in r, str(r))
    os.rename(k + ".weg", k)
    # ---- P2 Anzeige
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"])
    liste = s.sql('SELECT "Nr" FROM "V_Liste" ORDER BY "Nr"')
    pruef("P2 Liste zeigt Nummern", ("12_132_01_2023",) in [tuple(x) for x in liste] and ("unbenannt 4",) in [tuple(x) for x in liste], str(liste))
    s.foto("exp/v81_LI.png")
    s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    for _ in range(7):
        if info_nr() == "unbenannt 4":
            break
        s.k(*VE["pfeil_v"], warte=0.6)
    pruef("P2 Vertrag unbenannt 4 geöffnet", info_nr() == "unbenannt 4", info_nr())
    s.foto("exp/v81_VE1.png")
    def nummer(t):
        B("TSetText", "Vertrag", "VE1_txtVertragsnummer", t)
        s.k(*VE["sichern"], warte=0.8)
        return s.dialog_weg()
    d = nummer("12_132_01_2023")
    pruef("P2 doppelte Nummer → Meldung", d is not None and "gibt es schon" in d, str(d))
    d = nummer("AB/1")
    pruef("P2 Schrägstrich → Meldung", d is not None and "nicht enthalten" in d, str(d))
    d = nummer("XYZ-1")
    pruef("P2 anderer Aufbau → Hinweis", d is not None and "anders aufgebaut" in d, str(d))
    time.sleep(0.8)
    r = s.sql('SELECT "Nr" FROM "Vertrag" WHERE "ID" = 4')
    pruef("P2 trotzdem gespeichert", r == [["XYZ-1"]] or r == [("XYZ-1",)], str(r))
    d = nummer("15_100_01_2026")
    pruef("P2 üblicher Aufbau ohne Meldung", d is None, str(d))
    r = s.sql('SELECT "Nr" FROM "Vertrag" WHERE "ID" = 4')
    pruef("P2 neue Nummer gespeichert", str(r).find("15_100_01_2026") >= 0, str(r))
    time.sleep(0.5)
    pruef("P2 Kopf zeigt neue Nummer", info_nr() == "15_100_01_2026", info_nr())
    s.foto("exp/v81_VE1_nr.png")
    s.k(*VE["tab2"]); s.foto("exp/v81_VE2.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
