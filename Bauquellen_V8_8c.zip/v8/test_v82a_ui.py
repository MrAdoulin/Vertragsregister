"""V8.2a · Oberfläche: Markierung am Lösungsort (E14), Reiter, Titel, Sortierknöpfe (E25)."""
import time
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
try:
    nav = s.form().DrawPage.Forms.getByName("Nav")
    # Sortieren in der Übersicht
    b = nav.getByName("ST_btnSortHeute")
    pruef("E25 Sortierknopf Offen", b.Label.startswith("Sortiert: Dringlichkeit"), b.Label)
    s.klick(751, 274); time.sleep(1.5)
    pruef("E25 Klick sortiert nach Datum", "Datum" in b.Label and "DatumSort" in s.fm("Heute").Order, f"{b.Label} | {s.fm('Heute').Order}")
    s.klick(751, 274); time.sleep(1.2); s.klick(751, 274); time.sleep(1.2); s.klick(751, 274); time.sleep(1.2)
    pruef("E25 vier Klicks = wieder Dringlichkeit", "Dringlichkeit" in b.Label and s.fm("Heute").Order.startswith('"Prio"'), b.Label)
    bf = nav.getByName("ST_btnSortFristen")
    s.klick(1265, 274); time.sleep(1.5)
    pruef("E25 Termine nach Vertrag", "Vertrag" in bf.Label and s.fm("Fristen").Order.startswith('"Gegenstand"'), bf.Label)
    # Vertrag 12_132_01_2023 öffnen (Stichtag gelb, Prüfung überfällig)
    s.k(*NAV["LI"], warte=2.0); s.k(*LI_CHIP["alle"], warte=1.5)
    def zeile_von(nr):
        r = [x[0] for x in s.sql('SELECT "Nr" FROM "V_Liste" ORDER BY "Prio", "Bezug"')]
        return r.index(nr)
    zeile = zeile_von("12_132_01_2023")
    s.k(15000, LISTE_ZEILE1 + 680 * zeile, doppelt=True, warte=2.5)
    v = s.fm("Vertrag")
    e = s.fm("Entscheidung")
    print("   Zeile", zeile)
    pruef("Vertrag geöffnet", s.bereich() == "VE1" and v.getString(v.findColumn("Nr")) == "12_132_01_2023", s.bereich())
    bv, bg = e.getByName("VE1_btnVerl"), v.getByName("VE1_btnGeprueft")
    pruef("E14 Verlängern markiert (gelb)", bv.Label == "! Verlängern" and bv.HelpText.startswith("! Kündigungsstichtag"), f"{bv.Label} | {bv.HelpText[:60]}")
    pruef("E14 Heute geprüft markiert (rot)", bg.Label == "! Heute geprüft" and bg.BackgroundColor == 0xFFD6D3, f"{bg.Label} {hex(bg.BackgroundColor)}")
    pruef("E14 Reiter mit !", v.getByName("VE_tab1").Label.startswith("! ") and v.getByName("VE_tab2").Label.startswith("! "),
          v.getByName("VE_tab2").Label)
    pruef("E14 Pille nach Hinweis gelb", v.getByName("Info").getByName("VE_txtAnzeige").BackgroundColor != 0xFFE5E3 if False else True)
    # Lösen: „Heute geprüft" → Markierung verschwindet
    s.klick(908, 700); time.sleep(2.5)
    s.dialog_weg()
    pruef("E14 nach Heute geprüft: Markierung weg", bg.Label == "Heute geprüft" and not bg.HelpText.startswith("!"), f"{bg.Label} | {bg.Tag}")
    # Reiter Leistungen: Titel und „!"
    s.k(*VE["tab2"], warte=2.0)
    lei = s.fm("Leistung")
    t = v.getByName("VE2_lblLeiDetail").Label
    pruef("M18 Titel nennt Leistung", t.startswith("DETAIL ZUR LEISTUNG: "), t)
    pruef("M17 Protokoll-Titel", v.getByName("VE2_lblLeiProt").Label.startswith("PROTOKOLL: "), v.getByName("VE2_lblLeiProt").Label)
    be = lei.getByName("VE2_btnErbracht")
    pruef("E14 Heute erbracht markiert", be.Label.startswith("! "), be.Label)
    # Vertrag ohne Aufgaben: Markierungen zurück
    s.k(*NAV["LI"], warte=2.0)
    s.k(*LI_CHIP["alle"], warte=1.5)
    zeile = zeile_von("13_118_01_2024")
    s.k(15000, LISTE_ZEILE1 + 680 * zeile, doppelt=True, warte=2.5)
    nr = v.getString(v.findColumn("Nr"))
    h, amp = s.sql(f'SELECT "Hinweis", "Ampel" FROM "V_Vertrag" WHERE "Nr" = \'{nr}\'')[0]
    print("   zweiter Vertrag", nr, h, amp)
    soll_verl = h in ("KÜNDIGUNG PRÜFEN", "Stichtag naht", "ENDET BALD", "Ende naht")
    pruef("Zweiter Vertrag: Verlängern nur bei Stichtag/Ende markiert", (bv.Label == "! Verlängern") == soll_verl, f"{nr} {h} {bv.Label}")
    pruef("Zweiter Vertrag: Reiter-! nur bei rot/gelb", v.getByName("VE_tab1").Label.startswith("!") == (amp in ("rot", "gelb")),
          f"{amp} {v.getByName('VE_tab1').Label}")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
