"""V8.2b · Oberfläche: Seitenleiste (M04), Vertrag löschen (M14), Sichern grau (M06), „H" (M19), Verwerfen (M21),
Vorschläge (M20), Kästchen im Meldemodus (F9), Sortieren nach Datum (B2)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE, MELDEN
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
GRAU, BLAU = 0xE5E5EA, 0x007AFF
s = V8("v8.odb", warte=5)
def mitte(name=None, form=None, feld=None):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            m = sh.Control
        except Exception:
            continue
        if (name and m.Name == name) or (feld and m.Parent.Name == form and getattr(m, "DataField", "") == feld):
            return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2, m
    raise KeyError(name or feld)
def oeffnen(nr):
    s.k(*NAV["LI"], warte=2.0); s.k(*LI_CHIP["alle"], warte=1.5)
    r = [x[0] for x in s.sql('SELECT "Nr" FROM "V_Liste" ORDER BY "Prio", "Bezug"')]
    s.k(15000, LISTE_ZEILE1 + 680 * r.index(nr), doppelt=True, warte=3.0)
try:
    nav = s.form().DrawPage.Forms.getByName("Nav")
    # M04
    pruef("M04 Beenden schmal", nav.getByName("NA_btnBeenden").Label == "Beenden")
    pruef("M04 Melden als Käfer mit Tooltip", nav.getByName("NA_btnMelden").Label == "\U0001F41E"
          and "melden" in nav.getByName("NA_btnMelden").HelpText.lower())
    s.k(*NAV["EI"], warte=2.0)
    pruef("M04 Zahnrad öffnet Einstellungen", s.bereich() == "EI", s.bereich())
    pruef("M04 Zahnrad leuchtet", nav.getByName("NA_navEI").BackgroundColor == 0xE5F1FF, hex(nav.getByName("NA_navEI").BackgroundColor))
    s.k(*NAV["ST"], warte=1.5)
    # B2: Sortierknopf Offen auf Datum
    st = s.fm("Heute")
    s.klick(751, 274); time.sleep(1.5)
    st.first(); daten = []
    while not st.isAfterLast():
        daten.append(st.getString(st.findColumn("DatumText"))); st.next()
    leer = [i for i, d in enumerate(daten) if d == "—"]
    pruef("B2 ohne Datum am Ende", leer and leer == list(range(leer[0], len(daten))), daten)
    # M14, M06
    oeffnen("12_132_04_2022")
    v = s.fm("Vertrag")
    pruef("M14 Vertrag löschen", v.getByName("VE_btnLoeschen").Label == "Vertrag löschen")
    b = v.getByName("VE_btnSichern")
    pruef("M06 Sichern grau ohne Änderung", b.BackgroundColor == GRAU, hex(b.BackgroundColor))
    s.k(*VE["gegenstand"], warte=0.5); s.taste("End"); s.tippen("Z"); s.taste("Tab"); time.sleep(1.0)
    pruef("M06 Sichern blau nach Änderung", b.BackgroundColor == BLAU, hex(b.BackgroundColor))
    s.k(*VE["sichern"], warte=2.5)
    pruef("M06 Sichern grau nach Sichern", b.BackgroundColor == GRAU and not v.IsModified, hex(b.BackgroundColor))
    # M19: H über leeren Feldern, auch über markiertem Feld; Klick trägt heute ein
    E = s.fm("Entscheidung")
    hb = E.getByName("VE1h_txtBestaetigt")
    pruef("M19 H über leerem, markiertem Feld", hb.EnableVisible and E.getByName("VE1_txtBestaetigt").Date is None)
    pruef("M19 kein H über gefülltem Feld", not E.getByName("VE1h_txtVersandt").EnableVisible)
    x, y, _ = mitte("VE1h_txtGeprueft")
    s.k(x, y, warte=1.5)
    g = v.getByName("VE1_txtGeprueft").Date
    heute = time.localtime()
    pruef("M19 Klick auf H trägt heute ein", g is not None and (g.Year, g.Month, g.Day) == heute[:3], str(g))
    pruef("M19 H danach weg", not v.getByName("VE1h_txtGeprueft").EnableVisible)
    s.k(*VE["sichern"], warte=2.5)
    s.k(*VE["pfeil_v"], warte=3.0)
    leer = v.getByName("VE1_txtGeprueft").Date is None
    pruef("M19 nächster Vertrag: H folgt dem Feld", v.getByName("VE1h_txtGeprueft").EnableVisible == leer, f"leer={leer}")
    # F9: Kästchen im Meldemodus schaltet nicht um
    x, y, chk = mitte(form="Vertrag", feld="Wertsicherung")
    st0 = chk.State
    s.k(*MELDEN, warte=0.8); s.k(x - 1500, y, warte=2.0)
    d = s.dialog()
    pruef("F9 Kästchen erfasst", d is not None and "Wertsicherung" in d, str(d)[:120])
    s.dialog_weg(("Abbrechen", "Cancel")); time.sleep(1.5)
    pruef("F9 Kästchen unverändert", chk.State == st0 and not v.IsModified, f"{st0}->{chk.State} mod={v.IsModified}")
    # M21, M20 im Protokoll
    s.k(*NAV["PR"], warte=2.5)
    e = s.fm("Ereignis")
    vw = e.getByName("PRv_btnVerwerfen")
    pruef("M21 Verwerfen unsichtbar ohne Änderung", not vw.EnableVisible)
    x, y, besch = mitte(form="Ereignis", feld="Beschreibung")
    alt = besch.Text
    s.k(x, y, warte=0.5); s.taste("End"); s.tippen(" Test"); s.taste("Tab"); time.sleep(1.0)
    pruef("M21 Verwerfen sichtbar nach Änderung", vw.EnableVisible and vw.Label == "Verwerfen")
    x, y, _ = mitte("PRv_btnVerwerfen")
    s.k(x, y, warte=2.0)
    pruef("M21 Verwerfen stellt wieder her", besch.Text == alt and not e.IsModified and not vw.EnableVisible, besch.Text)
    cb = e.getByName("PR_cbFreiVon")
    pruef("M20 Vorschläge Freigegeben von", "F. Muster" in cb.StringItemList, cb.StringItemList)
    pruef("M20 Vorschläge Beleg", len(e.getByName("PR_cbBeleg").StringItemList) > 0, e.getByName("PR_cbBeleg").StringItemList[:2])
    # Eingabe in ein leeres Datumsfeld: H verschwindet, getippter Text bleibt (nachgelagerte Prüfung)
    x, y, fd = mitte("PR_txtFreiDatum")
    if e.getByName("PRh_txtFreiDatum").EnableVisible:
        s.k(x - 1500, y, warte=0.5); s.tippen("01.10.2026"); time.sleep(1.5)
        t = s.form().CurrentController.getControl(fd).Text
        pruef("M19 Tippen ins Datumsfeld: Text bleibt, H weg", t.strip() != "" and not e.getByName("PRh_txtFreiDatum").EnableVisible, t)
        s.k(*mitte("PRv_btnVerwerfen")[:2], warte=1.5)
    s.foto("exp/v82b_pr.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
