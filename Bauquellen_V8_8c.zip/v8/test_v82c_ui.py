"""V8.2c · Oberfläche: Entscheidung blockiert nicht (N11/N12), kein „+ Andere“ (N09), Verlängern nur einmal je Tag (N15),
Tooltips (N13/N17)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def oeffnen(nr):
    s.k(*NAV["LI"], warte=2.0); s.k(*LI_CHIP["alle"], warte=1.5)
    r = [x[0] for x in s.sql('SELECT "Nr" FROM "V_Liste" ORDER BY "Prio", "Bezug"')]
    s.k(15000, LISTE_ZEILE1 + 680 * r.index(nr), doppelt=True, warte=3.0)
try:
    E = s.fm("Entscheidung")
    pruef("N09 „+ Andere“ entfernt", not E.hasByName("VE1_btnEntNeu"))
    # Vertrag ohne Entscheidung: nur die Art wählen und sichern
    nr, vid = s.sql('SELECT v."Nr", v."ID" FROM "Vertrag" v WHERE NOT EXISTS (SELECT 1 FROM "Entscheidung" e '
                    'WHERE e."VertragID" = v."ID") ORDER BY v."ID"')[0]
    oeffnen(nr)
    arten = list(E.getByName("VE1_lbEntArt").StringItemList)
    B("TSetListe", "Entscheidung", "VE1_lbEntArt", arten.index("neu verhandeln"))
    s.k(*VE["sichern"], warte=2.0)
    d = s.dialog_weg()
    r = s.sql(f'SELECT "Art", "Datum" FROM "Entscheidung" WHERE "VertragID" = {vid}')
    pruef("N11 nur Art wählen genügt", d is None and r and r[0][0] == "neu verhandeln" and r[0][1] == time.strftime("%Y-%m-%d"), f"{d} {r}")
    # N15: Verlängern zweimal → eine Zeile
    n0 = int(s.sql(f'SELECT COUNT(*) FROM "Entscheidung" WHERE "VertragID" = {vid}')[0][0])
    x, y = mitte("VE1_btnVerl")
    s.k(x, y, warte=2.0); s.dialog_weg(); s.k(x, y, warte=2.0); s.dialog_weg()
    n1 = int(s.sql(f'SELECT COUNT(*) FROM "Entscheidung" WHERE "VertragID" = {vid} AND "Art" = \'verlängern\'')[0][0])
    pruef("N15 zweimal Verlängern = eine Entscheidung", n1 == 1, f"{n0} → verlängern {n1}")
    # N11: neuer Vertrag, in der Entscheidung nur „Verantwortlich“ angefangen → Sichern blockiert nicht
    s.k(*VE["neu"], warte=2.0)
    B("TSetText", "Vertrag", "VE_txtGegenstand", "Test N11")
    B("TSetListe", "Vertrag", "VE1_lbPartner", 1)
    vt = [m for m in (E.getByIndex(i) for i in range(E.Count)) if getattr(m, "DataField", "") == "Verantwortlich"][0]
    B("TSetText", "Entscheidung", vt.Name, "jemand")
    s.k(*VE["sichern"], warte=2.5)
    d = s.dialog_weg()
    v = s.sql('SELECT "ID" FROM "Vertrag" WHERE "Gegenstand" = \'Test N11\'')
    pruef("N11 angefangene Entscheidung blockiert das Sichern nicht", d is None and len(v) == 1, f"{d} {v}")
    if v:
        e = s.sql(f'SELECT COUNT(*) FROM "Entscheidung" WHERE "VertragID" = {v[0][0]}')[0][0]
        pruef("N11 leere Entscheidung verworfen", e == "0", e)
    s.k(*NAV["ST"], warte=2.0)
    d = s.dialog_weg()
    pruef("N11 Seite verlassen ohne Meldung", d is None and s.bereich() == "ST", f"{d} {s.bereich()}")
    # Tooltips
    f = s.fm("Vertrag")
    pruef("N17 Hinweis-Pille erklärt den Ort", "Entscheidung zum Stichtag" in s.fm("Info").getByName("VE_txtAnzeige").HelpText)
    g = s.fm("Dokumente").getByName("VE3_gridDok")
    pruef("N13 Spaltenköpfe der Dokumente mit Beispiel", all("z. B." in g.getByIndex(i).HelpText or "Haken" in g.getByIndex(i).HelpText
                                                          for i in range(g.Count)))
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
