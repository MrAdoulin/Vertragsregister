"""V8.3 · Oberfläche: „Ersetzt Vertrag“ mit Links (E30), zwei Partnerlisten (E29), Reiter Dienstvertrag (LEC),
Kostenkennzahl (E28)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def oeffnen(nr):
    s.k(*NAV["LI"], warte=2.0); s.k(*LI_CHIP["alle"], warte=1.5)
    r = [x[0] for x in s.sql('SELECT "Nr" FROM "V_Liste" ORDER BY "Prio", "Bezug"')]
    s.k(15000, LISTE_ZEILE1 + 680 * r.index(nr), doppelt=True, warte=3.0)
def nr():
    v = s.fm("Vertrag"); return v.getString(v.findColumn("Nr"))
try:
    nav = s.form().DrawPage.Forms.getByName("Nav")
    pruef("E28 Kennzahl heißt Prognose", "Prognose" in nav.getByName("ST_kpiKosten").HelpText)
    s.foto("exp/v83_st.png")
    # E30
    oeffnen("12_132_01_2023")
    v = s.fm("Vertrag")
    pruef("E30 neuer Vertrag: kein Nachfolger-Link", v.getByName("VE1_lblNachfolger").Label == "")
    s.k(*mitte("VE1_btnVorgaenger"), warte=2.5)
    pruef("E30 „›“ öffnet den alten Vertrag", nr() == "unbenannt 4", nr())
    lk = v.getByName("VE1_lblNachfolger")
    pruef("E30 alter Vertrag zeigt Link zum neuen", lk.Label.startswith("12_132_01_2023") and "Kaffeemaschine" in lk.HelpText and v.getByName("VE1_lblNachfolgerL").Label == "Wird ersetzt durch",
          lk.Label)
    s.foto("exp/v83_alt.png")
    s.k(*mitte("VE1_lblNachfolger"), warte=2.5)
    pruef("E30 Link öffnet den neuen Vertrag", nr() == "12_132_01_2023", nr())
    # LEC
    t4 = v.getByName("VEt_tab4")
    pruef("LEC Reiter versteckt bei Wartung", not t4.EnableVisible)
    arten = list(v.getByName("VE1_lbArt").StringItemList)
    x, y = mitte("VE1_lbArt")
    s.k(x - 800, y, warte=0.8); s.tippen("Dienstv"); time.sleep(0.5); s.taste("Return"); time.sleep(2.0)
    pruef("LEC Reiter erscheint bei Dienstvertrag (LEC)", t4.EnableVisible)
    s.k(*mitte("VEt_tab4"), warte=2.0)
    pruef("LEC Reiter öffnet die Dienstvertragsangaben", s.bereich() == "VE4", s.bereich())
    s.foto("exp/v83_ve4.png")
    s.k(*VE["tab1"], warte=2.0)
    s.k(x - 800, y, warte=0.8); s.tippen("Wa"); time.sleep(0.5); s.taste("Return"); time.sleep(2.0)
    pruef("LEC zurück auf Wartung: Reiter weg", not t4.EnableVisible, s.bereich())
    s.k(*VE["sichern"], warte=2.0); s.dialog_weg()
    # E29
    s.k(*NAV["PA"], warte=2.5)
    pa, pi, p = s.fm("PartnerAktiv"), s.fm("PartnerInaktiv"), s.fm("Partner")
    n_a = int(s.sql('SELECT COUNT(*) FROM "V_PartnerStand" WHERE "Stand" = \'aktiv\'')[0][0])
    pruef("E29 obere Liste = Partner mit laufendem Vertrag", pa.RowCount == n_a, f"{pa.RowCount}/{n_a}")
    pruef("E29 untere Liste mit Zusatz", pi.RowCount >= 1 and "(historisch)" in pi.getString(pi.findColumn("Anzeige")) or
          "(inaktiv)" in pi.getString(pi.findColumn("Anzeige")), pi.getString(pi.findColumn("Anzeige")))
    s.foto("exp/v83_pa.png")
    x, y = mitte("PA_gridPartnerInaktiv")
    s.k(x, y - 1500 + 800, warte=1.5)   # erste Zeile der unteren Liste
    pruef("E29 Klick unten zeigt den Partner rechts", p.getString(p.findColumn("Name")) == pi.getString(pi.findColumn("Name")),
          p.getString(p.findColumn("Name")))
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
