"""V8.4 · F10: zweite Registerdatei im selben Ordner bekommt einen eigenen Textordner."""
import os, time, shutil
import faulthandler; faulthandler.dump_traceback_later(300, exit=True)
from v8ui import V8, NAV
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
sich = os.path.abspath("xui_test/Sicherung")
shutil.rmtree(sich, ignore_errors=True)
shutil.copy("v8.odb", "zweite.odb")
for odb in ("v8.odb", "zweite.odb"):
    s = V8(odb, warte=5)
    try:
        time.sleep(3); s.k(*NAV["PK"], warte=2.5); s.k(29450, 9405, warte=5.0)
        d = s.dialog_weg()
        pruef("F10 Jetzt sichern " + odb, d is not None and "Gesichert" in d, str(d)[:80])
    finally:
        s.ende()
os.remove("zweite.odb")
t1 = os.path.join(sich, "Text"); t2 = os.path.join(sich, "Text_zweite")
pruef("F10 Text gehört v8", open(os.path.join(t1, "datei.txt")).read().strip() == "v8")
pruef("F10 Text_zweite hat eigenen Stand", os.path.exists(os.path.join(t2, "stand.txt")) and any(n.startswith("Basis_") for n in os.listdir(t2)), os.listdir(t2) if os.path.exists(t2) else "fehlt")
pruef("F10 Text ohne Stand der zweiten Datei", len([n for n in os.listdir(t1) if n.startswith("Basis_")]) == 1, os.listdir(t1))
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
