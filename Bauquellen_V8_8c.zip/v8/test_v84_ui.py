"""V8.4 · Paket D: Storno-Zeile (E21)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def links(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + 250
        except Exception:
            pass
try:
    time.sleep(3)  # V8.5: Start abwarten (Breite, Knöpfe nachgelagert)
    s.k(*NAV["PR"], warte=2.5)
    p, e = s.fm("Protokoll"), s.fm("Ereignis")
    # eine nicht stornierte Rechnung auswählen
    zid = s.sql('SELECT MIN("ID") FROM "Ereignis" WHERE "Art" = \'Rechnung erhalten\' AND "Storniert" IS NOT TRUE')[0][0]
    s.basic("Standard.App.TPrZeile", int(zid))
    time.sleep(2.5)
    k = e.getByName("PRv_btnKorrigieren")
    pruef("E21 Korrigieren sichtbar bei gesichertem Eintrag", k.EnableVisible and not e.getByName("PRv_btnVerwerfen").EnableVisible)
    n0 = p.RowCount
    # V8.5-Q6: ohne Änderung nur Hinweis
    s.k(*mitte("PRv_btnKorrigieren"), warte=1.5)
    d = s.dialog_weg()
    pruef("Q6 Korrigieren ohne Änderung: Hinweis", d is not None and "Ändere zuerst" in d, str(d)[:80])
    b0 = float(s.sql(f'SELECT "Betrag" FROM "Ereignis" WHERE "ID" = {zid}')[0][0])
    s.basic("Standard.App.TSetWert", "Ereignis", "PR_txtBetrag", b0 + 10)
    time.sleep(1.5)
    pruef("Q6 bei Änderung: Verwerfen und Korrigieren sichtbar", k.EnableVisible and e.getByName("PRv_btnVerwerfen").EnableVisible)
    s.k(*mitte("PRv_btnKorrigieren"), warte=1.5)
    d = s.dialog_weg(("Yes", "Ja"))
    time.sleep(2.5)
    neu = s.sql(f'SELECT "Betrag", "Storniert", "Bemerkung" FROM "Ereignis" WHERE "ID" = {zid}')[0]
    alt = s.sql(f'SELECT "ID", "Betrag", "Storniert", "Bemerkung" FROM "Ereignis" WHERE "Bemerkung" LIKE \'%Stand vor der Korrektur von Eintrag {zid}%\'')
    pruef("Q6 Eintrag hat den neuen Betrag, nicht storniert", d is not None and abs(float(neu[0]) - b0 - 10) < 0.01
          and neu[1] in ("0", "false", "False"), f"{d} {neu}")
    pruef("Q6 alter Stand als stornierte Zeile", len(alt) == 1 and abs(float(alt[0][1]) - b0) < 0.01 and alt[0][2] in ("1", "true", "True"), alt)
    pruef("Q6 Verweis im korrigierten Eintrag", alt and (neu[2] or "").startswith("Korrigiert, alter Stand: Eintrag " + alt[0][0]), neu[2])
    pruef("Q6 Liste zeigt den korrigierten Eintrag", str(p.getLong(p.findColumn("ID"))) == str(zid) and p.RowCount == n0 + 1, f"{p.RowCount}")
    st = s.sql(f'SELECT "Pruefergebnis" FROM "V_Ereignis" WHERE "ID" = {alt[0][0]}')[0][0] if alt else ""
    pruef("E21 Stand ✕ storniert", st.startswith("✕ storniert"), st)
    time.sleep(1.5)
    nst = int(s.sql('SELECT COUNT(*) FROM "Ereignis" WHERE "Storniert" IS TRUE')[0][0])
    s.k(links("PR_chkStorno"), mitte("PR_chkStorno")[1], warte=2.0)
    print("   Schalter", p.getByName("PR_chkStorno").State, "Filter", p.Filter, p.ApplyFilter)
    pruef("E21 Schalter blendet Stornierte aus", p.RowCount == n0 + 1 - nst, f"{p.RowCount} = {n0 + 1} - {nst}")
    s.k(links("PR_chkStorno"), mitte("PR_chkStorno")[1], warte=2.0)
    pruef("E21 Schalter blendet sie wieder ein", p.RowCount == n0 + 1, p.RowCount)
    s.foto("exp/v84_pr.png")
    # P01 Spalte „!“, P02 H in der Beschriftungszeile
    g = p.getByName("PR_gridProtokoll")
    pruef("P01 Spalte ! im Protokoll", g.getByIndex(0).Label == "!")
    # P05 Übersicht
    s.k(*NAV["ST"], warte=2.0)
    sy = [r[0] for r in s.sql('SELECT DISTINCT "Symbol" FROM "V_HeuteListe"')]
    pruef("P05 Stufe !!/!", set(sy) <= {"!! dringend", "! offen"} and sy, sy)
    # E18 Datumsanzeige und Notes
    import os, glob
    s.k(*NAV["EI"], warte=2.0)
    s.basic("Standard.App.TSetListe", "Einstellung", "EI_lbDatumFormat", 2)
    s.k(*mitte("EI_btnSichern"), warte=3.0)
    v = s.fm("Vertrag")
    pruef("E18 Datumsanzeige JJJJ-MM-TT übernommen", v.getByName("VE1_txtGeprueft").DateFormat == 11,
          v.getByName("VE1_txtGeprueft").DateFormat)
    s.sql_upd = None
    s.basic("Standard.App.TSql", 'UPDATE "Einstellung" SET "NotesGanztaegig" = FALSE, "NotesUhrzeit" = 8 WHERE "ID" = 1')
    s.k(*NAV["ST"], warte=2.0)
    s.k(*mitte("ST_btnNotes"), warte=4.0)
    s.dialog_weg()
    f = sorted(glob.glob("xui_test/Export/*.ics"))
    t = open(f[-1], encoding="utf-8").read() if f else ""
    pruef("E18 Notes: Termin zur Uhrzeit, Erinnerung 15 min vorher", "T080000" in t and "TRIGGER:-PT15M" in t, t[:0])
    s.foto("exp/v84_st.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
