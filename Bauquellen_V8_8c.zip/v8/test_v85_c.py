"""V8.5 · Paket C: Gesamtsuche (E23/E24), Auswahllisten mit Knopfleiste (E22)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def basic(n, *a):
    return s.basic("Standard.App." + n, *a)[0]
try:
    time.sleep(3)
    # E23 Gesamtsuche aus der Seitenleiste
    s.k(*mitte("NA_txtGesamt"), warte=0.5)
    s.tippen("Kaffee"); s.taste("Return"); time.sleep(3.0)
    t = s.fm("Treffer")
    r = s.sql('SELECT "Herkunft", COUNT(*) FROM "Treffer" GROUP BY "Herkunft"')
    her = dict(r)
    pruef("E23 Suche zeigt die Ansicht Suche", s.bereich() == "GS", s.bereich())
    pruef("E23 Treffer aus Vertrag, Leistung, Partner, Hilfe", all(h in her for h in ("Vertrag", "Leistung", "Partner", "Hilfe")), her)
    pruef("E23 Liste = Tabelle", t.RowCount == sum(int(v) for v in her.values()), f"{t.RowCount}")
    vo = t.getByName("GS_txtVorschau")
    txt = vo.String
    cur = vo.createTextCursor(); cur.gotoStart(False)
    pos = txt.lower().find("kaffee")
    cur.goRight(pos, False); cur.goRight(6, True)
    fett = cur.CharWeight
    cur.gotoStart(False); cur.goRight(1, True)
    pruef("E24 Vorschau: Zitat mit fettem Trefferwort", txt.startswith("„") and pos > 0 and fett >= 150 and cur.CharWeight < 150,
          f"{txt[:60]} fett={fett}")
    s.foto("exp/v85_gs.png")
    # Doppelklick-Ersatz: Öffnen springt zum ersten Treffer (Vertrag)
    s.k(*mitte("GS_btnOeffnen"), warte=3.0)
    pruef("E23 Öffnen springt zum Vertrag", s.bereich() == "VE1", s.bereich())
    zur = s.fm("Vertrag").getByName("VE_btnZurueck").Label
    pruef("E23 Zurück führt zur Suche", "Suche" in zur, zur)
    s.k(*mitte("VE_btnZurueck"), warte=2.0)
    pruef("E23 Zurück zeigt die Treffer", s.bereich() == "GS" and t.RowCount > 0, s.bereich())
    # Hilfe-Treffer öffnen
    basic("TSql", 'DELETE FROM "Treffer" WHERE "Herkunft" <> \'Hilfe\'')
    basic("TNeuLaden", "Treffer"); time.sleep(1.0)
    s.k(*mitte("GS_btnOeffnen"), warte=2.5)
    pruef("E23 Hilfe-Treffer öffnet die Hilfe", s.bereich() == "HI", s.bereich())
    # E22 Auswahllisten
    s.k(*NAV["EI"], warte=2.0)
    li = s.fm("Listen")
    li.beforeFirst()
    while li.next():
        if li.getString(li.findColumn("Typ")) == "Vertragsart":
            break
    werte = lambda: [x[0] for x in s.sql('SELECT "Wert" FROM "Liste" WHERE "Typ" = \'Vertragsart\' ORDER BY "Sort", "Wert"')]
    w0 = werte()
    gew = li.getString(li.findColumn("Wert"))
    i0 = w0.index(gew)
    s.k(*mitte("EI_btnListeRunter"), warte=2.0)
    w1 = werte()
    pruef("E22 ▼ schiebt den Wert nach unten", w1.index(gew) == min(i0 + 1, len(w0) - 1), f"{gew}: {w0} → {w1}")
    s.k(*mitte("EI_btnListeHoch"), warte=2.0)
    pruef("E22 ▲ schiebt ihn zurück", werte().index(gew) == i0, werte())
    pruef("E22 Spalte Reihe entfällt", li.getByName("EI_gridListen").Count == 2)
    s.k(*mitte("EI_btnListeNeu"), warte=1.5)
    # Text ins Eingabefeld des Dialogs (Bedienungshilfe; Tastatur erreicht den Dialog ohne Fenstermanager nicht)
    tk = s.ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", s.ctx)
    def edit(ac):
        c = ac.getAccessibleContext()
        if hasattr(c, "setText") and c.getAccessibleRole() in (60, 79, 80):  # TEXT, PARAGRAPH-ähnlich
            return c
        for i in range(c.getAccessibleChildCount()):
            r = edit(c.getAccessibleChild(i))
            if r is not None:
                return r
    gesetzt = False
    for i in range(tk.getTopWindowCount()):
        w = tk.getTopWindow(i)
        try:
            if w.isVisible() and w.getAccessibleContext().getAccessibleRole() in (1, 12):
                e = edit(w)
                if e is not None:
                    e.setText("Pacht"); gesetzt = True
        except Exception as ex:
            print("   ", ex)
    print("   gesetzt", gesetzt)
    s.dialog_weg(("OK",)); time.sleep(2.0)
    pruef("E22 + Neu legt den Wert an (am Ende)", werte()[-1:] == ["Pacht"], werte())
    sel = li.getString(li.findColumn("Wert"))
    if sel == "Pacht":
        s.k(*mitte("EI_btnListeWeg"), warte=1.5)
        d = s.dialog_weg(("Yes", "Ja")); time.sleep(2.0)
    else:
        d = None
    pruef("E22 Entfernen mit Rückfrage", sel == "Pacht" and d is not None and "Pacht" not in werte(), f"{sel} {d}")
    s.foto("exp/v85_ei.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
