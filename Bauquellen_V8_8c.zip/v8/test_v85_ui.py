"""V8.5 · Meldungen 15.10. 14:51–15:11 (Q1–Q8)."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def links(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + 250
        except Exception:
            pass
def basic(n, *a):
    return s.basic("Standard.App." + n, *a)[0]
try:
    time.sleep(3)
    # Q8 Übersicht: kein „Neuer Vertrag“, Notes-Knopf rechts
    nav = s.fm("Nav")
    pruef("Q8 kein Neuer Vertrag in der Übersicht", not nav.hasByName("ST_btnNeu"))
    nb = nav.getByName("ST_btnNotes")
    pruef("Q8 Notes-Knopf heißt „Termine (nach Notes) exportieren“", nb.Label == "Termine (nach Notes) exportieren", nb.Label)
    xn, xe = mitte("ST_btnNotes")[0], mitte("ST_btnExport")[0]
    pruef("Q8 Notes-Knopf schließt rechts ab", xn > xe, f"{xn} > {xe}")
    # Q5 Reaktionszeit als Hinweis
    basic("TSql", 'UPDATE "Ereignis" SET "FreigabeDatum" = CURRENT_DATE, "FreigabeBetrag" = 0 WHERE "Art" = \'Rechnung erhalten\' AND "FreigabeDatum" IS NULL AND "LeistungID" IN (SELECT "ID" FROM "V_Leistung" WHERE "SollVerfehlt12" > 0)')
    r = s.sql('SELECT "Ampel", "Anzeige", "AnzeigeTipp" FROM "V_Leistung" WHERE "Hinweis" = \'Soll verfehlt\'')
    pruef("Q5 Reaktionszeit: Hinweis ohne Ampel", r and all(x[0] == "neutral" and x[1].startswith("Hinweis: Reaktionszeit") for x in r), r[:1])
    pruef("Q5 Tooltip erklärt", r and "später reagiert als vereinbart" in r[0][2], r[:1])
    # Q7 Neue Leistung aus der Ansicht Leistungen
    s.k(*NAV["LE"], warte=2.5)
    s.k(*mitte("LE_btnNeu"), warte=1.5)
    d = s.dialog_weg(("Weiter",))
    time.sleep(3.0)
    lei = s.fm("Leistung")
    pruef("Q7 Dialog → Vertrag mit neuer Leistung", d is not None and "Für welchen Vertrag" in d and s.bereich() == "VE2" and lei.IsNew,
          f"{str(d)[:60]} {s.bereich()} {lei.IsNew}")
    s.k(*mitte("VE2_btnLeiLoeschen"), warte=1.5)   # Verwerfen der neuen Zeile
    s.dialog_weg()
    time.sleep(1.5)
    # Q3/Q2 Heute erbracht
    lid, vnow = map(int, s.sql('SELECT FIRST 1 "ID", "VertragID" FROM "V_Leistung" WHERE "Bezeichnung" = \'Entkalkung und Reinigung\'')[0])
    basic("TVertrag", vnow)
    time.sleep(2.0)
    s.k(*VE["tab2"], warte=2.0)
    basic("TLeistung", lid)
    time.sleep(2.0)
    n0 = int(s.sql(f'SELECT COUNT(*) FROM "Ereignis" WHERE "LeistungID" = {lid}')[0][0])
    s.k(*mitte("VE2_btnErbracht"), warte=3.0)
    s.dialog_weg()
    e = s.sql(f'SELECT FIRST 1 "ID", "Beschreibung", "Ergaenzen" FROM "Ereignis" WHERE "LeistungID" = {lid} ORDER BY "ID" DESC')[0]
    bez = s.sql(f'SELECT "Bezeichnung" FROM "Leistung" WHERE "ID" = {lid}')[0][0]
    pruef("Q3 Heute erbracht: Eintrag nennt die Leistung", int(s.sql(f'SELECT COUNT(*) FROM "Ereignis" WHERE "LeistungID" = {lid}')[0][0]) == n0 + 1
          and (e[1] or "").startswith(bez) and e[2] in ("1", "true", "True"), e)
    h = s.sql(f'SELECT "Hinweis", "Marke", "Anzeige" FROM "V_Leistung" WHERE "ID" = {lid}')[0]
    pruef("Q3 Leistung offen: Angaben ergänzen", h[0] == "Angaben ergänzen" and h[1] == "!", h)
    time.sleep(1.5)
    pruef("Q2 Liste zeigt die neue Marke sofort", lei.getString(lei.findColumn("Marke")) == "!" and lei.getLong(lei.findColumn("ID")) == lid,
          lei.getString(lei.findColumn("Marke")))
    s.foto("exp/v85_ve2.png")
    # Offenen Eintrag öffnen → ergänzen → sichern
    s.k(*mitte("VE2_btnOffenes"), warte=3.0)
    ev = s.fm("Ereignis")
    pruef("Q3 Offenen Eintrag öffnen zeigt den Eintrag", s.bereich() == "PR" and str(ev.getLong(ev.findColumn("ID"))) == e[0], s.bereich())
    basic("TSetText", "Ereignis", "PR_txtBeschreibung", (e[1] or "") + " – Kalk entfernt")
    s.k(*mitte("PR_btnSichern"), warte=3.0)
    s.dialog_weg()
    h2 = s.sql(f'SELECT "Hinweis", "Marke" FROM "V_Leistung" WHERE "ID" = {lid}')[0]
    erg = s.sql(f'SELECT "Ergaenzen" FROM "Ereignis" WHERE "ID" = {e[0]}')[0][0]
    pruef("Q3 nach dem Sichern erledigt", erg in ("0", "false", "False") and h2[0] != "Angaben ergänzen", f"{erg} {h2}")
    s.foto("exp/v85_pr.png")
    # Q1 Entscheidung: Sichern/Verwerfen
    vid = int(s.sql('SELECT MIN("VertragID") FROM "Entscheidung"')[0][0])
    s.k(*NAV["LI"], warte=2.0)
    basic("TVertrag", vid)
    time.sleep(2.5)
    en = s.fm("Entscheidung")
    vb = en.getByName("VE1_btnEntVerwerfen")
    pruef("Q1 Knöpfe in der Entscheidungskarte", en.hasByName("VE1_btnEntSichern") and vb.EnableVisible)
    beleg_alt = en.getString(en.findColumn("Beleg"))
    beleg_name = [en.getByIndex(i).Name for i in range(en.Count) if getattr(en.getByIndex(i), "DataField", "") == "Beleg"][0]
    basic("TSetText", "Entscheidung", beleg_name, "Test-Beleg.pdf")
    time.sleep(1.5)
    pruef("Q1 Verwerfen rot bei Änderung", en.IsModified and vb.TextColor == 0xD70015, f"{en.IsModified} {hex(vb.TextColor)}")
    s.k(*mitte("VE1_btnEntVerwerfen"), warte=2.0)
    pruef("Q1 Verwerfen nimmt die Eingabe zurück", not en.IsModified and en.getString(en.findColumn("Beleg")) == beleg_alt,
          en.getString(en.findColumn("Beleg")))
    s.foto("exp/v85_ve1.png")
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
