"""V8.6 · Layout: „H“ verdeckt keinen Beschriftungstext, Knöpfe überlappen nichts (je Ansicht, sichtbare Elemente, Pixel)."""
import time, sys
import faulthandler; faulthandler.dump_traceback_later(500, exit=True)
from v8ui import V8
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda n, *a: s.basic("Standard.App." + n, *a)[0]
def sichtbare():
    doc = s.form(); ctl = doc.CurrentController; dp = doc.DrawPage
    out = []
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            m = sh.Control
        except Exception:
            continue
        if m is None or not m.EnableVisible:
            continue
        try:
            c = ctl.getControl(m)
            if not c.isVisible():
                continue
            r = c.getPosSize()
        except Exception:
            continue
        if r.Width <= 0 or r.Height <= 0:
            continue
        out.append((m, c, r))
    return out
def ueber(a, b, tol=1):
    return a.X + tol < b.X + b.Width and b.X + tol < a.X + a.Width and a.Y + tol < b.Y + b.Height and b.Y + tol < a.Y + a.Height
def art(m):
    n = m.ImplementationName
    if "Button" in n: return "knopf"
    if "FixedText" in n: return "text"
    if "Grid" in n: return "raster"
    return "feld"
try:
    vid = int(s.sql('SELECT MIN("ID") FROM "Vertrag"')[0][0])
    probleme_h, probleme_k, probleme_t = [], [], []
    for code in ["ST", "LI", "LE", "PR", "PA", "VT1", "VT2", "AE", "AB", "PK", "EI", "HI", "GS", "VE1", "VE2", "VE3"]:
        if code == "VE1":
            B("TVertrag", vid)
        else:
            B("TGehe", code)
        time.sleep(2.0)
        el = sichtbare()
        # H-Knöpfe: Name <Bereich>h_<Feld>; Beschriftung = Feldname + "L"
        for m, c, r in el:
            nm = m.Name
            if "h_" in nm and art(m) == "knopf" and m.Tag:
                feld = m.Tag
                lab = [(m2, c2, r2) for m2, c2, r2 in el if m2.Name == feld + "L"]
                for m2, c2, r2 in lab:
                    txt_rechts = r2.X + c2.getPreferredSize().Width
                    if ueber(r, r2) and r.X < txt_rechts + 2:
                        probleme_h.append(f"{code}: {nm} verdeckt Text von {m2.Name} („{m2.Label}“): Beschriftung ab {r2.X} breit {r2.Width}, Text {c2.getPreferredSize().Width}, H ab {r.X} breit {r.Width}")
        # Knöpfe gegen alles andere
        for i, (m, c, r) in enumerate(el):
            if art(m) != "knopf":
                continue
            for j, (m2, c2, r2) in enumerate(el):
                if i == j:
                    continue
                if "h_" in m.Name and m2.Name == (m.Tag or "") + "L":
                    continue  # H in der Beschriftungszeile: oben geprüft (Text)
                if art(m2) == "text":
                    # Text darf hinter dem Knopf liegen, wenn sein Inhalt den Knopf nicht erreicht
                    try:
                        rechts = r2.X + c2.getPreferredSize().Width
                    except Exception:
                        rechts = r2.X + r2.Width
                    if m2.Label and ueber(r, r2) and r.X < rechts and r2.X < r.X + r.Width:
                        probleme_k.append(f"{code}: {m.Name} über Text {m2.Name} („{m2.Label[:30]}“)")
                    continue
                if ueber(r, r2) and (art(m2) != "knopf" or j > i):
                    probleme_k.append(f"{code}: {m.Name} überlappt {m2.Name}")
        # Beschriftungen und Kästchen: Text passt in die Breite (sonst abgeschnitten)
        for m, c, r in el:
            n = m.ImplementationName
            if ("FixedText" in n or "CheckBox" in n) and getattr(m, "Label", "") and not getattr(m, "MultiLine", False):
                try:
                    pw = c.getPreferredSize().Width
                except Exception:
                    continue
                if pw > r.Width + 3:
                    probleme_t.append(f"{code}: {m.Name} „{m.Label[:40]}“ Text {pw} > Breite {r.Width}")
        s.foto(f"exp/lay_{code}.png")
    pruef("H-Knöpfe verdecken keinen Beschriftungstext", not probleme_h, "\n  " + "\n  ".join(probleme_h))
    pruef("Knöpfe überlappen keine anderen Elemente", not probleme_k, "\n  " + "\n  ".join(probleme_k))
    pruef("Beschriftungen nicht abgeschnitten", not probleme_t, "\n  " + "\n  ".join(sorted(set(probleme_t))))
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
