"""V8.6 · N14 Ablage-Vorschlag als Link, N16 Statistik, N20 Ereignisarten."""
import time
import faulthandler; faulthandler.dump_traceback_later(400, exit=True)
from v8ui import V8, NAV
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(name)
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
def mitte(name):
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
    raise KeyError(name)
def basic(n, *a):
    return s.basic("Standard.App." + n, *a)[0]
import os, glob
try:
    # N20
    arten = [x[0] for x in s.sql('SELECT "Wert" FROM "Liste" WHERE "Typ" = \'Ereignis\' ORDER BY "Sort", "Wert"')]
    pruef("N20 Ereignisarten umbenannt", arten == ["Leistungsanfall", "Leistung erbracht", "Rechnung erhalten", "Reklamation"], arten)
    alt = s.sql('SELECT COUNT(*) FROM "Ereignis" WHERE "Art" IN (\'Störung\', \'Rechnung\')')[0][0]
    pruef("N20 keine alten Arten in den Daten", alt in ("0", 0), alt)
    off = s.sql('SELECT COUNT(*) FROM "V_Ereignis" WHERE "Offen" = \'Erledigung offen\'')[0][0]
    pruef("N20 Prüfung Reaktion greift beim Leistungsanfall", int(off) >= 1, off)
    s.k(*NAV["PR"], warte=2.0)
    pruef("N20 Chip heißt „Leistungsanfälle“", s.fm("Protokoll").getByName("PR_chipStoerung").Label == "Leistungsanfälle")
    # N14
    s.k(*NAV["EI"], warte=1.5)
    basic("TSetText", "Einstellung", "EI_txtAblage", os.path.abspath("ablage_test") + "/")
    s.k(*mitte("EI_btnSichern"), warte=1.5)
    s.k(*NAV["AB"], warte=1.5)
    s.k(*mitte("AB_btnPruefen"), warte=3.0)
    s.dialog_weg()
    r = s.sql('SELECT "ID", "Nr", "Wo", "Aktion", "WasTun", "Wert" FROM "AbgleichBefund" ORDER BY "ID"')
    pruef("N14 Spalte Wo gefüllt", r and all(x[2] in ("intern", "extern") for x in r), [x[2:4] for x in r][:6])
    pruef("N14 Was tun mit Intern/Extern", all(x[4].startswith(("Intern: ", "Extern: ")) for x in r))
    ziel = [x for x in r if x[3] == "DOKUMENT"] or [x for x in r if x[3] == "GEPRUEFT"]
    if ziel:
        bid, nr, wo, akt, tun, wert = ziel[0]
        basic("TAbgleichZeile", int(bid)); time.sleep(1.5)
        lk = s.fm("Abgleich").getByName("AB_lnkAktion").Label
        pruef("N14 Link zeigt den Vorschlag", lk.startswith("Jetzt umsetzen"), lk)
        vor = s.sql(f'SELECT COUNT(*) FROM "Dokument" d JOIN "Vertrag" v ON v."ID" = d."VertragID" WHERE v."Nr" = \'{nr}\'')[0][0]
        s.k(*mitte("AB_lnkAktion"), warte=1.5)
        d = s.dialog_weg(("Yes", "Ja")); time.sleep(2.0)
        weg = s.sql(f'SELECT COUNT(*) FROM "AbgleichBefund" WHERE "ID" = {bid}')[0][0]
        if akt == "DOKUMENT":
            nach = s.sql(f'SELECT COUNT(*) FROM "Dokument" d JOIN "Vertrag" v ON v."ID" = d."VertragID" WHERE v."Nr" = \'{nr}\' AND d."Datei" = \'{wert}\'')[0][0]
            pruef("N14 Aktion „Dokument eintragen“ ausgeführt", d is not None and int(nach) == 1 and weg in ("0", 0), f"{d} {nach} {weg}")
        else:
            g = s.sql(f'SELECT "ZuletztGeprueft" FROM "Vertrag" WHERE "Nr" = \'{nr}\'')[0][0]
            pruef("N14 Aktion „Heute geprüft“ ausgeführt", d is not None and g == time.strftime("%Y-%m-%d") and weg in ("0", 0), f"{d} {g}")
    else:
        pruef("N14 interner Vorschlag vorhanden", False, r)
    ext = [x for x in r if x[2] == "extern"]
    if ext:
        basic("TAbgleichZeile", int(ext[0][0])); time.sleep(1.0)
        lk = s.fm("Abgleich").getByName("AB_lnkAktion").Label
        pruef("N14 extern: Link öffnet nur den Ordner", lk.startswith(("Ordner öffnen", "Extern")), lk)
    s.foto("exp/v86_ab.png")
    # N16
    s.k(*NAV["ST"], warte=2.0)
    n0 = len(glob.glob("xui_test/Export/Statistik_*.ods"))
    s.k(*mitte("ST_btnStatistik"), warte=6.0)
    d = s.dialog_weg()
    calc = None
    e = s.desk.Components.createEnumeration()
    while e.hasMoreElements():
        c = e.nextElement()
        if c.supportsService("com.sun.star.sheet.SpreadsheetDocument"):
            calc = c
    pruef("N16 Statistik-Datei im Export", len(glob.glob("xui_test/Export/Statistik_*.ods")) == n0 + 1 and d is None, str(d)[:100])
    if calc:
        a = calc.Sheets.getByName("Auswertung")
        dp = a.DataPilotTables
        pruef("N16 Pivot-Tabelle und Diagramm", dp.hasByName("Kosten") and a.Charts.Count == 1, f"{dp.ElementNames} {a.Charts.Count}")
        z = a.getCellRangeByName("A4:D16").DataArray
        print("   ", z)
        pruef("N16 Pivot nach Vertragsart", any("Wartung" in str(row[0]) for row in z), z[:3])
        dp0 = dp.getByName("Kosten")
        pruef("V8.6b keine Gesamtsumme", not dp0.RowGrand and not dp0.ColumnGrand and not any("Summe" in str(c) or "Ergebnis" in str(c) for row in z for c in row), z)
        sh = a.DrawPage.getByIndex(0)
        breite = sum(a.Columns.getByIndex(i).Width for i in range(3))
        pruef("V8.6b Diagramm rechts neben Pivot", sh.Position.X >= breite, f"x={sh.Position.X} abc={breite}")
        pruef("V8.6b Spalte A feste Breite", abs(a.Columns.getByIndex(0).Width - 6000) <= 5, a.Columns.getByIndex(0).Width)
        calc.close(True)
finally:
    s.ende()
print("ERGEBNIS", len(ok), "OK /", len(fehler), "FEHL")
