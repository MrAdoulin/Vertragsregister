"""V8 · Funktionsdurchlauf mit echten Klicks und Eingaben (Xvfb)."""
import time, os, glob
from v8ui import V8, P, NAV, KPI, LI_CHIP, LISTE_ZEILE1, VE

ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(f"{name} {info}".strip())
    print(("OK   " if bed else "FEHL ") + name, info)

s = V8("v8.odb", warte=5)
base = os.path.abspath("xui_test")
try:
    pruef("A Start Übersicht", s.bereich() == "ST")
    s.k(*KPI["rot"], warte=1)
    # V8.2a: erwartete Zahlen aus der Datenbank (Ampelregeln E13–E16)
    n_rot = int(s.sql('SELECT COUNT(*) FROM "V_Liste" WHERE "Ampel" = \'rot\'')[0][0])
    pruef("B Kachel Rot → Verträge gefiltert", s.bereich() == "LI" and s.fm("Liste").RowCount == n_rot and n_rot > 0,
          f"{s.fm('Liste').RowCount} / {n_rot}")
    s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    pos = s.fm("Vertrag").getByName("VE_lblPosition").Label
    pruef("C Doppelklick → Vertrag", s.bereich() == "VE1" and pos == f"1 von {n_rot}", pos)
    vid = s.fm("Vertrag").getLong(s.fm("Vertrag").findColumn("ID"))
    n_lei = int(s.sql(f'SELECT COUNT(*) FROM "Leistung" WHERE "VertragID" = {vid}')[0][0])
    s.k(*VE["tab2"]); pruef("D Reiter Leistungen", s.bereich() == "VE2" and s.fm("Leistung").RowCount == n_lei,
                            f"{s.fm('Leistung').RowCount} / {n_lei}")
    s.foto("exp/f_VE2.png")
    s.k(*VE["tab3"]); pruef("D Reiter Dokumente", s.bereich() == "VE3"); s.foto("exp/f_VE3.png")
    s.k(*VE["tab1"]); pruef("D Reiter Vertrag", s.bereich() == "VE1"); s.foto("exp/f_VE1.png")
    s.k(*VE["zurueck"]); pruef("E Zurück → Verträge", s.bereich() == "LI")
    s.k(*LI_CHIP["alle"]); pruef("F Filter Alle", s.fm("Liste").RowCount == 6, str(s.fm("Liste").RowCount))
    s.k(15000, LISTE_ZEILE1 + 800, doppelt=True, warte=1.2)
    p1 = s.fm("Vertrag").getByName("VE_lblPosition").Label
    s.k(*VE["pfeil_v"]); p2 = s.fm("Vertrag").getByName("VE_lblPosition").Label
    s.k(*VE["pfeil_z"]); p3 = s.fm("Vertrag").getByName("VE_lblPosition").Label
    pruef("F Pfeile", p1 == "2 von 6" and p2 == "3 von 6" and p3 == "2 von 6", f"{p1}/{p2}/{p3}")
    s.k(*NAV["ST"]); s.k(*KPI["leistung"], warte=1)
    n_lrot = int(s.sql('SELECT COUNT(*) FROM "V_Leistung" WHERE "Ampel" = \'rot\'')[0][0])
    pruef("G Kachel Leistungen → Leistungen rot", s.bereich() == "LE" and s.fm("Leistungen").RowCount == n_lrot and n_lrot > 0,
          f"{s.fm('Leistungen').RowCount} / {n_lrot}")
    s.foto("exp/f_LE.png")
    s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.5)
    lid = s.fm("Leistung").getLong(s.fm("Leistung").findColumn("ID")) if s.fm("Leistung").RowCount else 0
    pruef("G Doppelklick → Vertrag bei Leistung", s.bereich() == "VE2", f"Leistung {lid}")
    n0 = int(s.sql(f'SELECT COUNT(*) FROM "Ereignis" WHERE "LeistungID" = {lid}')[0][0])
    s.k(25550, 12355, warte=1.2)
    n1 = int(s.sql(f'SELECT COUNT(*) FROM "Ereignis" WHERE "LeistungID" = {lid}')[0][0])
    pruef("H Heute erbracht", n1 == n0 + 1, f"{n0}→{n1}")
    s.k(29350, 12355, warte=1.5)
    e = s.fm("Ereignis")
    pruef("I + Eintrag → Protokoll neu", s.bereich() == "PR" and e.IsNew, f"{s.bereich()} neu={e.IsNew}")
    s.tippen("Rec"); time.sleep(0.4)
    s.k(28300, 9450); s.tippen("100"); time.sleep(0.3)
    s.k(24350, 3105, warte=1.5)
    d = s.dialog()
    if d: print("   Dialog:", d); s.dialog_weg()
    r = s.sql(f'SELECT "Art", "Betrag", "Bearbeiter", "Datum" FROM "Ereignis" WHERE "LeistungID" = {lid} ORDER BY "ID" DESC')
    pruef("I Eintrag gespeichert", r and r[0][0] == "Rechnung erhalten" and r[0][1].startswith("100"), str(r[:1]))
    s.foto("exp/f_PR.png")
    # J Pflichtfeld
    s.k(*NAV["LI"], warte=1.5)  # V8.5-Q8: „Neuer Vertrag“ nur noch in „Verträge“ (gleiche Stelle)
    d = s.dialog(warte=0.5)
    if d: print("   Dialog nach Übersicht:", d); s.foto("exp/f_J0.png"); s.dialog_weg()
    s.k(29800, 1000, warte=1.5)
    pruef("J Neuer Vertrag", s.bereich() == "VE1" and s.fm("Vertrag").IsNew)
    s.k(*VE["sichern"], warte=0.5)
    pruef("J leerer neuer Vertrag: keine Meldung, nichts gespeichert", s.dialog(warte=0.5) is None)
    s.k(*VE["gegenstand"]); s.tippen("Ohne Partner"); time.sleep(0.3)
    s.k(*VE["sichern"], warte=0.3)
    s.foto("exp/f_J.png")
    d = s.dialog_weg()
    pruef("J Pflichtfeld-Meldung", d is not None and "Vertragspartner" in d, str(d))
    pruef("J bleibt im Vertrag", s.bereich() == "VE1")
    # K Neuer Partner aus dem Vertrag
    s.k(*VE["gegenstand"]); s.taste("End")
    for _ in range(12): s.taste("BackSpace")
    s.tippen("Testvertrag Drucker"); time.sleep(0.3)
    s.k(*VE["partner_neu"], warte=1.5)
    d = s.dialog()
    pruef("K Partner-Abfrage erscheint", d is not None and "Name des neuen" in d, str(d))
    s.dialog_eingabe("Test Partner GmbH"); time.sleep(1.5)
    pid = s.sql('SELECT "ID" FROM "Partner" WHERE "Name" = \'Test Partner GmbH\'')
    v = s.fm("Vertrag")
    pv = v.getLong(v.findColumn("PartnerID"))
    pruef("K Partner angelegt und im Vertrag gewählt", s.bereich() == "VE1" and pid != [] and str(pv) == pid[0][0], f"{pid} {pv}")
    s.foto("exp/f_K.png")
    s.k(*VE["sichern"], warte=1.5)
    d = s.dialog()
    if d: print("   Dialog:", d); s.dialog_weg()
    r = s.sql('SELECT v."ID", p."Name" FROM "Vertrag" v JOIN "Partner" p ON p."ID" = v."PartnerID" WHERE v."Gegenstand" = \'Testvertrag Drucker\'')
    pruef("K Vertrag gespeichert", r != [] and r[0][1] == "Test Partner GmbH", str(r))
    s.foto("exp/f_VE1_neu.png")
    r = s.sql('SELECT "Tabelle", "Aktion", COUNT(*) FROM "Aenderung" WHERE "Benutzer" = \'unbekannt\' GROUP BY 1, 2')
    pruef("L Änderungsspur", len(r) >= 3, str(r))
    # M Export
    s.k(*NAV["LI"]); s.k(25950, 1000, warte=4)
    ex = glob.glob(os.path.join(base, "Export", "Verträge_*.ods"))
    pruef("M Export Verträge", len(ex) == 1, str(ex))
    for c in list(s.desk.Components):
        pass
    e_ = s.desk.Components.createEnumeration()
    while e_.hasMoreElements():
        c = e_.nextElement()
        if c.supportsService("com.sun.star.sheet.SpreadsheetDocument"):
            c.close(True)
    time.sleep(1)
    # N Notes
    s.k(*NAV["ST"]); s.k(25400, 1000, warte=2)
    d = s.dialog_weg()
    ics = glob.glob(os.path.join(base, "Export", "Vertragsfristen_*.ics"))
    nv = open(ics[0], encoding="utf-8").read().count("BEGIN:VEVENT") if ics else 0
    pruef("N Termine nach Notes", nv >= 10, f"{nv} Termine; {d}")
    # O Sicherung
    s.k(*NAV["EI"]); s.k(8275, 13375, warte=2.5)
    d = s.dialog_weg()
    sich = glob.glob(os.path.join(base, "Sicherung", "*.odb"))
    pruef("O Jetzt sichern", len(sich) >= 2, f"{len(sich)} Kopien; {d}")
    s.foto("exp/f_EI.png")
finally:
    print("\nERGEBNIS:", len(ok), "OK,", len(fehler), "FEHL")
    for f in fehler: print("  FEHL", f)
    s.ende()
