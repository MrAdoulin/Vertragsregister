"""V8 · Funktionsdurchlauf 2: Ablage prüfen, Falscheingaben, Leistung, Entscheidung, Vertretung, Filter, Export je Ansicht,
Beispieldaten entfernen, Beenden."""
import time, os, glob
from v8ui import V8, P, NAV, KPI, LI_CHIP, LISTE_ZEILE1, VE

ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(f"{name} {info}".strip())
    print(("OK   " if bed else "FEHL ") + name, info)

s = V8("v8.odb", warte=5)
base = os.path.abspath("xui_test")
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
def calc_zu():
    e = s.desk.Components.createEnumeration()
    while e.hasMoreElements():
        c = e.nextElement()
        if c.supportsService("com.sun.star.sheet.SpreadsheetDocument"):
            c.close(True)
try:
    # P Ablage prüfen
    time.sleep(3)  # V8.5: Breite wird nach dem Start nachgelagert angepasst
    s.k(*NAV["EI"], warte=1.5)
    B("TSetText", "Einstellung", "EI_txtAblage", os.path.abspath("ablage_test") + "/")
    s.k(30300, 1000, warte=1.0)
    pfad = s.sql('SELECT "Ablagepfad" FROM "Einstellung"')[0][0]
    pruef("P Ablagepfad gespeichert", pfad.endswith("ablage_test/"), pfad)
    s.k(*NAV["AB"], warte=1.5); s.k(29900, 1000, warte=2.5)
    d = s.dialog_weg()
    r = s.sql('SELECT "Nr", "Befund" FROM "AbgleichBefund" ORDER BY "Nr", "ID"')
    bef = {b for _, b in r}
    erwartet = {"Dateiname ohne Datum vorne", "Datei fehlt unter Dokumente", "Ordner ohne Vertrag im Register",
                "Datei außerhalb eines Vertragsordners", "Ordner nicht gefunden"}
    pruef("P Abgleich Befunde", erwartet <= bef and B("TZeilen", "Abgleich") == len(r), f"{len(r)} Befunde; fehlend: {erwartet - bef}; Dialog: {d}")
    pruef("P Abgleich Infozeile", "Befunde" in B("TLabel", "Abgleich", "AB_lblPfad"), B("TLabel", "Abgleich", "AB_lblPfad"))
    s.foto("exp/g_AB.png")
    # R Falscheingaben
    s.k(*NAV["EI"])
    f = s.fm("Einstellung")
    # V8.2a: Felder haben Namen (EI_numWarn); Beschriftungen heißen <Name>L
    warn = ["EI_numWarn"]
    B("TSetWert", "Einstellung", warn[0], 0)
    s.k(30300, 1000, warte=0.5)
    d = s.dialog_weg()
    pruef("R Einstellung: Rot ab 0 Tagen abgelehnt", d is not None and "zwischen 1 und 730" in d, str(d))
    B("TSetWert", "Einstellung", warn[0], 90)
    s.k(30300, 1000, warte=0.8)
    pruef("R Einstellung wieder gültig", s.dialog(warte=0.5) is None and s.sql('SELECT "WarnTage" FROM "Einstellung"')[0][0] == "90")
    s.k(*NAV["LI"]); s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1 + 800, doppelt=True, warte=1.2)
    v = s.fm("Vertrag"); vid = v.getLong(v.findColumn("ID"))
    namen = [v.getByIndex(i).Name for i in range(v.getCount())]
    dats = [n for n in namen if n.startswith("VE1_dat")]
    # Reihenfolge der Datumsfelder im Formular Vertrag: NaechsteAnpassung, Beginn, ErstesEnde, ZuletztGeprueft
    feld = {v.getByName(n).DataField: n for n in dats}
    B("TSetDatum", "Vertrag", feld["ErstesEnde"], 2001, 1, 1)
    s.k(*VE["sichern"], warte=0.5)
    d = s.dialog_weg()
    pruef("R Vertrag: Ende vor Beginn abgelehnt", d is not None and "vor dem Beginn" in d, str(d))
    B("TSetDatum", "Vertrag", feld["ErstesEnde"], 2029, 3, 31)
    s.k(*VE["sichern"], warte=0.8)
    pruef("R Vertrag wieder gültig", s.dialog(warte=0.5) is None)
    # Y Heute geprüft, X Entscheidung
    s.k(20715, 16300, warte=1.0)
    g = s.sql(f'SELECT "ZuletztGeprueft" FROM "Vertrag" WHERE "ID" = {vid}')[0][0]
    pruef("Y Heute geprüft", g == time.strftime("%Y-%m-%d"), g)
    n0 = int(s.sql(f'SELECT COUNT(*) FROM "Entscheidung" WHERE "VertragID" = {vid}')[0][0])
    s.k(25076, 5125, warte=1.0)
    n1 = int(s.sql(f'SELECT COUNT(*) FROM "Entscheidung" WHERE "VertragID" = {vid}')[0][0])
    pruef("X Entscheidung Verlängern", n1 == n0 + 1, f"{n0}→{n1}")
    # W Leistung neu und löschen
    s.k(*VE["tab2"])
    l0 = int(s.sql(f'SELECT COUNT(*) FROM "Leistung" WHERE "VertragID" = {vid}')[0][0])
    s.k(14150, 4355, warte=1.0)  # V8.2b-B1: lw 12000
    pruef("W + Neu Leistung", s.fm("Leistung").IsNew)
    B("TSetText", "Leistung", "VE2_txtLeistung", "Testleistung")
    s.k(29950, 4355, warte=0.5)
    d = s.dialog_weg()
    pruef("W Pflichtfeld Abdeckung", d is not None and "Abdeckung" in d, str(d))
    lb = s.fm("Leistung").getByName("VE2_lbAbdeckung")
    s.basic("Standard.App.TSetText", "Leistung", "VE2_txtLeistung", "Testleistung")
    s.basic("Standard.App.TSetListe", "Leistung", "VE2_lbAbdeckung", 1)
    s.k(29950, 4355, warte=1.0)
    l1 = int(s.sql(f'SELECT COUNT(*) FROM "Leistung" WHERE "VertragID" = {vid}')[0][0])
    pruef("W Leistung gespeichert", l1 == l0 + 1, f"{l0}→{l1}")
    s.k(16400, 4355, warte=0.8)  # V8.2b-B1
    d = s.dialog_weg(("Yes", "Ja"))
    l2 = int(s.sql(f'SELECT COUNT(*) FROM "Leistung" WHERE "VertragID" = {vid}')[0][0])
    pruef("W Leistung gelöscht (mit Rückfrage)", d is not None and l2 == l0, f"{d}; {l1}→{l2}")
    # S Vertretung
    s.k(*NAV["VT"]); s.k(29700, 1000, warte=1.2)
    vt = s.fm("Vertretung")
    pruef("S Neue Vertretung vorbelegt", vt.IsNew and vt.getString(vt.findColumn("UebergebenVon")) != "", vt.getString(vt.findColumn("UebergebenVon")))
    s.k(28350, 2925, warte=0.5)
    d = s.dialog_weg()
    pruef("S Pflichtfelder Vertretung", d is not None and "wer vertritt" in d, str(d))
    B("TSetText", "Vertretung", "VT1_txtVertreter", "Bert Test")
    B("TSetDatum", "Vertretung", "VT1_txtAb", 2026, 11, 2)
    s.k(28350, 2925, warte=1.0)
    pruef("S Vertretung gespeichert", s.sql('SELECT COUNT(*) FROM "Vertretung" WHERE "Vertreter" = \'Bert Test\'')[0][0] == "1")
    s.foto("exp/g_VT.png")
    # T Änderungen: Filter
    s.k(*NAV["AE"]); s.k(17600, 2950, warte=0.8)
    n7 = int(s.sql('SELECT COUNT(*) FROM "Aenderung" WHERE "Zeit" >= DATEADD(-7 DAY TO CURRENT_DATE)')[0][0])
    pruef("T Änderungen letzte 7 Tage", B("TZeilen", "Aenderungen") == n7, f"{B('TZeilen', 'Aenderungen')} / {n7}")
    s.foto("exp/g_AE.png")
    # U Suche Leistungen
    s.k(*NAV["LE"]); s.k(9400, 2950); s.tippen("Kaffee"); time.sleep(1.0)
    nk = int(s.sql('SELECT COUNT(*) FROM "V_Leistung" WHERE "Suchtext" LIKE \'%KAFFEE%\'')[0][0])
    pruef("U Suche Leistungen", B("TZeilen", "Leistungen") == nk, f"{B('TZeilen', 'Leistungen')} / {nk}")
    # V Export je Ansicht
    def mitte(name):  # V8.5: Knopf über den Namen suchen (Lage ändert sich mit der Knopfleiste)
        dp = s.form().DrawPage
        for i in range(dp.Count):
            sh = dp.getByIndex(i)
            try:
                if sh.Control.Name == name:
                    return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
            except Exception:
                pass
    for code in ["ST", "LE", "PR", "PA", "VT", "AE", "AB"]:
        vor = len(glob.glob(os.path.join(base, "Export", "*.ods")))
        s.k(*NAV[code], warte=1.5); s.k(*mitte(code + "_btnExport"), warte=3)
        d = s.dialog_weg()
        nach = len(glob.glob(os.path.join(base, "Export", "*.ods")))
        pruef(f"V Export {code}", nach == vor + 1, f"{vor}→{nach} {d or ''}")
        calc_zu(); time.sleep(0.8)
    s.k(*NAV["LI"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    vor = len(glob.glob(os.path.join(base, "Export", "*.ods")))
    s.k(*VE["export"], warte=3); calc_zu(); time.sleep(0.8)
    pruef("V Export Vertrag", len(glob.glob(os.path.join(base, "Export", "*.ods"))) == vor + 1)
    # Q Beispieldaten entfernen
    s.k(*NAV["EI"]); s.k(15300, 15975, warte=0.8)
    d1 = s.dialog_weg(("Yes", "Ja"), warte=2.0)
    d2 = s.dialog_weg()
    r = s.sql('SELECT (SELECT COUNT(*) FROM "Vertrag" WHERE "Beispiel"), (SELECT COUNT(*) FROM "Vertrag"), '
              '(SELECT COUNT(*) FROM "Vertretung" WHERE "Beispiel"), (SELECT COUNT(*) FROM "Aenderung" WHERE "Benutzer" = \'Anna Beispiel\') FROM RDB$DATABASE')[0]
    pruef("Q Beispieldaten entfernt", r[0] == "0" and r[1] == "0" and r[2] == "0" and r[3] == "0", f"{r}; {d1}; {d2}")
    s.k(*NAV["ST"], warte=1.0); s.foto("exp/g_ST_leer.png")
    # AA Beenden
    s.k(*NAV["ENDE"], warte=12)
    # V8.1: Beim Schließen läuft die Sicherung; eine UNO-Abfrage während des Beendens hängt → erst den Prozess prüfen
    if not os.popen("pgrep -f 'soffice\\.bin'").read().strip():
        fe = "Verbindung weg (beendet)"
    else:
        try:
            fe = s.fenster()
        except Exception as e:
            fe = f"Verbindung weg ({type(e).__name__})"
    time.sleep(2)
    pruef("AA Beenden schließt alles", fe == [] or "Verbindung weg" in str(fe), str(fe))
    pruef("AA LibreOffice beendet", s.p.poll() is not None or not os.popen("pgrep -f 'soffice\\.bin'").read().strip(), "")
finally:
    print("\nERGEBNIS:", len(ok), "OK,", len(fehler), "FEHL")
    for f_ in fehler: print("  FEHL", f_)
    s.ende()
