"""V8 · Durchlauf 3: Fehleingaben und Grenzfälle."""
import time, os, glob
from v8ui import V8, P, NAV, KPI, LI_CHIP, LISTE_ZEILE1, VE
ok, fehler = [], []
def pruef(name, bed, info=""):
    (ok if bed else fehler).append(f"{name} {info}".strip())
    print(("OK   " if bed else "FEHL ") + name, info)
s = V8("v8.odb", warte=5)
B = lambda name, *a: s.basic("Standard.App." + name, *a)[0]
def mitte(name):  # V8.5: Knöpfe über den Namen suchen
    dp = s.form().DrawPage
    for i in range(dp.Count):
        sh = dp.getByIndex(i)
        try:
            if sh.Control.Name == name:
                return sh.Position.X + sh.Size.Width // 2, sh.Position.Y + sh.Size.Height // 2
        except Exception:
            pass
try:
    # Partner doppelt
    time.sleep(3)  # V8.5: Start abwarten
    s.k(*NAV["PA"], warte=1.5); s.k(29800, 1000, warte=1.2)
    B("TSetText", "Partner", "PA_txtName", "Tele Beispiel AG")
    s.k(27800, 3105, warte=0.8)
    d1 = s.dialog_weg(); d2 = s.dialog(warte=1.0)
    pruef("Partner doppelt: verständliche Meldung, nur eine", d1 is not None and "gibt es schon" in d1 and d2 is None, f"{d1[:60] if d1 else d1} // {d2[:60] if d2 else d2}")
    if d2: s.dialog_weg()
    s.k(30150, 3105, warte=0.8)   # Löschen bei neuer Zeile = verwerfen
    s.k(*NAV["ST"], warte=1.0); d = s.dialog_weg()
    pruef("Verwerfen des neuen Partners: Wechsel ohne Meldung", d is None and s.bereich() == "ST", str(d))
    s.k(*NAV["PA"], warte=1.0)
    s.k(30150, 3105, warte=0.8)
    d = s.dialog_weg()
    pruef("Partner mit Verträgen löschen: abgelehnt", d is not None and "noch" in d and "Vertr" in d, str(d))
    # Protokoll: Störung Reaktion vor Meldung, Rechnung ohne Betrag
    s.k(*NAV["PR"]); s.k(29800, 1000, warte=1.2)
    e = s.fm("Ereignis")
    B("TSetListe", "Ereignis", "PR_lbLeistung", 0)  # V8.4: Auswahl im Hauptthread (commit aus dem Testthread verklemmte sich)
    art = e.getByName("PR_lbArt"); B("TSetListe", "Ereignis", "PR_lbArt", list(art.StringItemList).index("Leistungsanfall"))  # V8.2c-N20
    B("TSetDatum", "Ereignis", "PR_txtGemAm", 2026, 10, 10)
    B("TSetDatum", "Ereignis", "PR_txtReaAm", 2026, 10, 9)
    s.k(*mitte("PR_btnSichern"), warte=0.5)
    d = s.dialog_weg()
    pruef("Störung: Reaktion vor Meldung abgelehnt", d is not None and "vor der Meldung" in d, str(d))
    B("TSetListe", "Ereignis", "PR_lbArt", list(art.StringItemList).index("Rechnung erhalten"))
    s.k(*mitte("PR_btnSichern"), warte=0.5)
    d = s.dialog_weg()
    pruef("Rechnung ohne Betrag abgelehnt", d is not None and "Rechnungsbetrag" in d, str(d))
    s.k(*mitte("PRv_btnVerwerfen"), warte=0.8)   # neuen Eintrag verwerfen
    # Vertrag löschen
    s.k(*NAV["LI"], warte=1.0); d = s.dialog_weg()
    pruef("Wechsel nach Verwerfen ohne Meldung", d is None, str(d))
    s.k(*LI_CHIP["alle"]); s.k(15000, LISTE_ZEILE1 + 5 * 800, doppelt=True, warte=1.2)
    v = s.fm("Vertrag"); vid = v.getLong(v.findColumn("ID")); geg = v.getString(v.findColumn("Gegenstand"))
    s.k(*VE["loeschen"], warte=0.8)
    d = s.dialog_weg(("Yes", "Ja"), warte=1.5)
    n = s.sql(f'SELECT COUNT(*) FROM "Vertrag" WHERE "ID" = {vid}')[0][0]
    spur = s.sql(f'SELECT COUNT(*) FROM "Aenderung" WHERE "Tabelle" = \'Vertrag\' AND "Aktion" = \'gelöscht\' AND "DatensatzID" = {vid}')[0][0]
    pruef("Vertrag löschen mit Rückfrage", d is not None and n == "0" and s.bereich() == "LI" and spur == "1", f"{geg}: {d}; Spur {spur}")
    # Abgleich mit fehlendem Pfad
    s.k(*NAV["EI"]); B("TSetText", "Einstellung", "EI_txtAblage", "/gibt/es/nicht/")
    s.k(30300, 1000, warte=0.8)
    s.k(*NAV["AB"]); s.k(29900, 1000, warte=1.5)
    d = s.dialog_weg()
    pruef("Abgleich: Pfad fehlt → Meldung", d is not None and "nicht erreichbar" in d, str(d))
    # Doppelklick auf Platzhalterzeile nach Entfernen der Beispiele
    s.k(*NAV["EI"]); s.k(15300, 15975, warte=0.8); s.dialog_weg(("Yes", "Ja"), warte=2.0); s.dialog_weg()
    s.k(*NAV["ST"], warte=1.0)
    s.k(10000, 6850 + 420 + 375, doppelt=True, warte=1.0)
    pruef("Doppelklick auf „Alles im grünen Bereich“: nichts passiert", s.bereich() == "ST" and s.dialog(warte=0.5) is None)
    s.k(25400, 1000, warte=2)
    d = s.dialog_weg()
    pruef("Notes-Export ohne Termine", d is not None and "0 Termine" in d, str(d))
finally:
    print("\nERGEBNIS:", len(ok), "OK,", len(fehler), "FEHL")
    for f_ in fehler: print("  FEHL", f_)
    s.ende()
