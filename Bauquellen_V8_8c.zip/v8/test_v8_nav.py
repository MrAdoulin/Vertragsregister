"""V8 · Rundgang: jeder Bereich über die Seitenleiste, Zeit je Wechsel, Foto je Bereich."""
import time
from v8ui import V8, NAV
s = V8("v8.odb", warte=5)
erg = []
try:
    for code, foto in [("LI", "LI"), ("LE", "LE"), ("PR", "PR"), ("PA", "PA"), ("VT", "VT1"), ("AE", "AE"), ("AB", "AB"),
                       ("EI", "EI"), ("HI", "HI"), ("ST", "ST")]:
        t = s.wechsel(NAV[code], foto)
        time.sleep(0.6)
        s.foto(f"exp/v8_{foto}.png")
        erg.append((foto, t, s.fenster_zahl()))
    print(erg)
finally:
    s.ende()
