import sys, time
from xui import Sitzung
open("/tmp/xui_log.txt", "w").close()
s = Sitzung("v8.odb", warte=6)
try:
    print(s.fenster())
    s.foto("exp/v8_start.png")
finally:
    s.ende()
