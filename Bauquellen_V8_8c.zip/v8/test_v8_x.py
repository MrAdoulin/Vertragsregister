"""V8 · Schließen über das X des Fensters: Formular und .odb schließen, LibreOffice endet."""
import time, os
from v8ui import V8, NAV, VE, LI_CHIP, LISTE_ZEILE1
s = V8("v8.odb", warte=5)
try:
    s.k(*NAV["LI"]); s.k(15000, LISTE_ZEILE1, doppelt=True, warte=1.2)
    print("vor X:", s.fenster())
    s.schliessen_x(None); time.sleep(12)
    # V8.1: Sicherung beim Schließen; UNO-Abfrage nur, wenn LibreOffice noch läuft
    if not os.popen("pgrep -f 'soffice\\.bin'").read().strip():
        print("nach X: Verbindung weg (beendet)")
    else:
        try:
            print("nach X:", s.fenster())
        except Exception as e:
            print("nach X: Verbindung weg", type(e).__name__)
    time.sleep(2)
    print("soffice läuft noch:", bool(os.popen("pgrep -f 'soffice\\.bin'").read().strip()))
finally:
    s.ende()
