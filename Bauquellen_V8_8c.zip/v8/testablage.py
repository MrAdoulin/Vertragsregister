"""Testablage für „Ablage prüfen“: Dummy-Dateien mit absichtlichen Fehlern."""
import os, sys
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
import docx

ZIEL = sys.argv[1]
# V8.1-P2: --nummern legt die Ordner mit den echten Vertragsnummern der Beispieldaten an
NUMMERN = {"V-004_": "unbenannt 4_", "V-001_": "12_132_01_2023_", "V-002_": "14_210_03_2024_", "V-003_": "11_305_02_2022_",
           "V-005_": "13_118_01_2024_", "V-006_": "12_132_04_2022_", "V-099_": "99_999_99_2099_"}
DATEIEN = [
    ("lose_datei.txt", "Datei außerhalb eines Vertragsordners"),
    ("_Vorlagen/Vorlage_Vertragsdeckblatt.docx", "kein Befund: Ordner mit _ wird übergangen"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/2023-01-15_Grundvertrag.pdf", "Datei geändert nach letzter Prüfung"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/2025-03-01_Nachtrag-2.pdf", "Datei geändert nach letzter Prüfung"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/Nachtrag2.pdf", "Dateiname ohne Datum vorne"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/_ersetzt/2024-02-10_Nachtrag-1.pdf", "kein Befund"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/_bearbeitbar/2025-03-01_Nachtrag-2.docx", "kein Befund"),
    ("V-001_Kaffeemaschine_MusterKaffeeservice/_korrespondenz/2026-10-01_Mail-Preiserhoehung.pdf", "Neue Korrespondenz seit letzter Prüfung"),
    ("V-002_Drucker_BeispielBuerotechnik/2024-03-20_Leasingvertrag.pdf", "Datei geändert nach letzter Prüfung"),
    ("V-002_Drucker_BeispielBuerotechnik/2024-03-20_Leasingvertrag_Anlage-Servicepauschale.pdf", "Datei geändert nach letzter Prüfung"),
    ("V-002_Drucker_BeispielBuerotechnik/2026-09-01_Preisblatt.pdf", "Datei fehlt unter Dokumente"),
    ("V-002_Drucker_BeispielBuerotechnik/_bearbeitbar/2026-10-10_Angebot-Entwurf.docx", "kein Befund: Entwurf"),
    ("V-002_Drucker_BeispielBuerotechnik/_bearbeitbar/2026-10-12_Zusatzvereinbarung.docx", "Unterschriebene Fassung fehlt"),
    ("V-003_Reinigung_ReinigungBeispiel/2022-06-01_Rahmenvertrag.pdf", "Datei geändert nach letzter Prüfung"),
    ("V-003_Reinigung_ReinigungBeispiel/Rechnungen/2026-09-30_Rechnung-September.pdf", "Unbekannter Unterordner"),
    ("V-004_Kaffeemaschine_Alt/2019-04-20_Wartungsvertrag.pdf", "Ordnername weicht ab; Datei fehlt unter Dokumente"),
    ("V-005_Wasserspender_QuelleBeispiel/2024-01-10_Mietvertrag.pdf", "kein Befund: sauberer Ordner"),
    ("V-006_Telefonanlage_TeleBeispiel/2021-11-30_Wartungsvertrag.pdf", "kein Befund"),
    ("V-006_Telefonanlage_TeleBeispiel/_korrespondenz/2026-09-20_Kündigung-versandt.pdf", "kein Befund: Beleg mit Umlaut vorhanden"),
    ("V-099_Unbekannt/2026-01-01_Notiz.txt", "Ordner ohne Vertrag im Register"),
]
for rel, zweck in DATEIEN:
    if "--nummern" in sys.argv:
        for a, b in NUMMERN.items():
            if rel.startswith(a):
                rel = b + rel[len(a):]
    p = os.path.join(ZIEL, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    zeilen = ["DUMMY – Testablage Vertragsregister V8", "Datei: " + os.path.basename(rel), "Zweck im Test: " + zweck]
    if p.endswith(".pdf"):
        c = canvas.Canvas(p, pagesize=A4)
        y = 780
        for z in zeilen:
            c.drawString(72, y, z)
            y -= 20
        c.save()
    elif p.endswith(".docx"):
        d = docx.Document()
        for z in zeilen:
            d.add_paragraph(z)
        d.save(p)
    else:
        open(p, "w", encoding="utf-8").write("\r\n".join(zeilen) + "\r\n")
print(len(DATEIEN))
