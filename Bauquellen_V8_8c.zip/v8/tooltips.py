"""V8.2c-N17: Tooltips für alle Elemente ohne eigenen Hilfetext.
Schlüssel: voller Name (Knöpfe, Raster, benannte Felder) oder „Formular|Datenfeld" (unbenannte Felder).
Ein Hilfetext aus forms_def.py hat Vorrang; diese Tabelle füllt nur Lücken."""

TIPPS = {
    # ---------------------------------------------------------------- Seitenleiste
    "NA_txtHeute": "Heutiges Datum. Danach richten sich alle Fristen und Farben.",
    "NA_navST": "Übersicht: was offen ist, nächste Termine und Kennzahlen.",
    "NA_navLI": "Alle Verträge als Liste. Doppelklick öffnet einen Vertrag.",
    "NA_navLE": "Alle vereinbarten Leistungen aller Verträge mit Fälligkeit und Stand.",
    "NA_navPR": "Leistungen, Leistungsanfälle, Reklamationen und Rechnungen aller Verträge erfassen und prüfen.",
    "NA_navPA": "Vertragspartner mit Kontakt, Hotline und ihren Verträgen.",
    "NA_navVT": "Übergabe an eine Vertretung: Checkliste, offene Punkte, Änderungen während der Vertretung.",
    "NA_navAE": "Änderungsspur: wer wann was geändert hat.",
    "NA_navAB": "Vergleicht die Ordner im Ablagepfad mit dem Register. Der Abgleich ändert nichts.",
    "NA_navPK": "Gelöschte Einträge zurückholen (90 Tage) und Stände aus der Sicherung vergleichen.",
    "NA_navHI": "Anleitung zum Vertragsregister.",
    # ---------------------------------------------------------------- Übersicht
    "ST_txtBeispiel": "Solange Beispieldaten drin sind, steht hier ein Hinweis. Entfernen: Einstellungen › Beispieldaten entfernen.",
    "ST_kpiRot": "Dringend: bald fällig oder überfällig. Klick zeigt diese Verträge. Schwellen: Einstellungen.",
    "ST_kpiGelb": "Offen, aber noch nicht dringend. Klick zeigt diese Verträge.",
    "ST_kpiLeistung": "Leistungen und Rechnungen, die zu prüfen sind. Klick zeigt sie.",
    "ST_kpiAktiv": "Zahl der aktiven Verträge. Klick zeigt sie.",
    "ST_kpiKosten": "Prognose der Kosten im laufenden Kalenderjahr: jeder Vertrag anteilig nach seinen Lauftagen im Jahr (Beginn oder Ende im Jahr zählt anteilig). Klick zeigt die aktiven Verträge.",
    "ST_gridHeute": "Alles, was offen ist: !! dringend (bald fällig oder überfällig), ! offen. Klick markiert (Strg+C kopiert), Doppelklick öffnet den Vertrag.",
    "ST_gridFristen": "Termine der nächsten 12 Monate. Klick markiert, Doppelklick öffnet den Vertrag.",
    # ---------------------------------------------------------------- Verträge
    "LI_btnNeu": "Legt einen neuen, leeren Vertrag an.",
    "LI_chipAlle": "Zeigt alle Verträge.",
    "LI_chipRot": "Nur Verträge mit dringendem Handlungsbedarf (rot).",
    "LI_chipGelb": "Nur Verträge mit offenen Punkten (gelb).",
    "LI_chipAktiv": "Nur aktive Verträge.",
    "LI_chipBeendet": "Nur beendete und gekündigte Verträge.",
    "LI_gridListe": "Doppelklick öffnet den Vertrag. Die Suche oben filtert die Liste.",
    # ---------------------------------------------------------------- Vertrag Kopf und Reiter
    "VE_btnZurueck": "Zurück zur Liste, aus der du gekommen bist. Ungesicherte Eingaben werden vorher gesichert.",
    "VE_btnNeu": "Legt einen neuen, leeren Vertrag an. Der aktuelle wird vorher gesichert.",
    "VE_btnExport": "Exportiert diesen Vertrag mit Leistungen und Protokoll als Tabelle.",
    "VE_tab1": "Vertragsdaten, Laufzeit, Kündigung, Entscheidung zum Stichtag.",
    "VE_tab2": "Vereinbarte Leistungen dieses Vertrags und ihr Protokoll (Leistungsanfälle, Rechnungen, erbrachte Leistungen).",
    "VE_tab3": "Dokumentenliste und Änderungsverlauf dieses Vertrags.",
    "VE_txtNr": "Vertragsnummer. Ohne Nummer zeigt das Register „unbenannt <Zahl>“.",
    "VE_txtAnzeige": "Was beim Vertrag als Nächstes zu tun ist. Bearbeiten: im Reiter „Vertrag“ rechts unter "
                     "„Entscheidung zum Stichtag“ (Verlängern oder Kündigen). Rot = dringend, gelb = offen.",
    # ---------------------------------------------------------------- Vertrag Felder
    "Vertrag|Status": "aktiv = läuft; zukünftig = Beginn liegt in der Zukunft (setzt sich selbst, ab Beginn aktiv); gekündigt/abgelaufen/ersetzt = keine Fristen mehr.",
    "Vertrag|Art": "Art des Vertrags, z. B. Wartung, Miete, Dienstleistung. „Dienstvertrag (LEC)“ zeigt den Reiter „Dienstvertrag“.",
    "Vertrag|PartnerVertragsnr": "Nummer, unter der der Partner den Vertrag führt, z. B. WV-2023-0815.",
    "Vertrag|Kosten": "Betrag je Zahlung in Euro. Mit dem Zahlungsintervall ergibt er die Jahreskosten.",
    "Vertrag|Intervall": "Wie oft gezahlt wird. Zusammen mit dem Betrag ergibt das die Jahreskosten.",
    "Vertrag|Kostenstelle": "Kostenstelle für die Verrechnung, z. B. 4100 Küche.",
    "Vertrag|Wertsicherung": "Haken = Preis ist an einen Index gebunden. Dann „Anpassung am“ und „Index und Basis“ ausfüllen.",
    "Vertrag|NaechsteAnpassung": "Wann der Preis das nächste Mal nach dem Index angepasst wird. Das Register erinnert vorher.",
    "Vertrag|Beginn": "Erster Tag des Vertrags.",
    "Vertrag|AutoVerl": "Haken = Vertrag verlängert sich ohne Kündigung. Dann „Verlängerung (Monate)“ ausfüllen.",
    "Vertrag|KTermin": "Zu welchem Termin gekündigt werden kann, z. B. Monatsende oder Quartalsende.",
    "Vertrag|ZuletztGeprueft": "Wann der Vertrag zuletzt durchgesehen wurde. Die nächste Prüfung folgt nach den Monaten aus den Einstellungen.",
    "VE1_btnGeprueft": "Trägt heute als „Zuletzt geprüft“ ein. Danach ist die Prüfung erledigt.",
    "Vertrag|Bemerkung": "Freie Notizen zum Vertrag.",
    "Vertrag|Bereitschaft": "Haken = Bereitschaft vereinbart. Dann die Bereitschaftsstunden je Monat eintragen.",
    "VEt_tab4": "Angaben zum Dienstvertrag. Erscheint nur bei Vertragsart „Dienstvertrag (LEC)“.",
    "Info|JahreskostenText": "Berechnet: Betrag je Zahlung × Zahlungen im Jahr.",
    "Info|Ende": "Berechnet aus Beginn, Erstem Vertragsende und Verlängerung.",
    "Info|Frueh": "Berechnet: frühestes Ende, wenn jetzt gekündigt wird.",
    "Info|NaechstePruefung": "Berechnet: Zuletzt geprüft + Prüfabstand aus den Einstellungen.",
    # ---------------------------------------------------------------- Entscheidung
    "Entscheidung|Art": "verlängern, kündigen oder neu verhandeln. Datum und Name füllen sich beim Sichern selbst.",
    "Entscheidung|Datum": "Wann entschieden wurde. Leer = heute.",
    "Entscheidung|Verantwortlich": "Wer entschieden hat. Leer = dein Name.",
    "Entscheidung|Versandart": "Wie die Kündigung verschickt wurde, z. B. Einschreiben, E-Mail.",
    "Entscheidung|Versandt": "Wann die Kündigung verschickt wurde. Danach wartet das Register auf die Bestätigung.",
    "Entscheidung|Bestaetigt": "Wann der Partner die Kündigung bestätigt hat. Damit ist die Kündigung abgeschlossen.",
    "Entscheidung|Beleg": "Datei im Unterordner _korrespondenz, z. B. 2026-09-20_Kündigung-versandt.pdf",
    # ---------------------------------------------------------------- Leistungen im Vertrag
    "VE2_btnLeiLoeschen": "Löscht die markierte Leistung mit ihrem Protokoll (mit Rückfrage, 90 Tage im Papierkorb).",
    "VE2_btnLeiSichern": "Sichert die Leistung. Grau = nichts geändert.",
    "Leistung|Quelle": "Wo die Leistung vereinbart ist, z. B. Grundvertrag, Pkt. 3.",
    "Leistung|SollStunden": "Vereinbarte Erledigungszeit bei Leistungsanfällen in Stunden. Das Protokoll prüft sie.",
    "Leistung|Bemerkung": "Freie Notizen zur Leistung.",
    "LeistungInfo|ZuletztText": "Letzte erbrachte Leistung laut Protokoll.",
    "LeistungInfo|NaechsteText": "Berechnet: zuletzt erbracht + Intervall.",
    "LeistungInfo|RechnungenJahr": "Summe der Rechnungen dieses Kalenderjahres zu dieser Leistung.",
    "LeistungInfo|NVJahr": "Teil der Rechnungen, der über der Kostengrenze liegt oder nicht verrechenbar ist.",
    "LeistungInfo|Anzeige": "Was bei dieser Leistung zu tun ist.",
    "VE2_gridProt": "Protokoll dieser Leistung. Doppelklick öffnet den Eintrag in „Rechnungsverlauf“.",
    "VE3_gridDok": "Dokumente dieses Vertrags. Neue Zeile: unterste leere Zeile. Die Spaltenköpfe erklären die Felder.",
    "VE2_gridLeistung": "Vereinbarte Leistungen. Klick zeigt Detail, Stand und Protokoll. „!!“ dringend, „!“ offen.",
    "LE_gridLeistungen": "Alle Leistungen aller Verträge. Doppelklick öffnet den Vertrag bei dieser Leistung.",
    "VE3_gridVerlauf": "Alle Änderungen an diesem Vertrag und seinen Leistungen.",
    # ---------------------------------------------------------------- Leistungen (Liste)
    "LE_btnExport": "Exportiert die angezeigten Leistungen als Tabelle.",
    "LE_btnNeu": "Neue Leistung erfassen. Zuerst wählst du den Vertrag, dann öffnet sich der Vertrag mit einer leeren Leistung.",
    "VE1_btnEntSichern": "Speichert alle Änderungen.",
    "VE1_btnEntVerwerfen": "Nimmt ungesicherte Eingaben in dieser Karte zurück (Entscheidung, Versand, Bestätigung, Beleg).",
    "LE_chipAlle": "Zeigt alle Leistungen.",
    "LE_chipRot": "Nur dringende Leistungen (überfällig oder bald fällig, alte offene Rechnung oder Leistungsanfall).",
    "LE_chipGelb": "Nur Leistungen mit offenen Punkten.",
    # ---------------------------------------------------------------- Protokoll
    "PR_btnExport": "Exportiert die angezeigten Einträge als Tabelle.",
    "PR_chipOffen": "Nur Einträge, bei denen noch etwas zu tun ist.",
    "PR_chipRechnung": "Nur Rechnungen.",
    "PR_chipStoerung": "Nur Leistungsanfälle.",
    "PR_chipAlle": "Alle Einträge.",
    "PR_gridProtokoll": "Klick zeigt den Eintrag rechts. Die Suche oben filtert.",
    "PR_btnZumVertrag": "Öffnet den Vertrag dieses Eintrags im Reiter „Leistungen & Protokoll“.",
    "PR_btnSichern": "Sichert den Eintrag. Grau = nichts geändert.",
    "Ereignis|Datum": "Datum des Ereignisses. Bei Rechnungen das Rechnungsdatum.",
    "Ereignis|Art": "Leistungsanfall, Leistung erbracht, Rechnung erhalten oder Reklamation. Davon hängen die Pflichtfelder ab.",
    "Ereignis|Beschreibung": "Kurz, was war, z. B. Papierstau, Gerät meldet Fehler E7.",
    "Ereignis|GemeldetAm": "Wann der Leistungsanfall dem Partner gemeldet wurde. Leer = heute. Daraus rechnet die Erledigungszeit.",
    "Ereignis|ReagiertAm": "Wann der Partner die Leistung erledigt hat. Mit der Uhrzeit prüft das Register die Soll-Erledigungszeit.",
    "Ereignis|ReagiertUm": "Uhrzeit der Erledigung als SS:MM, z. B. 14:30.",
    "Ereignis|Rechnungsnr": "Nummer der Rechnung, z. B. RE-2026-702.",
    "Ereignis|Betrag": "Rechnungsbetrag in Euro. Pflicht bei Rechnungen.",
    "Ereignis|FreigabeDatum": "Wann die Rechnung freigegeben wurde. Mit Datum gilt sie als geprüft.",
    "Ereignis|Storniert": "Gesetzt = der Eintrag zählt nicht mehr (Kostengrenze, offene Aufgaben). Setzen mit dem Knopf „Stornieren“ unten links.",
    "Ereignis|Bemerkung": "Freie Notiz zum Eintrag.",
    "Ereignis|Bearbeiter": "Wer den Eintrag angelegt hat. Füllt sich selbst.",
    "EreignisInfo|MaxFreigabe": "Berechnet: höchstens freizugebender Betrag (Rechnung minus nicht verrechenbar).",
    "EreignisInfo|Pruefergebnis": "Ergebnis der Prüfung: zulässig, zu viel freigegeben, Soll überschritten usw.",
    "EreignisInfo|Offen": "Was bei diesem Eintrag noch zu tun ist.",
    # ---------------------------------------------------------------- Partner
    "PA_btnNeu": "Legt einen neuen Partner an.",
    "PA_btnExport": "Exportiert die Partnerliste als Tabelle.",
    "PA_gridPartner": "Partner mit laufendem (oder zukünftigem) Vertrag. Klick zeigt den Partner rechts.",
    "PA_gridPartnerInaktiv": "Partner ohne laufenden Vertrag: (inaktiv) = nie ein Vertrag, (historisch) = alle Verträge beendet. Klick zeigt ihn rechts.",
    "PA_gridPVertraege": "Verträge dieses Partners. Doppelklick öffnet den Vertrag.",
    "PA_btnLoeschen": "Löscht den Partner (mit Rückfrage). Geht nur, wenn kein Vertrag an ihm hängt.",
    "PA_btnSichern": "Sichert den Partner. Grau = nichts geändert.",
    "Partner|Name": "Firmenname, z. B. Muster Kaffeeservice GmbH. Pflicht und eindeutig.",
    "Partner|Ansprechperson": "Wer beim Partner zuständig ist, z. B. Fr. Muster.",
    "Partner|Telefon": "Telefonnummer, z. B. 01 555 12 34.",
    "Partner|Email": "E-Mail-Adresse, z. B. office@partner.at.",
    "Partner|Hotline": "Nummer für Störungen, falls anders als das Telefon.",
    "Partner|Kundennr": "Unsere Kundennummer beim Partner.",
    "Partner|Bemerkung": "Freie Notizen zum Partner.",
    # ---------------------------------------------------------------- Vertretung
    "VT_btnNeu": "Legt eine neue Vertretung an. „Übergeben von“ ist dein Name.",
    "VT_btnNotes": "Exportiert die Termine als Kalenderdatei für Notes, wie „Termine (nach Notes) exportieren“ in der Übersicht.",
    "VT_btnExport": "Exportiert die Vertretung mit Punkten und Änderungen als Tabelle.",
    "VT_gridVertretung": "Klick zeigt die Vertretung unten.",
    "VT_tab1": "Wer vertritt, Zeitraum, Übergabe-Checkliste.",
    "VT_tab2": "Offene Punkte für die Vertretung und alle Änderungen im Zeitraum.",
    "VT_btnLoeschen": "Löscht die Vertretung (mit Rückfrage).",
    "VT_btnSichern": "Sichert die Vertretung. Grau = nichts geändert.",
    "Vertretung|Vertreter": "Name der Person, die vertritt. Pflicht.",
    "Vertretung|Ab": "Erster Tag der Vertretung. Pflicht.",
    "Vertretung|Bis": "Letzter Tag der Vertretung.",
    "Vertretung|UebergebenVon": "Wer übergibt. Füllt sich mit deinem Namen.",
    "Vertretung|UebergabeAm": "Tag der Übergabe.",
    "Vertretung|RueckgabeAm": "Tag der Rückgabe.",
    "Vertretung|Bemerkung": "Freie Notizen zur Vertretung.",
    "VT2_gridPunkte": "Offene Punkte für die Vertretung. Neue Zeile: unterste leere Zeile.",
    "VT2_gridVtAenderung": "Alle Änderungen im Vertretungszeitraum.",
    # ---------------------------------------------------------------- Änderungen, Ablage, Papierkorb, Einstellungen
    "AE_btnExport": "Exportiert die angezeigten Änderungen als Tabelle.",
    "AE_chipAlle": "Alle Änderungen.",
    "AE_chip7": "Nur Änderungen der letzten 7 Tage.",
    "AE_chip30": "Nur Änderungen der letzten 30 Tage.",
    "AE_gridAenderung": "Wer wann was geändert hat. Die Suche oben filtert.",
    "AB_btnPruefen": "Vergleicht jetzt die Ordner im Ablagepfad (Einstellungen) mit dem Register. Ändert nichts.",
    "AB_btnExport": "Exportiert das Ergebnis des Abgleichs als Tabelle.",
    "AB_gridAbgleich": "Ergebnis des Abgleichs mit vorgeschlagener Aktion.",
    "PK_gridPapierkorb": "Gelöschte Einträge der letzten 90 Tage. Markieren und „Zurückholen“.",
    "PK_gridVergleich": "Unterschiede zur gewählten Sicherung. Haken in „Zurück“ = soll zurückkommen.",
    "PK_btnSichOrdner": "Öffnet den Sicherungsordner im Explorer.",
    "PK_btnAusgewaehlte": "Holt die in „Zurück“ angehakten Einträge aus der Sicherung zurück.",
    "EI_btnSichern": "Sichert die Einstellungen. Grau = nichts geändert.",
    "Einstellung|PruefMonate": "Abstand der regelmäßigen Vertragsprüfung in Monaten (Standard 12).",
    "EI_chkNotesErinn": "Haken = jeder exportierte Termin bringt eine Erinnerung mit.",
    "EI_chkNotesGanz": "Haken = Termine als ganztägige Einträge. Ohne Haken: zur Uhrzeit rechts, 1 Stunde lang.",
    "EI_btnBeispiele": "Löscht alle Beispieldaten. Eigene Einträge bleiben.",
    "GS_gridTreffer": "Treffer der Gesamtsuche: Herkunft, Fundort und Ausschnitt. Klick zeigt die Vorschau, Doppelklick öffnet die Fundstelle.",
    "EI_gridListen": "Werte der Auswahllisten in der Reihenfolge der Auswahl. Zeile markieren, dann „+ Neu“, „Entfernen“, „▲“ oder „▼“.",
    "HI_txtAnleitung": "Anleitung. Mit dem Mausrad blättern.",
}

for _i, _t in enumerate(("Die Vertretung kann das Register öffnen.", "Der Name der Vertretung steht in LibreOffice.",
                         "Die Vertretung erreicht den Ablagepfad.", "Eine Sicherung ist erstellt.",
                         "Die Übersicht ist gemeinsam durchgesehen.", "Die Termine sind im Kalender der Vertretung."), 1):
    TIPPS[f"VT1_chkC{_i}"] = "Haken, wenn erledigt: " + _t


def anwenden(fd):
    """Setzt Tooltips, wo forms_def keinen gesetzt hat. Liefert die Namen, die noch keinen haben."""
    fehlt = []
    for m in fd.alle_modelle():
        try:
            if m.HelpText:
                continue
        except Exception:
            continue
        sch = [m.Name]
        df = getattr(m, "DataField", "") if hasattr(m, "DataField") else ""
        if df:
            sch.append(f"{m.Parent.Name}|{df}")
        t = next((TIPPS[k] for k in sch if k in TIPPS), None)
        if t:
            m.HelpText = t
        elif not m.Name.startswith(("NA_lbl", "lbl")) and m.supportsService("com.sun.star.form.FormControlModel") \
                and not m.supportsService("com.sun.star.form.component.FixedText") and "h_" not in m.Name:
            fehlt.append(m.Name)
    return fehlt
