"""Gemeinsame UNO-Hilfen für den Base-Bau und die Tests."""
import time, subprocess, os, sys, uno

# V8.6c: Bau auch unter Windows (Python von LibreOffice); Linux unverändert
WIN = os.name == "nt"
SOFFICE = os.path.join(os.path.dirname(sys.executable), "soffice.exe") if WIN else "soffice"
from com.sun.star.beans import PropertyValue

def pv(n, v):
    p = PropertyValue(); p.Name = n; p.Value = v; return p

def pva(*pairs):
    return uno.Any("[]com.sun.star.beans.PropertyValue", tuple(pv(n, v) for n, v in pairs))

class Office:
    """Startet ein eigenes soffice (headless) auf einem Port und liefert ctx/smgr/desktop."""
    def __init__(self, port):
        self.port = port
        # Eigenes Profil je Port: sonst übernimmt eine laufende Instanz den Start (Einzelinstanz-Modus)
        prof = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_profile", str(port))
        # Eine abgebrochene Instanz hinterlässt eine Sperrdatei; sie blockiert den nächsten Start ohne Meldung
        if not WIN:
            subprocess.run(["pkill", "-f", f"accept=socket,host=localhost,port={port};"], check=False)
        try:
            os.remove(os.path.join(prof, ".lock"))
        except FileNotFoundError:
            pass
        self.proc = subprocess.Popen([SOFFICE, "-env:UserInstallation=" + uno.systemPathToFileUrl(prof), "--headless", "--invisible",
                                      "--norestore", "--nologo", f"--accept=socket,host=localhost,port={port};urp;"],
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        local = uno.getComponentContext()
        res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
        for _ in range(240):
            try:
                self.ctx = res.resolve(f"uno:socket,host=localhost,port={port};urp;StarOffice.ComponentContext")
                break
            except Exception:
                time.sleep(0.5)
        else:
            raise RuntimeError(f"LibreOffice auf Port {port} nicht erreichbar")
        self.smgr = self.ctx.ServiceManager
        self.desktop = self.smgr.createInstanceWithContext("com.sun.star.frame.Desktop", self.ctx)

    def create(self, name):
        return self.smgr.createInstanceWithContext(name, self.ctx)

    def close(self):
        try:
            self.desktop.terminate()
        except Exception:
            pass
        time.sleep(1)
        if WIN:
            # soffice.exe startet soffice.bin als Kindprozess: nur diesen Prozessbaum beenden
            subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.proc.pid)], check=False,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return
        self.proc.kill()
        # soffice ist ein Startskript; soffice.bin des eigenen Ports gezielt beenden
        subprocess.run(["pkill", "-f", f"accept=socket,host=localhost,port={self.port};"], check=False)
        time.sleep(0.5)

def url(path):
    return uno.systemPathToFileUrl(os.path.abspath(path))
