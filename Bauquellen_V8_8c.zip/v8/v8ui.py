"""V8 · Testhilfen: Seitenkoordinaten → Bildschirm, Zustand des Formulars lesen, Dialoge erkennen."""
import time
from Xlib import X, XK
from xui import Sitzung

def P(x, y):
    """Seitenkoordinate (1/100 mm) → Bildschirmpunkt (Xvfb 1456×819, Fenster ohne Leisten, ganze Seite)."""
    return int(19 + x * 0.0429), int(y * 0.0429)

NAV = {c: (2900, 2300 + i * 950 + 410) for i, c in enumerate(["ST", "LI", "LE", "PR", "PA", "VT", "AE", "AB", "PK", "HI"])}
NAV["EI"] = (4890, 16610)      # V8.2b-M04: Zahnrad
NAV["ENDE"] = (1450, 16610)
MELDEN = (3910, 16610)         # V8.2b-M04: Käfer
KPI = {n: (5900 + i * 5260 + 2380, 3550) for i, n in enumerate(["rot", "gelb", "leistung", "aktiv", "kosten"])}
KOPF = {"rechts1": (29800, 1000), "rechts2_3800": (25950, 1000), "notes": (25400, 1000), "st_export": (21250, 1000)}
LI_CHIP = {"alle": (14750, 2950), "rot": (19000, 2950), "gelb": (23350, 2950), "aktiv": (25500, 2950), "beendet": (27850, 2950)}
LISTE_ZEILE1 = 4920
VE = {"zurueck": (7700, 825), "pfeil_z": (13350, 825), "pfeil_v": (14400, 825), "sichern": (30300, 840),
      "neu": (26900, 840), "loeschen": (23700, 840), "export": (20550, 840), "tab1": (7400, 3075), "tab2": (11650, 3075),
      "tab3": (16800, 3075), "gegenstand": (13650, 1900), "partner_neu": (12616, 6800)}


class V8(Sitzung):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        # V8.5: Nach dem Start passt das Register die Breite nachgelagert an; feste Klickpunkte erst danach
        time.sleep(3)

    def form(self):
        e = self.desk.Components.createEnumeration()
        while e.hasMoreElements():
            c = e.nextElement()
            if getattr(c, "Title", "").endswith("Vertragsregister") and hasattr(c, "DrawPage"):
                return c
        return None

    def fm(self, name):
        def such(cont):
            for i in range(cont.getCount()):
                m = cont.getByIndex(i)
                if m.supportsService("com.sun.star.form.component.Form"):
                    if m.Name == name:
                        return m
                    r = such(m)
                    if r is not None:
                        return r
        return such(self.form().DrawPage.Forms)

    def bereich(self):
        return self.form().DrawPage.Forms.getByName("Nav").getByName("NA_lblApp").Tag

    def k(self, x, y, doppelt=False, warte=0.8):
        self.klick(*P(x, y), doppelt=doppelt)
        time.sleep(warte)

    def wechsel(self, ziel_xy, erwartet, max_s=5.0):
        """Klickt und misst, bis der Bereich wechselt. Liefert Sekunden oder None."""
        t0 = time.time()
        self.klick(*P(*ziel_xy))
        while time.time() - t0 < max_s:
            try:
                if self.bereich() == erwartet:
                    return round(time.time() - t0, 2)
            except Exception:
                pass
            time.sleep(0.02)
        return None

    def fenster_zahl(self):
        root = self.d.screen().root
        return len([w for w in root.query_tree().children if w.get_attributes().map_state == 2])

    def taste_kombi(self, mod, name):
        mc = self.d.keysym_to_keycode(XK.string_to_keysym(mod))
        kc = self.d.keysym_to_keycode(XK.string_to_keysym(name))
        from Xlib.ext import xtest
        self.d.xtest_fake_input(X.KeyPress, mc); self.d.xtest_fake_input(X.KeyPress, kc)
        self.d.xtest_fake_input(X.KeyRelease, kc); self.d.xtest_fake_input(X.KeyRelease, mc); self.d.sync()

    def sql(self, q):
        con = self.form().DrawPage.Forms.getByName("Nav").ActiveConnection
        rs = con.createStatement().executeQuery(q)
        out = []
        n = rs.getMetaData().getColumnCount()
        while rs.next():
            out.append(tuple(rs.getString(i) for i in range(1, n + 1)))
        return out

    def dialog(self, warte=2.0):
        """Texte eines offenen Meldungsfensters (Rolle ALERT oder DIALOG) oder None. Wartet bis zu warte Sekunden."""
        tk = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", self.ctx)
        def texte(ac):
            out = []
            try:
                c = ac.getAccessibleContext()
                n = c.getAccessibleName()
                if n:
                    out.append(n)
                for i in range(c.getAccessibleChildCount()):
                    out += texte(c.getAccessibleChild(i))
            except Exception:
                pass
            return out
        t0 = time.time()
        while True:
            for i in range(tk.getTopWindowCount()):
                w = tk.getTopWindow(i)
                try:
                    if w.isVisible() and w.getAccessibleContext().getAccessibleRole() in (1, 12):
                        return " | ".join(texte(w))
                except Exception:
                    pass
            if time.time() - t0 > warte:
                return None
            time.sleep(0.1)

    def dialog_weg(self, knopf=("OK", "Ok", "Yes", "Ja"), warte=0.8):
        """Schließt das offene Meldungsfenster über die Schaltfläche knopf (Bedienungshilfe-Aktion, ohne Tastatur).
        Ohne Fenstermanager erreicht ein Tastendruck den Dialog nicht."""
        txt = self.dialog()
        if txt is None:
            return None
        if isinstance(knopf, str):
            knopf = (knopf,)
        tk = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", self.ctx)
        def suche(ac):
            c = ac.getAccessibleContext()
            if c.getAccessibleRole() in (42, 44) and c.getAccessibleName().replace("~", "") in knopf:
                return c
            for i in range(c.getAccessibleChildCount()):
                r = suche(c.getAccessibleChild(i))
                if r is not None:
                    return r
        for i in range(tk.getTopWindowCount()):
            w = tk.getTopWindow(i)
            try:
                if w.isVisible() and w.getAccessibleContext().getAccessibleRole() in (1, 12):
                    c = suche(w)
                    if c is not None:
                        c.doAccessibleAction(0)
                        break
            except Exception as e:
                print("   dialog_weg:", e)
        time.sleep(warte)
        return txt

    def dialog_eingabe(self, text, knopf="OK"):
        """Schreibt text in das Eingabefeld des offenen Dialogs (InputBox) und klickt knopf."""
        if self.dialog() is None:
            return False
        tk = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.awt.Toolkit", self.ctx)
        def suche(ac):
            c = ac.getAccessibleContext()
            if hasattr(c, "setText") and c.getAccessibleRole() not in (86,):
                return c
            for i in range(c.getAccessibleChildCount()):
                r = suche(c.getAccessibleChild(i))
                if r is not None:
                    return r
        for i in range(tk.getTopWindowCount()):
            w = tk.getTopWindow(i)
            if w.isVisible() and w.getAccessibleContext().getAccessibleRole() in (1, 12):
                c = suche(w)
                if c is not None:
                    c.setText(text)
                    break
        time.sleep(0.3)
        self.dialog_weg(knopf)
        return True

    def basic_t(self, name, *args, timeout=6):
        """Basic-Aufruf mit Zeitlimit; öffnet sich ein Dialog, wird er gemeldet und geschlossen."""
        import threading
        r = {}
        def lauf():
            try:
                r["x"] = self.basic("Standard.App." + name, *args)[0]
            except Exception as e:
                r["x"] = "EX " + str(e)[:300]
        th = threading.Thread(target=lauf, daemon=True)
        th.start(); th.join(timeout)
        if th.is_alive():
            d = self.dialog(warte=0.5)
            print("   (Basic blockiert; Dialog:", (d or "")[:200].replace("\n", " "), ")")
            if d:
                self.dialog_weg(("OK", "Ok", "Yes", "Ja", "No", "Nein"))
            th.join(timeout)
        return r.get("x", "(keine Antwort)")
