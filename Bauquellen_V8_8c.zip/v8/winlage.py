"""V8.8c · Lage nach Fensterwechseln: verkleinern, maximieren, Formular schließen und neu öffnen."""
import sys, time
import winui

w = winui.Win(sys.argv[1] if len(sys.argv) > 1 else "v8.odb")
B = lambda n, *a: w.basic("Standard.App." + n, *a)[0]
def lage(t):
    d = B("TDiag")
    f = float(d.split("f=")[1].split()[0].replace(",", "."))
    feh = []
    for z in d.splitlines()[1:]:
        p = dict(x.split("=") for x in z.split()[1:4])
        if abs(int(p["X"]) - int(p["gemerkt"]) * f) > 30:
            feh.append(z.split()[0])
    print(t, d.splitlines()[0], "FEHL " + str(feh) if feh else "OK")
try:
    lage("Start")
    win = w.form().CurrentController.Frame.ContainerWindow
    for i, (bw, bh) in enumerate(((1300, 760), (1700, 900), (1000, 900), (1920, 1040))):
        win.setPosSize(0, 0, bw, bh, 15)
        time.sleep(3)
        lage(f"{bw}x{bh}")
    if "--offen" not in sys.argv:
        w.ende()
except Exception:
    w.ende()
    raise
