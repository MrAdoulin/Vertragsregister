"""V8.8c · Windows-Kurzprüfung (UNO): Lage, Gesamtsuche, Ansichten, Anzeige-Einstellungen, Zeitgeber."""
import sys, time, os
import winui

w = winui.Win("v8.odb")
B = lambda n, *a: w.basic("Standard.App." + n, *a)[0]
ok = []
def pruef(name, bed, info=""):
    ok.append(bed)
    print(("OK   " if bed else "FEHL ") + name, info)
try:
    d = B("TDiag")
    print(d.splitlines()[0])
    zeilen = [z for z in d.splitlines()[1:]]
    def stimmt(z):
        t = dict(p.split("=") for p in z.split()[1:4])
        return abs(int(t["X"]) - int(int(t["gemerkt"]) * float(d.split("f=")[1].split()[0].replace(",", ".")))) < 30
    pruef("Lage = gemerkt × Faktor", all(stimmt(z) for z in zeilen))
    doc = w.form()
    for wort, mind in (("kaffe", 3), ("kaffee service", 1), ("KAFE", 3), ("muster kaffeeservice", 1)):
        w.basic("Standard.App.GesamtSuchen", doc, wort)
        time.sleep(1)
        n = B("TZeilen", "Treffer")
        pruef(f"Gesamtsuche „{wort}“", n >= mind, f"{n} Treffer")
    for b in ("PR", "PA", "EI", "VE1", "ST"):
        B("TGehe", b)
        time.sleep(1.5)
        pruef("Ansicht " + b, w.basic("Standard.App.AktuellerBereich", doc)[0] == b)
    m = w.fm("Einstellung").getByName("EI_lbHinweis")
    pruef("Hinweisstufe Vorgabe 1", tuple(m.SelectedItems) == (1,), str(tuple(m.SelectedItems)))
    pruef("Tooltip 1,0 s", abs(w.fm("Einstellung").getByName("EI_numTipp").Value - 1.0) < 0.01)
    pruef("Stornieren-Knopf", w.fm("Ereignis").hasByName("PR_btnStornieren"))
    pruef("Zeitgeber", w.basic("Standard.App.Zeitgeber", 100, "TLog", "zeit")[0] is True)
    print(B("TDiag").splitlines()[0])
    print("ERGEBNIS", sum(ok), "/", len(ok))
    if "--offen" not in sys.argv:
        w.ende()
except Exception:
    w.ende()
    raise
