"""V8.8c · Windows-Prüfhilfe: Register sichtbar in eigenem soffice öffnen (Kopie im Testordner) und Lage messen.
Aufruf (PowerShell, im Ordner v8):  python.exe winui.py v8.odb [Breite Höhe]
Ohne Xlib: nur UNO. Klicks/Fotos macht die Bildschirmsteuerung."""
import os, sys, time, shutil, subprocess, html, uno
from uno_util import pv, url, SOFFICE
from odb_patch import patch_zip
import re
TESTMODUL = re.search(r"TESTMODUL = \"\"\"(.*?)\"\"\"", open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "xui.py"), encoding="utf8").read(), re.S).group(1).replace("/tmp/xui_log.txt", r"C:\Claude Projekts\Vertragsregister-Test\_win\xui_log.txt")

PORT = 2041
TEST = r"C:\Claude Projekts\Vertragsregister-Test\_win"

DIAG = """
Function TDiag() As String
	Dim oDoc As Object, r As Object, t As String, i As Long, oS As Object, nm As String, n As Long, oC As Object
	oDoc = AppDoc()
	r = oDoc.CurrentController.Frame.ComponentWindow.getPosSize()
	t = "Fenster " & r.Width & "x" & r.Height & " f=" & dBreiteF & " h=" & dHoeheF & " n=" & nBreiteN & "/" & oDoc.DrawPage.Count
	t = t & " Vorlage=" & oDoc.Text.getStart().PageDescName & " B=" & oDoc.StyleFamilies.getByName("PageStyles").getByName("Standard").Width
	On Error Resume Next
	For i = 0 To oDoc.DrawPage.Count - 1
		oS = oDoc.DrawPage.getByIndex(i)
		nm = "" : nm = oS.Control.Name
		If nm = "NA_lblApp" Or nm = "ST_btnKpi4" Or nm = "LI_grdListe" Or nm = "NA_lblHinweis" Or Right(nm, 6) = "btnNeu" Then
			oC = oDoc.CurrentController.getControl(oS.Control)
			t = t & Chr(10) & nm & " X=" & oS.Position.X & " W=" & oS.Size.Width & " gemerkt=" & aBreiteX(i) & " view=" & oC.getPosSize().X & "/" & oC.getPosSize().Width
		End If
	Next i
	TDiag = t
End Function
Function TVorlagen() As String
	Dim a, q As Integer, t As String, o As Object
	a = AppDoc().StyleFamilies.getByName("PageStyles").getElementNames()
	For q = 0 To UBound(a)
		o = AppDoc().StyleFamilies.getByName("PageStyles").getByName(a(q))
		t = t & a(q) & "=" & o.Width & " "
	Next q
	TVorlagen = t
End Function
"""

def kopie(odb):
    os.makedirs(TEST, exist_ok=True)
    ziel = os.path.join(TEST, os.path.basename(odb))
    shutil.copy(odb, ziel)
    def f(n, t):
        if n == "Basic/Standard/App.xml":
            return t.replace("</script:module>", html.escape(TESTMODUL + DIAG, quote=False) + "</script:module>")
    patch_zip(ziel, f)
    return ziel

class Win:
    def __init__(self, odb, warte=8):
        odb = kopie(odb)
        prof = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_profile", str(PORT))
        try:
            os.remove(os.path.join(prof, ".lock"))
        except FileNotFoundError:
            pass
        self.p = subprocess.Popen([SOFFICE, "-env:UserInstallation=" + uno.systemPathToFileUrl(prof), "--norestore", "--nologo",
                                   f"--accept=socket,host=localhost,port={PORT};urp;"])
        local = uno.getComponentContext()
        res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
        for _ in range(120):
            try:
                self.ctx = res.resolve(f"uno:socket,host=localhost,port={PORT};urp;StarOffice.ComponentContext")
                break
            except Exception:
                time.sleep(0.5)
        self.desk = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", self.ctx)
        cp = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.configuration.ConfigurationProvider", self.ctx)
        acc = cp.createInstanceWithArguments("com.sun.star.configuration.ConfigurationUpdateAccess",
                                             (pv("nodepath", "/org.openoffice.Office.Common/Security/Scripting"),))
        acc.SecureURL = (uno.systemPathToFileUrl(TEST),)
        acc.commitChanges()
        self.doc = self.desk.loadComponentFromURL(url(odb), "_blank", 0, (pv("MacroExecutionMode", 4),))
        time.sleep(3)
        if not self.form():
            self.basic("Standard.App.AppStartSpaeter")
        time.sleep(warte)

    def basic(self, name, *args):
        sp = self.doc.getScriptProvider()
        return sp.getScript(f"vnd.sun.star.script:{name}?language=Basic&location=document").invoke(args, (), ())

    def form(self):
        e = self.desk.Components.createEnumeration()
        while e.hasMoreElements():
            c = e.nextElement()
            if hasattr(c, "DrawPage") and getattr(c, "Title", "").endswith("Vertragsregister"):
                return c
        return None

    def fm(self, name):
        def such(c):
            for i in range(c.getCount()):
                m = c.getByIndex(i)
                if m.supportsService("com.sun.star.form.component.Form"):
                    if m.Name == name:
                        return m
                    r = such(m)
                    if r is not None:
                        return r
        return such(self.form().DrawPage.Forms)

    def ende(self):
        subprocess.run(["taskkill", "/F", "/T", "/PID", str(self.p.pid)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

if __name__ == "__main__":
    w = Win(sys.argv[1])
    try:
        print(w.basic("Standard.App.TDiag")[0])
        print(w.basic("Standard.App.TVorlagen")[0])
        if len(sys.argv) > 3:
            win = w.form().CurrentController.Frame.ContainerWindow
            win.setPosSize(50, 50, int(sys.argv[2]), int(sys.argv[3]), 15)
            time.sleep(4)
            print(w.basic("Standard.App.TDiag")[0])
        if "--offen" not in sys.argv:
            w.ende()
    except Exception:
        w.ende()
        raise
