"""Sichtbarer Test auf virtuellem Bildschirm (Xvfb): öffnet eine .odb oder ein Formular und macht Bildschirmfotos.
Aufruf: python3 xshot.py <datei.odb> <ausgabe.png> [formularname] [wartezeit]"""
import os, sys, time, subprocess, uno
from uno_util import pv, url
FORM = uno.getConstantByName("com.sun.star.sdb.application.DatabaseObject.FORM")
PORT = 2031
DISP = ":99"

def start_x():
    if subprocess.run(["pgrep", "-f", f"Xvfb {DISP}"], capture_output=True).returncode != 0:
        subprocess.Popen(["Xvfb", DISP, "-screen", "0", "1456x819x24"], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        time.sleep(1.5)

def start_office():
    prof = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_profile", str(PORT))
    subprocess.run(["pkill", "-f", f"port={PORT};"], check=False)
    try: os.remove(os.path.join(prof, ".lock"))
    except FileNotFoundError: pass
    env = dict(os.environ, DISPLAY=DISP, SAL_USE_VCLPLUGIN="gen")
    p = subprocess.Popen(["soffice", f"-env:UserInstallation=file://{prof}", "--norestore", "--nologo", "--nodefault",
                          f"--accept=socket,host=localhost,port={PORT};urp;"], env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    local = uno.getComponentContext()
    res = local.ServiceManager.createInstanceWithContext("com.sun.star.bridge.UnoUrlResolver", local)
    for _ in range(240):
        try:
            ctx = res.resolve(f"uno:socket,host=localhost,port={PORT};urp;StarOffice.ComponentContext"); break
        except Exception:
            time.sleep(0.5)
    desk = ctx.ServiceManager.createInstanceWithContext("com.sun.star.frame.Desktop", ctx)
    if os.environ.get("XUI_GDB"):
        pid = subprocess.run(["pgrep", "-f", f"soffice[.]bin.*port={PORT}"], capture_output=True, text=True).stdout.split()[0]
        subprocess.Popen(["gdb", "-p", pid, "-batch", "-x", os.environ["XUI_GDBCMD"]] if os.environ.get("XUI_GDBCMD") else
                         ["gdb", "-p", pid, "-batch", "-ex", "handle SIGPIPE SIGUSR1 SIGUSR2 nostop noprint", "-ex", "continue",
                          "-ex", "bt 40", "-ex", "thread apply all bt 12"], stdout=open(os.environ["XUI_GDB"], "w"), stderr=subprocess.STDOUT)
        time.sleep(3)
    return p, ctx, desk

def shot(path):
    subprocess.run(["import", "-display", DISP, "-window", "root", path], check=True)

if __name__ == "__main__":
    src, out = os.path.abspath(sys.argv[1]), sys.argv[2]
    form = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] != "-" else None
    warte = float(sys.argv[4]) if len(sys.argv) > 4 else 6
    start_x()
    p, ctx, desk = start_office()
    try:
        doc = desk.loadComponentFromURL(url(src), "_blank", 0, (pv("MacroExecutionMode", 4),))
        if form:
            c = doc.CurrentController; c.connect()
            comp = c.loadComponent(FORM, form, False)
            fr = comp.CurrentController.Frame
            fr.LayoutManager.Visible = False
            fr.ContainerWindow.IsMaximized = True
            comp.CurrentController.ViewSettings.ZoomType = 2
        time.sleep(warte)
        shot(out)
        print("Foto:", out)
    finally:
        try: desk.terminate()
        except Exception: pass
        time.sleep(1); p.kill()
        subprocess.run(["pkill", "-f", f"port={PORT};"], check=False)
