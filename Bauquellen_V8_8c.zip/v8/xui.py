"""Bedienungstest auf virtuellem Bildschirm (Xvfb): echte Klicks über XTest, Makros im Hauptthread.
Wird als Modul benutzt: s = Sitzung(odb); s.klick(x, y); s.foto(name); s.fenster(); s.ende()"""
import os, time, subprocess, uno
from Xlib import X, display, XK
from Xlib.ext import xtest
from xshot import start_x, start_office, shot, PORT, DISP
from uno_util import pv, url

TESTMODUL = """Sub TLog(s As String)
	Dim i As Integer
	i = FreeFile
	Open "/tmp/xui_log.txt" For Append As #i
	Print #i, s
	Close #i
End Sub
Function TCur(sForm As String) As String
	Dim oFC As Object, oC As Object
	On Error Resume Next
	oFC = AppDoc().CurrentController.getFormController(Fm(AppDoc(), sForm))
	oC = oFC.getCurrentControl()
	If IsNull(oC) Then TCur = "(keins)" Else TCur = oC.Model.Name
End Function
Function TFokus() As String
	Dim oW As Object
	On Error Resume Next
	TFokus = "?"
End Function
Function TSpeichern(sForm As String) As String
	Dim oFC As Object, bNeu As Boolean, oF As Object
	On Error GoTo F
	oF = Fm(AppDoc(), sForm)
	TSpeichern = "geladen=" & oF.isLoaded() & " neu=" & oF.IsNew & " mod=" & oF.IsModified
	oFC = AppDoc().CurrentController.getFormController(oF)
	If IsNull(oFC) Then
		TSpeichern = TSpeichern & " (kein Controller)"
		Exit Function
	End If
	TSpeichern = TSpeichern & " commit=" & oFC.FormOperations.commitCurrentRecord(bNeu)
	Exit Function
F:
	TSpeichern = TSpeichern & " FEHLER " & Error$ & " Zeile " & Erl
End Function
Sub TSetText(sForm As String, sName As String, sText As String)
	Dim m As Object
	m = Fm(AppDoc(), sForm).getByName(sName)
	m.Text = sText
	m.commit()
End Sub
Sub TSetWert(sForm As String, sName As String, v)
	Dim m As Object
	m = Fm(AppDoc(), sForm).getByName(sName)
	m.Value = v
	m.commit()
End Sub
Function TBreiteCheck() As String
	Dim oDP As Object, i As Long, oS As Object, t As String, nm As String
	oDP = AppDoc().DrawPage
	t = "f=" & dBreiteF & " n=" & nBreiteN & "/" & oDP.Count & ";"
	For i = 0 To nBreiteN - 1
		oS = oDP.getByIndex(i)
		nm = "?"
		On Error Resume Next
		nm = oS.Control.Name
		On Error GoTo 0
		If Abs(oS.Position.X - CLng(aBreiteX(i) * dBreiteF)) > 5 Then t = t & nm & ":" & oS.Position.X & "<>" & aBreiteX(i) & ";"
		If InStr(nm, "EntDatum") > 0 Then t = t & "[" & i & " " & nm & " " & oS.Position.X & " gemerkt " & aBreiteX(i) & "]"
	Next i
	TBreiteCheck = t
End Function
Sub TLage()
	LageHerstellen(AppDoc())
End Sub
Sub TAbgleichZeile(n As Long)
	Dim oF As Object
	oF = Fm(AppDoc(), "Abgleich")
	oF.beforeFirst()
	Do While oF.next()
		If oF.getLong(oF.findColumn("ID")) = n Then Exit Sub
	Loop
End Sub
Sub TGehe(s As String)
	Bereich(AppDoc(), s)
End Sub
Sub TNeuLaden(sForm As String)
	Fm(AppDoc(), sForm).reload()
End Sub
Sub TLeistung(n As Long)
	LeistungAuswaehlen(AppDoc(), n)
End Sub
Sub TVertrag(n As Long)
	VertragOeffnen(AppDoc(), n, "LI", "", "VE1")
End Sub
Sub TPrZeile(n As Long)
	ProtokollNeuLaden(AppDoc(), n)
End Sub
Function TSichernFarbe()
	SichernFarbe(AppDoc())
	TSichernFarbe = Fm(AppDoc(), "Partner").IsModified & "/" & Fm(AppDoc(), "Partner").IsNew & "/" & Fm(AppDoc(), "Partner").getByName("PA_btnLoeschen").Parent.Name
End Function
Sub TSql(s As String)
	Verbindung().createStatement().executeUpdate(s)
End Sub
Sub TSetListe(sForm As String, sName As String, n As Integer)
	REM V8.2a: Auswahl im Hauptthread setzen (commit aus dem Testthread verklemmte sich mit dem Zeichnen der Liste)
	Dim m As Object
	m = Fm(AppDoc(), sForm).getByName(sName)
	m.SelectedItems = Array(n)
	m.commit()
End Sub
Sub TSetDatum(sForm As String, sName As String, y As Integer, mo As Integer, d As Integer)
	Dim m As Object, u As New com.sun.star.util.Date
	u.Year = y : u.Month = mo : u.Day = d
	m = Fm(AppDoc(), sForm).getByName(sName)
	m.Date = u
	m.commit()
End Sub
Function TZeilen(sForm As String) As Long
	TZeilen = Fm(AppDoc(), sForm).RowCount
End Function
Function TLabel(sForm As String, sName As String) As String
	TLabel = Fm(AppDoc(), sForm).getByName(sName).Label
End Function
Function TVerwerfen(sForm As String) As String
	Dim oF As Object, oFC As Object, r As String
	On Error GoTo F
	oF = Fm(AppDoc(), sForm)
	r = "vorher neu=" & oF.IsNew & " mod=" & oF.IsModified
	oFC = AppDoc().CurrentController.getFormController(oF)
	r = r & " | undo enabled=" & oFC.FormOperations.isEnabled(com.sun.star.form.runtime.FormFeature.UndoRecordChanges)
	oFC.FormOperations.execute(com.sun.star.form.runtime.FormFeature.UndoRecordChanges)
	r = r & " | nach undo neu=" & oF.IsNew & " mod=" & oF.IsModified
	If oF.IsNew Then oF.moveToCurrentRow()
	r = r & " | nach move neu=" & oF.IsNew & " mod=" & oF.IsModified
	TVerwerfen = r
	Exit Function
F:
	TVerwerfen = r & " FEHLER " & Error$
End Function
Function TC()
	TC = AppDoc().Title
End Function
Sub AppStartSpaeter()
	Dim oL As Object
	oL = CreateUnoListener("TS_", "com.sun.star.awt.XCallback")
	createUnoService("com.sun.star.awt.AsyncCallback").addCallback(oL, Empty)
End Sub
Sub TS_notify(aData)
	AppStart()
End Sub
"""

LOGPUNKTE = [("Sub Fenster_windowClosing(oEvent)\n", "TLog(\"windowClosing\")\n"),
             ("\tIf IsNull(oDb) Then Exit Sub\n\toL = CreateUnoListener(\"Ende_\"", None),
             ("Sub Ende_notify(aData)\n", "TLog(\"Ende_notify\")\n")]

def testkopie(odb, ohne_waechter=False):
    """Kopie mit Testmodul (AppStartSpaeter steht im Modul App? nein: eigenes Modul TestUI)."""
    import shutil, zipfile
    from odb_patch import patch_zip
    ziel = os.path.abspath("xui_test/" + os.path.basename(odb))
    os.makedirs(os.path.dirname(ziel), exist_ok=True)
    shutil.copy(odb, ziel)
    def f(n, t):
        if n == "Basic/Standard/App.xml":
            import html
            if ohne_waechter:
                t = t.replace("Sub FensterUeberwachen(oDoc As Object)", "Sub FensterUeberwachen(oDoc As Object)\n\tExit Sub")
            return t.replace("</script:module>", html.escape(TESTMODUL, quote=False) + "</script:module>")
    patch_zip(ziel, f)
    return ziel

class Sitzung:
    def __init__(self, odb, warte=8, makros=True, ohne_waechter=False):
        odb = testkopie(odb, ohne_waechter)
        start_x()
        self.p, self.ctx, self.desk = start_office()
        self.d = display.Display(DISP)
        self._vertrauen(os.path.dirname(os.path.abspath(odb)))
        args = (pv("MacroExecutionMode", 4),) if makros else ()
        self.doc = self.desk.loadComponentFromURL(url(odb), "_blank", 0, args)
        time.sleep(2)
        if makros and not any("Start" in t for t, v in self.fenster()):
            # Das Öffnen-Ereignis der .odb startet hier nicht; AppStart im Hauptthread nachholen (wie unter Windows)
            self.basic("Standard.App.AppStartSpaeter")
        time.sleep(warte)

    def _vertrauen(self, ordner):
        """Testprofil: genau den Ordner der Testdatei als vertrauenswürdig eintragen (wie bei Nico)."""
        cp = self.ctx.ServiceManager.createInstanceWithContext("com.sun.star.configuration.ConfigurationProvider", self.ctx)
        acc = cp.createInstanceWithArguments("com.sun.star.configuration.ConfigurationUpdateAccess",
                                             (pv("nodepath", "/org.openoffice.Office.Common/Security/Scripting"),))
        acc.SecureURL = (uno.systemPathToFileUrl(ordner),)
        acc.commitChanges()

    def basic(self, name, *args):
        sp = self.doc.getScriptProvider()
        return sp.getScript(f"vnd.sun.star.script:{name}?language=Basic&location=document").invoke(args, (), ())

    def klick(self, x, y, doppelt=False):
        self.d.xtest_fake_input(X.MotionNotify, x=x, y=y); self.d.sync(); time.sleep(0.05)
        for _ in range(2 if doppelt else 1):
            self.d.xtest_fake_input(X.ButtonPress, 1); self.d.sync(); time.sleep(0.03)
            self.d.xtest_fake_input(X.ButtonRelease, 1); self.d.sync(); time.sleep(0.06)

    def taste(self, name):
        code = self.d.keysym_to_keycode(XK.string_to_keysym(name))
        self.d.xtest_fake_input(X.KeyPress, code); self.d.sync(); time.sleep(0.03)
        self.d.xtest_fake_input(X.KeyRelease, code); self.d.sync()

    def tippen(self, text):
        for ch in text:
            ks = XK.string_to_keysym(ch) or XK.string_to_keysym({" ": "space", "-": "minus", ".": "period"}.get(ch, ch))
            code = self.d.keysym_to_keycode(ks)
            shift = ch.isupper()
            if shift:
                self.d.xtest_fake_input(X.KeyPress, self.d.keysym_to_keycode(XK.XK_Shift_L))
            self.d.xtest_fake_input(X.KeyPress, code); self.d.xtest_fake_input(X.KeyRelease, code)
            if shift:
                self.d.xtest_fake_input(X.KeyRelease, self.d.keysym_to_keycode(XK.XK_Shift_L))
            self.d.sync(); time.sleep(0.02)

    def schliessen_x(self, titelteil):
        """Wie Klick auf das X: WM_DELETE_WINDOW an das Fenster mit passendem Titel."""
        from Xlib import protocol
        root = self.d.screen().root
        WM_PROTOCOLS = self.d.intern_atom("WM_PROTOCOLS"); WM_DELETE = self.d.intern_atom("WM_DELETE_WINDOW")
        def suche(w):
            n = None
            try:
                n = w.get_wm_name()
                if not n:
                    prop = w.get_full_property(self.d.intern_atom("_NET_WM_NAME"), 0)
                    n = prop.value.decode("utf8", "replace") if prop else None
            except Exception:
                n = None
            if n and titelteil in str(n):
                return w
            for k in w.query_tree().children:
                r = suche(k)
                if r: return r
        w = suche(root) if titelteil else None
        if not w:
            # ohne Fenstermanager haben die Fenster keinen Titel: oberstes sichtbares Fenster nehmen
            sicht = [k for k in root.query_tree().children if k.get_attributes().map_state == 2]
            if not sicht:
                return False
            w = sicht[-1]
        ev = protocol.event.ClientMessage(window=w, client_type=WM_PROTOCOLS, data=(32, [WM_DELETE, X.CurrentTime, 0, 0, 0]))
        w.send_event(ev); self.d.sync()
        return True

    def foto(self, pfad):
        shot(pfad)

    def fenster(self):
        out = []
        e = self.desk.Components.createEnumeration()
        while e.hasMoreElements():
            c = e.nextElement()
            try:
                w = c.CurrentController.Frame.ContainerWindow
                out.append((c.Title, w.isVisible()))
            except Exception as ex:
                out.append((getattr(c, "Title", "?"), "?"))
        return out

    def ende(self):
        # Testprozess hart beenden; das Schließverhalten prüft schliessen() gezielt
        self.p.kill(); subprocess.run(["pkill", "-f", f"port={PORT};"])

if __name__ == "__main__":
    import sys
    s = Sitzung(sys.argv[1])
    try:
        print(s.fenster())
        s.foto("exp/u1.png")
    finally:
        s.ende()
